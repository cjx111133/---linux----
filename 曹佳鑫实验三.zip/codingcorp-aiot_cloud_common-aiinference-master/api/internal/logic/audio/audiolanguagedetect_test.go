package audio

import "testing"

func TestLangCompare(t *testing.T) {
	cases := []struct {
		langA  string
		langB  string
		expect bool
	}{
		{"zh-CN", "zh", true},
		{"en-US", "en-GB", true},
		{"zh-Hant", "zh-TW", true},
		{"ja", "zh", false},
		{"invalid", "en", false},
	}

	for _, c := range cases {
		got := isSameBaseLang(c.langA, c.langB)
		if got != c.expect {
			t.Errorf("%s vs %s: expected %t got %t",
				c.langA, c.langB, c.expect, got)
		}
	}
}
