package audio

import (
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/jinzhu/copier"
)

// AudioTranslatePacketLogic handles packet sending logic for audio translation
type AudioTranslatePacketLogic struct {
	*BaseAITask
}

// NewAudioTranslatePacketLogic creates a new AudioTranslatePacketLogic instance
func NewAudioTranslatePacketLogic(baseTask *BaseAITask) *AudioTranslatePacketLogic {
	return &AudioTranslatePacketLogic{
		BaseAITask: baseTask,
	}
}

// Send sends audio translation packets
func (l *AudioTranslatePacketLogic) Send(req *types.AudioTranslateReq) error {
	switch req.ReqStatus {
	case types.ReqStatusFirst:
		err := l.sendFirst(req)
		if err != nil {
			return fmt.Errorf("send first packet failed: %w", err)
		}
		l.Infof("AudioTranslate First: %+v", *req)

		if req.SourceLanguage == types.AutoDetectLanguage || l.lang != "" {
			req.SourceLanguage = l.lang
		}
		if l.workFlowIndex == 0 {
			l.utilLogic.SendFirstDataToRecv(req.CommonReq)
			l.workFlowIndex++
		}
	case types.ReqStatusMiddle:
		if l.messageId != req.MessageId {
			l.Errorf("AudioTranslate messageId mismatch, expected: %s, got: %s, index: %s", l.messageId, req.MessageId, req.Index)
			return nil
		}

		if req.SourceLanguage == types.AutoDetectLanguage && l.lang != "" {
			req.SourceLanguage = l.lang
		}
		if req.Type == types.ReqTypeAudio && req.SourceLanguage == "" {
			req.SourceLanguage = l.lang
		}

		err := l.sendMiddle(req)
		if err != nil {
			return fmt.Errorf("send middle packet failed: %w", err)
		}
	case types.ReqStatusEnd:
		l.Infof("AudioTranslate End: %+v", *req)
		l.StreamClose()
	}
	return nil
}

// sendFirst sends the first packet
func (l *AudioTranslatePacketLogic) sendFirst(req *types.AudioTranslateReq) error {
	streamReq := l.createFirstStreamTaskReq(req)
	l.Infof("AudioTranslate Send: mesId:%+v  index:%d language: %s streamReq %+v ", req.MessageId, req.Index, req.SourceLanguage, streamReq)

	if l.IsStreamClosed() {
		return nil
	}

	if err := l.GetStream().Send(streamReq); err != nil {
		l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return fmt.Errorf("send first packet failed: %s", err)
	}
	return nil
}

// sendMiddle sends middle packets
func (l *AudioTranslatePacketLogic) sendMiddle(req *types.AudioTranslateReq) error {
	streamReq := l.createMiddleStreamTaskReq(req)
	l.Debugf("AudioTranslate Send: mesId:%+v  index:%d language: %s streamReq %+v ", req.MessageId, req.Index, req.SourceLanguage, streamReq)

	if l.IsStreamClosed() {
		return nil
	}

	if err := l.GetStream().Send(streamReq); err != nil {
		l.Errorf("AudioTranslate Send failed, err: %v", err)
		l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

func (l *AudioTranslatePacketLogic) createFirstStreamTaskReq(req *types.AudioTranslateReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: l.connInfo.SessionId + "-" + req.MessageId,
			UserId: l.connInfo.UserId,
			AppId:  l.connInfo.AppId,
		},
	}

	switch {
	case l.workFlow == aiparameter.TaskType_TASK_TYPE_Language_Detect:
		l.setupLanguageDetectWorkflow(req, streamReq)
	case req.Type == types.ReqTypeAudio, req.Type == types.ReqTypeSimultaneous:
		l.setupAudioWorkflow(req, streamReq)
	case req.Type == types.ReqTypeText:
		l.setupTextWorkflow(req, streamReq)
	}
	return streamReq
}

func getAudioString(audio *aicommon.AudioInfo) string {
	return fmt.Sprintf(
		`{"service_provider": "anker", "target": {"sample_rate": %d, "bit_rate": %d, "channels": %d, "format": "%s", "language": "%s"}}`,
		audio.SampleRate, audio.BitRate, audio.Channels, audio.Format, audio.Language)
}

// 语言检测工作流
func (l *AudioTranslatePacketLogic) setupLanguageDetectWorkflow(req *types.AudioTranslateReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	var audio = new(aicommon.AudioInfo)
	copier.Copy(audio, req)
	if req.Format == types.AudioFormatOpus {
		audio.Format = types.AudioFormatPcm
		l.setupOpusWrapper(req, streamReq)
	} else {
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Language_Detect
		streamReq.Data = &aimanagerrpc.StreamTaskReq_LangDetectReq{
			LangDetectReq: &aiparameter.LanguageDetectInferenceParameter{
				Audio: audio,
			},
		}
	}
	l.addWorkflowNode(streamReq, aiparameter.TaskType_TASK_TYPE_Language_Detect, `{"service_provider": "anker"}`)
}

// 把编码抽出来共用
func (l *AudioTranslatePacketLogic) setupOpusWrapper(req *types.AudioTranslateReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	var targetAudio = &aicommon.AudioInfo{
		Format:      types.AudioFormatPcm,
		SampleRate:  req.SampleRate,
		BitRate:     req.BitRate,
		Channels:    1,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	var sourceAudio = &aicommon.AudioInfo{
		Format:      req.Format,
		SampleRate:  req.SampleRate,
		BitRate:     req.BitRate,
		Channels:    req.Channels,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	if req.SourceLanguage == "auto" {
		targetAudio.Language = l.lang
	}
	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
		IsNeedResult: false,
		Parameters:   getAudioString(targetAudio),
	})
	streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
		OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
			Source:      sourceAudio,
			IsEnableEnc: true,
		},
	}
}

func (l *AudioTranslatePacketLogic) setupAudioWorkflow(req *types.AudioTranslateReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	streamReq.Workflow = make([]*aimanagerrpcclient.Node, 0)

	// 自研模型灰度逻辑暂时不用
	// modelName := l.utilLogic.GetModelName(l.svcCtx.Config.AudioTranslate.AudioGrayScaleConfig)

	if req.SourceLanguage == "" {
		req.SourceLanguage = l.lang
	}
	// 初始化基础音频参数
	baseAudio := &aicommon.AudioInfo{
		Format:      req.Format,
		SampleRate:  req.SampleRate,
		BitRate:     req.BitRate,
		Channels:    req.Channels,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	if req.SourceLanguage == "auto" || req.SourceLanguage == "" {
		baseAudio.Language = l.lang
	}
	// OPUS 处理逻辑
	if req.Format == types.AudioFormatOpus {
		// 解码 OPUS -> PCM
		l.setupOpusWrapper(req, streamReq)
	} else {
		streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
			AsrReq: &aiparameter.SpeechToTextInferenceParameter{
				Audio: baseAudio,
			},
		}
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
	}
	// 添加语音转文本节点
	if req.Type == types.ReqTypeSimultaneous {
		// 实时翻译使用流式翻译：将语音转文本的临时结果也传入下一节点
		l.addWorkflowNode(
			streamReq,
			aiparameter.TaskType_TASK_TYPE_Speech_To_Text,
			l.svcCtx.Config.AudioTranslate.SpeechToTextParam.String(
				req.TargetLanguage,
				l.svcCtx.Config.AudioTranslate.SpeechToTextParam.UseTempResult,
			),
		)
	} else {
		l.addWorkflowNode(
			streamReq,
			aiparameter.TaskType_TASK_TYPE_Speech_To_Text,
			l.svcCtx.Config.AudioTranslate.SpeechToTextParam.String(req.TargetLanguage, false),
		)
	}

	// 添加文本翻译节点
	translateParam := l.getTranslateParam(req)
	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Translate),
		IsNeedResult: true,
		Parameters:   translateParam,
	})

	// TTS 参数处理
	ttsFormat := req.Format
	if req.Format == types.AudioFormatOpus {
		ttsFormat = types.AudioFormatPcm // TTS 生成 PCM 再进行编码
	}

	// 添加文本转语音节点
	ttsData := &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech),
		IsNeedResult: req.Format != types.AudioFormatOpus,
		Parameters:   l.svcCtx.Config.AudioTranslate.TextToSpeechParam.String(ttsFormat, baseAudio.SampleRate, baseAudio.BitRate, 1, req.TargetLanguage),
	}
	streamReq.Workflow = append(streamReq.Workflow, ttsData)

	// 如果需要返回 OPUS 格式，添加编码节点
	if req.Format == types.AudioFormatOpus {
		encodeParams := fmt.Sprintf(`{
	   "service_provider": "anker",
	   "target": {
	       "sample_rate": %d,
	       "bit_rate": %d,
	       "channels": %d,
	       "format": "%s",
	       "frame_size_ms": %d
	   }
	}`, req.SampleRate, req.BitRate, 1, types.AudioFormatOpus, req.FrameSizeMs)

		streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
			TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
			IsNeedResult: true,
			Parameters:   encodeParams,
		})
	}
}

// setupTextWorkflow 设置文本工作流
func (l *AudioTranslatePacketLogic) setupTextWorkflow(req *types.AudioTranslateReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	// 自研模型灰度逻辑暂时不用
	// modelName := l.utilLogic.GetModelName(l.svcCtx.Config.AudioTranslate.AudioGrayScaleConfig)

	translateParam := l.getTranslateParam(req)

	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Translate
	streamReq.Workflow = []*aimanagerrpcclient.Node{
		{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Translate), IsNeedResult: true, Parameters: translateParam},
	} // todo 需要吧各个模块的参数独立出来

	if req.Format != types.AudioFormatOpus {
		streamReq.Workflow = append(
			streamReq.Workflow,
			&aimanagerrpcclient.Node{
				TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech),
				IsNeedResult: true,
				Parameters:   l.svcCtx.Config.AudioTranslate.TextToSpeechParam.String(req.Format, req.SampleRate, req.BitRate, req.Channels, req.TargetLanguage),
			})
		return
	}

	// 初始化基础音频参数
	baseAudio := &aicommon.AudioInfo{
		Format:      req.Format,
		SampleRate:  req.SampleRate,
		BitRate:     req.BitRate,
		Channels:    req.Channels,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	if req.SourceLanguage == "auto" || req.SourceLanguage == "" {
		baseAudio.Language = l.lang
	}

	ttsFormat := req.Format
	if req.Format == types.AudioFormatOpus {
		ttsFormat = types.AudioFormatPcm // TTS 生成 PCM 再进行编码
	}
	// 添加文本转语音节点
	ttsData := &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech),
		IsNeedResult: req.Format != types.AudioFormatOpus,
		Parameters:   l.svcCtx.Config.AudioTranslate.TextToSpeechParam.String(ttsFormat, baseAudio.SampleRate, baseAudio.BitRate, 1, req.TargetLanguage),
	}

	streamReq.Workflow = append(streamReq.Workflow, ttsData)

	// 如果需要返回 OPUS 格式，添加编码节点
	if req.Format == types.AudioFormatOpus {
		encodeParams := fmt.Sprintf(`{
	   "service_provider": "anker",
	   "target": {
	       "sample_rate": %d,
	       "bit_rate": %d,
	       "channels": %d,
	       "format": "%s",
	       "frame_size_ms": %d
	   }
	}`, req.SampleRate, req.BitRate, 1, types.AudioFormatOpus, req.FrameSizeMs)

		streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
			TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
			IsNeedResult: true,
			Parameters:   encodeParams,
		})
	}
}

func (l *AudioTranslatePacketLogic) getTranslateParam(req *types.AudioTranslateReq) string {
	contexts := l.contextManager.GetContext()
	result := l.contextManager.HandleContext(req.Role, req.SourceLanguage)

	var translateParam string
	if req.Type == types.ReqTypeSimultaneous {
		// 实时翻译使用非流式翻译
		translateParam = l.svcCtx.Config.AudioTranslate.TranslateParam.String(
			req.Role,
			req.SourceLanguage,
			req.TargetLanguage,
			false,
		)
	} else {
		translateParam = l.svcCtx.Config.AudioTranslate.TranslateParam.String(
			req.Role,
			req.SourceLanguage,
			req.TargetLanguage,
			l.svcCtx.Config.AudioTranslate.TranslateParam.EnableStream,
		)
	}

	if len(contexts) > 0 && !result {
		translateParam = l.svcCtx.Config.AudioTranslate.TranslateParam.StringWithContext(
			req.Role,
			req.SourceLanguage,
			req.TargetLanguage,
			l.svcCtx.Config.AudioTranslate.TranslateParam.EnableStream,
			contexts)
	}
	return translateParam
}

// addWorkflowNode 添加工作流节点
func (l *AudioTranslatePacketLogic) addWorkflowNode(streamReq *aimanagerrpcclient.StreamTaskReq, taskType aiparameter.TaskType, parameters string) {
	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		TaskType:     int32(taskType),
		IsNeedResult: true,
		Parameters:   parameters,
	})
}

// createMiddleStreamTaskReq 创建中间包请求
func (l *AudioTranslatePacketLogic) createMiddleStreamTaskReq(req *types.AudioTranslateReq) *aimanagerrpcclient.StreamTaskReq {
	audioFirst := l.audios[0]
	reqType := req.Type
	if l.workFlow == aiparameter.TaskType_TASK_TYPE_Language_Detect {
		reqType = types.ReqTypeLangDetect
	}
	// 发送语音识别请求
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: l.connInfo.SessionId + "-" + req.MessageId,
			UserId: l.connInfo.UserId,
			AppId:  l.connInfo.AppId,
		},
	}
	switch reqType {
	case types.ReqTypeLangDetect:
		if l.audios[0].Format == types.AudioFormatOpus {
			isEnableEnc := false
			if audioFirst.Channels > 1 {
				isEnableEnc = true
			}
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
			streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
				OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
					Source: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  audioFirst.SampleRate,
						BitRate:     audioFirst.BitRate,
						Channels:    audioFirst.Channels,
						FrameSizeMs: audioFirst.FrameSizeMs,
					},
					IsEnableEnc: isEnableEnc,
				},
			}
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Language_Detect
			streamReq.Data = &aimanagerrpc.StreamTaskReq_LangDetectReq{
				LangDetectReq: &aiparameter.LanguageDetectInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  audioFirst.SampleRate,
						BitRate:     audioFirst.BitRate,
						Channels:    audioFirst.Channels,
						FrameSizeMs: audioFirst.FrameSizeMs,
					},
				},
			}
		}
	case types.ReqTypeAudio, types.ReqTypeSimultaneous:
		lang := l.audios[0].SourceLanguage
		if lang == "auto" || lang == "" {
			lang = l.lang
		}
		l.Debugf("AudioTranslate Send: mesId:%+v  index:%d language: %s", req.MessageId, req.Index, lang)
		if l.audios[0].Format == types.AudioFormatOpus {
			isEnableEnc := false
			if audioFirst.Channels > 1 {
				isEnableEnc = true
			}
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
			streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
				OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
					Source: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  audioFirst.SampleRate,
						BitRate:     audioFirst.BitRate,
						Channels:    audioFirst.Channels,
						FrameSizeMs: audioFirst.FrameSizeMs,
						Language:    lang,
						Format:      types.AudioFormatOpus,
					},
					IsEnableEnc: isEnableEnc,
				},
			}
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  audioFirst.SampleRate,
						BitRate:     audioFirst.BitRate,
						Channels:    audioFirst.Channels,
						FrameSizeMs: audioFirst.FrameSizeMs,
						Language:    lang,
						Format:      req.Format,
					},
				},
			}
		}
	case types.ReqTypeText:
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Translate
		streamReq.Data = &aimanagerrpc.StreamTaskReq_TranslateReq{
			TranslateReq: &aiparameter.TranslateInferenceParameter{
				Text:       req.Data,
				SentenceId: req.Index,
				IsSentence: true,
			},
		}
	}
	return streamReq
}
