package texttoimagedesign

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type TextToImageDesignExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewTextToImageDesignExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *TextToImageDesignExecutor {
	return &TextToImageDesignExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *TextToImageDesignExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *TextToImageDesignExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *TextToImageDesignExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.AiGenerateImageReq, error) {
	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	var ePara aiparameter.TextToImageDesignExtendedParameter
	err := common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.AiGenerateParameter == nil {
		return nil, fmt.Errorf("ExtendedParameter AiGenerateParameter is nil")
	}

	var controlnets []adaptermodel.Controlnet
	for _, controlnet := range ePara.AiGenerateParameter.Controlnets {
		controlnets = append(controlnets, adaptermodel.Controlnet{
			Module:        controlnet.Module,
			Model:         controlnet.Model,
			Weight:        controlnet.Weight,
			ThresholdA:    controlnet.ThresholdA,
			ThresholdB:    controlnet.ThresholdB,
			GuidanceStart: controlnet.GuidanceStart,
			GuidanceEnd:   controlnet.GuidanceEnd,
		})
	}

	req := &adaptermodel.AiGenerateImageReq{
		TaskId:              in.Header.TaskId,
		TaskType:            in.TaskType,
		ResultImageUpTokens: in.ResultUpTokens,
		ThumbImageUpTokens:  in.ThumbUpTokens,
		GenerateImageParameter: adaptermodel.GenerateImageParameter{
			Prompt:            ePara.AiGenerateParameter.Prompt,
			NegativePrompt:    ePara.AiGenerateParameter.NegativePrompt,
			SamplerName:       ePara.AiGenerateParameter.SamplerName,
			BatchSize:         ePara.AiGenerateParameter.BatchSize,
			BatchCount:        ePara.AiGenerateParameter.BatchCount,
			Steps:             ePara.AiGenerateParameter.Steps,
			CfgScale:          ePara.AiGenerateParameter.CfgScale,
			Width:             ePara.AiGenerateParameter.Width,
			Height:            ePara.AiGenerateParameter.Height,
			DenoisingStrength: ePara.AiGenerateParameter.DenoisingStrength,
			Controlnet:        controlnets,
			SdModel:           ePara.AiGenerateParameter.SdModel,
			LoraModels:        ePara.AiGenerateParameter.LoraModels,
			VaeModel:          ePara.AiGenerateParameter.VaeModel,
			ControlnetModels:  ePara.AiGenerateParameter.ControlnetModels,
		},
	}
	return req, nil
}

func (e *TextToImageDesignExecutor) doInference(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.AiGenerateImageHandler(req)
	if err != nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, code: %d, message: %s", result.Code, result.Message)
	}

	return result, nil
}

func (e *TextToImageDesignExecutor) buildResponse(resp *adaptermodel.AiGenerateImageResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Style_Transfer,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_StyleTransfer{
			StyleTransfer: &aiparameter.StyleTransferInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	for _, imageInfo := range resp.ImageInfos {
		out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
			FileData: string(imageInfo.Data),
			FileMd5:  imageInfo.Md5,
			FileSize: imageInfo.Size,
		})
	}
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
