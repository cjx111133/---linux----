package sagemaker

import (
	"context"
	"fmt"
	"strings"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"github.com/zeromicro/go-zero/core/logx"
)

type SagemakerAdapter struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewSagemakerAdapter(ctx context.Context, svcCtx *svc.ServiceContext) *SagemakerAdapter {
	return &SagemakerAdapter{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// FaceSwapHandler
func (s *SagemakerAdapter) FaceSwapHandler(req *adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error) {
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	// s.Infof("FaceSwapHandler, task id: %s, sageJSONInput: %s", req.TaskId, string(sageJSONInput))

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(config.GetSrvConfig().SageMaker.FaceSwapEndpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: sageOutput is nil")
	}

	var resp adaptermodel.FaceSwapResp
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}
func (s *SagemakerAdapter) AiGenerateImageHandler(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	req.GenerateImageParameter.InferenceType = adaptermodel.SAGEMAKER_INFERENCE_TYPE_Real_time

	switch req.TaskType {
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design,
		aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		req.GenerateImageParameter.TaskType = adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_txt2img
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer1,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer2,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		req.GenerateImageParameter.TaskType = adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_img2img
	default:
		return nil, fmt.Errorf("task type not supported, task type: %v", req.TaskType)
	}

	var err error
	if len(req.ImageToPromptModel) > 0 && len(req.GenerateImageParameter.InitImage) > 0 {
		endpointName, err := s.getEndpointName(req.TaskType)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences, getEndpointName failed, error: %v", err)
		}
		caption, err := s.ImageToPromptInferences(endpointName, req.ImageToPromptModel, req.GenerateImageParameter.InitImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, req.TaskType)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.GenerateImageParameter.Prompt = strings.Replace(req.GenerateImageParameter.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("image to prompt: %s,task: %s", req.GenerateImageParameter.Prompt, req.TaskId)
		}
	}
	generator := NewGenerateImage(s.ctx, s.svcCtx)
	req.GenerateImageParameter.Controlnet, err = generator.BuildControlnetParams(req.GenerateImageParameter.TaskType, req.GenerateImageParameter.Controlnet)
	if err != nil {
		return nil, fmt.Errorf("build controlnet params failed, error:%v", err)
	}

	resp, err := generator.Inferences(req)
	if err != nil {
		return nil, fmt.Errorf("inferences error: %v, task type: %v", err, req.TaskType)
	}
	if resp == nil || len(resp.ImageInfos) == 0 {
		return nil, fmt.Errorf("inferences error: response is incomplete, task type: %v", req.TaskType)
	}
	if len(resp.ImageInfos) > len(req.ResultImageUpTokens) {
		return nil, fmt.Errorf("inferences error: response image count: %d is more than request: %d, task type: %v", len(resp.ImageInfos), len(req.ResultImageUpTokens), req.TaskType)
	}

	// 图片资源处理
	if err = s.handleImage(req, resp); err != nil {
		return nil, err
	}
	return resp, nil
}

// ImageUpscaleHandler 图片超分处理
func (s *SagemakerAdapter) ImageUpscaleHandler(req *adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error) {
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(config.GetSrvConfig().SageMaker.UpscaleEndpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: sageOutput is nil")
	}

	var resp adaptermodel.ImageUpscaleResp
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *SagemakerAdapter) ImageToPromptInferences(endpointName, imageToPromptModel string, initImage []byte) (*adaptermodel.ImageToPromptResponse, error) {
	sageReq := &adaptermodel.ImageToPromptRequest{
		Task:          adaptermodel.INFERENCE_TASK_TYPE_interrogateclip,
		Username:      config.GetSrvConfig().AwsSd.UserName,
		PayloadString: "{}",
		InterrogatePayload: adaptermodel.InterrogatePayload{
			Model: imageToPromptModel,
			Image: common.BytesToBase64(initImage),
		},
	}

	sageJSONInput, err := common.AnyToJson(sageReq)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(endpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}
	var resp adaptermodel.ImageToPromptResponse
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}

	return &resp, nil
}

func (s *SagemakerAdapter) InstantStyleHandler(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error) {
	if len(req.InputImage) > 0 && strings.Contains(req.Prompt, "{PROMPT}") {
		var (
			err      error
			srcImage []byte
		)
		if common.IsUrl(req.InputImage) {
			srcImage, err = common.DownloadFile(s.ctx, req.InputImage)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", req.InputImage, err)
			}
		} else {
			srcImage, err = common.Base64ToBytes(req.InputImage)
			if err != nil {
				return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", req.InputImage[1000])
			}
		}
		caption, err := s.ImageToPromptInferences(config.GetSrvConfig().SageMaker.StyleTransferEndpointName, "clip", srcImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, aiparameter.TaskType_TASK_TYPE_Instant_Style)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.Prompt = strings.Replace(req.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("task_id: %s, image to prompt: %s,", req.TaskId, req.Prompt)
		}
	}
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(config.GetSrvConfig().SageMaker.InstantStyleEndpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.InstantStyleResp
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *SagemakerAdapter) InstantStylePlusHandler(req *adaptermodel.InstantStylePlusReq) (*adaptermodel.InstantStylePlusResp, error) {
	var (
		err      error
		srcImage []byte
	)
	if len(req.ContentImage) > 0 && strings.Contains(req.Prompt, "{PROMPT}") {
		if common.IsUrl(req.ContentImage) {
			srcImage, err = common.DownloadFile(s.ctx, req.ContentImage)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", req.ContentImage, err)
			}
			//req.ContentImage = common.BytesToBase64(srcImage)
		} else {
			srcImage, err = common.Base64ToBytes(req.ContentImage)
			if err != nil {
				return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", req.ContentImage[1000])
			}
		}
		caption, err := s.ImageToPromptInferences(config.GetSrvConfig().SageMaker.StyleTransferEndpointName, "clip", srcImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, aiparameter.TaskType_TASK_TYPE_Instant_Style_Plus)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.Prompt = strings.Replace(req.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("task_id: %s, image to prompt: %s,", req.TaskId, req.Prompt)
		}
	}
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(config.GetSrvConfig().SageMaker.InstantStylePlusEndpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmPlusClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.InstantStylePlusResp
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *SagemakerAdapter) DepthMapGenerationHandler(req *adaptermodel.DepthMapGenerationReq) (*adaptermodel.DepthMapGenerationResp, error) {
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(config.GetSrvConfig().SageMaker.DepthMapGenerationEndpointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.DepthMapGenerationResp
	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal resp: %s, error: %v", string(sageOutput.Body), err)
	}
	return &resp, nil
}

func (s *SagemakerAdapter) RemoveBackgroundHandler(req *adaptermodel.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	sageJSONInput, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	endpointName := config.GetSrvConfig().SageMaker.RemoveBackgroundEndpointName
	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(endpointName),
		ContentType:  aws.String("application/json"),
	}

	sageOutput, err := GetSgmClient().SgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var output adaptermodel.RemoveBackgroundResp
	err = common.JsonToAny(sageOutput.Body, &output)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal resp: %s, error: %v", string(sageOutput.Body), err)
	}
	if output.Code != codes.CodeOk {
		return nil, fmt.Errorf("code: %d, message: %s", output.Code, output.Message)
	}

	return &bgremoverrpc.RemoveBackgroundResp{
		Header: &aicommon.RspHeader{
			Code:    output.Code,
			Message: output.Message,
		},
		ResultImages: []*aicommon.FileInfo{{
			FileData: output.ResultImage,
			FileMd5:  output.ImageMd5,
			FileSize: output.ImageSize,
		}},
		TimeTakenMs: output.TimeTakenMs,
	}, nil
}

func (s *SagemakerAdapter) ComfyUiStyleTransferHandler(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error) {
	// 输入图替换
	req.GenerateImageParameter = strings.Replace(req.GenerateImageParameter, "{DOWNLOAD_URL}", req.InputImage, -1)
	// 生图数量替换
	if strings.Contains(req.GenerateImageParameter, "{IMAGE_NUM}") {
		req.GenerateImageParameter = strings.Replace(req.GenerateImageParameter, "{IMAGE_NUM}", fmt.Sprintf("%d", req.ImageNum), -1)
	}
	// 随机数替换
	if strings.Contains(req.GenerateImageParameter, "{RANDOM_SEED}") {
		randStr, err := common.ReplaceRandSeedPlaceholder(req.GenerateImageParameter, "{RANDOM_SEED}")
		if err != nil {
			return nil, err
		}
		req.GenerateImageParameter = randStr
	}
	// controlNet 图片替换
	if strings.Contains(req.GenerateImageParameter, "{CONTROLNET_URL}") && len(req.ControlNetImage) > 0 {
		req.GenerateImageParameter = strings.Replace(req.GenerateImageParameter, "{CONTROLNET_URL}", req.ControlNetImage[0], -1)
	}
	endpointName, err := s.getEndpointName(req.TaskType)
	if err != nil {
		return nil, err
	}
	s.Infof("generateImageParameter: %s, endpointName: %s,", req.GenerateImageParameter, endpointName)
	resp, err := s.ComfyUiGenImage(req, endpointName)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

func (s *SagemakerAdapter) getEndpointName(taskType aiparameter.TaskType) (string, error) {
	sageMakerConfig := config.GetSrvConfig().SageMaker
	switch taskType {
	case aiparameter.TaskType_TASK_TYPE_Face_Swap:
		return sageMakerConfig.FaceSwapEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Image_Upscale:
		return sageMakerConfig.UpscaleEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design:
		return sageMakerConfig.TextToImageDesignEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		return sageMakerConfig.PetPortraitEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer:
		return sageMakerConfig.StyleTransferEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Instant_Style:
		return sageMakerConfig.InstantStyleEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Depth_Map_Generation:
		return sageMakerConfig.DepthMapGenerationEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer1:
		return sageMakerConfig.StyleTransfer1EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer2:
		return sageMakerConfig.StyleTransfer2EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		return sageMakerConfig.StyleTransfer3EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer:
		return sageMakerConfig.ComfyUIEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer1:
		return sageMakerConfig.ComfyUI1EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer2:
		return sageMakerConfig.ComfyUI2EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer3:
		return sageMakerConfig.ComfyUI3EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer4:
		return sageMakerConfig.ComfyUI4EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer5:
		return sageMakerConfig.ComfyUI5EndpointName, nil
	}
	return "", fmt.Errorf("getEndpointName, taskType: %d is not support", taskType)
}

// 检测 prompt中 "{CUSTOMIZ_PROMPT}" 字样，如果存在则替换为 parameter.Prompt
func (s *SagemakerAdapter) ReplaceCustomPrompt(prompt, customPrompt string) string {
	if customPrompt == "" {
		return prompt
	}
	if prompt == "" {
		return customPrompt
	}

	return strings.Replace(prompt, "{CUSTOMIZ_PROMPT}", customPrompt, -1)
}

func (s *SagemakerAdapter) TranslateHandler(*adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	return nil, fmt.Errorf("TranslateHandler not implemented")
}

func (s *SagemakerAdapter) TranslateQuestionRecommendHandler(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	return nil, fmt.Errorf("TranslateQuestionRecommendHandler not implemented")
}

func (s *SagemakerAdapter) FastTranscribeHandler(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	return nil, fmt.Errorf("FastTranscribeHandler not implemented")
}

func (s *SagemakerAdapter) TextSummaryHandler(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	return nil, fmt.Errorf("TextSummaryHandler not implemented")
}

func (s *SagemakerAdapter) SpeechToTextStreamHandler(<-chan *adaptermodel.SpeechToTextReq, chan<- *adaptermodel.SpeechToTextResp) error {
	return fmt.Errorf("SpeechToTextStreamHandler not implemented")
}

func (s *SagemakerAdapter) TextToSpeechStreamHandler(<-chan *adaptermodel.TextToSpeechReq, chan<- *adaptermodel.TextToSpeechResp) error {
	return fmt.Errorf("TextToSpeechStreamHandler not implemented")
}

func (s *SagemakerAdapter) TranslateStreamHandler(request <-chan *adaptermodel.TranslateReq, response chan<- *adaptermodel.TranslateResp) error {
	return fmt.Errorf("TranslateStreamHandler not implemented")
}

func (s *SagemakerAdapter) DifyWorkflowHandler(*adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error) {
	return nil, fmt.Errorf("DifyWorkflowHandler not implemented")
}

func (s *SagemakerAdapter) DifyWorkflowStreamHandler(request <-chan *adaptermodel.DifyWorkflowReq, response chan<- *adaptermodel.DifyWorkflowResp) error {
	return fmt.Errorf("DifyWorkflowStreamHandler not implemented")
}

func (s *SagemakerAdapter) DifyChatflowHandler(*adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error) {
	return nil, fmt.Errorf("DifyChatflowHandler not implemented")
}

func (s *SagemakerAdapter) DifyChatflowStreamHandler(request <-chan *adaptermodel.DifyChatflowReq, response chan<- *adaptermodel.DifyChatflowResp) error {
	return fmt.Errorf("DifyChatflowStreamHandler not implemented")
}

func (s *SagemakerAdapter) LanguageDetectStreamHandler(<-chan *adaptermodel.LanguageDetectReq, chan<- *adaptermodel.LanguageDetectResp) error {
	return fmt.Errorf("LanguageDetectStreamHandler not implemented")
}

func (s *SagemakerAdapter) OpusWrapperStreamHandler(<-chan *adaptermodel.OpusWrapperReq, chan<- *adaptermodel.OpusWrapperResp) error {
	return fmt.Errorf("OpusWrapperStreamHandler not implemented")
}

func (s *SagemakerAdapter) TranslateQuestionRecommendStreamHandler(<-chan *adaptermodel.TranslateQuestionRecommendReq, chan<- *adaptermodel.TranslateQuestionRecommendResp) error {
	return fmt.Errorf("TranslateQuestionRecommendStreamHandler not implemented")
}
