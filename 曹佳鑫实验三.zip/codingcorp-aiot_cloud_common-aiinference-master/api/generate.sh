goctl api go -api ../../protocol/client/aiinference.api -dir .
