package sagemaker

import (
	"bytes"
	"fmt"
	"image"
	"net/url"
	"path"
	"runtime"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"golang.org/x/sync/errgroup"
)

// 图片资源处理（接口返回前置方法）
func (s *SagemakerAdapter) handleImage(req *model.AiGenerateImageReq, resp *model.AiGenerateImageResp) error {
	for i, imageInfo := range resp.ImageInfos {
		if imageInfo == nil {
			return fmt.Errorf("generateImage error: image info is nil at index %d", i)
		}

		var err error

		// 0:默认，不处理生图结果图， 1:前端裁减过的图会调用，输入图带mask则需要叠加到结果图
		if req.ApplyInputMask == 1 && len(req.GenerateImageParameter.InitImage) > 0 {
			maskSt := time.Now()
			resultImg, err := common.AddInputMaskNew(req.GenerateImageParameter.InitImage, imageInfo.Data)
			if err != nil {
				s.Logger.Error(fmt.Sprintf("task_id: %s, applyInputMask failed, url: %s, error: %v", req.TaskId, req.ResultImageUpTokens[i], err))
			}
			if resultImg != nil {
				s.Logger.Info(fmt.Sprintf("task_id: %s, applyInputMask elapsed: %d ms", req.TaskId, time.Since(maskSt).Milliseconds()))
				imageInfo.Data, err = common.ImageEncode(resultImg, ".png", 100)
				if err != nil {
					return err
				}
				s.Logger.Info(fmt.Sprintf("task_id: %s, resultImg imageEncode elapsed: %d ms", req.TaskId, time.Since(maskSt).Milliseconds()))
			}
		}

		// 这里处理灰度图叠底与应用mask的逻辑
		controlNetImage := make([]byte, 0)
		if len(req.GenerateImageParameter.Controlnet) > 0 && len(req.GenerateImageParameter.Controlnet[0].Image) > 0 {
			controlNetImage = req.GenerateImageParameter.Controlnet[0].Image
			if imageInfo.Data, err = s.depthGrayAddAndMask(req.TaskId, req.DepthDetail, controlNetImage, imageInfo.Data); err != nil {
				return fmt.Errorf("generateImage, depth gray add and mask failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
			}
		}

		// 获取contentType
		urlParse, err := url.Parse(req.ResultImageUpTokens[i])
		if err != nil {
			return fmt.Errorf("generateImage, raw url into a [URL] failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
		}
		urlPath := strings.ToLower(urlParse.Path)
		contentType := common.TypeByExtension(urlPath)

		// 上传原图和缩略图到s3，可以并发上传，提升接口吞吐能力
		st := time.Now()
		wg := errgroup.Group{}

		// 原图处理
		wg.Go(func() error {
			var oriImageData []byte
			oriImageData, err = s.imageEncode(imageInfo.Data, urlPath)
			if err != nil {
				return fmt.Errorf("generateImage, image encode failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
			}
			s.Logger.Info(fmt.Sprintf("task_id: %s, image encode elapsed: %d ms", req.TaskId, time.Since(st).Milliseconds()))
			imageInfo.Size = int64(len(oriImageData))

			oriUploadSt := time.Now()
			if _, err = common.UploadFile(s.ctx, oriImageData, req.ResultImageUpTokens[i], contentType); err != nil {
				return fmt.Errorf("upload image s3 failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
			}
			s.Logger.Info(fmt.Sprintf("task_id: %s, ori image upload to s3 elapsed: %d ms", req.TaskId, time.Since(oriUploadSt).Milliseconds()))
			oriImageData = nil
			return nil
		})

		// 缩略图生成
		wg.Go(func() error {
			var imageThumbData []byte
			if len(req.ThumbImageUpTokens) > 0 && len(req.ThumbImageUpTokens) == len(req.ResultImageUpTokens) {
				// svg格式的上传图片不生成缩略图
				thumbUrlParse, err := url.Parse(req.ThumbImageUpTokens[i])
				if err != nil {
					return fmt.Errorf("generateImage, raw url into a [URL] failed, url: %s, error: %v", req.ThumbImageUpTokens[i], err)
				}
				thumbUrlPath := strings.ToLower(thumbUrlParse.Path)
				if !strings.HasSuffix(thumbUrlPath, ".svg") {
					imageThumbData, err = s.thumbResizeAndEncodePng(req.TaskId, imageInfo.Data, thumbUrlPath)
					if err != nil {
						return fmt.Errorf("generateImage, thumbnail resize failed, url: %s, error: %v", req.ThumbImageUpTokens[i], err)
					}
				}
			}
			if len(imageThumbData) > 0 {
				uploadSt := time.Now()
				if _, err = common.UploadFile(s.ctx, imageThumbData, req.ThumbImageUpTokens[i], contentType); err != nil {
					return fmt.Errorf("upload thumb image s3 failed, url: %s, error: %v", req.ThumbImageUpTokens[i], err)
				}
				s.Logger.Info(fmt.Sprintf("task_id: %s, thumbnail image upload to s3 elapsed: %d ms", req.TaskId, time.Since(uploadSt).Milliseconds()))
			}
			imageThumbData = nil
			return nil
		})

		if err := wg.Wait(); err != nil {
			return err
		}

		s.Logger.Info(fmt.Sprintf("task_id: %s, total elapsed: %d ms", req.TaskId, time.Since(st).Milliseconds()))
		// gc
		imageInfo.Data = nil
	}
	return nil
}

func (s *SagemakerAdapter) imageEncode(ori []byte, urlPath string) ([]byte, error) {
	var err error
	newOri := ori
	if strings.HasSuffix(urlPath, ".webp") {
		newOri, err = common.PngToWebp(ori)
		if err != nil {
			return nil, fmt.Errorf("generateImage, convert to webp failed, error: %v", err)
		}
	}
	return newOri, nil
}

func (s *SagemakerAdapter) thumbResizeAndEncodePng(taskId string, imageInfo []byte, thumbUrlPath string) ([]byte, error) {
	st := time.Now()
	var imageThumb image.Image
	var err error
	var imageThumbData []byte
	imageThumb, err = common.ImageResize(imageInfo, config.GetSrvConfig().Thumbnail.PixLimit)
	s.Logger.Info(fmt.Sprintf("task_id:%s, resize elapsed: %d ms", taskId, time.Since(st).Milliseconds()))
	if err != nil {
		return nil, fmt.Errorf("ImageResize failed, error: %v", err)
	}
	defer func() {
		// 释放内存
		imageThumb = nil
	}()
	//缩略图格式保持跟上传url一致，并检查是否支持缩放，若不支持则默认使用webp编码
	ext := path.Ext(thumbUrlPath)
	if common.IsExitSuffix(strings.ToLower(ext)) {
		imageThumbData, err = common.ImageEncode(imageThumb, strings.ToLower(ext), config.GetSrvConfig().Thumbnail.ImageQuality)
	} else {
		imageThumbData, err = common.ImageEncode(imageThumb, ".webp", config.GetSrvConfig().Thumbnail.ImageQuality)
	}
	s.Logger.Info(fmt.Sprintf("task_id:%s, imageThumb save elapsed: %d ms", taskId, time.Since(st).Milliseconds()))
	if err != nil {
		return nil, fmt.Errorf("generateImage, thumbnail convert to png failed, error: %v", err)
	}
	return imageThumbData, nil
}

func (s *SagemakerAdapter) depthGrayAddAndMask(taskId string, depthDetail model.DepthToDetailParams, controlNetImage, imageInfo []byte) ([]byte, error) {
	reader := bytes.NewReader(controlNetImage)

	// 解析图片配置（仅读取元数据）
	imageConfig, _, err1 := image.DecodeConfig(reader)
	if err1 != nil {
		return nil, err1
	}
	channelNum, _ := common.GetImageChannel(imageConfig)
	if channelNum == 0 {
		channelNum = 4 //按照最大值取
	}

	imageMemSize := imageConfig.Width * imageConfig.Height * channelNum
	// 大于配置图片的最大值，则不进行resize操作，原因: 图片像素值太大会导致服务OOM
	if int64(imageMemSize) > config.GetSrvConfig().ImageMaxSize {
		s.Logger.Error(fmt.Sprintf("task_id: %s, adepthGrayAddAndMask image size more than %d", taskId, config.GetSrvConfig().ImageMaxSize))
		return nil, fmt.Errorf("image size more than %d", config.GetSrvConfig().ImageMaxSize)
	}

	if !depthDetail.DepthToDetail.ApplyGrayImage && !depthDetail.DepthToDetail.ApplyBlackMask {
		return imageInfo, nil
	}

	var (
		resultImage   image.Image
		err           error
		controlNetImg image.Image
		imageObj      image.Image
	)

	st := time.Now()

	controlNetImg, imageObj, err = s.imageDecode(taskId, controlNetImage, imageInfo)
	if err != nil {
		return nil, fmt.Errorf("image decode failed, task_id: %s, error: %v", taskId, err)
	}

	// 判断是否需要深度图叠底
	if depthDetail.DepthToDetail.ApplyGrayImage {
		resultImage, err = common.DepthGrayAdd(imageObj, controlNetImg, depthDetail.DepthToDetail.GrayScale)
		if err != nil {
			return nil, fmt.Errorf("depth gray add failed, task_id: %s, error: %v", taskId, err)
		}
	}

	s.Logger.Info(fmt.Sprintf("task_id: %s, ApplyGrayImage is %v, elapsed: %d ms", taskId,
		depthDetail.DepthToDetail.ApplyGrayImage, time.Since(st).Milliseconds()))

	// 判断是否需要应用mask
	if depthDetail.DepthToDetail.ApplyBlackMask {
		if resultImage != nil {
			resultImage, err = common.HandleApplyMask(resultImage, controlNetImg)
		} else {
			resultImage, err = common.HandleApplyMask(imageObj, controlNetImg)
		}
		if err != nil {
			return nil, fmt.Errorf("apply mask failed, task_id: %s, error: %v", taskId, err)
		}
	}

	s.Logger.Info(fmt.Sprintf("task_id: %s, ApplyBlackMask is %v, elapsed: %d ms", taskId,
		depthDetail.DepthToDetail.ApplyBlackMask, time.Since(st).Milliseconds()))

	defer func() {
		runtime.GC()
	}()

	if resultImage != nil {
		//调整图像中最低灰度值的像素
		graySt := time.Now()
		resultImage, err = common.AdjustLowestGray(resultImage, depthDetail.DepthToDetail.PixPercent)
		if err != nil {
			return nil, fmt.Errorf("adjust lowest gray failed, task_id: %s, error: %v", taskId, err)
		}
		s.Logger.Info(fmt.Sprintf("task_id: %s, adjust lowest gray elapsed: %d ms", taskId, time.Since(graySt).Milliseconds()))

		imageInfo, err = common.ImageEncode(resultImage, ".png", 100)
		if err != nil {
			return nil, fmt.Errorf("generateImage, image encode failed, task_id: %s, error: %v", taskId, err)
		}
	}

	s.Logger.Info(fmt.Sprintf("task_id: %s, resultImage imageEncode, elapsed: %d ms", taskId, time.Since(st).Milliseconds()))

	return imageInfo, err
}

func (s *SagemakerAdapter) imageDecode(taskId string, cImg, imgInfo []byte) (image.Image, image.Image, error) {
	st := time.Now()
	var (
		controlNetImg image.Image
		imageObj      image.Image
		err           error
	)
	// 这里对图片的处理非常耗内存, 等待自动内存回收的过程比较漫长, 这里手动回收内存
	defer func() {
		runtime.GC()
	}()

	controlNetImg, _, err = image.Decode(bytes.NewBuffer(cImg))
	if err != nil {
		return nil, nil, err
	}
	s.Logger.Info(fmt.Sprintf("task_id: %s, controlNetImg elapsed: %d ms", taskId, time.Since(st).Milliseconds()))

	imageObj, _, err = image.Decode(bytes.NewBuffer(imgInfo))
	if err != nil {
		return nil, nil, err
	}
	s.Logger.Info(fmt.Sprintf("task_id: %s, imageInfo elapsed: %d ms", taskId, time.Since(st).Milliseconds()))

	return controlNetImg, imageObj, nil
}
