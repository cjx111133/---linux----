package audio

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type AudioTranslateLogic struct {
	logx.Logger
	ctx         context.Context
	svcCtx      *svc.ServiceContext
	connInfo    *types.ConnectionInfo
	wsStopChan  chan struct{}
	utilLogic   *common.UtilLogic
	mu          sync.Mutex
	msgLogicMap map[string]*AudioMessage
}

// NewAudioTranslate 创建语音翻译的逻辑
func NewAudioTranslate(ctx context.Context, svcCtx *svc.ServiceContext, data *types.WebSocketData) (*AudioTranslateLogic, error) {
	l := &AudioTranslateLogic{
		Logger:     logx.WithContext(ctx),
		ctx:        ctx,
		svcCtx:     svcCtx,
		connInfo:   data.ConnectionInfo,
		wsStopChan: data.StopWsChan,
		utilLogic:  common.NewUtilLogic(ctx, svcCtx, data),
	}
	l.msgLogicMap = make(map[string]*AudioMessage)

	// 启动一个协程来监听ws连接关闭事件
	// TODO：为什么要在这里监听ws连接关闭事件？
	threading.GoSafe(func() {
		l.listenForClose()
	})
	return l, nil
}

// Handle 处理语音翻译的逻辑
func (l *AudioTranslateLogic) Handle(msg *types.WebSocketReq) error {
	req, tip, sendErr := l.parse(msg)
	if sendErr != nil {
		l.Errorf("AudioTranslate parse failed, tip: %s, err: %v", tip, sendErr)
		l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeDataErr, tip)
		return sendErr
	}

	l.Debugf("AudioTranslate Handle parse success, sessionId: %s, msgId: %s, connInfo.Cmd: %s, cmd:%s, subCmd: %s, type: %d, reqStatus: %d, index: %d", l.connInfo.SessionId, req.MessageId, l.connInfo.Cmd, req.Cmd, req.SubCmd, req.Type, req.ReqStatus, req.Index)

	// 如果是v1版本且请求类型为ReqTypeSimultaneous，等待其他消息处理完成
	if l.connInfo.Cmd != "" && req.Type == types.ReqTypeSimultaneous {
		l.Debugf("AudioTranslate Handle, waiting for other messages to finish processing, sessionId: %s, msgId: %s, connInfo.Cmd: %s", l.connInfo.SessionId, req.MessageId, l.connInfo.Cmd)
		var isProcess bool
		for {
			l.mu.Lock()
			// 检查是否有其他消息在处理
			if len(l.msgLogicMap) == 0 {
				isProcess = true
			} else if len(l.msgLogicMap) == 1 {
				for key := range l.msgLogicMap {
					if key == req.MessageId {
						isProcess = true
					}
					break
				}
			}
			l.mu.Unlock()

			if isProcess {
				l.Debugf("AudioTranslate Handle, other messages finished processing, sessionId: %s, msgId: %s, connInfo.Cmd: %s", l.connInfo.SessionId, req.MessageId, l.connInfo.Cmd)
				break
			}

			time.Sleep(time.Millisecond * 100)
		}
	}

	code, tip, sendErr := l.HandleLogic(req)
	if sendErr != nil {
		l.Errorf("AudioTranslate HandleLogic failed, code: %d, tip: %s, err: %v", code, tip, sendErr)
		l.utilLogic.SendErrDataToRecv(req.CommonReq, code, tip)
		return sendErr
	}
	return nil
}

// 数据解析
func (l *AudioTranslateLogic) parse(msg *types.WebSocketReq) (*types.AudioTranslateReq, string, error) {
	if msg == nil {
		l.Errorf("AudioTranslate parse failed, msg is nil")
		return nil, "msg is nil", errors.New("msg is nil")
	}

	// 1. 将msg进行反序列化，获取到语音识别的结果
	req := &types.AudioTranslateReq{}
	err := json.Unmarshal(msg.Data, req)
	if err != nil {
		l.Errorf("AudioTranslate Unmarshal failed, msgId:%s, err: %v, msg: %s", req.MessageId, err, string(msg.Data))
		return nil, "Failed to unmarshal data", err
	}

	// 2. 解密数据
	req.Data, err = l.utilLogic.DataDecrypt(req.Data)
	if err != nil {
		l.Errorf("AudioTranslate dataDecrypt failed, msgId:%s, err: %v, Data: %s", req.MessageId, err, req.Data)
		return nil, "Failed to decrypt data", err
	}

	// 3. 检查参数
	err = l.checkParam(msg, req)
	if err != nil {
		l.Errorf("AudioTranslate checkParam failed, msgId:%s, err: %v", req.MessageId, err)
		if req.ReqStatus == types.ReqStatusEnd {
			return nil, err.Error(), err
		}
		return nil, err.Error(), err
	}
	return req, "", nil
}

func (l *AudioTranslateLogic) HandleLogic(req *types.AudioTranslateReq) (int32, string, error) {
	l.mu.Lock()
	l.Debugf("AudioTranslate HandleLogic start, msgId: %s, reqStatus: %d, index: %d", req.MessageId, req.ReqStatus, req.Index)
	defer func() {
		if err := recover(); err != nil {
			l.Errorf("AudioTranslate HandleLogic panic, msgId: %s, err: %v", req.MessageId, err)
		}
		l.mu.Unlock()
		l.Debugf("AudioTranslate HandleLogic end, msgId: %s, reqStatus: %d, index: %d", req.MessageId, req.ReqStatus, req.Index)
	}()

	// 获取或创建AudioMessage实例
	msgLogic, exists := l.msgLogicMap[req.MessageId]
	if !exists {
		// 如果不是首包但没有对应的AudioMessage实例，返回错误
		if req.ReqStatus != types.ReqStatusFirst {
			l.Errorf("AudioTranslate HandleLogic, Invalid message sequence, msgId: %s, reqStatus: %d, index: %d", req.MessageId, req.ReqStatus, req.Index)
			return types.RespCodeDataErr, "Invalid message sequence", errors.New("invalid message sequence")
		}

		// 如果消息数量超过限制，返回错误
		if l.svcCtx.Config.AudioTranslate.SupportMsgIdNum > 0 && len(l.msgLogicMap) >= l.svcCtx.Config.AudioTranslate.SupportMsgIdNum {
			l.Errorf("AudioTranslate HandleLogic, Too many message, msgId: %s, supportMsgIdNum: %d, currentMsgIdNum: %d", req.MessageId, l.svcCtx.Config.AudioTranslate.SupportMsgIdNum, len(l.msgLogicMap))
			return types.RespCodeDataErr, "Too many message", errors.New("too many message")
		}

		// 创建新的AudioMessage实例
		msgLogic = NewAudioMessage(l, req)
		threading.GoSafe(func() {
			msgLogic.Run(req)
		})

		l.msgLogicMap[req.MessageId] = msgLogic
	} else if req.ReqStatus == types.ReqStatusFirst {
		// 如果是重复的首包，返回成功
		l.Infof("AudioTranslate HandleLogic, Duplicate first message, msgId: %s, reqStatus: %d, index: %d", req.MessageId, req.ReqStatus, req.Index)
		return types.RespCodeSuccess, "", nil
	}

	// 缓存请求
	msgLogic.audios = append(msgLogic.audios, req)
	return types.RespCodeSuccess, "", nil
}

// close 关闭发送
func (l *AudioTranslateLogic) listenForClose() {
	// 清理所有活跃的AudioMessage实例
	defer l.utilLogic.IncryModel(-1)

	select {
	case <-l.ctx.Done():
		l.Infof("AudioTranslate Stop, ctx done")
	case <-l.wsStopChan:
		l.Infof("AudioTranslate Stop, wsStopChan")
	}
}

// checkParam 检查参数
func (l *AudioTranslateLogic) checkParam(msg *types.WebSocketReq, req *types.AudioTranslateReq) error {
	if req == nil {
		return errors.New("req data is empty")
	}
	if req.MessageId == "" {
		// 兼容旧协议
		if msg.MsgId == "" {
			return errors.New("MessageId is empty")
		}
		req.MessageId = msg.MsgId
		req.Timestamp = msg.Timestamp
		req.Cmd = msg.Cmd
		req.SubCmd = msg.SubCmd
		req.CustomFields = msg.CustomFields
	}

	switch req.ReqStatus {
	case types.ReqStatusFirst:
		// 处理自动重连，重复发首包问题
		if req.Format == "" {
			return errors.New("format is empty")
		}
		if req.SampleRate == 0 {
			return errors.New("SampleRate is 0")
		}
		//if req.BitRate == 0 {
		//	return errors.New("bitRate is 0")
		//}
		if req.Channels == 0 {
			return errors.New("channels is 0")
		}
		if req.SourceLanguage == "" {
			return errors.New("SourceLanguage is empty")
		}
		if req.TargetLanguage == "" {
			return errors.New("TargetLanguage is empty")
		}
		req.SourceLanguage, req.TargetLanguage = common.FixLanguage(req.SourceLanguage), common.FixLanguage(req.TargetLanguage)
		if len(req.Role) == 0 {
			req.Role = "user_a"
		}
	case types.ReqStatusMiddle:
		if req.Data == "" {
			return errors.New("data is empty")
		}
		if req.Type == types.ReqTypeAudio || req.Type == types.ReqTypeSimultaneous {
			// 将base64编码的音频数据解码
			binaryData, err := base64.StdEncoding.DecodeString(req.Data)
			if err != nil {
				return fmt.Errorf("base64 decode failed, err: %v", err)
			}
			if len(binaryData) == 0 {
				return errors.New("data is empty")
			}
			req.Data = string(binaryData)
		}
	case types.ReqStatusEnd:
		l.Infof("AudioTranslate, recv client end, msgId: %s", req.MessageId)
	default:
		return fmt.Errorf("ReqStatus is invalid, reqStatus: %d", req.ReqStatus)
	}
	return nil
}

func isStreamEOF(err error) bool {
	if err == io.EOF {
		return true
	}

	if st, ok := status.FromError(err); ok {
		// 匹配gRPC包装的EOF错误
		return st.Code() == codes.Unknown &&
			strings.Contains(st.Message(), "EOF")
	}
	return false
}
