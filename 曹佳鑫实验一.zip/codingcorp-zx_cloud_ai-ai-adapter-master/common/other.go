package common

import (
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"strings"
)

func IsExistInArray(arr []string, str string) bool {
	for _, v := range arr {
		if v == str {
			return true
		}
	}
	return false
}

func RandomNumberCryptoRand() (uint64, error) {
	var buf [8]byte
	_, err := rand.Read(buf[:])
	if err != nil {
		return 0, err
	}
	return binary.BigEndian.Uint64(buf[:]), nil
}

func ReplaceRandSeedPlaceholder(s, placeholder string) (string, error) {
	result := ""
	parts := strings.Split(s, placeholder)
	for i, part := range parts {
		randNum, err := RandomNumberCryptoRand()
		if err != nil {
			return "", err
		}
		result += part
		if i < len(parts)-1 {
			result += fmt.Sprintf("%d", randNum)
		}
	}
	return result, nil
}
