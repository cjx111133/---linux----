package aliyun

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	nls "github.com/aliyun/alibabacloud-nls-go-sdk"
	"github.com/zeromicro/go-zero/core/logx"
)

type Header struct {
	Namespace  string `json:"namespace"` // 消息所属的命名空间
	Name       string `json:"name"`      // 消息名称
	Status     int32  `json:"status"`
	MessageID  string `json:"message_id"`
	TaskID     string `json:"task_id"`     // 任务全局唯一ID，请记录该值，便于排查问题
	StatusText string `json:"status_text"` // 本次消息的ID
}

type Payload struct {
	Index      int32   `json:"index"`      // 句子编号，从1开始递增
	Time       int32   `json:"time"`       // 当前已处理的音频时长，单位是毫秒。
	BeginTime  int32   `json:"begin_time"` // 当前句子的开始时间，单位是毫秒
	Result     string  `json:"result"`     // 当前句子的识别结果
	Words      []Word  `json:"words"`      // 当前句子的词信息，需要将enable_words设置为true
	Confidence float32 `json:"confidence"` // 当前句子识别结果的置信度，取值范围：[0.0,1.0]。值越大表示置信度越高
}

type Word struct {
	Text      string `json:"text"`
	StartTime int32  `json:"startTime"` // 单位为毫秒
	EndTime   int32  `json:"endTime"`   // 单位为毫秒
}

type AsrResult struct {
	Header  Header  `json:"header"`
	Payload Payload `json:"payload"`
}

type AsrClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	segments  []*aicommon.Segment
	startTime time.Time
	errCh     chan error
	buf       *bytes.Buffer
	perSize   int
	audioLen  int
	result    string
	index     int32

	request  <-chan *adaptermodel.SpeechToTextReq
	response chan<- *adaptermodel.SpeechToTextResp
	first    *adaptermodel.SpeechToTextReq
	st       *nls.SpeechTranscription
}

func NewAsrClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.SpeechToTextReq,
	response chan<- *adaptermodel.SpeechToTextResp,
	first *adaptermodel.SpeechToTextReq) *AsrClient {
	return &AsrClient{
		ctx:       ctx,
		svcCtx:    svcCtx,
		Logger:    logx.WithContext(ctx),
		segments:  make([]*aicommon.Segment, 0),
		startTime: time.Now(),
		errCh:     make(chan error, 10),
		buf:       new(bytes.Buffer),
		perSize:   3200,
		index:     1,
		request:   request,
		response:  response,
		first:     first,
	}
}

func (c *AsrClient) SpeechTranscription() error {
	var err error
	c.st, err = c.initClient()
	if err != nil {
		return fmt.Errorf("init asr client failed, err: %v", err)
	}
	defer c.st.Shutdown()

	param := nls.SpeechTranscriptionStartParam{
		Format:                         c.first.Audio.Format,
		SampleRate:                     int(c.first.Audio.SampleRate),
		EnableIntermediateResult:       true,
		EnablePunctuationPrediction:    c.first.AddPunctuation,
		EnableInverseTextNormalization: true,
		MaxSentenceSilence:             int(c.first.MaxSentenceSilence),
		EnableWords:                    true,
	}
	extra := make(map[string]interface{})
	extra["test"] = "hello" // test
	start, err := c.st.Start(param, extra)
	if err != nil {
		return fmt.Errorf("start speech transcription failed, err: %v", err)
	}
	err = c.Wait(start)
	if err != nil {
		return fmt.Errorf("wait speech transcription start failed, err: %v", err)
	}
	c.Info("speech transcription start")

	c.audioLen = len(c.first.Audio.Data)
	_, err = c.buf.Write(c.first.Audio.Data)
	if err != nil {
		return fmt.Errorf("write first audio data to buffer failed, err: %v", err)
	}
	// send first package to Aliyun
	for c.buf.Len() >= c.perSize {
		c.Infof("send first audio data to aliyun, len: %d, perSize: %d", c.buf.Len(), c.perSize)
		err = c.st.SendAudioData(c.buf.Next(c.perSize))
		if err != nil {
			return fmt.Errorf("send first audio data to aliyun failed, err: %v", err)
		}
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop speech transcription failed, err: %v", err)
	}

	stop, err := c.st.Stop()
	if err != nil {
		return fmt.Errorf("stop speech transcription failed, err: %v", err)
	}
	err = c.Wait(stop)
	if err != nil {
		return fmt.Errorf("wait speech transcription start failed, err: %v", err)
	}
	// SPEECH END
	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		Language:    c.first.Audio.Language,
		SpeechEnd:   true,
		Text:        c.result,
		TimeTakenMs: int32(time.Since(c.startTime).Milliseconds()),
	}
	c.Infof("recv from aliyun asr end, SpeechEnd: %v, result: %v", true, c.result)

	return nil
}

func (c *AsrClient) loop() error {
	var interval = 5 * time.Second
	ticker := time.NewTicker(interval)
	defer func() {
		ticker.Stop()
		c.Infof("send audio data to aliyun end, audioLen: %d", c.audioLen)
	}()

	for {
		select {
		case err, ok := <-c.errCh:
			if !ok {
				return nil
			}
			return fmt.Errorf("speech synthesis failed, err: %v", err)
		case <-c.ctx.Done():
			c.Infof("send audio data to aliyun end, ctx done")
			return nil
		case <-ticker.C:
			c.first.Audio.Data = []byte{0}
			c.Infof("send blank audio to asr to keep heartbeat, len: %d", len(c.first.Audio.Data))
			err := c.st.SendAudioData(c.first.Audio.Data)
			if err != nil {
				return fmt.Errorf("send audio data to aliyun failed, err: %v", err)
			}
		case req, ok := <-c.request:
			if !ok {
				if c.buf.Len() > 0 {
					err := c.st.SendAudioData(c.buf.Bytes())
					if err != nil {
						return fmt.Errorf("send last audio data to aliyun failed, err: %v", err)
					}
				}
				c.Infof("send audio data to aliyun end, request channel closed")
				return nil
			}
			if req == nil {
				continue
			}
			if req.Audio == nil {
				continue
			}
			if len(req.Audio.Data) == 0 {
				c.Errorf("audio data is empty")
				continue
			}
			c.audioLen += len(req.Audio.Data)
			ticker.Reset(interval)

			_, err := c.buf.Write(req.Audio.Data)
			if err != nil {
				return fmt.Errorf("write audio data to buffer failed, err: %v", err)
			}
			for c.buf.Len() >= c.perSize {
				c.Debugf("send audio data to aliyun, len: %d", c.perSize)
				err = c.st.SendAudioData(c.buf.Next(c.perSize))
				if err != nil {
					return fmt.Errorf("send audio data to aliyun failed, err: %v", err)
				}
			}
		}
	}
}

func (c *AsrClient) initClient() (*nls.SpeechTranscription, error) {
	appKey, err := c.getAppKey()
	if err != nil {
		return nil, fmt.Errorf("get app key failed, err: %v", err)
	}

	// connect to Aliyun
	var cfg = config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)]
	connConfig, err := nls.NewConnectionConfigWithAKInfoDefault(cfg.VoiceServerUrl, appKey, cfg.AccessKeyID, cfg.AccessKeySecret)
	if err != nil {
		return nil, fmt.Errorf("create connection config failed, err: %v", err)
	}

	st, err := nls.NewSpeechTranscription(connConfig, nil,
		c.TaskFailed,
		c.TranscriptionStarted,
		c.SentenceBegin,
		c.SentenceEnd,
		c.ResultChanged,
		c.Completed,
		c.Closed, nil)
	if err != nil {
		return nil, fmt.Errorf("create speech transcription failed, err: %v", err)
	}
	return st, nil
}

// 识别过程中的错误处理回调
func (c *AsrClient) TaskFailed(text string, param interface{}) {
	c.Errorf("recv TaskFailed from aliyun tts, text: %s", text)
	c.errCh <- errors.New(text)
}

// 建连完成回调
func (c *AsrClient) TranscriptionStarted(text string, param interface{}) {
	c.Infof("recv TranscriptionStarted from aliyun asr, text: %s", text)
}

// 一句话开始回调
func (c *AsrClient) SentenceBegin(text string, param interface{}) {
	c.Infof("recv SentenceBegin from aliyun asr, text: %s", text)
}

// 一句话结束回调
func (c *AsrClient) SentenceEnd(text string, param interface{}) {
	var asrResult AsrResult
	err := common.JsonToAny([]byte(text), &asrResult)
	if err != nil {
		c.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		c.errCh <- fmt.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		return
	}
	c.Infof("recv SentenceEnd from aliyun asr, index: %d, text: %s", asrResult.Payload.Index, asrResult.Payload.Result)
	if asrResult.Payload.Result == "" {
		return
	}

	var words []*aicommon.Word
	if c.first.EnableWord && len(asrResult.Payload.Words) > 0 {
		words = make([]*aicommon.Word, 0, len(asrResult.Payload.Words))
		for _, word := range asrResult.Payload.Words {
			words = append(words, &aicommon.Word{
				Text:    word.Text,
				StartMs: word.StartTime,
				EndMs:   word.EndTime,
				// Confidence: asrResult.Payload.Confidence,
			})
		}
	}
	c.segments = append(c.segments, &aicommon.Segment{
		Id:         asrResult.Payload.Index,
		StartMs:    asrResult.Payload.BeginTime,
		EndMs:      asrResult.Payload.Time,
		Text:       asrResult.Payload.Result,
		Confidence: asrResult.Payload.Confidence,
		Words:      words,
	})

	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SegmentId:     asrResult.Payload.Index,
		SegmentEnd:    true,
		Text:          asrResult.Payload.Result,
		Language:      c.first.Audio.Language,
		Segments:      c.segments,
		UseTempResult: c.first.UseTempResult,
		TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
	}
	c.result += asrResult.Payload.Result
	c.index = asrResult.Payload.Index + 1
}

// 识别中间结果回调
func (c *AsrClient) ResultChanged(text string, param interface{}) {
	if !c.first.EnableWord {
		c.response <- &adaptermodel.SpeechToTextResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "success",
			},
			SegmentId:     c.index,
			SegmentEnd:    false,
			Text:          "",
			Language:      c.first.Audio.Language,
			Segments:      c.segments,
			UseTempResult: c.first.UseTempResult,
			TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
		}
		return
	}

	var asrResult AsrResult
	err := common.JsonToAny([]byte(text), &asrResult)
	if err != nil {
		c.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		c.errCh <- fmt.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		return
	}
	c.Debugf("recv ResultChanged from aliyun asr, index: %d, text: %s", asrResult.Payload.Index, asrResult.Payload.Result)
	if asrResult.Payload.Result == "" {
		return
	}

	var words []*aicommon.Word
	if len(asrResult.Payload.Words) > 0 {
		words = make([]*aicommon.Word, 0, len(asrResult.Payload.Words))
		for _, word := range asrResult.Payload.Words {
			words = append(words, &aicommon.Word{
				Text:    word.Text,
				StartMs: word.StartTime,
				EndMs:   word.EndTime,
				// Confidence: asrResult.Payload.Confidence,
			})
		}
	}
	var segment = &aicommon.Segment{
		Id:         asrResult.Payload.Index,
		StartMs:    asrResult.Payload.BeginTime,
		EndMs:      asrResult.Payload.Time,
		Text:       asrResult.Payload.Result,
		Confidence: asrResult.Payload.Confidence,
		Words:      words,
	}

	var segments = make([]*aicommon.Segment, 0, len(c.segments)+1)
	segments = append(segments, c.segments...)
	segments = append(segments, segment)

	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SegmentId:     asrResult.Payload.Index,
		SegmentEnd:    false,
		Text:          asrResult.Payload.Result,
		Language:      c.first.Audio.Language,
		Segments:      segments,
		UseTempResult: c.first.UseTempResult,
		TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
	}
}

// 最终识别结果回调
func (c *AsrClient) Completed(text string, param interface{}) {
	c.Infof("recv Completed from aliyun asr, text: %s", text)
}

// 连接断开回调
func (c *AsrClient) Closed(param interface{}) {
	c.Infof("recv Closed from aliyun asr")
}

// 等待start或stop完成
func (c *AsrClient) Wait(ch chan bool) error {
	select {
	case message, done := <-ch:
		if !done {
			return errors.New("wait failed")
		}
		c.Infof("Wait done: %v", message)
	case <-time.After(60 * time.Second):
		return errors.New("Wait timeout")
	}
	return nil
}

func (c *AsrClient) Close() {
	if c.errCh != nil {
		for len(c.errCh) > 0 {
			<-c.errCh
		}
		close(c.errCh)
	}
	if c.response != nil {
		close(c.response)
	}
}

func (c *AsrClient) getAppKey() (string, error) {
	var appKey string
	var cfg = config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)]
	switch strings.ToLower(c.first.Audio.Language) {
	case "zh", "zh-cn", "zh-CN":
		appKey = cfg.ZhAsrAppKey
	case "en", "en-us", "en-US":
		appKey = cfg.EnAsrAppKey
	case "ja", "ja-jp", "ja-JP":
		appKey = cfg.JaAsrAppKey
	case "de", "de-de", "de-DE":
		appKey = cfg.DeAsrAppKey
	case "es", "es-es", "es-ES":
		appKey = cfg.EsAsrAppKey
	case "fr", "fr-fr", "fr-FR":
		appKey = cfg.FrAsrAppKey
	default:
		return "", fmt.Errorf("unsupported language: %s", c.first.Audio.Language)
	}
	return appKey, nil
}
