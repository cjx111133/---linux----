package model

import (
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

const (
	SAGEMAKER_INFERENCE_URL                        = "/inferences"
	SAGEMAKER_INFERENCE_STATUS_inprogress          = "inprogress"
	SAGEMAKER_INFERENCE_STATUS_succeed             = "succeed"
	SAGEMAKER_INFERENCE_TYPE_Real_time             = "Real-time"
	SAGEMAKER_INFERENCE_TYPE_Async                 = "Async"
	SAGEMAKER_INFERENCE_TASK_TYPE_txt2img          = "txt2img"
	SAGEMAKER_INFERENCE_TASK_TYPE_img2img          = "img2img"
	INFERENCE_TASK_TYPE_interrogateclip            = "interrogate_clip"
	SAGEMAKER_TRAIN_KOHYA_TOML_FILE_NAME           = "kohya_config_cloud.toml"
	SAGEMAKER_TRAIN_KOHYA_XL_TOML_FILE_NAME        = "kohya_config_cloud_xl.toml"
	SAGEMAKER_TRAIN_KOHYA_PRETRAINED_MODEL_PATH    = "./sd-models/v1-5-pruned-emaonly.safetensors"
	SAGEMAKER_TRAIN_KOHYA_XL_PRETRAINED_MODEL_PATH = "models/Stable-diffusion/albedobaseXL_v21.safetensors"
	SAGEMAKER_TRAIN_METHOD                         = "kohya"
	SAGEMAKER_TRAIN_FM_TYPE_SD_1_5                 = "sd_1_5"
	SAGEMAKER_TRAIN_FM_TYPE_SD_XL                  = "sd_xl"
)

var TomlFile = `[training]
v2 = false
v_parameterization = false
pretrained_model_name_or_path = "SD_MODEL_PATH"
train_data_dir = "./train/input"
reg_data_dir = ""
prior_loss_weight = 1
cache_latents = true
shuffle_caption = true
enable_bucket = true
network_dim = 32
network_alpha = 16
network_train_unet_only = false
network_train_text_encoder_only = false
network_module = "networks.lora"
network_args = []
unet_lr = 0.0001
text_encoder_lr = 1e-05
optimizer_type = "AdamW8bit"
lr_scheduler = "cosine_with_restarts"
lr_warmup_steps = 0
lr_restart_cycles = 1
resolution = "512,512"
train_batch_size = 1
max_train_epochs = 10
noise_offset = 0.0
keep_tokens = 0
xformers = true
lowram = false
clip_skip = 2
mixed_precision = "fp16"
save_precision = "fp16"
output_name = "output_name"
save_every_n_epochs = 1
save_n_epoch_ratio = 0
save_last_n_epochs = 499
save_state = false
save_model_as = "safetensors"
output_dir = "output"
logging_dir = "./logs"
log_prefix = "output_name"
min_bucket_reso = 256
max_bucket_reso = 1024
caption_extension = ".txt"
max_token_length = 225
seed = 1337
no_half_vae = NO_HALF_VAE

[saving_arguments]
output_name = "OUTPUT_NAME"
save_every_n_epochs = SAVE_EVERY_N_EPOCHS

[training_arguments]
max_train_epochs = MAX_TRAIN_EPOCHS
`

type CreateInferencesPayload struct {
	InferenceType string                 `json:"inference_type"`
	TaskType      string                 `json:"task_type"`
	Models        CreateInferencesModels `json:"models"`
}

type CreateInferencesModels struct {
	StableDiffusion []string `json:"Stable-diffusion"`
	VAE             []string `json:"VAE"`
	Embeddings      []string `json:"embeddings"`
}

type CreateInferencesResponse struct {
	StatusCode int                  `json:"statusCode"`
	Message    string               `json:"message"`
	Debug      Debug                `json:"debug"`
	Data       CreateInferencesData `json:"data"`
}

type Debug struct {
	FunctionURL string `json:"function_url"`
	LogURL      string `json:"log_url"`
	TraceURL    string `json:"trace_url"`
}

type CreateInferencesData struct {
	Inference InferenceV1 `json:"inference"`
}

type InferenceV1 struct {
	ID                   string                  `json:"id"`
	Type                 string                  `json:"type"`
	APIParamsS3Location  string                  `json:"api_params_s3_location"`
	APIParamsS3UploadURL string                  `json:"api_params_s3_upload_url"`
	Models               []CreateInferencesModel `json:"models"`
}

type CreateInferencesModel struct {
	ID   string   `json:"id"`
	Name []string `json:"name"`
	Type string   `json:"type"`
}

type StartInferencesResponse struct {
	StatusCode int              `json:"statusCode"`
	Message    string           `json:"message"`
	Debug      Debug            `json:"debug"`
	Data       InferencesResult `json:"data"`
}

type GetInferencesResponse struct {
	StatusCode int              `json:"statusCode"`
	Message    string           `json:"message"`
	Data       InferencesResult `json:"data"`
}

type InferencesResult struct {
	InferenceJobId      string                 `json:"InferenceJobId"`
	Status              string                 `json:"status"`
	TaskType            string                 `json:"taskType"`
	InferenceType       string                 `json:"inference_type"`
	ImageNames          []string               `json:"image_names"`
	ImgPresignedUrls    []string               `json:"img_presigned_urls"`
	OutputPresignedUrls []string               `json:"output_presigned_urls"`
	CreateTime          string                 `json:"createTime"`
	StartTime           string                 `json:"startTime"`
	CompleteTime        string                 `json:"completeTime"`
	OwnerGroupOrRole    []string               `json:"owner_group_or_role"`
	Params              map[string]interface{} `json:"params"`
}

type InvocationRequest struct {
	ID            string                 `json:"id"`
	Task          string                 `json:"task"`
	Username      string                 `json:"username"`
	Models        map[string]interface{} `json:"models"`
	ParamS3       string                 `json:"param_s3"`
	PayloadString string                 `json:"payload_string"`
}

type InvocationResponse struct {
	Images     []string                 `json:"images"`
	Parameters map[string]interface{}   `json:"parameters"`
	Info       string                   `json:"info"`
	Details    []map[string]interface{} `json:"details"`
}

type UsedModel struct {
	S3        string `json:"s3"`
	ID        string `json:"id"`
	ModelName string `json:"model_name"`
	Type      string `json:"type"`
}

// ------------------- Train -------------------

type TrainPara struct {
	ID               string `json:"id"`
	TrainingID       string `json:"training_id"`
	SagemakerProgram string `json:"sagemaker_program"`
	Params           Params `json:"params"`
	S3InputPath      string `json:"s3-input-path"`
	S3OutputPath     string `json:"s3-output-path"`
	TrainingType     string `json:"training-type"`
}

type Params struct {
	EnableWd14Tagger          bool                      `json:"enable_wd14_tagger"`
	Wd14TaggerParamsSageMaker Wd14TaggerParamsSageMaker `json:"wd14_tagger_params"`
	TrainingParams            TrainingParams            `json:"training_params"`
	ConfigParams              ConfigParams              `json:"config_params"`
	TrainingType              string                    `json:"training_type"`
}

type Wd14TaggerParamsSageMaker struct {
	CharacterThreshold string `json:"character_threshold"`
	GeneralThreshold   string `json:"general_threshold"`
}

type TrainingParams struct {
	DatasetPath          string `json:"s3_data_path"`
	TrainingInstanceType string `json:"training_instance_type"`
	ModelPath            string `json:"s3_model_path"`
	FmType               string `json:"fm_type"`
	S3TomlPath           string `json:"s3_toml_path"`
}

type ConfigParams struct {
	SavingArguments   SavingArguments   `json:"saving_arguments"`
	TrainingArguments TrainingArguments `json:"training_arguments"`
}

type SavingArguments struct {
	OutputName       string `json:"output_name"`
	SaveEveryNEpochs int32  `json:"save_every_n_epochs"`
}

type TrainingArguments struct {
	MaxTrainEpochs int32 `json:"max_train_epochs"`
}

type CreateTrainReq struct {
	TaskId          string
	UserId          string
	InstanceName    string
	DatasetPath     string
	OutputModelPath string
}

type GetTrainReq struct {
	TaskId string
	UserId string
}

type GetTrainResp struct {
	Code      int32
	Message   string
	ModelPath string
	Status    aicommon.TaskStatus
	Progress  int32
}

type StopTrainReq struct {
	TaskId string
	UserId string
}

type CreateTrainingJobInput struct {
	TaskId           string           `json:"task_id"`
	DataPath         string           `json:"data_path"`
	ModelPath        string           `json:"model_path"`
	TomlPath         string           `json:"toml_path"`
	OutputPath       string           `json:"output_path"`
	FmType           string           `json:"fm_type"`
	EnableWd14Tagger bool             `json:"enable_wd14_tagger"`
	Wd14TaggerParams Wd14TaggerParams `json:"wd14_tagger_params"`
}

type Wd14TaggerParams struct {
	Onnx          bool `json:"onnx"`
	ForceDownload bool `json:"force_download"`
	FrequencyTags bool `json:"frequency_tags"`
}

// ------------------- FaceSwap -------------------

type FaceSwapReq struct {
	TaskId                      string      `json:"task_id"`
	TemplateImage               string      `json:"template_image"`
	FacialAreas                 [][]float64 `json:"facial_areas"`
	FaceImages                  []string    `json:"face_images"`
	Prompt                      string      `json:"prompt"`
	NegativePrompt              string      `json:"negative_prompt"`
	MaskStrength                float32     `json:"mask_strength"`
	IpAdapterScale              float32     `json:"ip_adapter_scale"`
	ControlnetConditioningScale float32     `json:"controlnet_conditioning_scale"`
	NumInferenceSteps           int32       `json:"num_inference_steps"`
	GuidanceScale               float32     `json:"guidance_scale"`
	ResultImageUpToken          string      `json:"result_image_up_token"`
	ThumbnailImageUpToken       string      `json:"thumbnail_image_up_token"`
}

type FaceSwapResp struct {
	Code        int32     `json:"code"`
	Message     string    `json:"message"`
	Score       []float32 `json:"score"`
	Retry       []int32   `json:"retry"`
	ResultImage string    `json:"result_image"`
	ImageMd5    string    `json:"image_md5"`
	ImageSize   int64     `json:"image_size"`
	TimeTakenMs int32     `json:"time_taken_ms"`
}

// ------------------- GenerateImage -------------------

type AiGenerateImageReq struct {
	TaskId                 string
	TaskType               aiparameter.TaskType
	ResultImageUpTokens    []string
	ThumbImageUpTokens     []string
	GenerateImageParameter GenerateImageParameter
	ImageToPromptModel     string
	DepthDetail            DepthToDetailParams
	ApplyInputMask         int32
}

type GenerateImageParameter struct {
	InferenceType     string       `json:"inference_type"`
	TaskType          string       `json:"task_type"`
	Prompt            string       `json:"prompt"`
	NegativePrompt    string       `json:"negative_prompt"`
	InitImage         []byte       `json:"init_image"`
	SamplerName       string       `json:"sampler_name"`
	BatchSize         int32        `json:"batch_size"`
	BatchCount        int32        `json:"batch_count"`
	Steps             int32        `json:"steps"`
	CfgScale          float32      `json:"cfg_scale"`
	Width             int32        `json:"width"`
	Height            int32        `json:"height"`
	DenoisingStrength float32      `json:"denoising_strength"`
	Controlnet        []Controlnet `json:"controlnet"`
	SdModel           string       `json:"sd_model"`
	LoraModels        []string     `json:"lora_models"`
	VaeModel          string       `json:"vae_model"`
	ControlnetModels  []string     `json:"controlnet_models"`
}

type Controlnet struct {
	Enabled bool   `json:"enabled"` // 启用
	Image   []byte `json:"image"`   // 图片信息
	//InputImage            []byte  `json:"input_image,omitempty"`
	Module                string  `json:"module"`                   // 模块
	Model                 string  `json:"model"`                    // 模型
	Weight                float32 `json:"weight"`                   // 权重
	ResizeMode            string  `json:"resize_mode"`              // 调整模式
	LowVram               bool    `json:"low_vram"`                 // 低VRAM
	ProcessorRes          int32   `json:"processor_res"`            // 处理器分辨率
	ThresholdA            int32   `json:"threshold_a"`              // 阈值A
	ThresholdB            int32   `json:"threshold_b"`              // 阈值B
	GuidanceStart         float32 ` json:"guidance_start"`          // 引导开始
	GuidanceEnd           float32 ` json:"guidance_end"`            // 引导结束
	PixelPerfect          bool    `json:"pixel_perfect"`            // 像素完美
	ControlMode           string  `json:"control_mode"`             // 控制模式
	InpaintCropInputImage bool    `json:"inpaint_crop_input_image"` // 修复裁剪输入图像
	HrOption              string  `json:"hr_option"`                // HR选项
	SaveDetectedMap       bool    `json:"save_detected_map"`        // 保存检测到的地图
	//AdvancedWeighting     *string `json:"advanced_weighting"`       // 高级加权
	IsUi        bool   `json:"is_ui"`        // 是否UI
	InputMode   string `json:"input_mode"`   // 输入模式
	BatchImages string `json:"batch_images"` // 批量图片
	OutputDir   string `json:"output_dir"`   // 输出目录
	Loopback    bool   `json:"loopback"`     // 回环
}

type AiGenerateImageResp struct {
	Code        int32
	Message     string
	ImageInfos  []*ImageInfo
	TimeTakenMs int32
}

type ImageToPromptRequest struct {
	Task               string             `json:"task"`
	Username           string             `json:"username"`
	PayloadString      string             `json:"payload_string"`
	InterrogatePayload InterrogatePayload `json:"interrogate_payload"`
}
type ImageToPromptResponse struct {
	Caption string `json:"caption"`
}

type InterrogatePayload struct {
	Image string `json:"image"`
	Model string `json:"model"`
}

type ImageInfo struct {
	Md5  string
	Size int64
	Data []byte
}

// ------------------- ImageUpscale -------------------

type ImageUpscaleReq struct {
	TaskId                string  `json:"task_id"`
	ImageUrl              string  `json:"image_url"`
	Outscale              float32 `json:"outscale"`
	Tile                  int32   `json:"tile"`
	TilePad               int32   `json:"tile_pad"`
	PrePad                int32   `json:"pre_pad"`
	AlphaUpsampler        string  `json:"alpha_upsampler"`
	ResultImageUpToken    string  `json:"result_image_up_token"`
	ThumbnailImageUpToken string  `json:"thumbnail_image_up_token"`
}

type ImageUpscaleResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ImageMd5    string `json:"image_md5"`
	ResultImage string `json:"result_image"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

// ------------------- Translate -------------------
type TranslateContext struct {
	Role string `json:"role"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type TranslateRecord struct {
	SentenceId int32
	Text       string
	StartTime  time.Time
	EndTime    time.Time
}

type TranslateReq struct {
	TaskId          string              `json:"task_id"`
	AppId           string              `json:"app_id"`
	Text            string              `json:"text"`
	SentenceId      int32               `json:"sentence_id"`
	LlmType         string              `json:"llm_type"`
	ServiceProvider string              `json:"service_provider"`
	EnableStream    bool                `json:"enable_stream"`
	FromLang        string              `json:"from_lang"`
	ToLang          string              `json:"to_lang"`
	Role            string              `json:"role"`
	Contexts        []*TranslateContext `json:"contexts"`
	IsSentence      bool                `json:"is_sentence"`
	LlmTypeSentence string              `json:"llm_type_sentence"`
}

type TranslateResp struct {
	Header        *aicommon.RspHeader `json:"rsp_header"`
	SentenceId    int32               `json:"sentence_id"`
	SentenceStart bool                `json:"sentence_start"`
	SentenceEnd   bool                `json:"sentence_end"`
	Text          string              `json:"text"`
	Language      string              `json:"language"`
	TimeTakenMs   int32               `json:"time_taken_ms"`
}

// ------------------- TranslateQuestionRecommend -------------------

type TranslateQuestionRecommendReq struct {
	TaskId          string              `json:"task_id"`
	ServiceProvider string              `json:"service_provider"`
	TargetLanguage  string              `json:"target_language"`
	QuestionsNumber int32               `json:"questions_number"`
	Contexts        []*TranslateContext `json:"contexts"`
}

type TranslateQuestionRecommendResp struct {
	Header      *aicommon.RspHeader `json:"rsp_header"`
	Questions   []string            `json:"questions"`
	Language    string              `json:"language"`
	TimeTakenMs int32               `json:"time_taken_ms"`
}

// ------------------- DifyWorkflow -------------------
type DifyWorkflowContext struct {
	Role string `json:"role"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type DifyWorkflowReq struct {
	TaskId          string              `json:"task_id"`
	Body            DifyWorkflowReqBody `json:"body"`
	ServiceProvider string              `json:"service_provider"`
	Contexts        []*TranslateContext `json:"contexts"`
}

type DifyWorkflowReqBody struct {
	Inputs       DifyWorkflowReqBodyInputs `json:"inputs"`
	ResponseMode string                    `json:"response_mode"`
	User         string                    `json:"user"`
}

type DifyWorkflowReqBodyInputs struct {
	Text string `json:"text"`
}

type DifyWorkflowResp struct {
	TaskId        string               `json:"task_id"`
	WorkflowRunId string               `json:"workflow_run_id"`
	Data          DifyWorkflowRespData `json:"data"`
}

type DifyWorkflowRespData struct {
	Id          string                  `json:"id"`
	WorflowId   string                  `json:"workflow_id"`
	Status      string                  `json:"status"`
	Outputs     DifyWorkflowRespOutputs `json:"outputs"`
	Error       string                  `json:"error"`
	ElapsedTime float32                 `json:"elapsed_time"`
	TotalTokens int32                   `json:"total_tokens"`
	TotalSteps  int32                   `json:"total_steps"`
	CreatedAt   int32                   `json:"created_at"`
	FinishedAt  int32                   `json:"finished_at"`
}

type DifyWorkflowRespOutputs struct {
	Text string `json:"text"`
}

// ------------------- DifyChatflow -------------------
type DifyChatflowContext struct {
	Role string `json:"role"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type DifyChatflowReq struct {
	TaskId          string              `json:"task_id"`
	Body            DifyChatflowReqBody `json:"body"`
	ServiceProvider string              `json:"service_provider"`
	NeedReply       bool                `json:"need_reply"`
	NeedEmotion     bool                `json:"need_emotion"`
	NeedQuestion    bool                `json:"need_question"`
	ChatFlowName    string              `json:"chat_flow_name"`
	StationSn       string              `json:"station_sn"` // 可选值 t9000_manager, soundcore_manager
	Params          map[string]string   `json:"params"`
	Contexts        []*TranslateContext `json:"contexts"`
}

type DifyChatflowReqBody struct {
	Inputs         DifyChatflowReqBodyInputs `json:"inputs"`
	Query          string                    `json:"query"`
	ResponseMode   string                    `json:"response_mode"`
	User           string                    `json:"user"`
	ConversationId string                    `json:"conversation_id"`
}

type DifyChatflowReqBodyInputs map[string]interface{}

type DifyChatflowResp struct {
	Event          string                   `json:"event"`
	TaskId         string                   `json:"task_id"`
	Id             string                   `json:"id"`
	MessageId      string                   `json:"message_id"`
	ConversationId string                   `json:"conversation_id"`
	Mode           string                   `json:"mode"`
	Answer         string                   `json:"answer"`
	MetaData       DifyChatflowRespMetaData `json:"metadata"`
	CreatedAt      int32                    `json:"created_at"`
	Command        string                   `json:"command"`
	CommandArgs    string                   `json:"command_args"`
	TTSText        string                   `json:"tts_text"`
	Question       []string                 `json:"-"`
	Emotion        string                   `json:"-"`
	SentenceEnd    bool                     `json:"-"`
	SentenceStart  bool                     `json:"-"`
}

type DifyChatflowRespMetaData struct {
	Usage DifyChatflowRespUsage `json:"usage"`
}

type DifyChatflowRespUsage struct {
	PromptTokens        int     `json:"prompt_tokens"`
	PromptUnitPrice     string  `json:"prompt_unit_price"`
	PromptPriceUnit     string  `json:"prompt_price_unit"`
	PromptPrice         string  `json:"prompt_price"`
	CompletionTokens    int     `json:"completion_tokens"`
	CompletionUnitPrice string  `json:"completion_unit_price"`
	CompletionPriceUnit string  `json:"completion_price_unit"`
	CompletionPrice     string  `json:"completion_price"`
	TotalTokens         int32   `json:"total_tokens"`
	TotalPrice          string  `json:"total_price"`
	Currency            string  `json:"currency"`
	Latency             float32 `json:"latency"`
}

// ------------------- SpeechToText -------------------

type SpeechToTextReq struct {
	TaskId             string                   `json:"task_id"`
	AppId              string                   `json:"app_id"`
	TargetLang         string                   `json:"target_lang"`
	AddPunctuation     bool                     `json:"add_punctuation"`
	EnableWord         bool                     `json:"enable_word"`
	MaxSentenceSilence int32                    `json:"max_sentence_silence"`
	MaxStartSilence    int32                    `json:"max_start_silence"`
	MaxEndSilence      int32                    `json:"max_end_silence"`
	ServiceProvider    string                   `json:"service_provider"`
	Audio              *aicommon.AudioInfo      `json:"audio"`
	UseTempResult      bool                     `json:"use_temp_result"`
	HotWordsList       []*aicommon.HotWordsInfo `json:"hot_words_list"`
}

type SpeechToTextResp struct {
	Header        *aicommon.RspHeader `json:"rsp_header"`
	SegmentId     int32               `json:"segment_id"`
	SegmentEnd    bool                `json:"segment_end"`
	Text          string              `json:"text"`
	Language      string              `json:"language"`
	Segments      []*aicommon.Segment `json:"segments"`
	TimeTakenMs   int32               `json:"time_taken_ms"`
	SpeechEnd     bool                `json:"speech_end"`
	UseTempResult bool                `json:"use_temp_result"`
}

// ------------------- TextToSpeech -------------------

type TextToSpeechReq struct {
	TaskId          string `json:"task_id"`
	AppId           string `json:"app_id"`
	Format          string `json:"format"`
	SampleRate      int32  `json:"sample_rate"`
	Bitrate         int32  `json:"bitrate"`
	Voice           string `json:"voice"`
	Speed           int32  `json:"speed"`
	Volume          int32  `json:"volume"`
	Pitch           int32  `json:"pitch"`
	Channels        int32  `json:"channels"`
	Language        string `json:"language"`
	EnableSubtitle  bool   `json:"enable_subtitle"`
	ServiceProvider string `json:"service_provider"`
	Text            string `json:"text"`
	SentenceId      int32  `json:"sentence_id"`
}

type TextToSpeechResp struct {
	Header        *aicommon.RspHeader  `json:"rsp_header"`
	SentenceId    int32                `json:"sentence_id"`
	Audio         *aicommon.AudioInfo  `json:"audio"`
	Subtitles     []*aicommon.Subtitle `json:"subtitles"`
	SentenceStart bool                 `json:"sentence_start"`
	TimeTakenMs   int32                `json:"time_taken_ms"`
}

// ------------------- LanguageDetect -------------------

type LanguageDetectReq struct {
	TaskId          string              `json:"task_id"`
	ServiceProvider string              `json:"service_provider"`
	Text            string              `json:"text"`
	Audio           *aicommon.AudioInfo `json:"audio"`
}

type LanguageDetectResp struct {
	Header      *aicommon.RspHeader `json:"rsp_header"`
	Language    string              `json:"language"`
	Confidence  float32             `json:"confidence"`
	TimeTakenMs int32               `json:"time_taken_ms"`
}

// ------------------- OpusWrapper -------------------

type OpusWrapperReq struct {
	TaskId          string              `json:"task_id"`
	ServiceProvider string              `json:"service_provider"`
	IsEnableEnc     bool                `json:"is_enable_enc"`
	Source          *aicommon.AudioInfo `json:"source"`
	Target          *aicommon.AudioInfo `json:"target"`
}

type OpusWrapperResp struct {
	Header      *aicommon.RspHeader `json:"rsp_header"`
	Audio       *aicommon.AudioInfo `json:"audio"`
	TimeTakenMs int32               `json:"time_taken_ms"`
}

type InstantStyleReq struct {
	TaskId                      string  `json:"task_id"`
	StyleImage                  string  `json:"style_image"`
	InputImage                  string  `json:"input_image"`
	Prompt                      string  `json:"prompt"`
	NegativePrompt              string  `json:"negative_prompt"`
	NegativeContentPrompt       string  `json:"neg_content_prompt"`
	NegativeContentScale        float32 `json:"neg_content_scale"`
	IpAdapterScale              float32 `json:"ip_adapter_scale"`
	ControlnetConditioningScale float32 `json:"controlnet_conditioning_scale"`
	NumInferenceSteps           int32   `json:"num_inference_steps"`
	GuidanceScale               float32 `json:"guidance_scale"`
	ResultImageUpToken          string  `json:"result_image_up_token"`
	ThumbnailImageUpToken       string  `json:"thumbnail_image_up_token"`
}

type InstantStyleResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ResultImage string `json:"result_image"`
	ImageMd5    string `json:"image_md5"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

type FastTranscribeReq struct {
	TaskId          string   `json:"task_id"`          // 任务id
	AppId           string   `json:"app_id"`           // 应用id
	ServiceProvider string   `json:"service_provider"` // 服务商
	Language        string   `json:"language"`         // 语言
	Diarization     bool     `json:"diarization"`      // 是否需要说话人分离
	MaxSpeakers     int64    `json:"max_speakers"`     // 最大说话人数
	AudioUrls       []string `json:"audio_urls"`       // 音频url列表
	ResultUrl       string   `json:"result_url"`       // 结果url
	Locales         []string `json:"locales"`
}

type FastTranscribeResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ResultPath  string `json:"result_path"`
	ImageMd5    string `json:"image_md5"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

type TextSummaryReq struct {
	TaskId          string   `json:"task_id"`          // 任务id
	AppId           string   `json:"app_id"`           // 应用id
	ServiceProvider string   `json:"service_provider"` // 服务商
	TemplateContent string   `json:"template_content"` // 模板内容
	Language        string   `json:"language"`         // 语言
	AesKey          string   `json:"aes_key"`          // 加密key
	TextUrls        []string `json:"text_urls"`        // 文本url列表
	MultiTextMode   bool     `json:"multi_mode"`       // 是否多文本模式
	ResultUrl       string   `json:"result_url"`       // 结果url
}

type TextSummaryResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ResultPath  string `json:"result_path"`
	ImageMd5    string `json:"image_md5"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

type DepthMapGenerationReq struct {
	TaskId             string `json:"task_id"`
	ModelType          int32  `json:"model_type"`
	ImageUrl           string `json:"image_url"`
	IsBase64           bool   `json:"is_base64"`
	ResultImageUpToken string `json:"result_image_up_token"`
}

type DepthMapGenerationResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ResultImage string `json:"result_image"`
	ImageMd5    string `json:"image_md5"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

type InstantStylePlusReq struct {
	TaskId                      string  `json:"task_id"`
	StyleImage                  string  `json:"style_image"`
	ContentImage                string  `json:"content_image"`
	Prompt                      string  `json:"prompt"`
	NegativePrompt              string  `json:"negative_prompt"`
	GuidanceScale               float32 `json:"guidance_scale"`
	NumInferenceSteps           int32   `json:"num_inference_steps"`
	NumInversionSteps           int32   `json:"num_inversion_steps"`
	NumRenoiseSteps             int32   `json:"num_renoise_steps"`
	ControlnetConditioningScale float32 `json:"controlnet_conditioning_scale"`
	StyleGuidanceScale          float32 `json:"style_guidance_scale"`
	ContentGuidanceScale        float32 `json:"content_guidance_scale"`
	ResultImageUpToken          string  `json:"result_image_up_token"`
	ThumbnailImageUpToken       string  `json:"thumbnail_image_up_token"`
}

type InstantStylePlusResp struct {
	Code        int32  `json:"code"`
	Message     string `json:"message"`
	ResultImage string `json:"result_image"`
	ImageMd5    string `json:"image_md5"`
	ImageSize   int64  `json:"image_size"`
	TimeTakenMs int32  `json:"time_taken_ms"`
}

type RemoveBackgroundReq struct {
	TaskId                string `json:"task_id"`
	ImageUrl              string `json:"image_url"`
	ResultImageUpToken    string `json:"result_image_up_token"`
	ThumbnailImageUpToken string `json:"thumbnail_image_up_token"`
	IsMask                int8   `json:"is_mask"`
}

type RemoveBackgroundResp struct {
	Code           int32  `json:"code"`
	Message        string `json:"message"`
	ResultImage    string `json:"result_image"`
	ImageMd5       string `json:"image_md5"`
	ImageSize      int64  `json:"image_size"`
	TimeTakenMs    int32  `json:"time_taken_ms"`
	ThumbnailImage string `json:"thumbnail_image"`
}

type ComfyUiStyleTransferReq struct {
	TaskId                 string
	TaskType               aiparameter.TaskType
	ResultImageUpTokens    []string
	ThumbImageUpTokens     []string
	GenerateImageParameter string
	InputImage             string
	ControlNetImage        []string
	ImageNum               int32
	DepthDetail            DepthToDetailParams
	ApplyInputMask         int32
	Images                 [][]byte
}

type ComfyUiStyleTransferResp struct {
	Id         string      `json:"id"`
	Prompt     interface{} `json:"prompt"`
	Images     []string    `json:"images"`
	ImagesSize []int       `json:"images_size"`
	CostTime   int64       `json:"cost_time"`
}

type DepthToDetailParams struct {
	DepthToDetail struct {
		ApplyBlackMask bool    `json:"apply_black_mask"`
		ApplyGrayImage bool    `json:"apply_gray_image"`
		GrayScale      float64 `json:"gray_scale"`
		PixPercent     float64 `json:"pix_percent"`
	} `json:"depth_to_detail"`
}
