package types

const (
	ReqStatusAlone  = 0 // 单包
	ReqStatusFirst  = 1
	ReqStatusMiddle = 2
	ReqStatusEnd    = 3
	ReqStatusStop   = 4
)

const (
	ReqTypeAudio        = 0
	ReqTypeText         = 1
	ReqTypeSimultaneous = 2 // 实时音频
	ReqTypeLangDetect   = 3 // 语种检测
)

const (
	MessageTypePreset      = 1  // 预设问题，开场白
	MessageTypeSimilar     = 2  // 相似问题推荐
	MessageTypeCustomer    = 3  // 客服信息
	MessageTypeSafetyDaily = 4  // 安全日报
	MessageTypeTTS         = 10 // 语音合成
)

const (
	CmdPing      = "ping"      // 用于测试
	CmdTranslate = "translate" // 语音翻译
	CmdChat      = "chat"      // 聊天
)

const (
	LoginTypeAccount = 0 // 账号登录
	LoginTypeGuest   = 1 // 游客登录
)

const (
	TaskTypeSpeechToText    = 20 // 语音转文本
	TaskTypeTextToSpeech    = 21 // 文本转语音
	TaskTypeTranslate       = 22 // 翻译
	TaskTypeChat            = 28 // 聊天
	TaskTypeEmotion         = 29 // 情感识别
	TaskTypeSimilarQuestion = 32 // 相似问题
)

const (
	RespCodeSuccess                = 0
	RespCodeConnErr                = 1
	RespCodeSendErr                = 2
	RespCodeRecvErr                = 3
	RespCodeUndetectedData         = 4
	RespDataDetectedDataButTimeout = 5
	RespDataTimeout                = 6
	RespCodeDataErr                = 10
	RespCodeCodecErr               = 11
	RespCodeDetectLanguageTimeout  = 12 // 语种检测超时
	RespCodeDetectLanguageEqual    = 13 // 语种检测 源语言和目标语言相同
)

const (
	TranslateContextListDataRedisKey = "{%s:translate_context_data:%s:%s}:list" // 翻译上下文list数据
	TranslateContextHashDataRedisKey = "{%s:translate_context_data:%s:%s}:hash" // 翻译上下文hash数据
	TranslateModelRedisKey           = "%s:translate_model:%s"                  // 翻译模型, 例如：soundcore_app:translate_model:anker
	SessionDataRedisKey              = "%s:session_data:%s:%s"                  // 会话数据, 例如：soundcore_app:session_data:userId:sessionId
)

const (
	ModelAnker  = "anker"
	ModelAliyun = "aliyun"
)

const (
	ChatflowNameT9000     = "t9000_manager"
	ChatflowNameSoundcore = "soundcore_manager"
	ChatflowNameAID       = "hearing_aid_manager"
	ChatflowNameDIFM      = "DIFM_manager"
)

const (
	Eufy_APPID      = "eufy"
	Soundcore_APPID = "soundcore_app"
	// 助听APP
	HEARD_AID_APPID = "hearing_app"
	DIFM_APP        = "difm"
)

const ( //自动语种检测
	AutoDetectLanguage = "auto"
)

const (
	AudioFormatPcm  = "pcm"
	AudioFormatMp3  = "mp3"
	AudioFormatWav  = "wav"
	AudioFormatOpus = "opus"
)
