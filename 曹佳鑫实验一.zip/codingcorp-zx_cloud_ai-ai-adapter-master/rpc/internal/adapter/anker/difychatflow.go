package anker

import (
	"bufio"
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/go-resty/resty/v2"
	"github.com/zeromicro/go-zero/core/logx"
)

const (
	REQUEST_TYPE_CHATFLOW = "chatflow"
	REQUEST_TYPE_EMOTION  = "chatflow_emotion"
	REQUEST_TYPE_QUESTION = "question"
	// 修改范式 将指令下发节点改为llm,
	// 后续可能需要动态配置
	DIFY_COMMAND_NODE              = "llm"
	DIFY_COMMAND_TITLE             = "command_delivery"
	DIFY_COMMAND_LIVE_STREAM_TITLE = "command_live_stream"
	DIFY_COMMAND_MODEL_CALL        = "model_call_tool"
	SentenceEndStr                 = "。？！.~?!"
	difyEventError                 = "error"
	difyEventMessage               = "message"
	difyEventNodeFinished          = "node_finished"
)

type DifyClient struct {
	ctx        context.Context
	svcContext *svc.ServiceContext
	logx.Logger
	start time.Time
	Host  string

	request  <-chan *adaptermodel.DifyChatflowReq
	response chan<- *adaptermodel.DifyChatflowResp
	first    *adaptermodel.DifyChatflowReq
}

func NewDifyClient(ctx context.Context, svcContext *svc.ServiceContext,
	host string,
	request <-chan *adaptermodel.DifyChatflowReq,
	response chan<- *adaptermodel.DifyChatflowResp,
	first *adaptermodel.DifyChatflowReq,
) *DifyClient {
	return &DifyClient{
		ctx:        ctx,
		svcContext: svcContext,
		Logger:     logx.WithContext(ctx),
		start:      time.Now(),
		Host:       host,
		request:    request,
		response:   response,
		first:      first,
	}
}

func (c DifyClient) ChatflowStream() (err error) {
	defer close(c.response)
	err = c.Chatflow(c.first)
	if err != nil {
		return fmt.Errorf("Chatflow failed, err: %v", err)
	}
	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop failed, err: %v", err)
	}
	return
}

// 根据不同的请求类型 取对应的token
func (c DifyClient) getChatflowParams(req *adaptermodel.DifyChatflowReq) (res []DifyChatflowRequest) {
	localConfig := config.GetSrvConfig().DifyChatflow
	// todo soundcore 语音助手后续可能也需要类似的情绪和相似问题的处理
	if req.NeedReply {
		token := ""
		// ChatFlowName 在不传的时候默认是t9000
		switch req.ChatFlowName {
		case config.T9000_CHATFLOW_NAME:
			// t9000的助手是默认的
			token = localConfig.ChatflowKey
		case config.SOUNDCORE_CHATFLOW_NAME:
			token = localConfig.ChatflowSoundcoreManagerKey
		case config.HEARING_AID_CHATFLOW_NAME:
			token = localConfig.ChatflowHearingAidManagerKey
		case config.DIFM_CHATFLOW_NAME:
			token = localConfig.ChatflowDifmManagerKey
		}
		c.Infof("Chatflow, token: %s", token)
		history := make([]DifyChatHistory, 0)
		for _, context := range req.Contexts {
			history = append(history, DifyChatHistory{
				Role: context.Role,
				Text: context.Text,
			})
		}
		res = append(res, DifyChatflowRequest{
			Query:          req.Body.Query,
			ResponseMode:   req.Body.ResponseMode,
			ConversationId: req.Body.ConversationId,
			User:           req.Body.User,
			Token:          token,
			RequestType:    REQUEST_TYPE_CHATFLOW,
			Inputs:         req.Body.Inputs,
			History:        history,
		})
	}
	if req.NeedEmotion {
		res = append(res, DifyChatflowRequest{
			Query:          req.Body.Query,
			ResponseMode:   config.DIFY_RESPONSE_MODE_BLOCKING,
			ConversationId: req.Body.ConversationId,
			User:           req.Body.User,
			Token:          localConfig.ChatflowEmotionKey,
			RequestType:    REQUEST_TYPE_EMOTION,
		})
	}
	if req.NeedQuestion {
		res = append(res, DifyChatflowRequest{
			Query:          req.Body.Query,
			ResponseMode:   config.DIFY_RESPONSE_MODE_BLOCKING,
			ConversationId: req.Body.ConversationId,
			User:           req.Body.User,
			Token:          localConfig.ChatflowQuestionKey,
			RequestType:    REQUEST_TYPE_QUESTION,
		})
	}
	return
}

func (c DifyClient) doRequest(chatflowReq DifyChatflowRequest, wg *sync.WaitGroup) (err error) {
	defer wg.Done()
	var errorStr string
	if chatflowReq.ResponseMode == config.DIFY_RESPONSE_MODE_BLOCKING {
		c.Infof("Chatflow, blocking, request: %+v", chatflowReq)
		restyReq := resty.New().SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
			SetTimeout(60*time.Second).R().
			SetContext(c.ctx).
			SetHeader("Authorization", fmt.Sprintf("Bearer %s", chatflowReq.Token)).
			SetBody(chatflowReq)
		for i := 0; i < 3; i++ {
			ret, err := restyReq.Post(c.Host)
			if err != nil {
				c.Errorf("Chatflow, blocking, Post failed, err: %v", err)
				time.Sleep(500 * time.Millisecond)
				continue
			}
			defer ret.RawBody().Close()
			if ret.StatusCode() != http.StatusOK {
				c.Errorf("Chatflow, blocking, response status code: %d, error : %s", ret.StatusCode(), string(ret.Body()))
				errorStr += fmt.Sprintf("Chatflow, blocking, response status code: %d, error : %s \n", ret.StatusCode(), string(ret.Body()))
				time.Sleep(500 * time.Millisecond)
				continue
			}
			var resp DifyChatflowBlockingResponse
			err = common.JsonToAny(ret.Body(), &resp)
			if err != nil {
				c.Errorf("Chatflow, blocking, json unmarshal error: %v  raw json : %s param: %+v", err, string(ret.Body()), chatflowReq)
				time.Sleep(500 * time.Millisecond)
				continue
			}
			res := adaptermodel.DifyChatflowResp{
				Answer:         resp.Answer,
				ConversationId: resp.ConversationId,
				CreatedAt:      int32(resp.CreatedAt),
				SentenceStart:  true,
				SentenceEnd:    true,
			}
			if chatflowReq.RequestType == REQUEST_TYPE_EMOTION {
				res.Emotion = resp.Answer
				res.Answer = ""
			}
			if chatflowReq.RequestType == REQUEST_TYPE_QUESTION {
				err := common.JsonToAny([]byte(resp.Answer), &res.Question)
				res.Answer = ""
				if err != nil {
					c.Errorf("Chatflow, blocking, json unmarshal error: %v raw text %v rawbody %v", err, resp.Answer, string(ret.Body()))
					return err
				}
			}
			c.Infof("Chatflow, blocking, response: %+v", res)
			c.response <- &res
			return nil
		}
		return fmt.Errorf("chatflow, blocking, failed after 3 retries error string %s", errorStr)
	}
	restyReq := resty.New().SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
		SetTimeout(60*time.Second).R().
		SetContext(c.ctx).
		SetDoNotParseResponse(true).
		SetHeader("Authorization", fmt.Sprintf("Bearer %s", chatflowReq.Token)).
		SetBody(chatflowReq)
	c.Infof("Chatflow, stream, request: %+v", chatflowReq)
	for i := 0; i < 3; i++ {
		firstPackage := true
		ret, err := restyReq.Post(c.Host)
		if err != nil {
			c.Errorf("Chatflow, stream, Post failed, err: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		defer ret.RawBody().Close()
		c.Infof("Chatflow, stream, response status code: %d", ret.StatusCode())
		if ret.StatusCode() != http.StatusOK {
			c.Errorf("Chatflow, stream, response status code: %d, error : %s reqparam: %+v", ret.StatusCode(), string(ret.Body()), chatflowReq)
			errorStr += fmt.Sprintf("Chatflow, stream, response status code: %d, error : %s reqparam: %+v\n", ret.StatusCode(), string(ret.Body()), chatflowReq)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		// 打印返回的数据
		//c.Infof("Chatflow, stream, response: %s", ret.Body())
		scanner := bufio.NewScanner(ret.RawBody())
		// 设置更大的缓冲区，避免超出默认限制
		buf := make([]byte, 0, 64*1024)
		scanner.Buffer(buf, 1024*1024)

		fullText := ""
		ttsText := ""
		liveCommand := false
		for scanner.Scan() {
			text := scanner.Text()
			c.Debugf("Chatflow, stream, response: %s", text)
			lines := strings.Split(text, "\n")
			for _, line := range lines {
				if strings.TrimSpace(line) == "" {
					continue
				}
				line = strings.TrimPrefix(line, "data: ")
				// 如果内容只是event: ping的话
				if line == "event: ping" {
					continue
				}
				// c.Debugf("Chatflow, stream, line: %s", line)
				var event DifyChatflowStreamResponse
				err = common.JsonToAny([]byte(line), &event)
				if err != nil {
					c.Errorf("Chatflow, stream, error unmarshalling JSON %+v raw_content: %s", err, line)
					continue
				}

				c.Debugf("Chatflow, stream, event: %+v", event)

				if event.Event == difyEventError {
					c.Errorf("Chatflow, stream, error code: %s message: %s", event.Code, event.Message)
					return fmt.Errorf("Chatflow, stream, error code: %s message: %s", event.Code, event.Message)
				}

				if event.Event == difyEventMessage {
					// 判断是否为live_stream的消息
					// 都转换为小写在比较
					// 这条消息
					if strings.ToLower(event.NodeTitle) == DIFY_COMMAND_LIVE_STREAM_TITLE {
						// 如果是以[开始，则认为是live_s
						if strings.HasPrefix(event.Answer, "[") {
							c.Infof("Chatflow, stream, live_stream message: %s", event.Answer)
							liveCommand = true
							continue
						}
						if liveCommand {
							c.Infof("Chatflow, stream, live_stream message: %s", event.Answer)
							continue
						}
					}
					fullText += event.Answer
					ttsText += event.Answer
					res := adaptermodel.DifyChatflowResp{
						Answer:         fullText,
						ConversationId: event.ConversationId,
						CreatedAt:      int32(time.Now().Unix()),
						SentenceStart:  firstPackage,
					}
					if len(ttsText) > 10 || strings.ContainsAny(ttsText, SentenceEndStr) {
						res.TTSText = ttsText
						ttsText = ""
					}
					c.response <- &res
					firstPackage = false
				}
				if event.Event == difyEventNodeFinished {
					if event.Data.Title == DIFY_COMMAND_LIVE_STREAM_TITLE {
						commands := event.Data.Outputs.Text
						if len(commands) > 0 && commands[0] == '[' {
							// 下发指令
							var command CommandType
							command.Command = DIFY_COMMAND_MODEL_CALL
							command.CommandArgs = make(map[string]interface{})
							command.CommandArgs["tool_name"] = commands
							command.CommandArgs["tool_args"] = ""
							c.Infof("send command to chatflow %+v", commands)

							commandArgsJson, _ := common.AnyToJson(command.CommandArgs)
							res := adaptermodel.DifyChatflowResp{
								Command:        command.Command,
								CommandArgs:    string(commandArgsJson),
								ConversationId: event.ConversationId,
								CreatedAt:      int32(time.Now().Unix()),
							}
							c.response <- &res
						}
					}
					// 下发指令不一定要是大模型节点，普通节点也可以
					if event.Data.Title == DIFY_COMMAND_TITLE {
						commands := event.Data.Outputs.Text
						// 加入一些普通的防呆
						// 去掉markdown的格式
						commands = strings.ReplaceAll(commands, "```", "")
						commands = strings.ReplaceAll(commands, "```json", "")
						// 解析出来
						var command CommandType
						err = common.JsonToAny([]byte(commands), &command)
						if err != nil {
							logx.Infof("commands json unmarshal error: %v  commands %s", err, commands)
							continue
						}
						c.Infof("send command to chatflow %+v", commands)

						commandArgsJson, _ := common.AnyToJson(command.CommandArgs)
						res := adaptermodel.DifyChatflowResp{
							Command:        command.Command,
							CommandArgs:    string(commandArgsJson),
							ConversationId: event.ConversationId,
							CreatedAt:      int32(time.Now().Unix()),
						}
						c.response <- &res
					}
				}
			}
		}

		// 检查是否因为错误而结束扫描
		if err := scanner.Err(); err != nil {
			c.Errorf("Chatflow, stream, scanner error: %v", err)
			// 可以选择返回错误或继续处理已收到的数据
			errorStr += fmt.Sprintf("Scanner error: %v\n", err)
			// 即使有错误也发送已处理的数据
			if fullText != "" {
				c.response <- &adaptermodel.DifyChatflowResp{
					SentenceEnd: true,
					Answer:      fullText,
				}
			}
			return fmt.Errorf("scanner error: %v", err)
		}

		// 扫描正常结束后发送最后一个响应
		c.response <- &adaptermodel.DifyChatflowResp{
			SentenceEnd: true,
			Answer:      fullText,
		}
		return nil
	}
	return fmt.Errorf("chatflow, stream, failed after 3 retries errors string %s", errorStr)
}

func (c DifyClient) Chatflow(chatflowReq *adaptermodel.DifyChatflowReq) error {
	params := c.getChatflowParams(chatflowReq)
	c.Infof("Chatflow, request: %+v", chatflowReq)
	var wg sync.WaitGroup
	errChan := make(chan error, len(params))
	defer close(errChan)
	for _, param := range params {
		wg.Add(1)
		p := param
		go func() {
			errChan <- c.doRequest(p, &wg)
		}()
	}
	wg.Wait()
	// 处理errchan里面的错误, 如果有多个错误，拼接成一个
	var errStr string
	for i := 0; i < len(params); i++ {
		err := <-errChan
		if err != nil {
			errStr += err.Error() + ";"
		}
	}
	if errStr != "" {
		return errors.New(errStr)
	}
	return nil
}

func (c DifyClient) loop() (err error) {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("send text to aliyun llm end, ctx done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send text to aliyun llm end, request channel closed")
				return
			}
			if req == nil {
				c.Errorf("send text to aliyun llm end, the request is nil")
				return fmt.Errorf("send text to aliyun llm end, the request is nil")
			}

			err = c.Chatflow(req)
			if err != nil {
				return fmt.Errorf("loop translate failed, err: %v", err)
			}
		}
	}
}

func (s *AnkerAdapter) DifyChatflowHandler(req *adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error) {
	url := config.GetSrvConfig().DifyChatflow.Url
	token := config.GetSrvConfig().DifyChatflow.Token

	input, err := common.AnyToJson(req.Body)

	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", url, token, input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.DifyChatflowResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) DifyChatflowStreamHandler(request <-chan *adaptermodel.DifyChatflowReq, response chan<- *adaptermodel.DifyChatflowResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	difyreq, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	url := config.GetSrvConfig().DifyChatflow.Url
	client := NewDifyClient(s.ctx, s.svcCtx, url, request, response, difyreq)
	err := client.ChatflowStream()
	if err != nil {
		return fmt.Errorf("ChatflowStream failed, err: %v", err)
	}
	return nil
}

type DifyChatHistory struct {
	Role string `json:"role"`
	Text string `json:"content"`
}

type DifyChatflowRequest struct {
	Inputs         map[string]interface{} `json:"inputs"`
	Query          string                 `json:"query"`
	ResponseMode   string                 `json:"response_mode"`
	ConversationId string                 `json:"conversation_id"`
	User           string                 `json:"user"`
	Files          []struct {
		Type           string `json:"type"`
		TransferMethod string `json:"transfer_method"`
		Url            string `json:"url"`
	} `json:"files"`
	Token       string            `json:"-"`
	RequestType string            `json:"-"`
	History     []DifyChatHistory `json:"history"`
}

type DifyChatflowBlockingResponse struct {
	Event          string `json:"event"`
	MessageId      string `json:"message_id"`
	ConversationId string `json:"conversation_id"`
	Mode           string `json:"mode"`
	Answer         string `json:"answer"`
	Emotion        string `json:"-"`
	Metadata       struct {
		Usage struct {
			PromptTokens        int     `json:"prompt_tokens"`
			PromptUnitPrice     string  `json:"prompt_unit_price"`
			PromptPriceUnit     string  `json:"prompt_price_unit"`
			PromptPrice         string  `json:"prompt_price"`
			CompletionTokens    int     `json:"completion_tokens"`
			CompletionUnitPrice string  `json:"completion_unit_price"`
			CompletionPriceUnit string  `json:"completion_price_unit"`
			CompletionPrice     string  `json:"completion_price"`
			TotalTokens         int     `json:"total_tokens"`
			TotalPrice          string  `json:"total_price"`
			Currency            string  `json:"currency"`
			Latency             float64 `json:"latency"`
		} `json:"usage"`
		RetrieverResources []struct {
			Position     int     `json:"position"`
			DatasetId    string  `json:"dataset_id"`
			DatasetName  string  `json:"dataset_name"`
			DocumentId   string  `json:"document_id"`
			DocumentName string  `json:"document_name"`
			SegmentId    string  `json:"segment_id"`
			Score        float64 `json:"score"`
			Content      string  `json:"content"`
		} `json:"retriever_resources"`
	} `json:"metadata"`
	CreatedAt int `json:"created_at"`
}

type CommandType struct {
	Command     string                 `json:"command"`
	CommandArgs map[string]interface{} `json:"command_args"`
}

type DifyChatflowStreamResponseData struct {
	Id                string      `json:"id"`
	NodeId            string      `json:"node_id"`
	NodeType          string      `json:"node_type"`
	Title             string      `json:"title"`
	Index             int         `json:"index"`
	PredecessorNodeId interface{} `json:"predecessor_node_id"`
	Inputs            interface{} `json:"inputs"`
	ProcessData       interface{} `json:"process_data"`
	Outputs           struct {
		Answer string        `json:"answer,omitempty"`
		Text   string        `json:"text,omitempty"`
		Files  []interface{} `json:"files,omitempty"`
	} `json:"outputs"`
	Status            string      `json:"status"`
	Error             interface{} `json:"error"`
	ElapsedTime       float64     `json:"elapsed_time"`
	ExecutionMetadata struct {
		ParallelId                string      `json:"parallel_id"`
		ParallelStartNodeId       string      `json:"parallel_start_node_id"`
		ParentParallelId          interface{} `json:"parent_parallel_id"`
		ParentParallelStartNodeId interface{} `json:"parent_parallel_start_node_id"`
	} `json:"execution_metadata"`
	CreatedAt                 int           `json:"created_at"`
	FinishedAt                int           `json:"finished_at"`
	Files                     []interface{} `json:"files"`
	ParallelId                string        `json:"parallel_id"`
	ParallelStartNodeId       string        `json:"parallel_start_node_id"`
	ParentParallelId          interface{}   `json:"parent_parallel_id"`
	ParentParallelStartNodeId interface{}   `json:"parent_parallel_start_node_id"`
	IterationId               interface{}   `json:"iteration_id"`
}

type DifyChatflowStreamResponse struct {
	Event          string                         `json:"event"`
	Answer         string                         `json:"answer"`
	ConversationId string                         `json:"conversation_id"`
	MessageId      string                         `json:"message_id"`
	CreatedAt      int                            `json:"created_at"`
	TaskId         string                         `json:"task_id"`
	WorkflowRunId  string                         `json:"workflow_run_id"`
	Data           DifyChatflowStreamResponseData `json:"data"`
	Code           string                         `json:"code"`
	Message        string                         `json:"message"`
	NodeTitle      string                         `json:"node_title"`
}
