package anker

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
	"google.golang.org/grpc/metadata"
)

type AnkerAdapter struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewAnkerAdapter(ctx context.Context, svcCtx *svc.ServiceContext) *AnkerAdapter {
	return &AnkerAdapter{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (s *AnkerAdapter) GetHostWithInvocations(endpointName string) (string, error) {
	host, err := url.JoinPath(endpointName, "invocations")
	if err != nil {
		return "", fmt.Errorf("join path failed, error:%s", err)
	}
	return host, nil
}

func (s *AnkerAdapter) RequestWithJSON(ctx context.Context, method, url string, token string, input []byte, timeout time.Duration) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, method, url, bytes.NewReader(input))
	if err != nil {
		return nil, fmt.Errorf("create http request failed, error:%s", err)
	}
	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}

	// s.Logger.Infof("RequestWithJSON req %+v", req)

	client := &http.Client{Timeout: timeout * time.Second}
	resp, err := client.Do(req)

	// s.Logger.Infof("RequestWithJSON resp %+v", resp)

	if err != nil {
		return nil, fmt.Errorf("http request failed, error:%s", err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response body failed, error:%s", err)
	}

	// s.Logger.Infof("RequestWithJSON resp body %s", string(body))

	return body, nil
}

// FaceSwapHandler
func (s *AnkerAdapter) FaceSwapHandler(req *adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error) {
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	s.Infof("FaceSwapHandler, task id: %s, input: %s", req.TaskId, string(input))

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.FaceSwapEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.FaceSwapResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) AiGenerateImageHandler(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	req.GenerateImageParameter.InferenceType = adaptermodel.SAGEMAKER_INFERENCE_TYPE_Real_time

	switch req.TaskType {
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design,
		aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		req.GenerateImageParameter.TaskType = adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_txt2img
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer1,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer2,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		req.GenerateImageParameter.TaskType = adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_img2img
	default:
		return nil, fmt.Errorf("task type not supported, task type: %v", req.TaskType)
	}

	var err error
	if len(req.ImageToPromptModel) > 0 && len(req.GenerateImageParameter.InitImage) > 0 {
		endpointName, err := s.getEndpointName(req.TaskType)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences, getEndpointName failed, error: %v", err)
		}
		caption, err := s.ImageToPromptInferences(endpointName, req.ImageToPromptModel, req.GenerateImageParameter.InitImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, req.TaskType)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.GenerateImageParameter.Prompt = strings.Replace(req.GenerateImageParameter.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("image to prompt: %s,task: %s", req.GenerateImageParameter.Prompt, req.TaskId)
		}
	}
	generator := NewGenerateImage(s.ctx, s.svcCtx)
	req.GenerateImageParameter.Controlnet, err = generator.BuildControlnetParams(req.GenerateImageParameter.TaskType, req.GenerateImageParameter.Controlnet)
	if err != nil {
		return nil, fmt.Errorf("build controlnet params failed, error:%v", err)
	}

	resp, err := generator.Inferences(req)
	if err != nil {
		return nil, fmt.Errorf("Inferences error: %v, task type: %v", err, req.TaskType)
	}
	if resp == nil || len(resp.ImageInfos) == 0 {
		return nil, fmt.Errorf("Inferences error: response is incomplete, task type: %v", req.TaskType)
	}
	if len(resp.ImageInfos) > len(req.ResultImageUpTokens) {
		return nil, fmt.Errorf("Inferences error: response image count: %d is more than request: %d, task type: %v", req.TaskType, len(resp.ImageInfos), len(req.ResultImageUpTokens))
	}

	for i, imageInfo := range resp.ImageInfos {
		if imageInfo == nil {
			return nil, fmt.Errorf("generateImage error: image info is nil at index %d", i)
		}
		urlParse, err := url.Parse(req.ResultImageUpTokens[i])
		if err != nil {
			return nil, fmt.Errorf("generateImage, raw url into a [URL] failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
		}
		urlPath := strings.ToLower(urlParse.Path)
		contentType := common.TypeByExtension(urlPath)
		// convert to webp
		if strings.HasSuffix(urlPath, ".webp") {
			data, err := common.PngToWebp(imageInfo.Data)
			if err != nil {
				return nil, fmt.Errorf("generateImage, convert to webp failed, index: %d, error: %v", i, err)
			}
			imageInfo.Data = data
			imageInfo.Size = int64(len(data))
		}
		if _, err = common.UploadFile(s.ctx, imageInfo.Data, req.ResultImageUpTokens[i], contentType); err != nil {
			return nil, fmt.Errorf("upload file failed, index: %d, error: %v", i, err)
		}

		imageInfo.Data = nil
	}

	return resp, nil
}

// ImageUpscaleHandler
func (s *AnkerAdapter) ImageUpscaleHandler(req *adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error) {
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.UpscaleEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}
	var resp adaptermodel.ImageUpscaleResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) TranslateHandler(req *adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	if len(config.GetSrvConfig().AnkerModel.LLMUrl) == 0 ||
		len(config.GetSrvConfig().AnkerModel.Token) == 0 {
		return nil, grpcerrors.New(codes.CodeSystemException, " ali llm config error", grpcerrors.FindCaller(1))
	}

	url := config.GetSrvConfig().AnkerModel.LLMUrl
	apiKey := config.GetSrvConfig().AnkerModel.Token

	client := NewTranslateClient(s.ctx, s.svcCtx, url, apiKey, nil, nil, req)
	return client.Translate(req.Text)
}

func (s *AnkerAdapter) TranslateQuestionRecommendHandler(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	if len(config.GetSrvConfig().DifyWorkflow.Url) == 0 ||
		len(config.GetSrvConfig().DifyWorkflow.TranslateQuestionRecommendWorkflowKey) == 0 {
		return nil, grpcerrors.New(codes.CodeSystemException, " dify config error", grpcerrors.FindCaller(1))
	}

	url := config.GetSrvConfig().DifyWorkflow.Url
	apiKey := config.GetSrvConfig().DifyWorkflow.TranslateQuestionRecommendWorkflowKey

	client := NewTranslateQuestionRecommendClient(s.ctx, s.svcCtx, url, apiKey, nil, nil, req)
	return client.TranslateQuestionRecommend(req)
}

func (s *AnkerAdapter) FastTranscribeHandler(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	return nil, fmt.Errorf("FastTranscribeHandler not implemented")
}

func (s *AnkerAdapter) TextSummaryHandler(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	if len(config.GetSrvConfig().DifyWorkflow.Url) == 0 ||
		len(config.GetSrvConfig().DifyWorkflow.TranslateQuestionRecommendWorkflowKey) == 0 {
		return nil, grpcerrors.New(codes.CodeSystemException, " dify config error", grpcerrors.FindCaller(1))
	}

	user := config.GetSrvConfig().DifyWorkflow.User
	host := config.GetSrvConfig().DifyWorkflow.Url
	apiKey := config.GetSrvConfig().DifyWorkflow.TextSummaryWorkflowKey

	client := NewTextSummaryClient(s.ctx, s.svcCtx, user, host, apiKey)
	return client.ExtractTextSummary(req)
}

func (s *AnkerAdapter) ImageToPromptInferences(endpointName, imageToPromptModel string, initImage []byte) (*adaptermodel.ImageToPromptResponse, error) {
	req := &adaptermodel.ImageToPromptRequest{
		Task:          adaptermodel.INFERENCE_TASK_TYPE_interrogateclip,
		Username:      config.GetSrvConfig().AwsSd.UserName,
		PayloadString: "{}",
		InterrogatePayload: adaptermodel.InterrogatePayload{
			Model: imageToPromptModel,
			Image: common.BytesToBase64(initImage),
		},
	}

	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	host, err := s.GetHostWithInvocations(endpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.ImageToPromptResponse
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}

	return &resp, nil
}

func (s *AnkerAdapter) InstantStyleHandler(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error) {
	if len(req.InputImage) > 0 && strings.Contains(req.Prompt, "{PROMPT}") {
		var (
			err      error
			srcImage []byte
		)
		if common.IsUrl(req.InputImage) {
			srcImage, err = common.DownloadFile(s.ctx, req.InputImage)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", req.InputImage, err)
			}
		} else {
			srcImage, err = common.Base64ToBytes(req.InputImage)
			if err != nil {
				return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", req.InputImage[1000])
			}
		}
		caption, err := s.ImageToPromptInferences(config.GetSrvConfig().SageMaker.StyleTransferEndpointName, "clip", srcImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, aiparameter.TaskType_TASK_TYPE_Instant_Style)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.Prompt = strings.Replace(req.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("task_id: %s, image to prompt: %s,", req.TaskId, req.Prompt)
		}
	}
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.InstantStyleEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.InstantStyleResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) InstantStylePlusHandler(req *adaptermodel.InstantStylePlusReq) (*adaptermodel.InstantStylePlusResp, error) {
	var (
		err      error
		srcImage []byte
	)
	if len(req.ContentImage) > 0 && strings.Contains(req.Prompt, "{PROMPT}") {
		if common.IsUrl(req.ContentImage) {
			srcImage, err = common.DownloadFile(s.ctx, req.ContentImage)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", req.ContentImage, err)
			}
			req.ContentImage = common.BytesToBase64(srcImage)
		} else {
			srcImage, err = common.Base64ToBytes(req.ContentImage)
			if err != nil {
				return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", req.ContentImage[1000])
			}
		}
		caption, err := s.ImageToPromptInferences(config.GetSrvConfig().SageMaker.StyleTransferEndpointName, "clip", srcImage)
		if err != nil {
			return nil, fmt.Errorf("ImageToPromptInferences error: %v, task type: %v", err, aiparameter.TaskType_TASK_TYPE_Instant_Style_Plus)
		}
		if len(caption.Caption) > 0 && caption.Caption != "null" {
			req.Prompt = strings.Replace(req.Prompt, "{PROMPT}", caption.Caption, 1)
			s.Infof("task_id: %s, image to prompt: %s,", req.TaskId, req.Prompt)
		}
	}
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.InstantStylePlusEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.InstantStylePlusResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) DepthMapGenerationHandler(req *adaptermodel.DepthMapGenerationReq) (*adaptermodel.DepthMapGenerationResp, error) {
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.DepthMapGenerationEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	output, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.DepthMapGenerationResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal resp: %s, error: %v", string(output), err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) RemoveBackgroundHandler(req *adaptermodel.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	input, err := common.AnyToJson(req)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().SageMaker.RemoveBackgroundEndpointName)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	body, err := s.RequestWithJSON(s.ctx, "POST", host, "", input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if body == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var output adaptermodel.RemoveBackgroundResp
	err = common.JsonToAny(body, &output)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal resp: %s, error: %v", string(body), err)
	}
	if output.Code != codes.CodeOk {
		return nil, fmt.Errorf("code: %d, message: %s", output.Code, output.Message)
	}

	return &bgremoverrpc.RemoveBackgroundResp{
		Header: &aicommon.RspHeader{
			Code:    output.Code,
			Message: output.Message,
		},
		ResultImages: []*aicommon.FileInfo{{
			FileData: output.ResultImage,
			FileMd5:  output.ImageMd5,
			FileSize: output.ImageSize,
		}},
		TimeTakenMs: output.TimeTakenMs,
	}, nil
}

func (s *AnkerAdapter) getEndpointName(taskType aiparameter.TaskType) (string, error) {
	sageMakerConfig := config.GetSrvConfig().SageMaker
	switch taskType {
	case aiparameter.TaskType_TASK_TYPE_Face_Swap:
		return sageMakerConfig.FaceSwapEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Image_Upscale:
		return sageMakerConfig.UpscaleEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design:
		return sageMakerConfig.TextToImageDesignEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		return sageMakerConfig.PetPortraitEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer:
		return sageMakerConfig.StyleTransferEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Instant_Style:
		return sageMakerConfig.InstantStyleEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Depth_Map_Generation:
		return sageMakerConfig.DepthMapGenerationEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer1:
		return sageMakerConfig.StyleTransfer1EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer2:
		return sageMakerConfig.StyleTransfer2EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		return sageMakerConfig.StyleTransfer3EndpointName, nil
	}
	return "", fmt.Errorf("getEndpointName, taskType: %d is not support", taskType)
}

func (s *AnkerAdapter) SpeechToTextStreamHandler(request <-chan *adaptermodel.SpeechToTextReq, response chan<- *adaptermodel.SpeechToTextResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.Audio == nil {
		return fmt.Errorf("audio is nil")
	}

	client := NewAsrClient(s.ctx, s.svcCtx, request, response, req)
	defer client.Close()

	err := client.SpeechTranscription()
	if err != nil {
		return fmt.Errorf("SpeechTranscription failed, err: %v", err)
	}

	return nil
}

func (s *AnkerAdapter) TextToSpeechStreamHandler(request <-chan *adaptermodel.TextToSpeechReq, response chan<- *adaptermodel.TextToSpeechResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}

	client := NewTtsClient(s.ctx, s.svcCtx, request, response, req)
	// defer client.Close()

	err := client.SpeechSynthesis()
	if err != nil {
		return fmt.Errorf("SpeechSynthesis failed, err: %v", err)
	}
	return nil
}

func (s *AnkerAdapter) TranslateStreamHandler(request <-chan *adaptermodel.TranslateReq, response chan<- *adaptermodel.TranslateResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.LlmType == "" {
		return fmt.Errorf("llm type is empty")
	}

	url := config.GetSrvConfig().AnkerModel.LLMUrl
	apiKey := config.GetSrvConfig().AnkerModel.Token

	client := NewTranslateClient(s.ctx, s.svcCtx, url, apiKey, request, response, req)
	err := client.TranslateStream()
	if err != nil {
		return fmt.Errorf("anker TranslateStreamHandler failed, err: %v", err)
	}
	return nil
}

func (s *AnkerAdapter) LanguageDetectStreamHandler(request <-chan *adaptermodel.LanguageDetectReq, response chan<- *adaptermodel.LanguageDetectResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	md := metadata.New(map[string]string{
		"authorization": "Bearer " + config.GetDefaultConfig().SpeechToTextRpc.Token,
	})
	stream, err := s.svcCtx.SpeechToTextRpc.LanguageDetect(
		metadata.NewOutgoingContext(s.ctx, md),
	)
	if err != nil {
		return fmt.Errorf("connect to vad server failed, err: %v", err)
	}

	ctx, cancel := context.WithTimeout(stream.Context(), 7200*time.Second) // 2小时
	defer cancel()

	var wg sync.WaitGroup
	wg.Add(2)
	defer wg.Wait()
	errCh := make(chan error, 2)
	// recv message from stream
	go func() {
		defer wg.Done()
		errCh <- s.vadRecv(ctx, stream, response)
	}()
	// send message to stream
	go func() {
		defer wg.Done()
		errCh <- s.vadSend(ctx, stream, request)
	}()

	for i := 0; i < 2; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}

	return nil
}

func (s *AnkerAdapter) ComfyUiStyleTransferHandler(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error) {
	//TODO implement me
	return nil, fmt.Errorf("PetPortraitComfyHandler not implemented")
}

func (s *AnkerAdapter) OpusWrapperStreamHandler(request <-chan *adaptermodel.OpusWrapperReq, response chan<- *adaptermodel.OpusWrapperResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.Source == nil {
		return fmt.Errorf("source is nil")
	}
	if req.Target == nil {
		return fmt.Errorf("target is nil")
	}

	client := NewOpusWrapperClient(s.ctx, s.svcCtx, request, response, req)
	// defer client.Close()

	err := client.OpusWrapper()
	if err != nil {
		return fmt.Errorf("OpusWrapper failed, err: %v", err)
	}
	return nil
}

func (s *AnkerAdapter) TranslateQuestionRecommendStreamHandler(request <-chan *adaptermodel.TranslateQuestionRecommendReq, response chan<- *adaptermodel.TranslateQuestionRecommendResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}

	url := config.GetSrvConfig().DifyWorkflow.Url
	apiKey := config.GetSrvConfig().DifyWorkflow.TranslateQuestionRecommendWorkflowKey
	client := NewTranslateQuestionRecommendClient(s.ctx, s.svcCtx, url, apiKey, request, response, req)
	err := client.TranslateQuestionRecommendStream()
	if err != nil {
		return fmt.Errorf("anker TranslateQuestionRecommendStreamHandler failed, err: %v", err)
	}
	return nil
}
