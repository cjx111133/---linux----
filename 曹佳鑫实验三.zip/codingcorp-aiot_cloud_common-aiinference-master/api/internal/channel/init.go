package channel

import (
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
)

var (
	maxMessageSize = 65536
	readWait       = 5 * time.Minute
	writeWait      = 5 * time.Minute
)

// InitConfig 初始化配置
func InitConfig(c config.Config) {
	if c.WebSocketConfig.MaxMessageSize > 0 {
		maxMessageSize = c.WebSocketConfig.MaxMessageSize
	}
	if c.WebSocketConfig.ReadWait > 0 {
		readWait = time.Duration(c.WebSocketConfig.ReadWait) * time.Second
	}
	if c.WebSocketConfig.WriteWait > 0 {
		writeWait = time.Duration(c.WebSocketConfig.WriteWait) * time.Second
	}
}

//// 当WebSocketManager创建时进行一些全局初始化
//func InitManager(manager *WebSocketManager) {
//	// 启动定期清理过期连接的协程
//	threading.GoSafe(func() {
//		manager.Cleanup()
//	})
//
//	// 这里可以注册命令处理器
//	registerCommandHandlers(manager)
//}

//// 注册命令处理器
//func registerCommandHandlers(manager *WebSocketManager) {
//	// 注册翻译处理器
//	manager.RegisterCommandHandler(types.CmdTranslate, func(client *WebSocketClient, message []byte) error {
//		// 处理翻译请求
//		var req types.AudioTranslateReq
//		if err := json.Unmarshal(message, &req); err != nil {
//			client.Error("Failed to unmarshal translate message: %v", err)
//			return err
//		}
//
//		// 发送确认消息
//		response := map[string]interface{}{
//			"msg_type":   "translate_request_received",
//			"message_id": req.MessageId,
//			"status":     0,
//		}
//
//		data, _ := json.Marshal(response)
//		return client.Send(data)
//	})
//
//	// 注册聊天处理器
//	manager.RegisterCommandHandler(types.CmdChat, func(client *WebSocketClient, message []byte) error {
//		// 简单的回复消息作为示例
//		response := map[string]interface{}{
//			"msg_type":   "chat_response",
//			"message_id": "test-message-id",
//			"text":       "This is a test response from the chat handler",
//			"status":     0,
//		}
//
//		data, _ := json.Marshal(response)
//		return client.Send(data)
//	})
//
//	// 已经在manager中注册了Ping处理器
//}
