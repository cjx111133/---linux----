package main

import (
	"encoding/json"
	"flag"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	kitconfig "e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/config/nacos"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/middleware/serverinterceptor/errors"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/server"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

// var configFile = flag.String("f", "etc/aiadapter.json", "the config file")
var (
	// todo 自定义修改nacosNameSpace、nacosIP等
	nacosNameSpace = flag.String("nacos-ns", "AnkerMake-CI", "nacos name space")
	nacosIP        = flag.String("nacos-ip", "10.1.54.115", "nacos ip")
	nacosPort      = flag.Int("nacos-port", 8848, "nacos port")

	nacosUserName = flag.String("nacos-username", "nacos", "nacos user name")
	nacosPassWord = flag.String("nacos-password", "nacos", "nacos password")
	nacosGroup    = "aiadapter-rpc"
	nacosDataId   = "service-basic"
)

func main() {
	flag.Parse()

	sc := []nacos.ServerConfig{
		{
			IpAddr:      *nacosIP,
			Port:        uint64(*nacosPort),
			Scheme:      "http",
			ContextPath: "/nacos",
		},
	}

	client, err := nacos.NewIConfigClient(
		nacos.WithNamespaceID(*nacosNameSpace),
		nacos.WithTimeout(5000),
		nacos.WithLogLevel("debug"),
		nacos.WithNotLoadCacheAtStart(true),
		nacos.WithCacheDir("./logs/"),
		nacos.WithLogDir("./logs/"),
		nacos.WithRotateTime("1h"),
		nacos.WithUsername(*nacosUserName),
		nacos.WithPassword(*nacosPassWord),
		nacos.WithServerConfig(sc))
	if err != nil {
		fmt.Printf("newConfigClient error:%v", err)
		return
	}

	nacosConfig := kitconfig.New(kitconfig.WithSource(
		nacos.NewConfigSource(client,
			nacos.WithGroup(nacosGroup),
			nacos.WithDataID(nacosDataId))))
	if err := nacosConfig.Load(); err != nil {
		fmt.Printf("configSource load error:%v", err)
		return
	}
	defer nacosConfig.Close()

	confValue, _ := nacosConfig.Value(nacosDataId).String()

	if err := config.InitDefaultConfig(confValue); err != nil {
		fmt.Printf("%v", err)
		return
	}

	//conf.MustLoad(*configFile, config.DefaultConfig)
	ctx := svc.NewServiceContext()
	err = ctx.InitInternalModelFile()
	if err != nil {
		fmt.Printf("InitInternalModelFile error:%v", err)
		return
	}

	// watch config
	if err := nacosConfig.Watch(nacosDataId, func(k string, v kitconfig.Value) {
		value, err := v.String()
		if err != nil {
			logx.Errorf("config Value to string error:%v", err)
			return
		}
		var cfg config.SrvConfig
		//if err := conf.LoadFromJsonBytes([]byte(value), &cfg); err != nil {
		//	logx.Errorf("json unmarshal error:%v", err)
		//	return
		//}
		if err := json.Unmarshal([]byte(value), &cfg); err != nil {
			logx.Errorf("json unmarshal error:%v", err)
			return
		}
		config.UpdateSrvConfig(&cfg)
	}); err != nil {
		fmt.Printf("configSource watch error:%v", err)
		return
	}

	c := config.GetDefaultConfig()
	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		aiadapterrpc.RegisterAiAdapterRpcServer(grpcServer, server.NewAiAdapterRpcServer(ctx))

		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})
	defer s.Stop()

	s.AddUnaryInterceptors(errors.ServerErrorInterceptor)
	logx.DisableStat()

	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	s.Start()
}
