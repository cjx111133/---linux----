package config

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/queue/kq"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
)

type Config struct {
	rest.RestConf
	Cache           cache.CacheConf `json:",optional"`
	EncryptCache    cache.CacheConf `json:",optional"`
	WebSocketConfig WebSocketConfig `json:",optional"`
	AudioTranslate  AudioTranslate  `json:",optional"`
	Chat            Chat            `json:",optional"`
	ExternalModel   string          `json:",default=azure"`
	//ExternalModel   string          `json:",default=aliyun"`
	AiKafka map[string]kq.KqConf `json:",optional"` // ai 的 kafka 配置 appid => kq.KqConf

	AwsSagemakerConfig *AwsSagemakerConfig `json:",optional"`

	AiManagerRPC *zrpc.RpcClientConf `json:",optional"`
}

type WebSocketConfig struct {
	MaxMessageSize int `json:",default=65536"`
	ReadWait       int `json:",default=300"` // 单位秒
	WriteWait      int `json:",default=60"`  // 单位秒
}

type AwsSagemakerConfig struct {
	AccessKey       string `json:",optional"`
	SecretKey       string `json:",optional"`
	Region          string `json:",optional"`
	Endpoint        string `json:",optional"`
	CustomAttribute string `json:",optional"`
}

func (c *Config) CreateAwsSagemakerClient() *sagemakerruntime.SageMakerRuntime {
	if c.AwsSagemakerConfig == nil {
		return nil
	}

	sess, err := session.NewSession(&aws.Config{
		Region:      aws.String(c.AwsSagemakerConfig.Region),
		Credentials: credentials.NewStaticCredentials(c.AwsSagemakerConfig.AccessKey, c.AwsSagemakerConfig.SecretKey, ""),
	})
	if err != nil {
		logx.Errorf("Error creating session: %v", err)
		return nil
	}

	return sagemakerruntime.New(sess)
}
