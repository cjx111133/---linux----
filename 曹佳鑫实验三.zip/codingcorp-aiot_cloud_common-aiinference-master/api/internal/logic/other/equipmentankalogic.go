package other

import (
	"context"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type EquipmentAnkaLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewEquipmentAnkaLogic(ctx context.Context, svcCtx *svc.ServiceContext) *EquipmentAnkaLogic {
	return &EquipmentAnkaLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *EquipmentAnkaLogic) EquipmentAnka(req *types.AnkaRequest) (resp *types.EquipmentAnkaResponse, err error) {
	// todo: add your logic here and delete this line

	return
}
