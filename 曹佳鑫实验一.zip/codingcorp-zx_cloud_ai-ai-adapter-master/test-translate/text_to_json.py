import json
from collections import defaultdict

def convert_txt_to_json(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as f:
        data = f.read().strip()
    
    entries = data.split('\n\n')
    parsed_entries = []
    for entry in entries:
        lines = entry.strip().split('\n')
        entry_dict = {}
        for line in lines:
            key, value = line.split(': ', 1)
            entry_dict[key] = value
        parsed_entries.append(entry_dict)
    
    result = defaultdict(list)
    for entry in parsed_entries:
        language_code = entry.get('language_code')
        if language_code:
            obj = {
                'id': entry['id'],
                'ori_id': entry['ori_id'],
                'ori_text': entry['ori_text'],
                'scene': int(entry['scene']),
                'text': entry['text'],
                'language_code': language_code,
                'audio_path': None  # 按示例要求设为null
            }
            result[language_code].append(obj)
    
    # 将defaultdict转换为普通字典并生成JSON
    json_data = json.dumps(dict(result), indent=4, ensure_ascii=False)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(json_data)

# 使用示例：
txt_file = "data/text/translate.txt"  # 替换为你的TXT文件路径
json_file = "data/text/translate.json"  # 输出的JSON文件路径
convert_txt_to_json(txt_file, json_file)
print(f"TXT文件已成功转换为JSON文件，保存路径为：{json_file}")