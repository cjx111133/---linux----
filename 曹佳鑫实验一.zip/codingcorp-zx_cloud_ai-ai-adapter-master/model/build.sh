goctl model mysql ddl -src ./sql/t_internal_model_file.sql -dir . --home /Users/harry/.goctl/.git/goctl
goctl model mysql ddl -src ./sql/t_train_model_file.sql -dir . --home /Users/harry/.goctl/.git/goctl
