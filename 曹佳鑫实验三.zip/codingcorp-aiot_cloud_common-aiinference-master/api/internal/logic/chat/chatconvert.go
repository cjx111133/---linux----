package chat

import (
	"encoding/base64"
	"encoding/json"
	"go.uber.org/zap"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

// ChatConvertInterface defines the interface for chat convert processing
type ChatConvertInterface interface {
	ProcessStreamTaskRespData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.ChatReq, index int32) (*types.RecvDataResp, bool, bool)
	ConvertAsrData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, bool)
	ConvertTtsData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, bool)
	ConvertChatFlowData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, int, bool)
	ConvertOpusWrapper(streamRecv *aimanagerrpc.StreamTaskResp) interface{}
}

// ChatConvert implements ChatConvertInterface
type ChatConvert struct {
	*ChatMessage
}

func NewChatConvert(message *ChatMessage) *ChatConvert {
	return &ChatConvert{
		ChatMessage: message,
	}
}

func (p *ChatConvert) ProcessStreamTaskRespData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.ChatReq, index int32) (*types.RecvDataResp, bool, bool) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    p.wsData.ConnectionInfo.SessionId,
		MessageId:    p.messageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusMiddle,
		Index:        index,
		ReqType:      req.Type,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
	}
	var end bool
	var result interface{}
	switch streamRecv.TaskType {
	case aiparameter.TaskType_TASK_TYPE_Speech_To_Text: // 语音识别
		resp.Type = types.TaskTypeSpeechToText
		result, end = p.ConvertAsrData(streamRecv)
	case aiparameter.TaskType_TASK_TYPE_Text_To_Speech: // 文本转语音
		resp.Type = types.TaskTypeTextToSpeech
		result, end = p.ConvertTtsData(streamRecv)
	case aiparameter.TaskType_TASK_TYPE_Opus_Wrapper:
		resp.Type = int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech)
		result = p.ConvertOpusWrapper(streamRecv)
	case aiparameter.TaskType_TASK_TYPE_Dify_Chatflow: // 对话流程
		resp.Type = types.TaskTypeChat
		result, resp.MessageType, end = p.ConvertChatFlowData(streamRecv)
	}
	if result != nil {
		resp.SourceData = result
		if data, ok := result.(string); ok {
			resp.Data = data
		} else if sourceData, ok := result.([]byte); ok {
			resp.Data = string(sourceData)
		} else {
			sourceData, _ = json.Marshal(result)
			resp.Data = string(sourceData)
		}
	}
	resp.Data = p.utilLogic.DataEncrypt(resp.Data)
	return &resp, true, end
}

// ConvertAsrData 将语音识别的结果转换为json字符串
func (p *ChatConvert) ConvertAsrData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, bool) {
	asrResp := streamRecv.GetAsrResp()
	if asrResp == nil {
		p.Infof("Chat Recv: GetAsrResp data is nil")
		return "", false
	}

	// 如果是非流式识别，返回SegmentEnd为false，则跳过
	if !p.svcCtx.Config.Chat.SpeechToTextParam.EnableWord && !asrResp.SegmentEnd {
		return "", false
	}

	data := types.SpeechToTextData{
		SegmentEnd: asrResp.SegmentEnd,
		Text:       asrResp.Text,
		Segments:   make([]*types.Segment, 0),
		SpeechEnd:  asrResp.SpeechEnd,
	}

	for _, segment := range asrResp.Segments {
		data.Segments = append(data.Segments, &types.Segment{
			Id:         segment.Id,
			StartMs:    segment.StartMs,
			EndMs:      segment.EndMs,
			Text:       segment.Text,
			Confidence: segment.Confidence,
			Words:      make([]*types.Word, 0),
		})

		for _, word := range segment.Words {
			data.Segments[len(data.Segments)-1].Words = append(data.Segments[len(data.Segments)-1].Words, &types.Word{
				Text:       word.Text,
				StartMs:    word.StartMs,
				EndMs:      word.EndMs,
				Confidence: word.Confidence,
			})
		}
	}

	if data.SegmentEnd {
		p.Infof("Chat Recv AsrData: %s, messageId: %s", zap.Any("data", data), p.messageId)
	}
	if data.SpeechEnd && len(strings.TrimSpace(data.Text)) == 0 {
		// asr 为空的情况，没法走下一步
		p.Errorf("Chat Recv AsrData is null: %s,  messageId: %s", zap.Any("data", data), p.messageId)
		return "", true
	}

	return data, data.SegmentEnd
}

// ConvertTtsData 将文本转语音的结果转换为json字符串
func (p *ChatConvert) ConvertTtsData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, bool) {
	ttsResp := streamRecv.GetTtsResp()
	if ttsResp == nil {
		p.Infof("Chat Recv: GetTtsResp data is nil")
		return "", false
	}

	data := types.TextToSpeechData{
		SentenceStart: ttsResp.SentenceStart,
		Audio:         base64.StdEncoding.EncodeToString(ttsResp.Audio.Data),
		Subtitle:      make([]*types.Subtitle, 0),
	}

	for _, subtitle := range ttsResp.Subtitle {
		data.Subtitle = append(data.Subtitle, &types.Subtitle{
			SentenceStart: subtitle.SentenceStart,
			Text:          subtitle.Text,
			StartMs:       subtitle.StartMs,
			EndMs:         subtitle.EndMs,
		})
	}

	p.Infof("Chat Recv TtsData: SentenceStart  %+v  Subtitle %+v", data.SentenceStart, data.Subtitle)
	return data, data.SentenceStart
}

// ConvertChatFlowData 将对话流程的结果转换为json字符串
func (p *ChatConvert) ConvertChatFlowData(streamRecv *aimanagerrpc.StreamTaskResp) (interface{}, int, bool) {
	chatFlowResp := streamRecv.GetChatflowResp()
	if chatFlowResp == nil {
		p.Infof("Chat Recv: GetChatFlowResp data is nil")
		return "", 0, false
	}
	if chatFlowResp.Command != "" {
		p.Infof("Chat Recv ChatFlowData: %s messageId: %s", zap.Any("data", chatFlowResp), p.messageId)
	}

	// 如果是非流式识别，则跳过
	if !p.svcCtx.Config.Chat.ChatParam.EnableFlow {
		return "", 0, false
	}

	var data types.ChatData
	data = types.ChatData{
		SentenceStart: chatFlowResp.SentenceStart,
		SentenceEnd:   chatFlowResp.SentenceEnd,
		Text:          chatFlowResp.Text,
		Questions:     chatFlowResp.Question,
		Emotion:       chatFlowResp.Emotion,
		Command:       chatFlowResp.Command,
		CommandArgs:   chatFlowResp.CommandArgs,
	}
	var messageType int
	if chatFlowResp.Command == "daily_report" {
		messageType = types.MessageTypeSafetyDaily
	}
	p.Infof("Chat Recv ChatFlowData: %+v messageId: %s", data, p.messageId)
	return data, messageType, true
}

func (l *ChatLogic) ConvertOpusWrapper(streamRecv *aimanagerrpc.StreamTaskResp) interface{} {
	resp := streamRecv.GetOpusWrapperResp()
	if resp == nil {
		l.Infof("AudioTranslate Recv: convertOpusWrapper data is nil")
		return ""
	}
	data := types.TextToSpeechData{
		Audio: base64.StdEncoding.EncodeToString(resp.Audio.Data),
	}

	//l.Infof("AudioTranslate Recv Opus Wrapper: %+v", data)
	return data
}
