package types

type AudioTranslateReq struct {
	*CommonReq
	Format         string `json:"format"`          // 编码格式
	SampleRate     int32  `json:"sample_rate"`     // 音频采样率
	Bits           int32  `json:"bits"`            // 位长
	Channels       int32  `json:"channels"`        // 声道数
	BitRate        int32  `json:"bit_rate"`        // 码率
	FrameSizeMs    int32  `json:"frame_size_ms"`   // 帧大小
	Data           string `json:"data"`            // base64音频数据
	Role           string `json:"role"`            // 角色
	SourceLanguage string `json:"source_language"` // 源语言
	TargetLanguage string `json:"target_language"` // 目标语言
}
