package client

type Config struct {
	Address   string
	UserId    string
	TaskId    string
	Train     Train
	Inference Inference
	AudioPath string
}

type Train struct {
	InstanceName    string
	DatasetPath     string
	OutputModelPath string
}

const (
	ADAPTER_SERVICE_TYPE_SAGEMAKER = "sagemaker"
	ADAPTER_SERVICE_TYPE_ALIYUN    = "aliyun"
	ADAPTER_SERVICE_TYPE_ANKER     = "anker"
	ADAPTER_SERVICE_TYPE_AZURE     = "azure"
)

const (
	AI_ADAPTER_ACTION_imageupscale       = "image_upscale"
	AI_ADAPTER_ACTION_removebackground   = "remove_background"
	AI_ADAPTER_ACTION_imagetovector      = "image_to_vector"
	AI_ADAPTER_ACTION_texttoimagedesign  = "text_to_image_design"
	AI_ADAPTER_ACTION_styletransfer      = "style_transfer"
	AI_ADAPTER_ACTION_styletransfer1     = "style_transfer1"
	AI_ADAPTER_ACTION_styletransfer2     = "style_transfer2"
	AI_ADAPTER_ACTION_styletransfer3     = "style_transfer3"
	AI_ADAPTER_ACTION_popart             = "pop_art"
	AI_ADAPTER_ACTION_petportrait        = "pet_portrait"
	AI_ADAPTER_ACTION_faceswap           = "faceswap"
	AI_ADAPTER_ACTION_magiceraser        = "magic_eraser"
	AI_ADAPTER_ACTION_removebackfround   = "remove_foreground"
	AI_ADAPTER_ACTION_instantstyle       = "instant_style"
	AI_ADAPTER_ACTION_instantstyleplus   = "instant_style_plus"
	AI_ADAPTER_ACTION_depthmapgeneration = "depth_map_generation"
	AI_ADAPTER_ACTION_speechtotext       = "speech_to_text"
	AI_ADAPTER_ACTION_texttospeech       = "text_to_speech"
	AI_ADAPTER_ACTION_translate          = "translate"
	AI_ADAPTER_ACTION_dialogue           = "dialogue"
	AI_ADAPTER_ACTION_train              = "train"
	AI_ADAPTER_ACTION_difyworkflow       = "dify_workflow"
	AI_ADAPTER_ACTION_difychatflow       = "dify_chatflow"
)

type Inference struct {
	TaskType            string
	ResultImageUpTokens []string
	InferenceParameter  map[string]string
	ExtendedParameter   map[string]string
}
