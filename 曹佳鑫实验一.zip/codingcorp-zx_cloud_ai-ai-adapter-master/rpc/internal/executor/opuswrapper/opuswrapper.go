package opuswrapper

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type OpusWrapperExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger

	once bool
}

func NewOpusWrapperExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *OpusWrapperExecutor {
	return &OpusWrapperExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		once:   true,
	}
}

func (e *OpusWrapperExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	return nil, fmt.Errorf("Inference not implemented")
}

func (e *OpusWrapperExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}
	e.Info("OpusWrapperExecutor StreamInference end")
	return nil
}

func (e *OpusWrapperExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("OpusWrapperExecutor doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		e.Infof("OpusWrapperExecutor doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("doStreamInference recv opus first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	opusReq := make(chan *adaptermodel.OpusWrapperReq, 100)
	opusResp := make(chan *adaptermodel.OpusWrapperResp, 100)
	opusReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from audio processor
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, opusResp, cliResp)
	})
	// send message to audio processor
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, opusReq, cliReq)
	})
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.OpusWrapperStreamHandler(opusReq, opusResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *OpusWrapperExecutor) recv(ctx context.Context, opusResp <-chan *adaptermodel.OpusWrapperResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case <-ctx.Done():
			e.Infof("recv resp from audio processor end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from audio processor end, logic context done")
			return nil
		case resp, ok := <-opusResp:
			if !ok {
				e.Infof("recv resp from audio processor end, opusResp channel closed")
				return nil
			}

			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		}
	}
}

func (e *OpusWrapperExecutor) send(ctx context.Context,
	opusReq chan *adaptermodel.OpusWrapperReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(opusReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to audio processor end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to audio processor end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to audio processor end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to audio processor failed, request is nil")
			}
			r, err := e.buildParameter(req)
			if err != nil {
				e.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			if r.Source == nil {
				e.Errorf("recv req from client, Source is nil")
				return fmt.Errorf("recv req from client, Source is nil")
			}

			e.Debugf("send req to audio processor, ServiceProvider: %s, audio: %v", r.ServiceProvider, len(r.Source.Data))

			opusReq <- r
		}
	}
}

func (e *OpusWrapperExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.OpusWrapperReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.OpusWrapperInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.OpusWrapperExtendedParameter
	if e.once {
		e.once = false

		if in.ExtendedParameter == "" {
			return nil, fmt.Errorf("ExtendedParameter is empty")
		}
		err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
		if err != nil {
			return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
		}

		err = e.checkParameter(&iPara, &ePara)
		if err != nil {
			return nil, fmt.Errorf("checkParameter failed, err: %v", err)
		}
	}

	req := &adaptermodel.OpusWrapperReq{
		TaskId:          in.Header.TaskId,
		ServiceProvider: config.ADAPTER_SERVICE_TYPE_ANKER,
		IsEnableEnc:     iPara.IsEnableEnc,
		Source:          iPara.Source,
		Target:          ePara.Target,
	}
	return req, nil
}

func (e *OpusWrapperExecutor) checkParameter(
	iPara *aiparameter.OpusWrapperInferenceParameter,
	ePara *aiparameter.OpusWrapperExtendedParameter) error {
	// check iPara
	if iPara.Source == nil {
		return fmt.Errorf("InferenceParameter Source is empty")
	}
	iPara.Source.Format = strings.ToLower(iPara.Source.Format)
	switch iPara.Source.Format {
	case config.AUDIO_FORMAT_OPUS:
		if iPara.Source.FrameSizeMs == 0 {
			iPara.Source.FrameSizeMs = 20
		}
	case config.AUDIO_FORMAT_PCM:
	default:
		return fmt.Errorf("InferenceParameter Source Format is invalid, Format: %s", iPara.Source.Format)
	}
	if iPara.Source.SampleRate == 0 {
		iPara.Source.SampleRate = 16000
	}
	switch iPara.Source.SampleRate {
	case 16000:
	default:
		return fmt.Errorf("InferenceParameter Audio SampleRate is invalid, SampleRate: %d", iPara.Source.SampleRate)
	}
	if iPara.Source.BitRate == 0 {
		iPara.Source.BitRate = 16000
	}
	switch iPara.Source.BitRate {
	case 8000, 16000, 32000, 48000, 64000, 96000, 128000, 192000, 256000:
	default:
		return fmt.Errorf("InferenceParameter Audio BitRate is invalid, BitRate: %d", iPara.Source.BitRate)
	}
	switch iPara.Source.Channels {
	case 1, 2:
	default:
		return fmt.Errorf("InferenceParameter Audio Channel is invalid, Channel: %d", iPara.Source.Channels)
	}

	// check ePara
	if ePara.Target == nil {
		return fmt.Errorf("ExtendedParameter Target is empty")
	}
	ePara.Target.Format = strings.ToLower(ePara.Target.Format)
	switch ePara.Target.Format {
	case config.AUDIO_FORMAT_OPUS:
		if ePara.Target.FrameSizeMs == 0 {
			ePara.Target.FrameSizeMs = 20
		}
	case config.AUDIO_FORMAT_PCM:
	default:
		return fmt.Errorf("ExtendedParameter Target Format is invalid, Format: %s", ePara.Target.Format)
	}
	if ePara.Target.SampleRate == 0 {
		ePara.Target.SampleRate = 16000
	}
	switch ePara.Target.SampleRate {
	case 16000:
	default:
		return fmt.Errorf("ExtendedParameter Target SampleRate is invalid, SampleRate: %d", ePara.Target.SampleRate)
	}
	if ePara.Target.BitRate == 0 {
		ePara.Target.BitRate = 16000
	}
	switch ePara.Target.BitRate {
	case 8000, 16000, 32000, 48000, 64000, 96000, 128000, 192000, 256000:
	default:
		return fmt.Errorf("ExtendedParameter Audio BitRate is invalid, BitRate: %d", ePara.Target.BitRate)
	}
	switch ePara.Target.Channels {
	case 1, 2:
	default:
		return fmt.Errorf("ExtendedParameter Audio Channel is invalid, Channel: %d", ePara.Target.Channels)
	}
	return nil
}

func (e *OpusWrapperExecutor) buildResponse(resp *adaptermodel.OpusWrapperResp) (*aiadapterrpc.InferenceResp, error) {
	e.Debugf("OpusWrapperExecutor buildResponse, Audio: %d, TimeTakenMs: %d", len(resp.Audio.Data), resp.TimeTakenMs)

	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Opus_Wrapper,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_OpusWrapper{
			OpusWrapper: &aiparameter.OpusWrapperInferenceResultInfo{
				Audio:     resp.Audio,
				Timestamp: time.Now().UnixMilli(),
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
