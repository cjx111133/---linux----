package speechtotext

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type SpeechToTextExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	buf *bytes.Buffer

	once   bool
	taskId string
}

func NewSpeechToTextExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *SpeechToTextExecutor {
	return &SpeechToTextExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		buf:    new(bytes.Buffer),
		once:   true,
	}
}

func (e *SpeechToTextExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	return nil, fmt.Errorf("Inference not implemented")
}

func (e *SpeechToTextExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}

	if config.GetSrvConfig().AsrSaveAudio {
		index := 0
		for e.buf.Len() > 0 {
			index++
			data := common.BytesToBase64(e.buf.Next(8000))
			e.Infof("send req data to asr engine, TaskId: %s, index:%d, Base64 Audio: [%s]", e.taskId, index, data)
		}
		e.Infof("send req data to asr engine end, TaskId: %s, total index: %d", e.taskId, index)
	}

	e.Info("SpeechToTextExecutor StreamInference end")
	return nil
}

func (e *SpeechToTextExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		return fmt.Errorf("doStreamInference recv first message failed, request is nil")
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("doStreamInference recv asr first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	asrReq := make(chan *adaptermodel.SpeechToTextReq, 200)
	asrResp := make(chan *adaptermodel.SpeechToTextResp, 200)
	asrReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from asr engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, asrResp, cliResp)
	})
	// send message to asr engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, asrReq, cliReq)
	})
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.SpeechToTextStreamHandler(asrReq, asrResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *SpeechToTextExecutor) recv(ctx context.Context, asrResp <-chan *adaptermodel.SpeechToTextResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-asrResp:
			if !ok {
				e.Infof("recv resp from asr engine end, asrResp channel closed")
				return nil
			}
			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			e.Infof("recv resp from asr engine end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from asr engine end, logic context done")
			return nil
		}
	}
}

func (e *SpeechToTextExecutor) send(ctx context.Context, asrReq chan<- *adaptermodel.SpeechToTextReq, cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(asrReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to asr engine end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to asr engine end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to asr engine end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to asr engine failed, request is nil")
			}

			r, err := e.buildParameter(req)
			if err != nil {
				return fmt.Errorf("buildParameter failed, err: %v", err)
			}

			if config.GetSrvConfig().AsrSaveAudio && r.Audio != nil {
				e.buf.Write(r.Audio.Data)
			}

			asrReq <- r
		}
	}
}

func (e *SpeechToTextExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.SpeechToTextReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.SpeechToTextInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.SpeechToTextExtendedParameter
	if e.once {
		e.once = false
		e.taskId = in.Header.TaskId

		if in.Header.AppId == "" {
			return nil, fmt.Errorf("Header AppId is empty")
		}

		if in.ExtendedParameter != "" {
			err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
			if err != nil {
				return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
			}
		}

		err = e.checkParameter(&iPara, &ePara)
		if err != nil {
			return nil, fmt.Errorf("checkParameter failed, err: %v", err)
		}
	}

	return &adaptermodel.SpeechToTextReq{
		TaskId:             in.Header.TaskId,
		AppId:              in.Header.AppId,
		TargetLang:         ePara.TargetLanguage,
		AddPunctuation:     ePara.AddPunctuation,
		EnableWord:         ePara.EnableWord,
		MaxSentenceSilence: ePara.MaxSentenceSilence,
		MaxStartSilence:    ePara.MaxStartSilence,
		MaxEndSilence:      ePara.MaxEndSilence,
		ServiceProvider:    ePara.ServiceProvider,
		Audio:              iPara.Audio,
		UseTempResult:      ePara.UseTempResult,
		HotWordsList:       ePara.HotWordsList,
	}, nil
}

func (e *SpeechToTextExecutor) checkParameter(
	iPara *aiparameter.SpeechToTextInferenceParameter,
	ePara *aiparameter.SpeechToTextExtendedParameter) error {
	// check iPara
	if iPara.Audio == nil {
		return fmt.Errorf("InferenceParameter Audio is nil")
	}
	if iPara.Audio.SampleRate == 0 {
		iPara.Audio.SampleRate = 16000
	}
	switch iPara.Audio.SampleRate {
	case 16000:
	default:
		return fmt.Errorf("InferenceParameter Audio SampleRate is invalid, SampleRate: %d", iPara.Audio.SampleRate)
	}
	if iPara.Audio.BitRate == 0 {
		iPara.Audio.BitRate = 16000
	}
	switch iPara.Audio.BitRate {
	case 8000, 16000, 32000, 48000, 64000, 96000, 128000, 192000, 256000:
	default:
		return fmt.Errorf("InferenceParameter Audio BitRate is invalid, BitRate: %d", iPara.Audio.BitRate)
	}
	switch iPara.Audio.Channels {
	case 1, 2:
	default:
		return fmt.Errorf("InferenceParameter Audio Channel is invalid, Channel: %d", iPara.Audio.Channels)
	}
	if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, iPara.Audio.Language) {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, iPara.Audio.Language) {
			return fmt.Errorf("InferenceParameter Audio Language is invalid, Language: %s", iPara.Audio.Language)
		} else {
			iPara.Audio.Language = common.LanguageToBcp47(iPara.Audio.Language)
		}
	}
	iPara.Audio.Format = strings.ToLower(iPara.Audio.Format)
	if !common.IsExistInArray(config.SUPPORTEN_FORMAT, iPara.Audio.Format) {
		return fmt.Errorf("InferenceParameter Audio Format is invalid, Language: %s", iPara.Audio.Format)
	}

	// check ePara
	if ePara.TargetLanguage != "" {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, ePara.TargetLanguage) {
			if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, ePara.TargetLanguage) {
				return fmt.Errorf("ExtendedParameter TargetLanguage is invalid, TargetLanguage: %s", ePara.TargetLanguage)
			} else {
				ePara.TargetLanguage = common.LanguageToBcp47(ePara.TargetLanguage)
			}
		}
	}
	if ePara.MaxSentenceSilence <= 0 {
		ePara.MaxSentenceSilence = 500
	}
	// 最大开始静音时长。取值范围：(0, 60000]ms。60000
	if ePara.MaxStartSilence <= 0 || ePara.MaxStartSilence > 60000 {
		ePara.MaxStartSilence = 5000
	}
	// 最大结束静音时长。取值范围：[200ms, 2000]ms。
	if ePara.MaxEndSilence < 200 || ePara.MaxEndSilence > 2000 {
		ePara.MaxEndSilence = 1000
	}
	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ALIYUN, config.ADAPTER_SERVICE_TYPE_ANKER, config.ADAPTER_SERVICE_TYPE_AZURE:
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
	}

	return nil
}

func (e *SpeechToTextExecutor) buildResponse(resp *adaptermodel.SpeechToTextResp) (*aiadapterrpc.InferenceResp, error) {
	speechToText := &aiparameter.SpeechToTextInferenceResultInfo{
		Text:          resp.Text,
		SegmentId:     resp.SegmentId,
		SegmentEnd:    resp.SegmentEnd,
		Segments:      resp.Segments,
		Language:      resp.Language,
		SpeechEnd:     resp.SpeechEnd,
		UseTempResult: resp.UseTempResult,
		Timestamp:     time.Now().UnixMilli(),
	}
	// 保留最新的 3 个段落
	if len(speechToText.Segments) > 3 {
		speechToText.Segments = speechToText.Segments[len(speechToText.Segments)-3:]
	}

	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Speech_To_Text,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_SpeechToText{
			SpeechToText: speechToText,
		},
	}

	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
