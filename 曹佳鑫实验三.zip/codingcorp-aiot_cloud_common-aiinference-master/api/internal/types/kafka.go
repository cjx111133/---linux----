package types

type KafkaMessage struct {
	Timestamp int64  `json:"timestamp"` // 时间戳（毫秒）
	MsgID     string `json:"msgId"`     // 执行指令（translate/chat/ping）
	MsgType   string `json:"msgType"`   // 消息类型（如audio-callback）
	Data      []byte `json:"data"`      // 协议数据
}
