CREATE TABLE `t_internal_model_file`
(
    `id`         bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '自增长ID',
    `model_id`   varchar(64)  NOT NULL DEFAULT '' COMMENT '模型ID，全剧唯一',
    `model_name` varchar(128) NOT NULL DEFAULT '' COMMENT '模型名称，全剧唯一',
    `type`       varchar(64)  NOT NULL DEFAULT '' COMMENT '模型类型',
    `model_path` varchar(128) NOT NULL DEFAULT '' COMMENT '模型路径',
    `model_md5`  varchar(1024) COMMENT '模型文件md5',
    `model_size` bigint unsigned NOT NULL DEFAULT '0' COMMENT '模型文件大小，单位字节',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_model_id` (`model_id`) USING BTREE,
    UNIQUE KEY `uk_model_name` (`model_name`) USING BTREE,
    KEY          `idx_type` (`type`) USING BTREE
) ENGINE=InnoDB COMMENT='内部模型文件表';
