package main

import (
	"bufio"
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/test-translate/client"

	"github.com/zeromicro/go-zero/core/logx"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var (
	threads = flag.Int("threads", 1, "Run thread numbers per test")
)

var logger logx.Logger
var config struct {
	ClientConf *client.Config
}

const (
	//  `scene_id` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '场景id 1-日常问候 2-酒店-hotel 3-购物 4-餐厅 5-商务',
	DailyGreetings = 1
	Hotel          = 2
	Shopping       = 3
	Restaurant     = 4
	Business       = 5
)

func Process(ctx context.Context) error {
	address := "10.30.63.119:28083"
	diaOpt := grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(100*1024*1024), grpc.MaxCallSendMsgSize(100*1024*1024))
	conn, err := grpc.Dial(address, grpc.WithTransportCredentials(insecure.NewCredentials()), diaOpt)
	if err != nil {
		return fmt.Errorf("failed to dial: %v", err)
	}
	defer conn.Close()

	// 读取目录 data/origin 下所有 txt 文件
	origin := "data/origin/increment-0408"
	files, err := os.ReadDir(origin)
	if err != nil {
		return fmt.Errorf("failed to read dir: %v", err)
	}

	logger.Infof("files: %v", files)
	c := client.NewClient(config.ClientConf, conn)
	for i, file := range files {
		logger.Infof(">>>>>>>>> file: %v, process: %d/%d <<<<<<<<<<", file.Name(), i+1, len(files))

		start := time.Now()
		scene := 0
		switch file.Name() {
		case "Business.txt":
			scene = Business
		case "DailyGreetings.txt":
			scene = DailyGreetings
		case "Hotel.txt":
			scene = Hotel
		case "Restaurant.txt":
			scene = Restaurant
		case "Shopping.txt":
			scene = Shopping
		default:
			return fmt.Errorf("unknown file: %v", file.Name())
		}

		// 循环按行读取 file 文件内容
		f, err := os.Open(origin + "/" + file.Name())
		if err != nil {
			return fmt.Errorf("failed to open file: %v", err)
		}
		defer f.Close()

		// 创建一个 Scanner
		scanner := bufio.NewScanner(f)
		var limit = make(chan struct{}, *threads)
		var wg sync.WaitGroup
		// 按行读取文件内容
		for scanner.Scan() {
			line := scanner.Text() // 获取当前行的文本
			logger.Infof("line: %v", line)

			// 限制并发数
			limit <- struct{}{}
			wg.Add(1)
			go func() {
				defer func() {
					wg.Done()
					<-limit
				}()

				err := c.Translate(ctx, line, scene)
				if err != nil {
					logger.Errorf("Request failed: %v", err)
					log.Fatalf("Request failed: %v", err)
				}
			}()
		}
		wg.Wait()

		// 检查是否有读取错误
		if err := scanner.Err(); err != nil {
			fmt.Println("读取文件时出错:", err)
		}

		logger.Infof("scene: %v, time: %.3fs", scene, time.Since(start).Seconds())
	}
	return nil
}

func main() {
	flag.Parse()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	logger = logx.WithContext(ctx)
	logger.Infof("threads: %d", *threads)

	signalCh := make(chan os.Signal, 1)
	signal.Notify(signalCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		select {
		case <-ctx.Done():
			return
		case sig := <-signalCh:
			logger.Infof("Received signal: %v", sig)
			cancel()
		}
	}()

	beginTime := time.Now()

	err := Process(ctx)
	if err != nil {
		logger.Errorf("Process failed: %v", err)
		return
	}

	totalTime := time.Since(beginTime)
	logger.Infof("Total time: %.3fs", totalTime.Seconds())
}
