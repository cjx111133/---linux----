package config

import (
	"encoding/json"
	"fmt"
	"strings"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/grayscale"
)

type AudioTranslate struct {
	SpeechToTextParam      SpeechToTextParam `json:"speech_to_text"`
	TranslateParam         TranslateParam    `json:"translate"`
	TextToSpeechParam      TextToSpeechParam `json:"text_to_speech"`
	EnableContext          bool              `json:"enable_context,default=false"`
	ContextNum             int               `json:"context_num,default=10"`              // 0 表示不限制
	ContextPeriod          int               `json:"context_period,default=86400"`        // 0 表示不限制
	TimePeriod             int               `json:"time_period,default=10"`              // 0 表示不限制
	NextTimePeriod         int               `json:"next_time_period,default=10"`         // 0 已收到数据，等待下次收到数据的时间 毫秒
	LangDetectPeriod       int               `json:"lang_detect_period,default=1000"`     // 语言检测超时
	SimultaneousTimePeriod int               `json:"simultaneous_time_period,default=30"` // 同声传译超时
	AudioGrayScaleConfig   GrayScaleConfig   `json:"audio_gray_scale_config,optional"`    // 语音的灰度配置
	SimultaneousLineTime   float64           `json:"simultaneous_line_time,default=1"`    // 同声传译换行时间
	SupportMsgIdNum        int               `json:"support_msg_id_num,default=3"`        // 同时支持的msgId个数	默认3个，0 表示不限制
}

type SpeechToTextParam struct {
	EndPointType       string `json:"end_point_type,default=cloud_vad"`
	AddPunctuation     bool   `json:"add_punctuation,default=true"`
	MaxSentenceSilence int    `json:"max_sentence_silence,default=500"`
	EnableWord         bool   `json:"enable_word,default=true"`
	UseTempResult      bool   `json:"use_temp_result,default=false"`
	ServiceProvider    string `json:"service_provider,default=azure"`
}

type TranslateParam struct {
	LlmType         string `json:"llm_type,default=qwen-turbo"`
	EnableStream    bool   `json:"enable_stream,default=true"`
	LlmTypeSentence string `json:"llm_type_sentence,default=gpt-4o-mini"`
	ServiceProvider string `json:"service_provider,default=azure"`
}

type TextToSpeechParam struct {
	Voice           string `json:"voice,omitempty"`
	Speed           int    `json:"speed,default=0"`
	Volume          int    `json:"volume,default=50"`
	Pitch           int    `json:"pitch,default=0"`
	EnableSubtitle  bool   `json:"enable_subtitle,default=true"`
	ServiceProvider string `json:"service_provider,default=azure"`
}

type ChatParam struct {
	EnableFlow bool `json:"enable_flow,default=true"` // 是否需要流式返回
}

type GrayScaleConfig struct {
	GrayScaleConfig grayscale.Config `json:"gray_scale_config,optional"` // 灰度配置
	TrafficLimit    int64            `json:"traffic_limit,default=0"`    // 自研流量上限
	TrafficRatio    int64            `json:"traffic_ratio,default=0"`    // 自研流量比例
}

func (p *SpeechToTextParam) String(targetLanguage string, useTempResult bool) string {
	return fmt.Sprintf(`{"target_language": "%s","end_point_type": "%s","add_punctuation": %t,"max_sentence_silence": %d,"enable_word": %t, "use_temp_result": %t,"service_provider": "%s"}`,
		targetLanguage, p.EndPointType, p.AddPunctuation, p.MaxSentenceSilence, p.EnableWord, useTempResult, p.ServiceProvider)
}

func (p *TranslateParam) String(role, fromLang, toLang string, enableStream bool) string {
	return fmt.Sprintf(`{"from_lang": "%s","to_lang": "%s","llm_type": "%s","role": "%s","enable_stream": %t, "service_provider": "%s", "llm_type_sentence": "%s"}`,
		fromLang, toLang, p.LlmType, role, enableStream, p.ServiceProvider, p.LlmTypeSentence)
}

func (p *TranslateParam) StringWithContext(role, fromLang, toLang string, enableStream bool, contexts []*types.TranslateContext) string {
	value, _ := json.Marshal(contexts)
	return fmt.Sprintf(`{"from_lang": "%s","to_lang": "%s","llm_type": "%s","role": "%s","enable_stream": %t, "service_provider": "%s", "contexts": %s}`,
		fromLang, toLang, p.LlmType, role, enableStream, p.ServiceProvider, string(value))
}

func (p *TextToSpeechParam) String(format string, sampleRate, bitRate, channels int32, language string) string {
	voice := p.Voice
	if len(voice) > 0 {
		data := make(map[string]string)
		err := json.Unmarshal([]byte(voice), &data)
		if err == nil && len(data) > 0 {
			voice = data[strings.ToLower(language)]
		}
	}
	return fmt.Sprintf(`{"format": "%s","sample_rate": %d,"bit_rate": %d,"channels": %d,"language": "%s","voice": "%s","speed": %d,"volume": %d,"pitch": %d,"enable_subtitle": %t, "service_provider": "%s"}`,
		format, sampleRate, bitRate, channels, language, voice, p.Speed, p.Volume, p.Pitch, p.EnableSubtitle, p.ServiceProvider)
}

func (p *ChatParam) String(modelName string, needReply, needQuestion, needEmotion bool, contexts string) string {
	return fmt.Sprintf(`{"service_provider": "%s","need_reply": %t,"need_question": %t,"need_emotion": %t}`, modelName, needReply, needQuestion, needEmotion)
}

type Chat struct {
	SpeechToTextParam       SpeechToTextParam `json:"speech_to_text"`
	TextToSpeechParam       TextToSpeechParam `json:"text_to_speech"`
	ChatParam               ChatParam         `json:"chat_param"`
	GrayScaleConfig         GrayScaleConfig   `json:"gray_scale_config,optional"`             // 灰度配置
	SpeechGapThreshold      int               `json:"speech_gap_threshold,default=2000"`      // 单句识别的间隔时间 0表示不限制
	SpeechInactivityTimeout int               `json:"speech_inactivity_timeout,default=8000"` // 多长时间不说话 返回超时信息 0 表示不限制
}
