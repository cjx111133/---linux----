package chat

import (
	"encoding/json"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

// VoiceASRPacket implements ChatPacketInterface for ASR only functionality
type VoiceASRPacket struct {
	task *BaseChatTask
}

func NewVoiceASRPacket(task *BaseChatTask) *VoiceASRPacket {
	return &VoiceASRPacket{
		task: task,
	}
}

// Send handles sending chat messages
func (p *VoiceASRPacket) Send(req *types.ChatReq) error {
	switch req.ReqStatus {
	case types.ReqStatusAlone:
		err := p.SendAlone(req)
		if err != nil {
			return err
		}
	case types.ReqStatusFirst:
		err := p.SendFirst(req)
		if err != nil {
			return err
		}
		p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
	case types.ReqStatusMiddle:
		err := p.SendMiddle(req)
		if err != nil {
			return err
		}
	case types.ReqStatusEnd:
		p.task.Infof("Chat CloseSend")
		p.task.stream.CloseSend()
	case types.ReqStatusStop:
		p.task.Infof("Chat Stop")
		select {
		case <-p.task.stopChan:
			p.task.Infof("Chat Stop: stopChan already closed")
		default:
			close(p.task.stopChan)
		}
	}

	return nil
}

// CreateAloneStreamTaskReq creates a standalone stream task request
func (p *VoiceASRPacket) CreateAloneStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	// Only handle presets or similar messages for standalone requests
	switch req.MessageType {
	case types.MessageTypePreset, types.MessageTypeSimilar, types.MessageTypeCustomer:
		// These types don't require ASR processing
		return streamReq
	}

	return streamReq
}

func (p *VoiceASRPacket) getChatflowParam(req *types.ChatReq) *config.DifyChatflowParam {
	chatflowParam := config.NewDefaultDifyChatFlowParams(p.GetContext(req))

	// Set language and other parameters from request
	chatflowParam.Set(common.InterfaceToString(req.Params["house_id"]), common.InterfaceToString(req.Params["language"]), common.InterfaceToString(req.Params["timezone"]))
	for key, value := range req.Params {
		chatflowParam.Params[key] = common.InterfaceToString(value)
	}
	return chatflowParam
}

// CreateFirstStreamTaskReq creates the first stream task request
func (p *VoiceASRPacket) CreateFirstStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	switch req.Type {
	case types.ReqTypeAudio:
		if req.Format == types.AudioFormatOpus {
			p.setupOpusWrapper(req, streamReq)
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Format:     req.Format,
						SampleRate: req.SampleRate,
						BitRate:    DefaultBitRate,
						Channels:   req.Channels,
						Language:   req.SourceLanguage,
					}},
			}
		}

		// Only include the Speech-to-Text node in the workflow
		streamReq.Workflow = append(streamReq.Workflow,
			&aimanagerrpcclient.Node{
				TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text),
				IsNeedResult: true,
				Parameters:   p.task.svcCtx.Config.Chat.SpeechToTextParam.String(req.SourceLanguage, false),
			})

	case types.ReqTypeSimultaneous:
		if req.Format == types.AudioFormatOpus {
			p.setupOpusWrapper(req, streamReq)
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Format:     req.Format,
						SampleRate: req.SampleRate,
						BitRate:    DefaultBitRate,
						Channels:   req.Channels,
						Language:   req.SourceLanguage,
					}},
			}
		}

		// Only include the Speech-to-Text node in the workflow
		streamReq.Workflow = append(streamReq.Workflow, []*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text), IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.SpeechToTextParam.String(req.SourceLanguage, false)},
		}...)
	}

	return streamReq
}

func (p *VoiceASRPacket) setupOpusWrapper(req *types.ChatReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	var targetAudio = &aicommon.AudioInfo{
		Format:      types.AudioFormatPcm,
		SampleRate:  req.SampleRate,
		BitRate:     DefaultBitRate,
		Channels:    1,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	var sourceAudio = &aicommon.AudioInfo{
		Format:      req.Format,
		SampleRate:  req.SampleRate,
		BitRate:     DefaultBitRate,
		Channels:    req.Channels,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}

	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
		IsNeedResult: false,
		Parameters:   getAudioString(targetAudio),
	})
	streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
		OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
			Source:      sourceAudio,
			IsEnableEnc: true,
		},
	}
}

// CreateMiddleStreamTaskReq creates a middle stream task request
func (p *VoiceASRPacket) CreateMiddleStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	// 发送识别请求
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}
	switch req.Type {
	case types.ReqTypeAudio:
		if req.Format == types.AudioFormatOpus {
			isEnableEnc := false
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
			streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
				OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
					Source: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  req.SampleRate,
						BitRate:     DefaultBitRate,
						Channels:    req.Channels,
						FrameSizeMs: req.FrameSizeMs,
						Language:    req.SourceLanguage,
						Format:      types.AudioFormatOpus,
					},
					IsEnableEnc: isEnableEnc,
				},
			}
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Data: []byte(req.Data),
					}},
			}
		}
	case types.ReqTypeSimultaneous:
		if req.Format == "opus" {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
			streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
				OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
					Source: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  16000,
						BitRate:     DefaultBitRate,
						Channels:    req.Channels,
						FrameSizeMs: 60,
						Language:    req.SourceLanguage,
						Format:      "opus",
					},
					IsEnableEnc: false,
				},
			}
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Data: []byte(req.Data),
					},
				},
			}
		}
	}

	return streamReq
}

// SendAlone sends standalone convert data
func (p *VoiceASRPacket) SendAlone(req *types.ChatReq) error {
	// 1. 无需创建连接的场景
	if !p.task.isCreateGrpcConn(req) {
		switch req.MessageType {
		case types.MessageTypePreset:
			p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
			p.task.utilLogic.SendPresetDataToRecv(req.CommonReq)
			p.task.utilLogic.SendEndDataToRecv(req.CommonReq, 2)
		}
		return nil
	}

	// 2. 创建连接的场景
	streamReq := p.CreateAloneStreamTaskReq(req)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)

	return nil
}

// SendFirst sends first convert data
func (p *VoiceASRPacket) SendFirst(req *types.ChatReq) error {
	streamReq := p.CreateFirstStreamTaskReq(req)
	p.task.Infof("Chat first Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// SendMiddle sends middle convert data
func (p *VoiceASRPacket) SendMiddle(req *types.ChatReq) error {
	streamReq := p.CreateMiddleStreamTaskReq(req)
	//p.task.Infof("Chat middle Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// GetContext gets the context for the request
func (p *VoiceASRPacket) GetContext(req *types.ChatReq) []*types.TranslateContext {
	if len(req.Data) == 0 {
		return nil
	}

	chatContexts := make([]*types.ChatContext, 0)
	err := json.Unmarshal([]byte(req.Data), &chatContexts)
	if err != nil {
		p.task.Errorf("Chat Unmarshal failed, err: %v", err)
		return nil
	}

	resultContexts := make([]*types.TranslateContext, 0)
	for _, chatContext := range chatContexts {
		resultContexts = append(resultContexts, &types.TranslateContext{
			Role: "user",
			Text: chatContext.User,
		})
	}

	return resultContexts
}
