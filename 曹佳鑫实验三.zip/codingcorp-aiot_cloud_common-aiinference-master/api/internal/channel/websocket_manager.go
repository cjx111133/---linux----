package channel

import (
	"net/http"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/gorilla/websocket"
	"github.com/pborman/uuid"
	"github.com/zeromicro/go-zero/core/logx"
)

// IWebSocketManager WebSocket管理器接口，定义WebSocket连接管理的功能
type IWebSocketManager interface {
	// UpdateConfig 更新配置
	UpdateConfig(config config.Config)
	// HandleConnection 处理WebSocket连接请求
	HandleConnection(w http.ResponseWriter, r *http.Request, data *types.WebSocketData)
	// RemoveClient 从管理器中移除客户端
	RemoveClient(sessionID string)
	// GetClient 获取指定会话ID的客户端
	GetClient(userId, sessionID string) (*WebSocketClient, bool)
	// GetClients 获取指定用户ID的客户端列表，如果openuuid不为空则只返回匹配的客户端
	GetClients(userId string, openuuid string) ([]*WebSocketClient, bool)
	// Cleanup 定期清理已过期的连接
	Cleanup()
}

// WebSocketManager WebSocket管理器，负责管理所有的WebSocket连接
type WebSocketManager struct {
	// config 配置
	config *config.Config
	svcCtx *svc.ServiceContext

	// 所有活跃的WebSocket客户端，userId -> sessionId -> WebSocketClient
	clients     map[string]map[string]*WebSocketClient
	clientsLock sync.RWMutex

	// upgrader WebSocket连接升级器
	upgrader websocket.Upgrader

	// 命令处理器，根据命令类型分派到不同的处理逻辑
	// commandHandlers map[string]CommandHandlerFunc
}

// CommandHandlerFunc 命令处理函数类型
type CommandHandlerFunc func(client *WebSocketClient, message []byte) error

var WsManager *WebSocketManager

func InitWebSocketManager(svcCtx *svc.ServiceContext) {
	WsManager = NewWebSocketManager(&svcCtx.Config, svcCtx)
}

// NewWebSocketManager 创建一个新的WebSocket管理器
func NewWebSocketManager(config *config.Config, svcCtx *svc.ServiceContext) *WebSocketManager {
	manager := &WebSocketManager{
		config:  config,
		svcCtx:  svcCtx,
		clients: make(map[string]map[string]*WebSocketClient),
		upgrader: websocket.Upgrader{
			ReadBufferSize:  1024,
			WriteBufferSize: 1024,
			CheckOrigin: func(r *http.Request) bool {
				return true
			},
		},
	}
	go manager.Cleanup()
	return manager
}

// UpdateConfig 更新配置
func (m *WebSocketManager) UpdateConfig(config config.Config) {
	m.config = &config
}

// HandleConnection 处理WebSocket连接请求
func (m *WebSocketManager) HandleConnection(w http.ResponseWriter, r *http.Request, data *types.WebSocketData) {
	// 确保会话ID存在
	if len(data.ConnectionInfo.SessionId) == 0 {
		data.ConnectionInfo.SessionId = uuid.New()
	} else {
		// 这是一个重连请求
		data.RetryConn = true
	}

	// 升级HTTP连接为WebSocket
	conn, err := m.upgrader.Upgrade(w, r, nil)
	if err != nil {
		logx.Errorf("Failed to upgrade to websocket: %v", err)
		return
	}

	// 创建一个新的客户端
	client := NewWebSocketClient(conn, r.Context(), m.svcCtx, m, data)

	// 注册客户端
	m.clientsLock.Lock()
	if _, ok := m.clients[data.ConnectionInfo.UserId]; !ok {
		m.clients[data.ConnectionInfo.UserId] = make(map[string]*WebSocketClient)
	}
	m.clients[data.ConnectionInfo.UserId][data.ConnectionInfo.SessionId] = client
	m.clientsLock.Unlock()

	// 启动客户端处理
	client.Start()
}

// RemoveClient 从管理器中移除客户端
func (m *WebSocketManager) RemoveClient(sessionID string) {
	m.clientsLock.Lock()
	defer m.clientsLock.Unlock()

	delete(m.clients, sessionID)
}

// GetClient 获取指定会话ID的客户端
func (m *WebSocketManager) GetClient(userId, sessionID string) (*WebSocketClient, bool) {
	m.clientsLock.RLock()
	defer m.clientsLock.RUnlock()

	if clients, ok := m.clients[userId]; ok {
		if client, ok := clients[sessionID]; ok {
			return client, true
		}
	}
	return nil, false
}

// GetClients 获取指定用户ID的客户端列表，如果openuuid不为空则只返回匹配的客户端
func (m *WebSocketManager) GetClients(userId string, openuuid string) ([]*WebSocketClient, bool) {
	m.clientsLock.RLock()
	defer m.clientsLock.RUnlock()

	// 检查用户是否存在
	userClients, ok := m.clients[userId]
	if !ok {
		return nil, false
	}

	// 如果openuuid为空，返回该用户的所有客户端
	if openuuid == "" {
		clients := make([]*WebSocketClient, 0, len(userClients))
		for _, client := range userClients {
			clients = append(clients, client)
		}
		return clients, true
	}

	// 如果openuuid不为空，查找匹配的客户端
	for _, client := range userClients {
		if client.data.ConnectionInfo.OpenUuid == openuuid {
			return []*WebSocketClient{client}, true
		}
	}

	// 没有找到匹配的客户端
	return nil, false
}

// Cleanup 定期清理已过期的连接
func (m *WebSocketManager) Cleanup() {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		now := time.Now()
		m.clientsLock.Lock()

		for _, userClient := range m.clients {
			for sessionId, client := range userClient {
				// 如果客户端超过15分钟没有活动，关闭它
				if now.Sub(client.lastActivity) > 15*time.Minute {
					client.Stop()
					delete(m.clients, sessionId)
				}
			}
		}

		m.clientsLock.Unlock()
	}
}
