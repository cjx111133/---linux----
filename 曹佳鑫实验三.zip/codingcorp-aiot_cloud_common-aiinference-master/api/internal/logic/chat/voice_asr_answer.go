package chat

import (
	"fmt"
	"io"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"

	"github.com/zeromicro/go-zero/core/threading"
	"go.uber.org/zap"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

// VoiceASRAnswer implements ChatTaskInterface for ASR processing only
type VoiceASRAnswer struct {
	*BaseChatTask
	packetLogic *VoiceASRPacket
	result      string
}

func NewVoiceASRAnswer(message *ChatMessage) *VoiceASRAnswer {
	answer := &VoiceASRAnswer{
		BaseChatTask: NewBaseChatTask(message),
	}
	answer.packetLogic = NewVoiceASRPacket(answer.BaseChatTask)
	return answer
}

func (l *VoiceASRAnswer) Process(req *types.ChatReq) error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		l.Logger.Error("Failed to create stream RPC connection", zap.Error(err), zap.String("messageId", req.MessageId))
		return err
	}
	l.stream = stream
	l.isCloseSend.Store(false)
	l.messageId = req.MessageId

	if l.isCreateGrpcConn(req) { // 是否需要创建grpc连接 处理单包无需grpc连接的问题
		threading.GoSafe(func() { l.ProcessReceive(req) })
	}
	return l.ProcessTimer(req)
}

func (l *VoiceASRAnswer) ProcessTimer(req *types.ChatReq) error {
	for {
		select {
		case data, ok := <-l.reqs:
			if !ok {
				return nil
			}
			l.packetLogic.Send(data)
		case <-l.wsData.StopWsChan:
			return nil
		}
	}
}

// ProcessReceive handles receiving messages for ASR
func (l *VoiceASRAnswer) ProcessReceive(req *types.ChatReq) {
	defer func() {
		l.Close()
	}()
	if l.stream == nil {
		return
	}

	var index int32
	recvChan := make(chan *aimanagerrpc.StreamTaskResp, 1)
	errChan := make(chan error, 1)

	// Set a timeout for receiving ASR results
	var timerRecv = time.NewTicker(time.Second * 60)
	var inactivityTimer *time.Ticker
	asrTimeout := time.Duration(l.svcCtx.Config.Chat.SpeechGapThreshold) * time.Millisecond
	var inactivityTimeout = time.Duration(l.svcCtx.Config.Chat.SpeechInactivityTimeout) * time.Millisecond
	if l.svcCtx.Config.Chat.SpeechInactivityTimeout > 0 {
		inactivityTimer = time.NewTicker(inactivityTimeout)
	}

	// Helper function to set or reset the timeout
	go func() {
		defer close(recvChan)
		defer close(errChan)
		for {
			resp, err := l.stream.Recv()
			if err != nil {
				errChan <- err
				return
			}
			select {
			case recvChan <- resp:
			case <-l.stopChan: // 立即响应关闭信号
				return
			}
		}
	}()

	defer func() {
		if timerRecv != nil {
			timerRecv.Stop()
		}
		if inactivityTimer != nil {
			inactivityTimer.Stop()
		}
	}()

	for {
		// 可以同时等待多个事件
		select {
		case <-timerRecv.C:
			l.Logger.Infof("ready to send to dify VoiceASRAnswer Timer %s", req.MessageId)
			return
		case <-inactivityTimer.C:
			l.Infof("send timeout message to dify VoiceASRAnswer Timer %s", req.MessageId)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespDataTimeout, fmt.Sprintf("undected message for %d seconds", l.svcCtx.Config.Chat.SpeechInactivityTimeout/1000))
			return
		case <-l.wsData.StopWsChan:
			return
		case <-l.stopChan:
			l.utilLogic.SendStopDataToRecv(req.CommonReq, index)
			return
		case err := <-errChan:
			index++
			if err == io.EOF {
				l.Infof("ASR Recv EOF, msgid:%s", l.messageId)
				l.utilLogic.SendEndDataToRecv(req.CommonReq, index)
				return
			}
			l.Errorf("ASR Recv failed, msgid:%s err: %v", l.messageId, err)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to receive data")
			return
		case streamRecv := <-recvChan:
			index++
			// 处理接收到的数据...
			resp, valid, _ := l.convert.ProcessStreamTaskRespData(streamRecv, req, index)

			// Reset timeout when receiving ASR data
			if valid && streamRecv.TaskType == aiparameter.TaskType_TASK_TYPE_Speech_To_Text {
				// If it's ASR data, reset the timeout
				if timerRecv != nil {
					timerRecv.Reset(asrTimeout)
				} else {
					l.Logger.Error("VoiceASRAnswer Timer is nil", zap.String("messageId", req.MessageId))
					return // Invalid state to reset timer
				}
				if inactivityTimer != nil {
					inactivityTimer.Reset(inactivityTimeout)
				}
				textData, ok := resp.SourceData.(types.SpeechToTextData)
				if !ok {
					l.Logger.Error("Failed to assert ASR data", zap.String("messageId", req.MessageId),
						zap.Any("resp", resp))
					l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to assert ASR data")
					return
				}
				if len(textData.Segments) > 0 {
					l.result = textData.Segments[len(textData.Segments)-1].Text
				}
			}
			l.utilLogic.SendSuccessDataToRecv(*resp)
		}
	}
}

func (l *VoiceASRAnswer) Close() {
	// Avoid duplicate cleanup
	if l.messageId == "" {
		return
	}

	l.Logger.Info("Closing VoiceASRAnswer", zap.String("message_id", l.messageId))

	// Close the stream
	l.StreamClose()

	select {
	case <-l.reqs:
		return
	default:
		close(l.reqs)
		l.reqs = nil
	}
}
