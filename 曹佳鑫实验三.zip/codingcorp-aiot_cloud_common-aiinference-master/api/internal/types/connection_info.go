package types

// ConnectionInfo 封装WebSocket连接的用户信息
type ConnectionInfo struct {
	HeaderEncryptData
	OpenUuid   string `json:"Openudid"`
	Cmd        string `json:"cmd"         validate:"required"` // 命令, 任务类型
	SessionId  string `json:"session_id"  validate:"required"` // 会话id，用于标识客户端
	Type       string `json:"type"        validate:"required"` // 类型，例如面对面翻译、同声传译
	AppId      string `json:"app_id"      validate:"required"` // 应用id
	UserId     string `json:"user_id"     validate:"required"` // 用户id
	LoginType  int    `json:"login_type"  validate:"required"` // 登录类型
	AppVersion string `json:"app_version" validate:"required"` // app版本
}
