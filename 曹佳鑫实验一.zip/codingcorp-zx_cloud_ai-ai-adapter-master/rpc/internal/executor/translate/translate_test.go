package translate

import (
	"context"
	"fmt"
	"testing"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/stretchr/testify/assert"
)

func TestStreamInference(t *testing.T) {
	ctx := context.Background()
	svcCtx := &svc.ServiceContext{}
	config.SrvConfigs = &config.SrvConfig{
		ALiYun: map[config.AppId]config.ALiYun{
			"soundcore": config.ALiYun{
				LLMUrl: "https://dashscope.aliyuncs.com/compatible-mode",
				ApiKey: []string{"sk-240ae462f14c43d2ac98664bde6feca4"},
			},
		},
	}
	executor := NewTranslateExecutor(ctx, svcCtx)

	t.Run("NilRequestChannel", func(t *testing.T) {
		err := executor.StreamInference(nil, make(chan *aiadapterrpc.InferenceResp))
		assert.NotNil(t, err)
		assert.Equal(t, "request or response channel is nil", err.Error())
	})

	t.Run("NilResponseChannel", func(t *testing.T) {
		err := executor.StreamInference(make(chan *aiadapterrpc.InferenceReq), nil)
		assert.NotNil(t, err)
		assert.Equal(t, "request or response channel is nil", err.Error())
	})

	t.Run("ValidChannels", func(t *testing.T) {
		reqChan := make(chan *aiadapterrpc.InferenceReq)
		respChan := make(chan *aiadapterrpc.InferenceResp)
		defer close(reqChan)
		go func() {

			reqChan <- &aiadapterrpc.InferenceReq{
				Header:             &aicommon.ReqHeader{},
				InferenceParameter: `{"text": "Hello, world, is there anything better than apple?"}`,
				ExtendedParameter:  `{"llm_type": "qwen-turbo", "from_lang": "en", "to_lang": "zh", "role": "user"}`,
			}
		}()

		go func() {
			err := executor.StreamInference(reqChan, respChan)
			fmt.Println("++++>", err)
			assert.Nil(t, err)
		}()

		select {
		case resp := <-respChan:
			assert.NotNil(t, resp)
		case <-time.After(5 * time.Second):
			t.Fatal("Test timed out")
		}
	})

	t.Run("EnableStream", func(t *testing.T) {
		reqChan := make(chan *aiadapterrpc.InferenceReq)
		respChan := make(chan *aiadapterrpc.InferenceResp)
		go func() {
			// defer close(reqChan)
			fmt.Println("添加任务")
			reqChan <- &aiadapterrpc.InferenceReq{
				Header:             &aicommon.ReqHeader{},
				InferenceParameter: `{"text": "Hello, world, is there anything better than apple?"}`,
				ExtendedParameter:  `{"llm_type": "qwen-turbo", "from_lang": "en", "to_lang": "zh", "role": "user", "enable_stream": true}`,
			}
			fmt.Printf("二号人物")
			reqChan <- &aiadapterrpc.InferenceReq{
				Header:             &aicommon.ReqHeader{},
				InferenceParameter: `{"text": "it's the second sentence'"}`,
				ExtendedParameter:  `{"llm_type": "qwen-turbo", "from_lang": "en", "to_lang": "zh", "role": "user", "enable_stream": true}`,
			}
			fmt.Printf("二号人物完成")
		}()
		go func() {
			for {
				select {
				case resp, ok := <-respChan:
					if !ok {
						return
					}
					fmt.Println(resp)
					assert.NotNil(t, resp)
				case <-time.After(20 * time.Second):
					fmt.Println("Test timed out")

				}
			}
		}()
		err := executor.StreamInference(reqChan, respChan)
		assert.Nil(t, err)

	})
}

func TestDoStreamInference(t *testing.T) {
	ctx := context.Background()
	svcCtx := &svc.ServiceContext{}
	executor := NewTranslateExecutor(ctx, svcCtx)

	t.Run("ContextDone", func(t *testing.T) {
		reqChan := make(chan *aiadapterrpc.InferenceReq)
		respChan := make(chan *aiadapterrpc.InferenceResp)

		ctx, cancel := context.WithCancel(ctx)
		executor.ctx = ctx
		cancel()

		err := executor.doStreamInference(reqChan, respChan)
		assert.Nil(t, err)
	})

	t.Run("LogicContextDone", func(t *testing.T) {
		reqChan := make(chan *aiadapterrpc.InferenceReq)
		respChan := make(chan *aiadapterrpc.InferenceResp)

		go func() {
			defer close(reqChan)
			reqChan <- &aiadapterrpc.InferenceReq{
				InferenceParameter: `{"Text": "Hello"}`,
				ExtendedParameter:  `{"LlmType": "qwen-turbo", "FromLang": "en", "ToLang": "zh", "Role": "user"}`,
			}
		}()

		go func() {
			err := executor.doStreamInference(reqChan, respChan)
			assert.Nil(t, err)
		}()

		select {
		case resp := <-respChan:
			assert.NotNil(t, resp)
		case <-time.After(5 * time.Second):
			t.Fatal("Test timed out")
		}
	})

	t.Run("EnableStream", func(t *testing.T) {
		reqChan := make(chan *aiadapterrpc.InferenceReq)
		respChan := make(chan *aiadapterrpc.InferenceResp)

		go func() {
			defer close(reqChan)
			reqChan <- &aiadapterrpc.InferenceReq{
				InferenceParameter: `{"Text": "Hello"}`,
				ExtendedParameter:  `{"LlmType": "qwen-turbo", "FromLang": "en", "ToLang": "zh", "Role": "user", "EnableStream": true}`,
			}
		}()

		go func() {
			err := executor.doStreamInference(reqChan, respChan)
			assert.Nil(t, err)
		}()

		select {
		case resp := <-respChan:
			assert.NotNil(t, resp)
		case <-time.After(5 * time.Second):
			t.Fatal("Test timed out")
		}
	})
}
