package audio

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"go.uber.org/zap"
)

// AudioMessageInterface defines the interface for audio message handling
type AudioMessageInterface interface {
	// WorkFlow handles the main workflow of audio translation
	WorkFlow(req *types.AudioTranslateReq)
	// WorkFlowOver handles the cleanup when workflow is completed
	WorkFlowOver()
}

// AudioMessage implements AudioMessageInterface
type AudioMessage struct {
	*AudioTranslateLogic

	contextManager *common.ContextManager
	convertManager ConvertManage

	messageId string
	audios    []*types.AudioTranslateReq // 用于记录音频数据

	lang string // 语种 用于记录当前的语种

	workFlow      aiparameter.TaskType // 当前工作流
	workFlowIndex int32                // 工作流索引  记录执行到第几个工作流，只有第一个工作流才会发送首包
}

func NewAudioMessage(manager *AudioTranslateLogic, first *types.AudioTranslateReq) *AudioMessage {
	l := &AudioMessage{
		AudioTranslateLogic: manager,
		contextManager:      common.NewContextManager(manager.Logger, manager.svcCtx, manager.connInfo),
		messageId:           first.MessageId,
		audios:              make([]*types.AudioTranslateReq, 0),
	}

	l.convertManager = NewConvertManager(manager.Logger, manager.svcCtx.Config, manager.connInfo, manager.utilLogic, l.contextManager)
	return l
}

func (l *AudioMessage) Run(first *types.AudioTranslateReq) {
	defer func() {
		l.WorkFlowOver() // 使用 defer 确保结束时释放资源
	}()

	l.Infof("Audio translate workflow started, msgId: %s, first: %+v", first.MessageId, *first)

	// 语种检测
	if first.SourceLanguage == types.AutoDetectLanguage && l.lang == "" {
		if err := NewLanguageDetectTask(l).Process(first); err != nil {
			l.Errorf("Language detection failed, msgId: %s, err: %v", first.MessageId, err)
			return
		}
	}

	// 语音翻译
	if err := NewTranslateTask(l).Process(first); err != nil {
		l.Errorf("Audio translation failed, msgId: %s, err: %v", first.MessageId, err)
		return
	}
}

func (l *AudioMessage) WorkFlowOver() {
	//先清理上层绑定
	l.AudioTranslateLogic.mu.Lock()
	defer l.AudioTranslateLogic.mu.Unlock()
	if _, ok := l.AudioTranslateLogic.msgLogicMap[l.messageId]; ok {
		delete(l.AudioTranslateLogic.msgLogicMap, l.messageId)
		l.messageId = ""
		l.Logger.Info("Audio translate workflow completed", zap.String("message_id", ""))
	}
}
