package sagemaker

import (
	"bytes"
	"context"
	"fmt"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	"image/png"
	"io"
	"math"
	"net/http"
	"regexp"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"github.com/nfnt/resize"
	"github.com/zeromicro/go-zero/core/logx"
	"golang.org/x/image/webp"
)

type GenerateImage struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger

	client *http.Client
}

func NewGenerateImage(ctx context.Context, svcCtx *svc.ServiceContext) *GenerateImage {
	return &GenerateImage{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		client: &http.Client{},
	}
}

func (g *GenerateImage) Inferences(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	startTime := time.Now()
	g.Infof("Inferences, start, task id: %v, SdDeployType: %v, TaskType: %v", req.TaskId, config.GetSrvConfig().SdDeployType, req.TaskType)
	defer func() {
		g.Infof("Inferences, end, task id: %v, cost: %v", req.TaskId, time.Since(startTime).Seconds())
	}()

	err := g.checkParameter(req)
	if err != nil {
		return nil, fmt.Errorf("Inferences, checkParameter failed, error: %v", err)
	}

	var resp *adaptermodel.AiGenerateImageResp
	if config.GetSrvConfig().SdDeployType == config.SD_DEPLOY_TYPE_BYOC {
		resp, err = g.InferencesByByoc(req)
		if err != nil {
			return nil, fmt.Errorf("Inferences, InferencesByByoc failed, error: %v", err)
		}
	} else {
		resp, err = g.InferencesByAws(req)
		if err != nil {
			return nil, fmt.Errorf("Inferences, InferencesByAws failed, error: %v", err)
		}
	}

	if resp == nil {
		return nil, fmt.Errorf("Inferences, startInferences failed, resp is nil")
	}

	resp.TimeTakenMs = int32(time.Since(startTime).Milliseconds())
	return resp, nil
}

func (g *GenerateImage) InferencesByByoc(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	payload, err := g.buildSdParameters(req)
	if err != nil {
		return nil, fmt.Errorf("InferencesByByoc, buildSdParameters failed, error: %v", err)
	}

	//g.Infof("InferencesByByoc payload params :%v", payload)

	sageReq := &adaptermodel.InvocationRequest{
		ID:            req.TaskId,
		Task:          req.GenerateImageParameter.TaskType,
		Username:      config.GetSrvConfig().AwsSd.UserName,
		ParamS3:       "",
		PayloadString: payload,
	}
	sageReq.Models, err = g.buildUsedModels(req)
	if err != nil {
		return nil, fmt.Errorf("InferencesByByoc, buildUsedModels failed, error: %v", err)
	}

	sageJSONInput, err := common.AnyToJson(sageReq)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}
	// os.WriteFile("sageJSONInput.json", []byte(sageJSONInput), 0644)
	endpointName, err := g.getEndpointName(req.TaskType)
	if err != nil {
		return nil, fmt.Errorf("InferencesByByoc, getEndpointName failed, error: %v", err)
	}

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         sageJSONInput,
		EndpointName: aws.String(endpointName),
		ContentType:  aws.String("application/json"),
	}
	// g.Infof("InferencesByByoc, invoke endpoint, task id: %v, endpoint name: %v", req.TaskId, config.GetDefaultConfig().SageMaker.Sd15EndpointName)
	sgmRunClient := GetSgmClient().SgmRunClient
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(g.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("invoke endpoint error: sageOutput is nil")
	}

	var sageResp adaptermodel.InvocationResponse
	err = common.JsonToAny(sageOutput.Body, &sageResp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	if len(sageResp.Images) == 0 || len(sageResp.Details) > 20 {
		g.Errorf("invoke endpoint fail, images: %v, parameters: %v, info: %v, details: %v", len(sageResp.Images), sageResp.Parameters, sageResp.Info, sageResp.Details)
		return nil, fmt.Errorf("invoke endpoint fail, images: %v, parameters: %v, info: %v, details: %v", len(sageResp.Images), sageResp.Parameters, sageResp.Info, sageResp.Details)
	}
	//g.Infof("invoke endpoint success, parameters: %v, info: %v, details: %v", sageResp.Parameters, sageResp.Info, sageResp.Details)

	if len(sageResp.Images) != int(req.GenerateImageParameter.BatchCount*req.GenerateImageParameter.BatchSize) {
		return nil, fmt.Errorf("InferencesByByoc, images count not match, expect: %v, actual: %v", req.GenerateImageParameter.BatchCount*req.GenerateImageParameter.BatchSize, len(sageResp.Images))
	}

	resp := &adaptermodel.AiGenerateImageResp{
		Code:    codes.CodeOk,
		Message: sageResp.Info,
	}
	for i, v := range sageResp.Images {
		data, err := common.Base64ToBytes(v)
		if err != nil {
			return nil, fmt.Errorf("InferencesByByoc, Base64ToBytes failed, image:[%v], error: %v", i, err)
		}

		resp.ImageInfos = append(resp.ImageInfos, &adaptermodel.ImageInfo{
			Data: data,
			Size: int64(len(data)),
		})
	}

	return resp, nil
}

func (g *GenerateImage) getEndpointName(taskType aiparameter.TaskType) (string, error) {
	sageMakerConfig := config.GetSrvConfig().SageMaker
	switch taskType {
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design:
		return sageMakerConfig.TextToImageDesignEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		return sageMakerConfig.PetPortraitEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer:
		return sageMakerConfig.StyleTransferEndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer1:
		return sageMakerConfig.StyleTransfer1EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer2:
		return sageMakerConfig.StyleTransfer2EndpointName, nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		return sageMakerConfig.StyleTransfer3EndpointName, nil
	}
	return "", fmt.Errorf("getEndpointName, taskType: %d is not support", taskType)
}

func (g *GenerateImage) buildUsedModels(req *adaptermodel.AiGenerateImageReq) (map[string]interface{}, error) {
	// 构建使用的模型映射
	models := make(map[string]interface{}, 4)
	models["space_free_size"] = 4e10

	// StableDiffusion 模型
	sdModel, ok := config.GetSrvConfig().ModelFile.StableDiffusion[req.GenerateImageParameter.SdModel]
	if !ok {
		return nil, fmt.Errorf("buildUsedModels, model StableDiffusion[%s] is not support", req.GenerateImageParameter.SdModel)
	}
	models["Stable-diffusion"] = []adaptermodel.UsedModel{
		{
			S3:        sdModel.ModelPath,
			ID:        sdModel.ModelID,
			ModelName: sdModel.ModelName,
			Type:      sdModel.ModelType,
		},
	}

	// VAE 模型
	if req.GenerateImageParameter.VaeModel != "" {
		vaeModel, ok := config.GetSrvConfig().ModelFile.VAE[req.GenerateImageParameter.VaeModel]
		if !ok {
			if req.GenerateImageParameter.VaeModel == "Automatic" {
				vaeModel = config.Model{
					ModelPath: "None",
					ModelID:   "VAE_Automatic",
					ModelName: "Automatic",
					ModelType: "VAE",
				}
			}
			return nil, fmt.Errorf("buildUsedModels, model VAE[%s] is not support", req.GenerateImageParameter.VaeModel)
		}
		models["VAE"] = []adaptermodel.UsedModel{
			{
				S3:        vaeModel.ModelPath,
				ID:        vaeModel.ModelID,
				ModelName: vaeModel.ModelName,
				Type:      vaeModel.ModelType,
			},
		}
	}

	// Lora 模型
	if len(req.GenerateImageParameter.LoraModels) > 0 {
		loraModels := make([]adaptermodel.UsedModel, 0, len(req.GenerateImageParameter.LoraModels))
		for _, v := range req.GenerateImageParameter.LoraModels {
			if len(v) == 0 {
				continue
			}
			loraModel, ok := config.GetSrvConfig().ModelFile.Lora[v]
			if !ok {
				// 如果没有找到对应的lora模型，查询训练模型的数据库表
				model, err := g.svcCtx.TrainModelFileModel.FindOneByModelName(g.ctx, v)
				if err != nil {
					return nil, fmt.Errorf("buildUsedModels, FindOneByModelName failed, lora[%s], error: %v", v, err)
				}
				if model != nil {
					loraModel = config.Model{
						ModelPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, model.ModelPath),
						ModelID:   model.ModelId,
						ModelName: model.ModelName,
						ModelType: model.Type,
					}
				} else {
					return nil, fmt.Errorf("buildUsedModels, model Lora[%s] is not support", v)
				}
			}
			loraModels = append(loraModels, adaptermodel.UsedModel{
				S3:        loraModel.ModelPath,
				ID:        loraModel.ModelID,
				ModelName: loraModel.ModelName,
				Type:      loraModel.ModelType,
			})
		}
		models["Lora"] = loraModels
	}

	// ControlNet 模型
	if len(req.GenerateImageParameter.Controlnet) > 0 {
		controlNetModels := make([]adaptermodel.UsedModel, 0, len(req.GenerateImageParameter.ControlnetModels))
		for _, v := range req.GenerateImageParameter.ControlnetModels {
			if len(v) == 0 {
				continue
			}
			controlNetModel, ok := config.GetSrvConfig().ModelFile.ControlNet[v]
			if !ok {
				return nil, fmt.Errorf("buildUsedModels, model ControlNet[%s] is not support", v)
			}
			controlNetModels = append(controlNetModels, adaptermodel.UsedModel{
				S3:        controlNetModel.ModelPath,
				ID:        controlNetModel.ModelID,
				ModelName: controlNetModel.ModelName,
				Type:      controlNetModel.ModelType,
			})
		}
		models["ControlNet"] = controlNetModels
	}

	return models, nil
}

func (g *GenerateImage) InferencesByAws(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	// step 1: create task
	inference, err := g.createInferences(req)
	if err != nil {
		return nil, fmt.Errorf("Inferences, createInferences failed, error: %v", err)
	}

	// step 2: upload parameter to S3
	err = g.uploadParameterToS3(req, inference.APIParamsS3UploadURL)
	if err != nil {
		return nil, fmt.Errorf("Inferences, uploadParameterToS3 failed, error: %v", err)
	}

	// step 3: start task
	resp, err := g.startInferences(req, inference.ID)
	if err != nil {
		return nil, fmt.Errorf("Inferences, startInferences failed, error: %v", err)
	}

	return resp, nil
}

func (g *GenerateImage) createInferences(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.InferenceV1, error) {
	// Define the request payload
	payload := adaptermodel.CreateInferencesPayload{
		InferenceType: req.GenerateImageParameter.InferenceType,
		TaskType:      req.GenerateImageParameter.TaskType,
		Models: adaptermodel.CreateInferencesModels{
			StableDiffusion: []string{req.GenerateImageParameter.SdModel},
			VAE:             []string{req.GenerateImageParameter.VaeModel},
			Embeddings:      []string{},
		},
	}
	payloadBytes, err := common.AnyToJson(payload)
	if err != nil {
		return nil, fmt.Errorf("createInferences, marshal payload failed, error: %v", err)
	}
	payloadBuffer := bytes.NewBuffer(payloadBytes)
	// g.Infof("createInferences, payload: %s", payloadBuffer.String())

	// Define the request
	url := config.GetSrvConfig().AwsSd.ApiGatewayUrl + adaptermodel.SAGEMAKER_INFERENCE_URL
	postReq, err := http.NewRequestWithContext(g.ctx, "POST", url, payloadBuffer)
	if err != nil {
		return nil, fmt.Errorf("createInferences, create http req failed, error: %v", err)
	}
	g.setHttpHeader(postReq)
	// Perform the request
	postResp, err := g.client.Do(postReq)
	if err != nil {
		return nil, fmt.Errorf("createInferences, send http req failed, error: %v", err)
	}
	defer postResp.Body.Close()

	// Read the response body
	body, err := io.ReadAll(postResp.Body)
	if err != nil {
		return nil, fmt.Errorf("createInferences, read response body failed, error: %v", err)
	}
	// Unmarshal the response body into the Response struct
	var response adaptermodel.CreateInferencesResponse
	err = common.JsonToAny(body, &response)
	if err != nil {
		return nil, fmt.Errorf("createInferences, unmarshal response body failed, error: %v", err)
	}
	// g.Infof("createInferences, response statusCode: %v, message:%v, task id: %v", response.StatusCode, response.Message, response.Data.Inference.ID)

	if postResp.StatusCode != http.StatusOK && postResp.StatusCode != http.StatusCreated {
		return nil, fmt.Errorf("createInferences, response status code: %s", postResp.Status)
	}

	return &response.Data.Inference, nil
}

func (g *GenerateImage) buildSdParameters(req *adaptermodel.AiGenerateImageReq) (string, error) {
	// 构建SD参数
	const SdParams = `{"prompt": %s, "negative_prompt": %s, "seed": -1, "subseed": -1, "sampler_name": %s, "batch_size": %d, "n_iter": %d, "steps": %d, "cfg_scale": %f, "width": %d, "height": %d, "restore_faces": null, "tiling": null, "eta": null, "denoising_strength": %f, "init_images": [%s], "alwayson_scripts": {"controlnet": {"args": %s}}}`

	controlnet, err := common.AnyToJson(req.GenerateImageParameter.Controlnet)
	if err != nil {
		return "", fmt.Errorf("buildSdParameters, marshal controlnet failed, error: %v", err)
	}

	initImages := "null"
	if req.GenerateImageParameter.TaskType != adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_txt2img {
		initImage := common.BytesToBase64(req.GenerateImageParameter.InitImage)
		initImages = fmt.Sprintf("\"%s\"", initImage)
	}
	prompt, err := common.AnyToJson(req.GenerateImageParameter.Prompt)
	if err != nil {
		return "", fmt.Errorf("buildSdParameters, marshal Prompt failed, error: %v", err)
	}
	negativePrompt, err := common.AnyToJson(req.GenerateImageParameter.NegativePrompt)
	if err != nil {
		return "", fmt.Errorf("buildSdParameters, marshal NegativePrompt failed, error: %v", err)
	}
	samplerName, err := common.AnyToJson(req.GenerateImageParameter.SamplerName)
	if err != nil {
		return "", fmt.Errorf("buildSdParameters, marshal SamplerName failed, error: %v", err)
	}

	payload := fmt.Sprintf(SdParams, prompt, negativePrompt, samplerName, req.GenerateImageParameter.BatchSize, req.GenerateImageParameter.BatchCount, req.GenerateImageParameter.Steps, req.GenerateImageParameter.CfgScale, req.GenerateImageParameter.Width, req.GenerateImageParameter.Height, req.GenerateImageParameter.DenoisingStrength, initImages, controlnet)

	return payload, nil
}

func (g *GenerateImage) uploadParameterToS3(req *adaptermodel.AiGenerateImageReq, uploadURL string) error {
	payload, err := g.buildSdParameters(req)
	if err != nil {
		return fmt.Errorf("uploadParameterToS3, buildSdParameters failed, error: %v", err)
	}

	// os.WriteFile("payload.json", []byte(payload), 0644)
	// Define the request
	payloadBuffer := bytes.NewBuffer([]byte(payload))
	putReq, err := http.NewRequestWithContext(g.ctx, "PUT", uploadURL, payloadBuffer)
	if err != nil {
		return fmt.Errorf("uploadParameterToS3, create http req failed, error: %v", err)
	}
	// Perform the request
	putResp, err := g.client.Do(putReq)
	if err != nil {
		return fmt.Errorf("uploadParameterToS3, send http req failed, error: %v", err)
	}
	defer putResp.Body.Close()

	// g.Infof("uploadParameterToS3, response Status:%v, Header: %v, Body:%s", putResp.Status, putResp.Header, body)

	if putResp.StatusCode < http.StatusOK || putResp.StatusCode > http.StatusIMUsed {
		return fmt.Errorf("uploadParameterToS3, response status code: %s", putResp.Status)
	}

	return nil
}

func (g *GenerateImage) startInferences(req *adaptermodel.AiGenerateImageReq, id string) (*adaptermodel.AiGenerateImageResp, error) {
	// Define the request
	sdUrl := config.GetSrvConfig().AwsSd.ApiGatewayUrl + adaptermodel.SAGEMAKER_INFERENCE_URL + "/" + id + "/start"
	putReq, err := http.NewRequestWithContext(g.ctx, "PUT", sdUrl, nil)
	if err != nil {
		return nil, fmt.Errorf("startInferences, create http req failed, error: %v", err)
	}
	g.setHttpHeader(putReq)
	// Perform the request
	putResp, err := g.client.Do(putReq)
	if err != nil {
		return nil, fmt.Errorf("startInferences, send http req failed, error: %v", err)
	}
	defer putResp.Body.Close()

	// Read the response body
	body, err := io.ReadAll(putResp.Body)
	if err != nil {
		return nil, fmt.Errorf("startInferences, read response body failed, error: %v", err)
	}

	// g.Infof("startInferences, response Status:%v, Header: %v, body:%s", putResp.Status, putResp.Header, body)

	if putResp.StatusCode != http.StatusOK && putResp.StatusCode != http.StatusAccepted {
		return nil, fmt.Errorf("startInferences, response status code: %s", putResp.Status)
	}

	if req.GenerateImageParameter.InferenceType == adaptermodel.SAGEMAKER_INFERENCE_TYPE_Real_time {
		var response adaptermodel.StartInferencesResponse
		err = common.JsonToAny(body, &response)
		if err != nil {
			return nil, fmt.Errorf("startInferences, unmarshal response body failed, error: %v", err)
		}
		if response.Data.Status != adaptermodel.SAGEMAKER_INFERENCE_STATUS_succeed {
			return nil, fmt.Errorf("startInferences, inference failed, status: %s", response.Data.Status)
		}

		resp := &adaptermodel.AiGenerateImageResp{
			Code:    codes.CodeOk,
			Message: response.Message,
		}
		for _, imgUrl := range response.Data.ImgPresignedUrls {
			data, err := common.DownloadFile(g.ctx, imgUrl)
			if err != nil {
				return nil, fmt.Errorf("startInferences, download image failed, error: %v", err)
			}
			dataLen := int64(len(data))
			g.Infof("startInferences, download image success, url: %s, len: %d", imgUrl, dataLen)

			resp.ImageInfos = append(resp.ImageInfos, &adaptermodel.ImageInfo{
				// Md5:  common.Md5(data), // 暂不计算md5
				Size: dataLen,
				Data: data,
			})
		}
		return resp, nil
	}

	return nil, fmt.Errorf("startInferences, not support inference type: %s", req.GenerateImageParameter.InferenceType)
}

func (g *GenerateImage) checkParameter(req *adaptermodel.AiGenerateImageReq) error {
	if req == nil {
		return fmt.Errorf("checkParameter, req is nil")
	}

	switch req.GenerateImageParameter.TaskType {
	case adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_txt2img:
		if req.GenerateImageParameter.Prompt == "" {
			return fmt.Errorf("checkParameter, prompt is empty, task type: %v", req.TaskType)
		}
	default:
		if len(req.GenerateImageParameter.InitImage) <= 10 {
			return fmt.Errorf("checkParameter, initImage is empty, task type: %v", req.TaskType)
		}
	}

	if req.GenerateImageParameter.SamplerName == "" {
		req.GenerateImageParameter.SamplerName = "Euler a"
	}
	if req.GenerateImageParameter.BatchSize < 1 || req.GenerateImageParameter.BatchSize > 10 {
		req.GenerateImageParameter.BatchSize = 1
	}
	if req.GenerateImageParameter.BatchCount < 1 || req.GenerateImageParameter.BatchCount > 10 {
		req.GenerateImageParameter.BatchCount = 1
	}
	if req.GenerateImageParameter.Steps < 1 || req.GenerateImageParameter.Steps > 100 {
		req.GenerateImageParameter.Steps = 25
	}
	if req.GenerateImageParameter.CfgScale < 1 || req.GenerateImageParameter.CfgScale > 30 {
		req.GenerateImageParameter.CfgScale = 7.0
	}
	if req.GenerateImageParameter.Width < 1 || req.GenerateImageParameter.Height < 1 {
		req.GenerateImageParameter.Width = 1024
		req.GenerateImageParameter.Height = 1024
	}
	if req.GenerateImageParameter.Width*req.GenerateImageParameter.Height > 2048*2048 {
		ratio := math.Sqrt(float64(req.GenerateImageParameter.Width*req.GenerateImageParameter.Height) / float64(2048*2048))
		req.GenerateImageParameter.Width = int32(float64(req.GenerateImageParameter.Width) / ratio)
		req.GenerateImageParameter.Height = int32(float64(req.GenerateImageParameter.Height) / ratio)
	}
	if req.GenerateImageParameter.TaskType == adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_img2img {
		w, h, err := g.getTargetImageSize(req)
		if err != nil {
			return fmt.Errorf("checkParameter, getTargetImageSize failed, error: %v", err)
		}
		req.GenerateImageParameter.Width = w
		req.GenerateImageParameter.Height = h
	}
	if req.GenerateImageParameter.DenoisingStrength < 0 || req.GenerateImageParameter.DenoisingStrength > 1 {
		req.GenerateImageParameter.DenoisingStrength = 0.7
	}

	if req.GenerateImageParameter.SdModel == "" {
		return fmt.Errorf("checkParameter, sdModel is empty")
	}
	req.GenerateImageParameter.LoraModels = append(req.GenerateImageParameter.LoraModels, g.getLoraName(req.GenerateImageParameter.Prompt)...)
	req.GenerateImageParameter.LoraModels = g.deduplication(req.GenerateImageParameter.LoraModels)
	req.GenerateImageParameter.ControlnetModels = append(req.GenerateImageParameter.ControlnetModels, g.getControlnetName(req)...)
	req.GenerateImageParameter.ControlnetModels = g.deduplication(req.GenerateImageParameter.ControlnetModels)
	return nil
}

// 字符串数组去重
func (g *GenerateImage) deduplication(arr []string) []string {
	m := make(map[string]struct{})
	for _, v := range arr {
		m[v] = struct{}{}
	}
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}

var ControlnetPreprocessorMap = map[string]bool{
	"none":              true,
	"canny":             true,
	"depth_midas":       true,
	"depth_anything":    true,
	"depth_anything_v2": true,
	"normal_bae":        true,
	"normal_midas":      true,
	"animal_openpose":   true,
	"openpose":          true,
	"openpose_face":     true,
	"openpose_faceonly": true,
	"openpose_full":     true,
	"openpose_hand":     true,
	"dw_openpose_full":  true,
	"densepose_parula (black bg & blue torso)":      true,
	"densepose (pruple bg & purple torso)":          true,
	"mlsd":                                          true,
	"lineart_anime":                                 true,
	"lineart_anime_denoise":                         true,
	"lineart_realistic":                             true,
	"lineart_standard (from white bg & black line)": true,
	"softedge_hed":                                  true,
	"softedge_hedsafe":                              true,
	"softedge_pidinet":                              true,
	"softedge_pidisafe":                             true,
	"softedge_teed":                                 true,
	"scribble_hed":                                  true,
	"scribble_pidinet":                              true,
	"scribble_xdog":                                 true,
	"seg_anime_face":                                true,
	"seg_ofade20k":                                  true,
	"seg_ofcoco":                                    true,
	"seg_ufade20k":                                  true,
	"instant_id_face_embedding":                     true,
	"instant_id_face_keypoints":                     true,
	"ip-adapter_clip_sdxl":                          true,
	"ip-adapter_clip_sdxl_plus_vith":                true,
	"ip-adapter_face_id":                            true,
	"ip-adapter_face_id_plus":                       true,
	"t2ia_color_grid":                               true,
	"t2ia_sketch_pidi":                              true,
	"t2ia_style_clipvision":                         true,
}

var ControlModeMap = map[string]bool{
	"Balanced":                     true,
	"My prompt is more important":  true,
	"ControlNet is more important": true,
}

const (
	ControlMode_Balanced                    = "Balanced"
	ControlMode_PromptImportant             = "My prompt is more important"
	ControlMode_ControlNetImportant         = "ControlNet is more important"
	ControlnetPreprocessor_canny            = "canny"
	ControlnetPreprocessor_depth_midas      = "depth_midas"
	ControlnetPreprocessor_openpose_full    = "openpose_full"
	ControlnetPreprocessor_mlsd             = "mlsd"
	ControlnetPreprocessor_lineart_standard = "lineart_standard (from white bg & black line)"
	ControlnetPreprocessor_softedge_hed     = "softedge_hed"
)

func (g *GenerateImage) BuildControlnetParams(taskType string, controlnets []adaptermodel.Controlnet) ([]adaptermodel.Controlnet, error) {
	if len(controlnets) == 0 {
		out := []adaptermodel.Controlnet{
			{
				Enabled:               false,
				Module:                "none",
				Model:                 "None",
				Weight:                1,
				Image:                 nil,
				ResizeMode:            "Crop and Resize",
				LowVram:               false,
				ProcessorRes:          -1,
				ThresholdA:            -1,
				ThresholdB:            -1,
				GuidanceStart:         0,
				GuidanceEnd:           1,
				PixelPerfect:          false,
				ControlMode:           "Balanced",
				InpaintCropInputImage: false,
				HrOption:              "Both",
				SaveDetectedMap:       false,
				//AdvancedWeighting:     nil,
				IsUi:        false,
				InputMode:   "simple",
				BatchImages: "",
				OutputDir:   "",
				Loopback:    false,
			},
		}
		return out, nil
		// return []Controlnet{}, nil
	}

	out := make([]adaptermodel.Controlnet, 0, len(controlnets))
	for i, v := range controlnets {
		if !ControlnetPreprocessorMap[v.Module] {
			return nil, fmt.Errorf("buildControlnetParams, controlnets[%d] module[%v] is not support", i, v.Module)
		}
		if v.ControlMode != "" {
			if !ControlModeMap[v.ControlMode] {
				return nil, fmt.Errorf("buildControlnetParams, controlnets[%d] controlMode[%v] is not support", i, v.ControlMode)
			}
		}
		if v.Model == "" {
			return nil, fmt.Errorf("buildControlnetParams, controlnets[%d] model is empty, module: %v", i, v.Module)
		}
		if taskType == adaptermodel.SAGEMAKER_INFERENCE_TASK_TYPE_txt2img {
			if v.Image == nil || len(v.Image) == 0 {
				return nil, fmt.Errorf("buildControlnetParams, controlnet[%d] image is nil", i)
			}
		}

		v.Enabled = true
		if v.Weight <= 0 || v.Weight > 2 {
			v.Weight = 1.0
		}
		if v.ResizeMode == "" {
			v.ResizeMode = "Crop and Resize"
		}
		if v.ProcessorRes < 64 || v.ProcessorRes > 2048 {
			v.ProcessorRes = 512
		}
		if v.ThresholdA < 1 || v.ThresholdA > 255 {
			v.ThresholdA = 100
		}
		if v.ThresholdB < 1 || v.ThresholdB > 255 {
			v.ThresholdB = 200
		}
		if v.GuidanceStart < 0 || v.GuidanceStart > 1 {
			v.GuidanceStart = 1.0
		}
		if v.GuidanceEnd < 0 || v.GuidanceEnd > 1 {
			v.GuidanceEnd = 1.0
		}
		if v.GuidanceStart > v.GuidanceEnd {
			v.GuidanceStart, v.GuidanceEnd = v.GuidanceEnd, v.GuidanceStart
		}
		if v.ControlMode == "" {
			v.ControlMode = "Balanced"
		}
		if v.HrOption == "" {
			v.HrOption = "Both"
		}
		if v.InputMode == "" {
			v.InputMode = "simple"
		}
		out = append(out, v)
	}

	return out, nil
}

func (g *GenerateImage) getLoraName(prompt string) []string {
	re := regexp.MustCompile(`<lora:([^:]+):`)
	matches := re.FindAllStringSubmatch(prompt, -1)
	loras := make([]string, 0, len(matches))

	prefixes := make(map[string]string)
	for k := range config.GetSrvConfig().ModelFile.Lora {
		dotIndex := strings.LastIndex(k, ".")
		//dotIndex := strings.Index(k, ".")
		if dotIndex == -1 {
			prefixes[k] = k
		} else {
			prefixes[k[:dotIndex]] = k
		}
	}

	for _, match := range matches {
		if len(match) < 2 {
			continue
		}

		if k, exists := prefixes[match[1]]; exists {
			loras = append(loras, k)
		} else {
			// 如果没有找到对应的lora模型，查询训练模型的数据库表
			model, err := g.svcCtx.TrainModelFileModel.FindOneByInstanceName(g.ctx, match[1])
			if err != nil {
				g.Errorf("getLoraName, FindOneByInstanceName failed, error: %v", err)
				continue
			}
			if model != nil {
				loras = append(loras, model.ModelName)
			}
		}
	}
	return loras
}

func (g *GenerateImage) getControlnetName(req *adaptermodel.AiGenerateImageReq) []string {
	var controlnets []string

	for _, v := range req.GenerateImageParameter.Controlnet {
		if !v.Enabled {
			continue
		}

		for k := range config.GetSrvConfig().ModelFile.ControlNet {
			if v.Model == k {
				controlnets = append(controlnets, k)
			} else {
				dotIndex := strings.Index(k, ".")
				var stringAPrefix string
				if dotIndex == -1 {
					stringAPrefix = k
				} else {
					stringAPrefix = k[:dotIndex]
				}
				if v.Model == stringAPrefix {
					controlnets = append(controlnets, k)
				}
			}
		}
	}

	return controlnets
}

func (g *GenerateImage) setHttpHeader(req *http.Request) {
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", config.GetSrvConfig().AwsSd.APIToken)
	req.Header.Set("username", config.GetSrvConfig().AwsSd.UserName)
}

func (g *GenerateImage) getTargetImageSize(req *adaptermodel.AiGenerateImageReq) (int32, int32, error) {
	// 获取图片尺寸
	reader := bytes.NewReader(req.GenerateImageParameter.InitImage)
	img, format, err := image.Decode(reader)
	if err != nil {
		if err == image.ErrFormat && format == "webp" {
			// 重置reader，因为image.Decode可能已经读取了部分数据
			reader.Reset(req.GenerateImageParameter.InitImage)
			img, err = webp.Decode(reader)
			if err != nil {
				return 0, 0, fmt.Errorf("checkParameter, webp.Decode failed, error: %v", err)
			}
		} else {
			return 0, 0, fmt.Errorf("checkParameter, image.Decode failed, error: %v", err)
		}
	}

	size := img.Bounds().Size()
	originW := size.X
	originH := size.Y

	ratio := math.Sqrt(float64(originW*originH) / float64(req.GenerateImageParameter.Width*req.GenerateImageParameter.Height))
	// 生成图片的宽高
	w := int32(float64(originW) / ratio)
	h := int32(float64(originH) / ratio)
	w = int32(w/16) * 16
	h = int32(h/16) * 16

	if ratio > 1 {
		originW = int(w)
		originH = int(h)
	}

	// resize原图长宽为16的倍数
	tagetW := int(originW/16) * 16
	tagetH := int(originH/16) * 16
	img = resize.Resize(uint(tagetW), uint(tagetH), img, resize.Bicubic)
	buf := new(bytes.Buffer)
	err = png.Encode(buf, img)
	if err != nil {
		return 0, 0, fmt.Errorf("checkParameter, png.Encode failed, error: %v", err)
	}

	req.GenerateImageParameter.InitImage = buf.Bytes()
	return w, h, nil
}
