package channel

import (
	"context"
	"encoding/json"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/task"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/gorilla/websocket"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

// WebSocketClient 表示一个WebSocket客户端连接
type WebSocketClient struct {
	logx.Logger

	// 基础连接信息
	conn         *websocket.Conn      // WebSocket连接
	ctx          context.Context      // 上下文
	svcCtx       *svc.ServiceContext  // 服务上下文
	manager      *WebSocketManager    // 所属的管理器
	data         *types.WebSocketData // 客户端数据
	lastActivity time.Time            // 最后活动时间
	// configUpdated bool                 // 配置是否已更新

	streamLogic map[string]task.IStreamTask

	// 通道
	recvChan  chan []byte   // 接收用户消息通道
	sendChan  chan []byte   // 发送消息给用户通道
	closeChan chan struct{} // 关闭通道

	// 同步原语
	mu       sync.Mutex // 互斥锁，确保连接安全
	once     sync.Once  // 确保Stop方法只执行一次
	isClosed bool       // 连接是否已关闭

	// 可选的会话数据存储
	sessionData map[string]interface{}
	dataLock    sync.RWMutex
}

// NewWebSocketClient 创建一个新的WebSocket客户端
func NewWebSocketClient(
	conn *websocket.Conn,
	ctx context.Context,
	svcCtx *svc.ServiceContext,
	manager *WebSocketManager,
	data *types.WebSocketData,
) *WebSocketClient {

	client := &WebSocketClient{
		Logger:       logx.WithContext(ctx),
		conn:         conn,
		ctx:          ctx,
		svcCtx:       svcCtx,
		manager:      manager,
		data:         data,
		lastActivity: time.Now(),
		recvChan:     make(chan []byte, 2048), // 接收消息缓冲区
		sendChan:     make(chan []byte, 256),  // 发送消息缓冲区
		closeChan:    make(chan struct{}),
		sessionData:  make(map[string]interface{}),
	}
	data.SendWsChan = client.sendChan
	data.StopWsChan = client.closeChan
	client.streamLogic = task.NewStreamTaskMap(ctx, svcCtx, data)
	return client
}

// Start 启动WebSocket客户端的处理
func (c *WebSocketClient) Start() {
	c.Infof("WebSocket client started: sessionId=%s, cmd=%s, type=%s, app_version=%s, RetryConn=%v", c.data.ConnectionInfo.SessionId, c.data.ConnectionInfo.Cmd, c.data.ConnectionInfo.Type, c.data.ConnectionInfo.AppVersion, c.data.RetryConn)

	// 启动读取消息的协程
	threading.GoSafe(func() {
		c.readPump()
	})

	// 启动写入消息的协程
	threading.GoSafe(func() {
		c.writePump()
	})

	// 启动消息处理的协程
	threading.GoSafe(func() {
		c.processMessages()
	})
}

// Stop 停止WebSocket客户端
func (c *WebSocketClient) Stop() {
	c.once.Do(func() {
		c.Infof("Stopping WebSocket client: sessionId=%s", c.data.ConnectionInfo.SessionId)

		// 标记为已关闭
		c.mu.Lock()
		c.isClosed = true
		c.mu.Unlock()

		// 关闭WebSocket连接
		c.conn.Close()

		// 关闭通道，通知所有协程退出
		close(c.closeChan)

		// 保存会话数据以便后续可能的重连
		c.saveSessionData()

		// 从管理器中移除
		c.manager.RemoveClient(c.data.ConnectionInfo.SessionId)
	})
}

// Send 发送消息到客户端
func (c *WebSocketClient) Send(message []byte) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.isClosed {
		return nil // 连接已关闭，忽略消息
	}

	// 将消息放入发送通道
	select {
	case c.sendChan <- message:
		return nil
	default:
		// 如果通道已满，关闭连接
		c.Stop()
		return websocket.ErrCloseSent
	}
}

// readPump 从WebSocket连接读取消息
func (c *WebSocketClient) readPump() {
	defer c.Stop()

	// 设置读取超时和最大消息大小限制
	c.conn.SetReadDeadline(time.Now().Add(readWait))
	c.conn.SetReadLimit(int64(maxMessageSize))

	// 设置读取处理器
	c.conn.SetPongHandler(func(string) error {
		c.lastActivity = time.Now()
		c.conn.SetReadDeadline(time.Now().Add(readWait))
		return nil
	})

	for {
		_, message, err := c.conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err,
				websocket.CloseGoingAway,
				websocket.CloseAbnormalClosure) {
				c.Errorf("Unexpected close error: %v", err)
			}
			break
		}

		// 接到ping消息，返回pong消息
		if string(message) == types.CmdPing {
			c.lastActivity = time.Now()

			c.Debugf("WebSocketReadMessages read ping message, SessionId: %s", c.data.ConnectionInfo.SessionId)
			// 放一个字节流的pong回去
			c.mu.Lock()
			// 返回pong的bytes
			err = c.conn.WriteMessage(websocket.BinaryMessage, []byte("pong"))
			if err != nil {
				c.Errorf("WebSocketReadMessages write pong message error: %v", err)
			}
			c.Debugf("WebSocketReadMessages write pong message success, SessionId: %s", c.data.ConnectionInfo.SessionId)
			c.mu.Unlock()

			continue
		}

		c.conn.SetReadDeadline(time.Now().Add(readWait))

		// 接收到新消息，发送到接收通道
		select {
		case c.recvChan <- message:
		default:
			// 如果通道已满，丢弃消息
			// todo 通知前端消息丢弃
			c.Error("Receive channel full, message dropped")
		}
	}
}

// writePump 向WebSocket连接写入消息
func (c *WebSocketClient) writePump() {
	// 定义心跳间隔
	pingPeriod := readWait / 10
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		c.Stop()
	}()

	for {
		select {
		case <-c.closeChan:
			return

		case message := <-c.sendChan:
			// 设置写入超时
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))

			if err := c.conn.WriteMessage(websocket.TextMessage, message); err != nil {
				c.Errorf("Failed to write message: %v", err)
				return
			}

		case <-ticker.C:
			// 发送心跳
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				c.Errorf("Failed to write ping message: %v", err)
				return
			}
		}
	}
}

// processMessages 处理接收到的消息
func (c *WebSocketClient) processMessages() {
	for {
		select {
		case <-c.closeChan:
			return

		case message := <-c.recvChan: // todo 待优化
			// 交给管理器分发到对应的命令处理器
			if err := c.DispatchMessage(message); err != nil {
				c.Errorf("Failed to process message: %v", err)
			}
		}
	}
}

// DispatchMessage 分发消息到对应的命令处理器
func (m *WebSocketClient) DispatchMessage(message []byte) error {

	// 兼容旧协议：根据客户端的命令类型找到对应的处理器
	if handler, exists := m.streamLogic[m.data.ConnectionInfo.Cmd]; exists {
		if m.data.ConnectionInfo.Cmd == types.CmdPing {
			m.lastActivity = time.Now()
		}
		d := new(types.WebSocketReq)
		d.Data = message
		return handler.Handle(d)
	}

	// 尝试解析新协议格式
	var protocol = new(types.WebSocketReq)
	if err := json.Unmarshal(message, &protocol); err == nil {
		// 设置默认cmd
		if protocol.Cmd == "" {
			protocol.Cmd = types.CmdTranslate
		}
		// 根据协议中的cmd找到对应的处理器
		if handler, exists := m.streamLogic[protocol.Cmd]; exists {
			if m.data.ConnectionInfo.Cmd == types.CmdPing {
				m.lastActivity = time.Now()
			}
			return handler.Handle(protocol)
		}
	} else {
		m.Errorf("Failed to unmarshal message: %v", err)
	}

	// 未找到处理器，返回错误
	m.Errorf("Unsupported command: %s", string(message))
	return m.Send([]byte(`{"type":"error","error":"unsupported command"}`))
}

// SetSessionData 设置会话数据
func (c *WebSocketClient) SetSessionData(key string, value interface{}) {
	c.dataLock.Lock()
	defer c.dataLock.Unlock()
	c.sessionData[key] = value
}

// GetSessionData 获取会话数据
func (c *WebSocketClient) GetSessionData(key string) (interface{}, bool) {
	c.dataLock.RLock()
	defer c.dataLock.RUnlock()
	value, exists := c.sessionData[key]
	return value, exists
}

// saveSessionData 保存会话数据到持久化存储
func (c *WebSocketClient) saveSessionData() {
	// 这里可以实现保存会话数据到Redis或其他存储
	// 示例实现省略
}
