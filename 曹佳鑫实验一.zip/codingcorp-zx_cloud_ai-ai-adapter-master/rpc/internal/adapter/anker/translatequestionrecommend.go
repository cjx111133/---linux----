package anker

import (
	"context"
	"crypto/tls"
	"fmt"
	"net/http"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"github.com/zeromicro/go-zero/core/logx"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/go-resty/resty/v2"
)

type TranslateQuestionRecommendRequest struct {
	User         string                           `json:"user"`
	ResponseMode string                           `json:"response_mode"`
	Inputs       TranslateQuestionRecommendInputs `json:"inputs"`
}

type TranslateQuestionRecommendInputs struct {
	TargetLanguage string `json:"target_language"`
	QuestionsNum   int32  `json:"questions_num"`
	Context        string `json:"context"`
}

type TranslateQuestionRecommendResponse struct {
	TaskId        string                         `json:"task_id"`
	WorkflowRunId string                         `json:"workflow_run_id"`
	Data          TranslateQuestionRecommendData `json:"data"`
}
type TranslateQuestionRecommendData struct {
	Id          string                           `json:"id"`
	WorkflowId  string                           `json:"workflow_id"`
	Status      string                           `json:"status"`
	Outputs     TranslateQuestionRecommendOutput `json:"outputs"`
	Error       string                           `json:"error"`
	ElapsedTime float64                          `json:"elapsed_time"`
	TotalTokens int32                            `json:"total_tokens"`
	TotalSteps  int32                            `json:"total_steps"`
	CreatedAt   int32                            `json:"created_at"`
	FinishedAt  int32                            `json:"finished_at"`
}
type TranslateQuestionRecommendOutput struct {
	Code                 int32    `json:"code"`
	Message              string   `json:"message"`
	RecommendedQuestions []string `json:"recommended_questions"`
	Language             string   `json:"language"`
}

type TranslateQuestionRecommendClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	start time.Time
	Host  string
	Key   string

	request  <-chan *adaptermodel.TranslateQuestionRecommendReq
	response chan<- *adaptermodel.TranslateQuestionRecommendResp
	first    *adaptermodel.TranslateQuestionRecommendReq
}

func NewTranslateQuestionRecommendClient(ctx context.Context, svcCtx *svc.ServiceContext,
	host, apiKey string,
	request <-chan *adaptermodel.TranslateQuestionRecommendReq,
	response chan<- *adaptermodel.TranslateQuestionRecommendResp,
	first *adaptermodel.TranslateQuestionRecommendReq) *TranslateQuestionRecommendClient {
	return &TranslateQuestionRecommendClient{
		ctx:      ctx,
		svcCtx:   svcCtx,
		Logger:   logx.WithContext(ctx),
		start:    time.Now(),
		Host:     host,
		Key:      apiKey,
		request:  request,
		response: response,
		first:    first,
	}
}

func (c *TranslateQuestionRecommendClient) TranslateQuestionRecommend(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	c.start = time.Now()

	params, err := c.getDifyWorkflowParams(req)
	if err != nil {
		c.Errorf("getDifyWorkflowParams failed, err: %v", err)
		return nil, fmt.Errorf("getDifyWorkflowParams failed, err: %v", err)
	}

	c.Infof("TranslateQuestionRecommend params: %+v", *params)

	restyReq := resty.New().
		SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
		SetTimeout(10*time.Second).R().
		SetContext(c.ctx).
		SetHeader("Authorization", fmt.Sprintf("Bearer %s", c.Key)).
		SetBody(params)

	for i := 0; i < 3; i++ {
		ret, err := restyReq.Post(c.Host)
		if err != nil {
			c.Errorf("error sending dify request: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		defer ret.RawBody().Close()

		if ret.StatusCode() != http.StatusOK {
			c.Errorf("dify response status code: %s, error : %s, body: %s, ret: %+v", ret.Status(), ret.Error(), ret.String(), *ret)
			time.Sleep(500 * time.Millisecond)
			continue
		}

		var resp TranslateQuestionRecommendResponse
		err = common.JsonToAny(ret.Body(), &resp)
		if err != nil {
			c.Errorf("failed to unmarshal dify response: %+v, err: %v", string(ret.Body()), err)
			time.Sleep(500 * time.Millisecond)
			continue
		}

		if resp.Data.Error != "" {
			c.Errorf("dify response error: %s", resp.Data.Error)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		if resp.Data.Outputs.Code != 0 {
			c.Errorf("dify response code: %d, message: %s", resp.Data.Outputs.Code, resp.Data.Outputs.Message)
			time.Sleep(500 * time.Millisecond)
			continue
		}

		if len(resp.Data.Outputs.RecommendedQuestions) == 0 {
			c.Errorf("dify response recommended questions is empty")
			time.Sleep(500 * time.Millisecond)
			continue
		}

		c.Infof("TranslateQuestionRecommend, recv response, response: %+v", resp)
		return &adaptermodel.TranslateQuestionRecommendResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "",
			},
			Questions:   resp.Data.Outputs.RecommendedQuestions,
			Language:    resp.Data.Outputs.Language,
			TimeTakenMs: int32(time.Since(c.start).Milliseconds()),
		}, nil
	}

	c.Errorf("failed to get response from LLM for three times")
	return nil, fmt.Errorf("failed to get response from LLM for three times")
}

func (c *TranslateQuestionRecommendClient) TranslateQuestionRecommendStream() error {
	defer close(c.response)

	// set up the first request
	resp, err := c.TranslateQuestionRecommend(c.first)
	if err != nil {
		c.Errorf("TranslateQuestionRecommend failed, err: %v", err)
		return fmt.Errorf("TranslateQuestionRecommend failed, err: %v", err)
	}
	// c.Infof("TranslateQuestionRecommendStream, recv response, response: %+v", resp)
	c.response <- resp

	err = c.loop()
	if err != nil {
		c.Errorf("TranslateQuestionRecommendStream loop failed, err: %v", err)
		return fmt.Errorf("TranslateQuestionRecommendStream loop failed, err: %v", err)
	}
	c.Infof("TranslateQuestionRecommendStream end, time taken: %v", time.Since(c.start))
	return nil
}

func (c *TranslateQuestionRecommendClient) loop() (err error) {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("TranslateQuestionRecommendClient loop done, ctx done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("TranslateQuestionRecommendClient loop done, request channel closed")
				return nil
			}
			if req == nil {
				c.Errorf("TranslateQuestionRecommendClient loop, request is nil")
				return fmt.Errorf("request is nil")
			}

			resp, err := c.TranslateQuestionRecommend(req)
			if err != nil {
				c.Errorf("TranslateQuestionRecommendClient loop, TranslateQuestionRecommend failed, err: %v", err)
				return fmt.Errorf("TranslateQuestionRecommendClient loop, TranslateQuestionRecommend failed, err: %v", err)
			}
			// c.Infof("TranslateQuestionRecommendClient loop, recv response, response: %+v", resp)
			c.response <- resp
		}
	}
}

func (c *TranslateQuestionRecommendClient) getDifyWorkflowParams(req *adaptermodel.TranslateQuestionRecommendReq) (*TranslateQuestionRecommendRequest, error) {
	context, err := c.composeContext(req)
	if err != nil {
		c.Errorf("composeContext failed, err: %v", err)
		return nil, fmt.Errorf("composeContext failed, err: %v", err)
	}

	return &TranslateQuestionRecommendRequest{
		User:         config.GetSrvConfig().DifyWorkflow.User,
		ResponseMode: config.GetSrvConfig().DifyWorkflow.ResponseMode,
		Inputs: TranslateQuestionRecommendInputs{
			TargetLanguage: req.TargetLanguage,
			QuestionsNum:   req.QuestionsNumber,
			Context:        context,
		},
	}, nil
}

func (c *TranslateQuestionRecommendClient) composeContext(req *adaptermodel.TranslateQuestionRecommendReq) (string, error) {
	if len(req.Contexts) == 0 {
		return "", nil
	}
	for _, v := range req.Contexts {
		c.Debugf("composeContext, context: %+v, TargetLanguage: %s", *v, c.first.TargetLanguage)
	}

	context := ""
	for _, v := range req.Contexts {
		// if v.Lang != c.first.TargetLanguage {
		// 	continue
		// }

		if v.Role == "" || v.Text == "" {
			return "", fmt.Errorf("context role or text is empty")
		}
		context += fmt.Sprintf("%s: %s\n", v.Role, v.Text)
	}
	return context, nil
}
