package textsummary

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type TextSummaryExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewTextSummaryExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *TextSummaryExecutor {
	return &TextSummaryExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *TextSummaryExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *TextSummaryExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *TextSummaryExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.TextSummaryReq, error) {
	var ePara aiparameter.ExtractTextSummaryExtendedParameter
	var iPara aiparameter.ExtractTextSummaryInferenceParameter

	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}

	if len(in.GetResultUpTokens()) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}

	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	if len(iPara.GetImages()) == 0 {
		return nil, fmt.Errorf("InferenceParameter TextUrls is empty")
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}

	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	if len(ePara.GetLanguage()) == 0 {
		return nil, fmt.Errorf("ExtendedParameter Language is empty")
	}

	req := &adaptermodel.TextSummaryReq{
		TaskId:          in.Header.TaskId,
		AppId:           in.Header.AppId,
		ServiceProvider: ePara.ServiceProvider,
		TemplateContent: ePara.TemplateContent,
		Language:        ePara.Language,
		AesKey:          ePara.AesKey,
		TextUrls:        make([]string, 0),
		ResultUrl:       in.ResultUpTokens[len(in.ResultUpTokens)-1],
	}

	for _, v := range iPara.Images {
		req.TextUrls = append(req.TextUrls, v.FileData)
	}

	return req, nil
}

func (e *TextSummaryExecutor) doInference(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.TextSummaryHandler(req)
	if err != nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("task id: %s, InstantStyleHandler failed, code: %d, message: %s", req.TaskId, result.Code, result.Message)
	}

	return result, nil
}

func (e *TextSummaryExecutor) buildResponse(resp *adaptermodel.TextSummaryResp) (*aiadapterrpc.InferenceResp, error) {
	var out aiadapterrpc.InferenceResp

	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Audio_Fast_Transcription,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_ExtractTextSummary{
			ExtractTextSummary: &aiparameter.ExtractTextSummaryInferenceResultInfo{},
		},
	}

	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}

	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
		FileData: resp.ResultPath,
		FileMd5:  resp.ImageMd5,
		FileSize: resp.ImageSize,
	})

	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)

	return &out, nil
}
