package logic

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/sagemaker"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type PromptCheckLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewPromptCheckLogic(ctx context.Context, svcCtx *svc.ServiceContext) *PromptCheckLogic {
	return &PromptCheckLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *PromptCheckLogic) CheckPrompt(in *aiadapterrpc.PromptCheckReq) (*aiadapterrpc.PromptCheckResp, error) {
	resp := &aiadapterrpc.PromptCheckResp{}
	if err := l.checkParam(in); err != nil {
		l.Errorf("check prompt err : %s", err.Error())
		return nil, grpcerrors.Errorf(codes.CodeInputParamInvalid, err.Error(), grpcerrors.FindCaller(1))
	}

	bedRock := sagemaker.NewBedRockRuntime(l.ctx)
	result, err := bedRock.ApplyGuardrail(in.GetPrompt())
	if err != nil {
		l.Errorf("applyGuardrail err : %s", err.Error())
		return nil, err
	}

	if result == nil {
		return resp, nil
	}

	l.Infof("prompt check result, confidence : %s, checkType : %s", *result.Confidence, *result.Type)

	if *result.Confidence != "" {
		resp.Confidence = *result.Confidence
		resp.CheckType = *result.Type
		resp.CheckStatus = 1
	}

	return resp, nil
}

func (l *PromptCheckLogic) checkParam(in *aiadapterrpc.PromptCheckReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}
	if in.GetPrompt() == "" {
		return fmt.Errorf("prompt is empty")
	}
	return nil
}
