package anker

import (
	"context"
	"fmt"
	"io"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/audioprocessorrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/zeromicro/go-zero/core/logx"
)

type OpusWrapperClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	startTime time.Time

	request  <-chan *adaptermodel.OpusWrapperReq
	response chan<- *adaptermodel.OpusWrapperResp
	first    *adaptermodel.OpusWrapperReq
}

func NewOpusWrapperClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.OpusWrapperReq,
	response chan<- *adaptermodel.OpusWrapperResp,
	first *adaptermodel.OpusWrapperReq) *OpusWrapperClient {
	return &OpusWrapperClient{
		ctx:       ctx,
		svcCtx:    svcCtx,
		Logger:    logx.WithContext(ctx),
		startTime: time.Now(),
		request:   request,
		response:  response,
		first:     first,
	}
}

func (c *OpusWrapperClient) OpusWrapper() error {
	stream, err := c.svcCtx.AudioProcessorRpc.OpusWrapper(c.ctx)
	if err != nil {
		return fmt.Errorf("connect to audio processor server failed, err: %v", err)
	}

	// send first message
	err = stream.Send(&audioprocessorrpc.OpusWrapperReq{
		TaskId:  c.first.TaskId,
		PackIdx: 1,
		Source: &audioprocessorrpc.AudioMeta{
			SampleRate:  c.first.Source.SampleRate,
			Channels:    c.first.Source.Channels,
			BitRate:     c.first.Source.BitRate,
			Format:      c.first.Source.Format,
			FrameSizeMs: c.first.Source.FrameSizeMs,
		},
		Target: &audioprocessorrpc.AudioMeta{
			SampleRate:  c.first.Target.SampleRate,
			Channels:    c.first.Target.Channels,
			BitRate:     c.first.Target.BitRate,
			Format:      c.first.Target.Format,
			FrameSizeMs: c.first.Target.FrameSizeMs,
		},
		IsEnableEnc: c.first.IsEnableEnc,
		Data:        c.first.Source.Data,
	})
	if err != nil {
		return fmt.Errorf("send first message to audio processor server failed, err: %v", err)
	}

	var wg sync.WaitGroup
	wg.Add(2)
	defer wg.Wait()
	ctx, cancel := context.WithTimeout(stream.Context(), 7200*time.Second) // 2小时
	defer cancel()

	errCh := make(chan error, 2)
	// recv message from stream
	go func() {
		defer wg.Done()
		errCh <- c.recv(ctx, stream)
	}()
	// send message to stream
	go func() {
		defer wg.Done()
		errCh <- c.send(ctx, stream)
	}()

	for i := 0; i < 2; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}

	c.Infof("OpusWrapper end, time taken: %d ms", time.Since(c.startTime).Milliseconds())
	return nil
}

func (c *OpusWrapperClient) recv(ctx context.Context,
	stream audioprocessorrpc.AudioProcessorRpc_OpusWrapperClient) error {
	defer close(c.response)

	for {
		resp, err := stream.Recv()
		if err != nil {
			if err == io.EOF || err == context.Canceled {
				c.Infof("recv resp from audio processor server stream end, %v", err)
				return nil
			}
			return fmt.Errorf("recv resp from audio processor server stream failed, err: %v", err)
		}

		select {
		case <-ctx.Done():
			c.Infof("recv resp from audio processor server stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("recv resp from audio processor server stream end, logic context done")
			return nil
		default:
			if resp == nil {
				return fmt.Errorf("recv resp from audio processor server stream failed, resp is nil")
			}
			if resp.Code != 0 {
				c.Errorf("recv resp from audio processor server stream, code: %d, message: %s", resp.Code, resp.Message)
				return fmt.Errorf("recv resp from audio processor server stream failed, code: %d, message: %s", resp.Code, resp.Message)
			}

			c.Debugf("recv resp from audio processor server stream, code: %d, message: %s, data len: %d, format: %v, time taken: %d ms", resp.Code, resp.Message, len(resp.Data), c.first.Target.Format, resp.TimeTakenMs)

			c.response <- &adaptermodel.OpusWrapperResp{
				Header: &aicommon.RspHeader{
					Code:    resp.Code,
					Message: resp.Message,
				},
				Audio: &aicommon.AudioInfo{
					Data:       resp.Data,
					SampleRate: c.first.Target.SampleRate,
					BitRate:    c.first.Target.BitRate,
					Channels:   c.first.Target.Channels,
					Format:     c.first.Target.Format,
					Language:   c.first.Source.Language,
				},
				TimeTakenMs: resp.TimeTakenMs,
			}
		}
	}
}

func (c *OpusWrapperClient) send(ctx context.Context,
	stream audioprocessorrpc.AudioProcessorRpc_OpusWrapperClient) error {
	defer stream.CloseSend()
	packIdx := int32(1)

	for {
		select {
		case <-ctx.Done():
			c.Infof("send req to audio processor server stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("send req to audio processor server stream end, logic context done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send req to audio processor server stream end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send message failed, request is nil")
			}
			if req.Source == nil {
				return fmt.Errorf("send message failed, audio is nil")
			}
			if len(req.Source.Data) == 0 {
				c.Errorf("send message failed, audio data is empty")
				continue
			}

			packIdx++
			r := &audioprocessorrpc.OpusWrapperReq{
				TaskId:  c.first.TaskId,
				PackIdx: packIdx,
				Source: &audioprocessorrpc.AudioMeta{
					SampleRate:  c.first.Source.SampleRate,
					Channels:    c.first.Source.Channels,
					BitRate:     c.first.Source.BitRate,
					Format:      c.first.Source.Format,
					FrameSizeMs: c.first.Source.FrameSizeMs,
				},
				Target: &audioprocessorrpc.AudioMeta{
					SampleRate:  c.first.Target.SampleRate,
					Channels:    c.first.Target.Channels,
					BitRate:     c.first.Target.BitRate,
					Format:      c.first.Target.Format,
					FrameSizeMs: c.first.Target.FrameSizeMs,
				},
				IsEnableEnc: c.first.IsEnableEnc,
				Data:        req.Source.Data,
			}
			err := stream.Send(r)
			if err != nil {
				return fmt.Errorf("send message failed, err: %v", err)
			}
		}
	}
}
