package svc

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/middleware/clientinterceptor/errors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/middleware/clientinterceptor/prometheus"
	"github.com/zeromicro/go-zero/zrpc"
	"net/http"
	"time"

	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/ankerutil/encrypt/sensitive"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/healthcheck"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/queue/kq"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/proc"
	"github.com/zeromicro/go-zero/core/queue"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"github.com/zeromicro/go-zero/core/threading"
)

type ServiceContext struct {
	Config       config.Config
	RedisConn    *redis.Redis
	EncryptRedis *redis.Redis
	AiManagerRPC aimanagerrpcclient.AiManagerRpc

	AwsSagemakerClient *sagemakerruntime.SageMakerRuntime
	AiKafka            map[string]*queue.MessageQueue // 同步账号的kafka pusher
}

func NewServiceContext(c config.Config) *ServiceContext {
	logx.DisableStat()
	// 设置进程退出时间，避免业务逻辑未执行完毕导致进程退出
	proc.SetTimeToForceQuit(3 * time.Minute)
	healthCheck()

	var redisConn *redis.Redis
	//c.Cache[0].Host = "127.0.0.1:6379"
	//c.Cache[0].Type = ""
	//c.Cache[0].Pass = ""
	if len(c.Cache) > 0 {
		if c.Cache[0].Type == "cluster" {
			redisConn = redis.New(c.Cache[0].Host, redis.Cluster(), redis.WithPass(c.Cache[0].Pass), redis.WithHook(sensitive.Hook{}))
		} else {
			redisConn = redis.New(c.Cache[0].Host, redis.WithPass(c.Cache[0].Pass), redis.WithHook(sensitive.Hook{}))
		}
	}
	var encryptRedisConn *redis.Redis
	if len(c.EncryptCache) > 0 {
		if c.EncryptCache[0].Type == "cluster" {
			encryptRedisConn = redis.New(c.EncryptCache[0].Host, redis.Cluster(), redis.WithPass(c.EncryptCache[0].Pass), redis.WithHook(sensitive.Hook{}))
		} else {
			encryptRedisConn = redis.New(c.EncryptCache[0].Host, redis.WithPass(c.EncryptCache[0].Pass), redis.WithHook(sensitive.Hook{}))
		}
	}

	var aiManagerRPC aimanagerrpcclient.AiManagerRpc
	if c.AiManagerRPC != nil {
		// todo 本地调试
		//c.AiManagerRPC.Etcd.Hosts = []string{"etcd-cluster-us-qa-nlb-1166f5ab8999f1e9.elb.us-west-2.amazonaws.com:2379"}
		//c.AiManagerRPC.Etcd.User = "aiot-qa"
		//c.AiManagerRPC.Etcd.Pass = "aiot-qa@!~"
		//c.AiManagerRPC.Etcd.Key = "aiot-us-new-qa/aimanager.rpc"
		//
		aiManagerRPC = aimanagerrpcclient.NewAiManagerRpc(zrpc.MustNewClient(*c.AiManagerRPC,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor),
		))

		//client, _ := zrpc.NewClientWithTarget("10.30.52.154:38080")
		//aiManagerRPC = aimanagerrpcclient.NewAiManagerRpc(client)
	}

	return &ServiceContext{
		Config:             c,
		RedisConn:          redisConn,
		EncryptRedis:       encryptRedisConn,
		AiManagerRPC:       aiManagerRPC,
		AwsSagemakerClient: c.CreateAwsSagemakerClient(),
	}
}

func NewAiKafka(c config.Config, svcCtx *ServiceContext) map[string]queue.MessageQueue {
	aiKafka := make(map[string]queue.MessageQueue)

	for k, v := range c.AiKafka {

		aiKafka[k] = kq.MustNewQueue(v, kq.WithHandle(func(k, v string) error {
			fmt.Printf("%s => %s\n", k, v)
			return nil
		}))
	}
	return aiKafka
}

// healthCheck 健康检查.
func healthCheck() {
	threading.GoSafe(func() {
		health := healthcheck.NewHandler()
		health.AddLivenessCheck("basic-live-check", func() error {
			return nil
		})

		server := &http.Server{
			Addr:              ":8086",
			ReadHeaderTimeout: 3 * time.Second,
			Handler:           health,
		}
		err := server.ListenAndServe()
		if err != nil {
			logx.Error(err)
		}
	})
}
