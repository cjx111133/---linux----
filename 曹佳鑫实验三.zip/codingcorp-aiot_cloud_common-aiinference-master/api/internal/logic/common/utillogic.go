package common

import (
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/ankerutil/encrypt/symmetric"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"github.com/zeromicro/go-zero/core/logx"
	"golang.org/x/net/context"
)

// IUtilLogic 定义UtilLogic的接口
type IUtilLogic interface {
	CreateStreamRPCConn() (aimanagerrpc.AiManagerRpc_CreateStreamTaskClient, error)
	DataEncrypt(data string) string
	DataDecrypt(msg string) (string, error)
	GetModelName(config config.GrayScaleConfig) string
	IsUseAnkerModel(config config.GrayScaleConfig) bool
	IncryModel(delta int64)

	SendSuccessDataToRecv(resp interface{})

	SendFirstDataToRecv(req *types.CommonReq)
	SendEndData(req *types.CommonReq, index int32)
	SendEndDataToRecv(req *types.CommonReq, index int32)
	SendEndDataToRecvWithMessageId(req *types.CommonReq, index int32)
	SendStopDataToRecv(req *types.CommonReq, index int32)
	SendErrDataToRecv(req *types.CommonReq, code int32, msg string)
	SendErrDataToRecvWithMessageId(req *types.CommonReq, code int32, msg string)
	SendTimeoutDataToRecv(req *types.CommonReq)
	SendPresetDataToRecv(req *types.CommonReq)
}

type UtilLogic struct {
	logx.Logger
	Ctx      context.Context
	svcCtx   *svc.ServiceContext
	connInfo *types.ConnectionInfo
	sendChan chan []byte // 发送消息缓冲区

	secretKeyMap map[string]string // secretKeyMap 记录,减少redis查询
	modelName    string
}

func NewUtilLogic(ctx context.Context, svcCtx *svc.ServiceContext, data *types.WebSocketData) *UtilLogic {
	return &UtilLogic{
		Logger:       logx.WithContext(ctx),
		Ctx:          ctx,
		svcCtx:       svcCtx,
		connInfo:     data.ConnectionInfo,
		sendChan:     data.SendWsChan,
		secretKeyMap: make(map[string]string),
	}
}

// CreateStreamRPCConn 创建流式RPC连接
func (l *UtilLogic) CreateStreamRPCConn() (aimanagerrpc.AiManagerRpc_CreateStreamTaskClient, error) {
	stream, err := l.svcCtx.AiManagerRPC.CreateStreamTask(context.Background())
	if err != nil {
		l.Errorf("create stream rpc connection failed: %v", err)
		l.SendErrDataToRecv(&types.CommonReq{}, types.RespCodeConnErr, "Failed to create connection")
		return nil, err
	}
	return stream, nil
}

// DataEncrypt 加密数据
func (l *UtilLogic) DataEncrypt(data string) string {
	if l.connInfo.XEncryptionInfo != "algo_ecdh" {
		return data
	}

	encryptData, err := symmetric.AesCBCEncryptV2(data, l.secretKeyMap[l.connInfo.XKeyIdent])
	if err != nil {
		return data
	}

	return encryptData
}

// DataDecrypt 解密数据
func (l *UtilLogic) DataDecrypt(msg string) (string, error) {
	if l.connInfo.XEncryptionInfo != "algo_ecdh" {
		return msg, nil
	}

	if len(l.connInfo.XKeyIdent) != 32 {
		return "", errors.New("header X-Key-Ident is invalid")
	}

	// 1. 获取密钥
	secret, ok := l.secretKeyMap[l.connInfo.XKeyIdent]
	if !ok {
		var err error
		secretKey := "aiot:gateway:" + "key-" + l.connInfo.XKeyIdent
		secret, err = l.svcCtx.EncryptRedis.GetCtx(context.Background(), secretKey)
		if err != nil || len(secret) != 32 {
			return "", errors.New("secret key is invalid")
		}
		l.secretKeyMap[l.connInfo.XKeyIdent] = secret
	}

	if len(msg) == 0 {
		return msg, nil
	}

	// 2. 解密数据
	data, err := symmetric.AesCBCDecryptV2(msg, secret)
	if err != nil {
		return "", errors.New("decrypt data failed")
	}

	return data, nil
}

// GetModelName 获取模型名称
func (l *UtilLogic) GetModelName(config config.GrayScaleConfig) string {
	if l.modelName != "" {
		return l.modelName
	}

	if l.IsUseAnkerModel(config) {
		l.modelName = types.ModelAnker
	} else {
		l.modelName = l.svcCtx.Config.ExternalModel
	}

	l.IncryModel(1)
	return l.modelName
}

// IsUseAnkerModel 是否使用模型
func (l *UtilLogic) IsUseAnkerModel(config config.GrayScaleConfig) bool {
	if !config.GrayScaleConfig.InGrayMode(l.connInfo.UserId) {
		return false
	}

	// 如果配置了流量上限或者流量比例，则需要获取用户的流量信息
	if config.TrafficLimit == 0 && config.TrafficRatio == 0 {
		return true
	}

	ankerModelRedisKey := fmt.Sprintf(types.TranslateModelRedisKey, l.connInfo.AppId, types.ModelAnker)
	ankerValue, _ := l.svcCtx.RedisConn.Get(ankerModelRedisKey)
	ankerCount, _ := strconv.ParseInt(ankerValue, 10, 64)
	if config.TrafficLimit > 0 && ankerCount >= config.TrafficLimit {
		return false
	}

	if config.TrafficRatio > 0 {
		aliyunModelRedisKey := fmt.Sprintf(types.TranslateModelRedisKey, l.connInfo.AppId, l.svcCtx.Config.ExternalModel)
		aliyunValue, _ := l.svcCtx.RedisConn.Get(aliyunModelRedisKey)
		aliyunCount, _ := strconv.ParseInt(aliyunValue, 10, 64)
		if config.TrafficRatio > 0 && (aliyunCount+ankerCount) > 0 {
			// 使用浮点数进行除法运算，避免整数除法导致的精度丢失
			ratio := float64(ankerCount) / float64(aliyunCount+ankerCount) * 100
			if ratio >= float64(config.TrafficRatio) {
				return false
			}
		}
	}
	return true
}

// IncryModel 增加模型计数
func (l *UtilLogic) IncryModel(delta int64) {
	model := l.svcCtx.Config.ExternalModel
	if l.modelName == types.ModelAnker {
		model = types.ModelAnker
	}
	key := fmt.Sprintf(types.TranslateModelRedisKey, l.connInfo.AppId, model)
	val, _ := l.svcCtx.RedisConn.Incrby(key, delta)
	if val < 0 {
		l.svcCtx.RedisConn.Del(key)
	}
}

func (l *UtilLogic) SendSpeechEndDataToRecv(req *types.CommonReq, index int32, text string) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		Index:        index,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		ReqStatus:    types.ReqStatusMiddle,
		Type:         types.TaskTypeSpeechToText,
		Cmd:          l.connInfo.Cmd,
	}
	data, _ := json.Marshal(types.SpeechToTextData{
		SpeechEnd: true,
		Text:      text,
	})
	fmt.Println("=====> send speech end data", string(data))
	fmt.Println("=====> ", resp)
	resp.Data = l.DataEncrypt(string(data))
	l.SendSuccessDataToRecv(resp)
}

// SendSuccessDataToRecv 发送成功数据到接收端
func (l *UtilLogic) SendSuccessDataToRecv(resp types.RecvDataResp) {
	var data []byte
	if l.connInfo.Cmd != "" {
		data, _ = json.Marshal(resp) // 直接发送原始数据
	} else {
		respDataJson, _ := json.Marshal(resp)
		// 创建WebSocketResp包装
		wsResp := types.WebSocketResp{
			MsgId:        resp.MessageId,
			Code:         int64(resp.Code),
			Msg:          resp.Message,
			Cmd:          l.connInfo.Cmd,
			SubCmd:       "", // 可能需要从其他地方获取SubCmd
			Timestamp:    time.Now().UnixMilli(),
			CustomFields: resp.CustomFields,
			Data:         respDataJson,
		}
		data, _ = json.Marshal(wsResp)
	}
	select {
	case l.sendChan <- data:
		// 成功写入
		l.Debugf("Recv Data Write to ws client Success: %s", string(data))
	default:
		// 通道已关闭或阻塞，处理相应逻辑
		l.Errorf("Recv Data Write Fail: recv channel is closed or blocked")
	}
}

// SendFirstDataToRecv 发送首包数据到接收端
func (l *UtilLogic) SendFirstDataToRecv(req *types.CommonReq) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusFirst,
		Index:        0,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

func (l *UtilLogic) SendEndData(req *types.CommonReq, index int32) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		Index:        index,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

// SendEndDataToRecv 发送结束包数据到接收端
func (l *UtilLogic) SendEndDataToRecv(req *types.CommonReq, index int32) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		Index:        index,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}
func (l *UtilLogic) SendEndDataToRecvWithMessageId(req *types.CommonReq, index int32) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		Index:        index,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

// SendStopDataToRecv 发送停止包数据到接收端
func (l *UtilLogic) SendStopDataToRecv(req *types.CommonReq, index int32) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusStop,
		Index:        index,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

// SendErrDataToRecv 发送错误包数据给前端
func (l *UtilLogic) SendErrDataToRecv(req *types.CommonReq, code int32, msg string) {
	resp := types.RecvDataResp{
		Code:         code,
		Message:      msg,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

func (l *UtilLogic) SendErrDataToRecvWithMessageId(req *types.CommonReq, code int32, msg string) {
	resp := types.RecvDataResp{
		Code:         code,
		Message:      msg,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

// SendTimeoutDataToRecv 发送超时数据给前端，用于提示前端数据超时
func (l *UtilLogic) SendTimeoutDataToRecv(req *types.CommonReq) {
	resp := types.RecvDataResp{
		Code:         types.RespDataTimeout,
		Message:      "Data timeout",
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusEnd,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	l.SendSuccessDataToRecv(resp)
}

// SendPresetDataToRecv 发送预设数据给前端
func (l *UtilLogic) SendPresetDataToRecv(req *types.CommonReq) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusMiddle,
		Index:        1,
		ReqType:      req.Type,
		Type:         types.TaskTypeChat,
		MessageType:  req.MessageType,
		CustomFields: req.CustomFields,
		Cmd:          l.connInfo.Cmd,
	}
	data := types.ChatData{
		Questions: []string{"eufySecurity App Function Guide", "Differences Between All eufyCams", "Two-Step Verification for eufySecurity App", "How to View eufySecurity Cameras on a Computer"},
	}
	v, _ := json.Marshal(data)
	resp.Data = l.DataEncrypt(string(v))
	l.SendSuccessDataToRecv(resp)
}

func InterfaceToString(data interface{}) string {
	dataStr, ok := data.(string)
	if ok {
		return dataStr
	}
	return ""
}

func FixLanguage(language string) string {
	switch language {
	case "zh":
		language = "zh-CN"
	case "en":
		language = "en-US"
	case "ja":
		language = "ja-JP"
	}
	return language
}
