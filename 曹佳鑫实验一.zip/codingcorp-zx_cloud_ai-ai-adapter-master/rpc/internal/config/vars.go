package config

const (
	ADAPTER_SERVICE_TYPE_SAGEMAKER = "sagemaker"
	ADAPTER_SERVICE_TYPE_ALIYUN    = "aliyun"
	ADAPTER_SERVICE_TYPE_ANKER     = "anker"
	ADAPTER_SERVICE_TYPE_AZURE     = "azure"
	SD_DEPLOY_TYPE_BYOC            = "byoc"
	SD_DEPLOY_TYPE_SAGEMAKER       = "sagemaker"
)

type AppId string

const (
	APP_ID_SOUNDCORE    AppId = "soundcore"
	APP_ID_EUFY_MEGA    AppId = "eufy_mega"
	APP_ID_MAKE_IT_REAL AppId = "makeitreal"
	APP_ID_ANKER_MAKER  AppId = "anker_make"
)

const (
	MODEL_TYPE_STABLE_DIFFUSION = "Stable-diffusion"
	MODEL_TYPE_LORA             = "Lora"
	MODEL_TYPE_CONTROL_NET      = "ControlNet"
	MODEL_TYPE_VAE              = "VAE"
)

const (
	DIFY_RESPONSE_MODE_BLOCKING = "blocking"
	DIFY_RESPONSE_MODE_STREAM   = "streaming"
)

const (
	T9000_CHATFLOW_NAME     = "t9000_manager"
	SOUNDCORE_CHATFLOW_NAME = "soundcore_manager"
	// 助听助手
	HEARING_AID_CHATFLOW_NAME = "hearing_aid_manager"
	// DIFM
	DIFM_CHATFLOW_NAME = "DIFM_manager"
)

var (
	AUDIO_FORMAT_MP3  = "mp3"
	AUDIO_FORMAT_WAV  = "wav"
	AUDIO_FORMAT_PCM  = "pcm"
	AUDIO_FORMAT_OPUS = "opus"
	SUPPORTEN_FORMAT  = []string{
		"pcm", "wav", "opus", "mp3",
	}
)
