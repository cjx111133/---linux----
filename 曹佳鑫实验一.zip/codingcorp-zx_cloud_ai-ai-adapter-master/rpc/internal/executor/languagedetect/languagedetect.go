package languagedetect

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type LanguageDetectExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	buf *bytes.Buffer

	once   bool
	taskId string
}

func NewLanguageDetectExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *LanguageDetectExecutor {
	return &LanguageDetectExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		buf:    new(bytes.Buffer),
		once:   true,
	}
}

func (e *LanguageDetectExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	return nil, fmt.Errorf("Inference not implemented")
}

func (e *LanguageDetectExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}

	if config.GetSrvConfig().VadSaveAudio {
		index := 0
		for e.buf.Len() > 0 {
			index++
			data := common.BytesToBase64(e.buf.Next(8000))
			e.Infof("send req data to vad engine, TaskId: %s, index:%d, Base64 Audio: [%s]", e.taskId, index, data)
		}
		e.Infof("send req data to vad engine end, TaskId: %s, total index: %d", e.taskId, index)
	}

	e.Info("LanguageDetectExecutor StreamInference end")
	return nil
}

func (e *LanguageDetectExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("LanguageDetectExecutor doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		e.Infof("LanguageDetectExecutor doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("doStreamInference recv vad first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	llmReq := make(chan *adaptermodel.LanguageDetectReq, 100)
	llmResp := make(chan *adaptermodel.LanguageDetectResp, 100)
	llmReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from vad server
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, llmResp, cliResp)
	})
	// send message to vad server
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, llmReq, cliReq)
	})
	// handle message from vad server
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.LanguageDetectStreamHandler(llmReq, llmResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *LanguageDetectExecutor) recv(ctx context.Context, llmResp <-chan *adaptermodel.LanguageDetectResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-llmResp:
			if !ok {
				e.Infof("recv resp from llm engine end, llmResp channel closed")
				return nil
			}

			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			e.Infof("recv resp from vad server end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from vad server end, logic context done")
			return nil
		}
	}
}

func (e *LanguageDetectExecutor) send(ctx context.Context,
	llmReq chan *adaptermodel.LanguageDetectReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(llmReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to vad server end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to vad server end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to vad server end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to vad server failed, request is nil")
			}
			r, err := e.buildParameter(req)
			if err != nil {
				e.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			e.Debugf("send req to vad server, ServiceProvider: %s", r.ServiceProvider)

			if config.GetSrvConfig().VadSaveAudio && r.Audio != nil {
				e.buf.Write(r.Audio.Data)
			}

			llmReq <- r
		}
	}
}

func (e *LanguageDetectExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.LanguageDetectReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.LanguageDetectInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.LanguageDetectExtendedParameter
	if e.once {
		e.once = false
		e.taskId = in.Header.TaskId

		if in.ExtendedParameter == "" {
			return nil, fmt.Errorf("ExtendedParameter is empty")
		}
		err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
		if err != nil {
			return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
		}

		err = e.checkParameter(&iPara, &ePara)
		if err != nil {
			return nil, fmt.Errorf("checkParameter failed, err: %v", err)
		}
	}

	req := &adaptermodel.LanguageDetectReq{
		TaskId:          in.Header.TaskId,
		Text:            iPara.Text,
		ServiceProvider: ePara.ServiceProvider,
		Audio:           iPara.Audio,
	}

	return req, nil
}

func (e *LanguageDetectExecutor) checkParameter(
	iPara *aiparameter.LanguageDetectInferenceParameter,
	ePara *aiparameter.LanguageDetectExtendedParameter) error {
	if iPara.Audio == nil {
		return fmt.Errorf("InferenceParameter Text and Audio are empty")
	}
	if iPara.Audio.SampleRate == 0 {
		iPara.Audio.SampleRate = 16000
	}
	switch iPara.Audio.SampleRate {
	case 16000:
	default:
		return fmt.Errorf("InferenceParameter Audio SampleRate is invalid, SampleRate: %d", iPara.Audio.SampleRate)
	}
	if iPara.Audio.BitRate == 0 {
		iPara.Audio.BitRate = 16000
	}
	switch iPara.Audio.BitRate {
	case 8000, 16000, 32000, 48000, 64000, 96000, 128000, 192000, 256000:
	default:
		return fmt.Errorf("InferenceParameter Audio BitRate is invalid, BitRate: %d", iPara.Audio.BitRate)
	}
	switch iPara.Audio.Channels {
	case 1:
	default:
		return fmt.Errorf("InferenceParameter Audio Channel is invalid, Channel: %d", iPara.Audio.Channels)
	}
	iPara.Audio.Format = strings.ToLower(iPara.Audio.Format)
	switch iPara.Audio.Format {
	case config.AUDIO_FORMAT_PCM, config.AUDIO_FORMAT_WAV:
	default:
		return fmt.Errorf("InferenceParameter Audio Format is invalid, Format: %s", iPara.Audio.Format)
	}

	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ALIYUN, config.ADAPTER_SERVICE_TYPE_ANKER, config.ADAPTER_SERVICE_TYPE_AZURE:
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
	}

	return nil
}

func (e *LanguageDetectExecutor) buildResponse(resp *adaptermodel.LanguageDetectResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Language_Detect,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_LanguageDetect{
			LanguageDetect: &aiparameter.LanguageDetectInferenceResultInfo{
				Language:   resp.Language,
				Confidence: resp.Confidence,
				Timestamp:  time.Now().UnixMilli(),
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
