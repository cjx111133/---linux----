#e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter
