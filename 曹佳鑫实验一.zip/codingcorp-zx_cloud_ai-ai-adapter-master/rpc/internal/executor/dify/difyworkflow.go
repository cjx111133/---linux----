package dify

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type DifyWorkflowExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDifyWorkflowExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *DifyWorkflowExecutor {
	return &DifyWorkflowExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (d *DifyWorkflowExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := d.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}
	resp, err := d.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := d.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (d *DifyWorkflowExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := d.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}
	return nil
}

func (d *DifyWorkflowExecutor) receiveStream(resChan chan *adaptermodel.DifyWorkflowResp, cliResp chan<- *aiadapterrpc.InferenceResp) {
	defer close(cliResp)
	for {
		resp, ok := <-resChan
		if !ok {
			d.Infof("recv resp from llm engine end, resChan channel closed")
			return
		}
		if resp == nil {
			continue
		}
		out, err := d.buildResponse(resp)
		if err != nil {
			d.Errorf("buildResponse failed, err: %v", err)
			return
		}
		cliResp <- out
	}
}

func (d *DifyWorkflowExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		d.Infof("DifyWorkflow doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		d.Infof("DifyWorkflow doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := d.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}

	ctx, cancel := context.WithTimeout(d.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, d.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	workflowReq := make(chan *adaptermodel.DifyWorkflowReq, 100)
	workflowResp := make(chan *adaptermodel.DifyWorkflowResp, 100)
	workflowReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- d.recv(ctx, workflowResp, cliResp)
	})
	// send message to Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- d.send(ctx, workflowReq, cliReq)
	})
	// handle message from Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.DifyWorkflowStreamHandler(workflowReq, workflowResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (d *DifyWorkflowExecutor) recv(ctx context.Context, DifyWorkflowResp <-chan *adaptermodel.DifyWorkflowResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-DifyWorkflowResp:
			if !ok {
				d.Infof("recv resp from Dify end, DifyWorkflowResp channel closed")
				return nil
			}

			res, err := d.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			d.Infof("recv resp from Dify end, ctx done")
			return nil
		case <-d.ctx.Done():
			d.Infof("recv resp from Dify end, logic context done")
			return nil
		}
	}
}

func (d *DifyWorkflowExecutor) send(ctx context.Context,
	difyWorkflowReq chan *adaptermodel.DifyWorkflowReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(difyWorkflowReq)

	for {
		select {
		case <-ctx.Done():
			d.Infof("send req to Dify end, ctx done")
			return nil
		case <-d.ctx.Done():
			d.Infof("send req to Dify end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				d.Infof("send req to Dify end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to Dify failed, request is nil")
			}
			r, err := d.buildParameter(req)
			if err != nil {
				d.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			d.Infof("send req to dify, text: %s", r.Body.Inputs.Text)

			difyWorkflowReq <- r
		}
	}

}

func (d *DifyWorkflowExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.DifyWorkflowReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.DifyWorkflowInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.DifyWorkflowExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	err = d.checkParameter(&iPara, &ePara)
	if err != nil {
		return nil, fmt.Errorf("checkParameter failed, err: %v", err)
	}

	// var contexts []*adaptermodel.TranslateContext
	// if len(ePara.Contexts) > 0 {
	// 	if len(ePara.Contexts) > 10 {
	// 		// 只取最新的10个上下文
	// 		ePara.Contexts = ePara.Contexts[len(ePara.Contexts)-10:]
	// 	}
	// 	// TODO(joe): Dify Workflow 是否需要 外面传入 context?
	// 	contexts = make([]*adaptermodel.TranslateContext, 0, len(ePara.Contexts))
	// 	for _, v := range ePara.Contexts {
	// 		contexts = append(contexts, &adaptermodel.TranslateContext{
	// 			Text: v.Text,
	// 			Role: v.Role,
	// 			Lang: v.Language,
	// 		})
	// 	}
	// }

	req := &adaptermodel.DifyWorkflowReq{
		TaskId: in.Header.TaskId,
		Body: adaptermodel.DifyWorkflowReqBody{
			Inputs: adaptermodel.DifyWorkflowReqBodyInputs{
				// Text: iPara.Text,
			},
			ResponseMode: config.GetSrvConfig().DifyWorkflow.ResponseMode,
			User:         config.GetSrvConfig().DifyWorkflow.User,
		},
		ServiceProvider: ePara.ServiceProvider,
		// Contexts:        contexts,
	}

	d.Logger.Infof("dify workflow param %+v", req)
	return req, nil
}

func (d *DifyWorkflowExecutor) checkParameter(
	iPara *aiparameter.DifyWorkflowInferenceParameter,
	ePara *aiparameter.DifyWorkflowExtendedParameter) error {
	// check iPara
	// if iPara.Text == "" {
	// 	return fmt.Errorf("InferenceParameter Text is empty")
	// }

	// check ePara
	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ALIYUN, config.ADAPTER_SERVICE_TYPE_ANKER, config.ADAPTER_SERVICE_TYPE_AZURE:
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
	}
	return nil
}

func (d *DifyWorkflowExecutor) doInference(req *adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error) {
	adapter, err := adapter.NewAdapter(d.ctx, d.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	resp, err := adapter.DifyWorkflowHandler(req)
	if err != nil {
		return nil, fmt.Errorf("DifyWorkflowHandler failed, err: %v", err)
	}
	if resp.Data.Status != "succeeded" {
		return nil, fmt.Errorf("DifyWorkflowHandler failed, error: %s", resp.Data.Error)
	}
	if resp.Data.Outputs.Text == "" {
		return nil, fmt.Errorf("DifyWorkflowHandler failed, text is empty")
	}
	return resp, nil
}

func (d *DifyWorkflowExecutor) buildResponse(resp *adaptermodel.DifyWorkflowResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Dify_Workflow,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_DifyWorkflow{
			DifyWorkflow: &aiparameter.DifyWorkflowInferenceResultInfo{
				// Text:      resp.Data.Outputs.Text,
				Timestamp: time.Now().UnixMilli(),
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	header := aicommon.RspHeader{
		Code:    0,
		Message: "",
	}
	// 为了占位，避免 inferencelogic 报错
	resultImages := []*aicommon.FileInfo{
		{},
	}
	return &aiadapterrpc.InferenceResp{
		Header:              &header,
		InferenceResultInfo: string(info),
		ResultImages:        resultImages,
		TimeTakenMs:         int32(resp.Data.ElapsedTime),
	}, nil
}
