package chat

import (
	"io"
	"sync"

	"github.com/jinzhu/copier"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"

	"github.com/zeromicro/go-zero/core/threading"
	"go.uber.org/zap"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

// TTSAnswer implements ChatTaskInterface for Text-to-Speech
type TTSAnswer struct {
	*BaseChatTask
	packetLogic    *TTSPacket
	difyResultChan chan *types.ChatData
	processedText  string // 记录已经处理过的文本
}

func NewTTSAnswer(message *ChatMessage) *TTSAnswer {
	answer := &TTSAnswer{
		BaseChatTask: NewBaseChatTask(message),
	}
	answer.packetLogic = NewTTSPacket(answer.BaseChatTask)
	return answer
}

func (l *TTSAnswer) SetChannel(difyResultChan chan *types.ChatData) {
	l.difyResultChan = difyResultChan
}

func (l *TTSAnswer) Process(req *types.ChatReq) error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		l.Logger.Error("Failed to create stream RPC connection", zap.Error(err), zap.String("messageId", req.MessageId))
		return err
	}
	l.stream = stream
	l.isCloseSend.Store(false)
	l.messageId = req.MessageId

	wg := sync.WaitGroup{}
	wg.Add(2)
	threading.GoSafe(func() {
		l.ProcessReceive(req)
		wg.Done()
	})
	threading.GoSafe(func() {
		l.ProcessTimer(req)
		wg.Done()
	})
	wg.Wait()
	return nil
}

func (l *TTSAnswer) ProcessTimer(req *types.ChatReq) error {
	reqChan := make(chan *types.ChatReq, 100)
	// 首包
	reqChan <- req

	var currentFullText string
	channelClosed := false

	for {
		select {
		case data, ok := <-l.difyResultChan:
			if !ok && !channelClosed {
				// Channel is closed, set flag to avoid multiple end requests
				channelClosed = true
				// 发送结束包
				endReq := new(types.ChatReq)
				copier.Copy(endReq, req)
				endReq.ReqStatus = types.ReqStatusEnd
				reqChan <- endReq
			} else if ok {
				// 更新当前完整文本
				currentFullText = data.Text
				// 使用封装的函数查找可断句的文本
				textToSend := findBreakableText(l.processedText, currentFullText, data.SentenceEnd)

				// 如果找到可断句的文本，发送出去
				if textToSend != "" {
					var ttsReq types.ChatReq
					copier.Copy(&ttsReq, req)
					ttsReq.Data = textToSend
					ttsReq.ReqStatus = types.ReqStatusMiddle
					reqChan <- &ttsReq

					// 更新已处理文本位置
					l.processedText = l.processedText + textToSend
					// 打印文本用于测试
					l.Logger.Error("TTS ProcessTimer", zap.String("message_id", l.messageId), zap.String("text_to_send", textToSend))
				}
			}
		case data, ok := <-reqChan:
			if !ok {
				return nil
			}
			l.packetLogic.Send(data)
			if data.ReqStatus == types.ReqStatusEnd {
				return nil
			}
		case <-l.wsData.StopWsChan:
			return nil
		}
	}
}

// ProcessReceive handles receiving TTS messages
func (l *TTSAnswer) ProcessReceive(req *types.ChatReq) {
	defer func() {
		l.Close()
	}()
	if l.stream == nil {
		return
	}
	var index int32
	recvChan := make(chan *aimanagerrpc.StreamTaskResp, 1)
	errChan := make(chan error, 1)
	go func() {
		for {
			resp, err := l.stream.Recv()
			if err != nil {
				errChan <- err
				return
			}
			recvChan <- resp
		}
	}()
	for {
		// Wait for multiple events
		select {
		case <-l.wsData.StopWsChan:
			return
		case <-l.stopChan:
			l.utilLogic.SendStopDataToRecv(req.CommonReq, index)
			return
		case err := <-errChan:
			index++
			if err == io.EOF {
				l.Infof("TTS Recv EOF")
				l.utilLogic.SendEndDataToRecv(req.CommonReq, index)
				return
			}
			l.Errorf("TTS Recv failed, err: %v", err)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to receive data")
			return
		case streamRecv := <-recvChan:
			index++
			// Process received data
			resp, _, _ := l.convert.ProcessStreamTaskRespData(streamRecv, req, index)
			l.Logger.Debug("TTS ProcessReceive", zap.String("message_id", l.messageId), zap.Any("resp", resp))
			l.utilLogic.SendSuccessDataToRecv(*resp)
		}
	}
}

func (l *TTSAnswer) Close() {
	// Avoid duplicate cleanup
	if l.messageId == "" {
		return
	}

	l.Logger.Error("Closing TTSAnswer", zap.String("message_id", l.messageId))

	// Close the stream
	l.StreamClose()
}

func findBreakableText(processedText, fullText string, sentenceEnd bool) string {
	// 断句符号列表
	sentenceBreakers := []string{"。", "，", "；", "：", "！", "？", ".", ",", ";", ":", "!", "?", "~", "~ "}

	// 计算未处理的文本部分
	if len(fullText) <= len(processedText) {
		return ""
	}

	newTextToProcess := fullText[len(processedText):]
	if len(newTextToProcess) == 0 {
		return ""
	}

	// 如果标记为句子结束，则返回所有未处理的文本
	if sentenceEnd {
		return newTextToProcess
	}

	// 将字符串转换为rune切片，以便正确处理UTF-8字符
	runeText := []rune(newTextToProcess)

	// 查找最后一个断句符号位置
	var lastBreakPos = -1
	for _, breaker := range sentenceBreakers {
		breakerRunes := []rune(breaker)
		breakerLen := len(breakerRunes)

		// 从右向左查找最后一个断句符号
		for i := len(runeText) - breakerLen; i >= 0; i-- {
			isMatch := true
			for j := 0; j < breakerLen; j++ {
				if i+j >= len(runeText) || runeText[i+j] != breakerRunes[j] {
					isMatch = false
					break
				}
			}

			if isMatch {
				pos := i + breakerLen // 包含断句符号
				if pos > lastBreakPos {
					lastBreakPos = pos
				}
				break
			}
		}
	}

	// 如果找到断句位置，返回可以发送的文本
	if lastBreakPos > 0 {
		return string(runeText[:lastBreakPos])
	}
	return ""
}
