package removebackground

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type RemoveBackgroundExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewRemoveBackgroundExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *RemoveBackgroundExecutor {
	return &RemoveBackgroundExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *RemoveBackgroundExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req, in)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *RemoveBackgroundExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *RemoveBackgroundExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*bgremoverrpc.RemoveBackgroundReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.RemoveBackgroundInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
	}

	req := &bgremoverrpc.RemoveBackgroundReq{
		Header: &aicommon.ReqHeader{
			UserId: in.Header.UserId,
			TaskId: in.Header.TaskId,
		},
		Images:              iPara.Images,
		ResultImageUpTokens: in.ResultUpTokens,
	}
	return req, nil

}

func (e *RemoveBackgroundExecutor) doInference(req *bgremoverrpc.RemoveBackgroundReq, in *aiadapterrpc.InferenceReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	if config.GetSrvConfig().SageMaker.RemoveBackgroundEndpointName == "" {
		resp, err := e.doInferenceRpc(req)
		if err != nil {
			return nil, fmt.Errorf("doInferenceRpc failed, err: %v", err)
		}
		return resp, nil
	}
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}
	iPara := aiparameter.RemoveBackgroundInferenceParameter{}
	err = common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("RemoveBackgroundInferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	thumbUpTokens := ""
	if len(in.ThumbUpTokens) > 0 {
		thumbUpTokens = in.ThumbUpTokens[0]
	}
	removeReq := &adaptermodel.RemoveBackgroundReq{
		TaskId:                req.Header.TaskId,
		ImageUrl:              req.Images[0].FileData,
		ResultImageUpToken:    req.ResultImageUpTokens[0],
		ThumbnailImageUpToken: thumbUpTokens,
		IsMask:                int8(iPara.IsMask),
	}

	resp, err := adapter.RemoveBackgroundHandler(removeReq)
	if err != nil {
		return nil, fmt.Errorf("RemoveBackgroundHandler failed, err: %v", err)
	}
	return resp, nil
}

func (e *RemoveBackgroundExecutor) doInferenceRpc(req *bgremoverrpc.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	resp, err := e.svcCtx.BgRemoverRpc.RemoveBackground(e.ctx, req)
	if err != nil {
		return nil, fmt.Errorf("RemoveBackground failed, err: %v", err)
	}
	if resp.Header == nil {
		return nil, fmt.Errorf("RemoveBackground Header is nil")
	}
	if resp.Header.Code != codes.CodeOk {
		return nil, fmt.Errorf("RemoveBackground failed, code: %v, message: %v", resp.Header.Code, resp.Header.Message)
	}
	if len(resp.ResultImages) != len(req.Images) {
		return nil, fmt.Errorf("RemoveBackground result image count is incorrect, expect: %d, actual: %d", len(req.Images), len(resp.ResultImages))
	}
	for i, image := range resp.ResultImages {
		if image == nil {
			return nil, fmt.Errorf("RemoveBackground result image[%d] is nil", i)
		}
		if len(req.ResultImageUpTokens) == 0 {
			if image.FileData == "" {
				return nil, fmt.Errorf("RemoveBackground result image FileData is empty, index: %d", i)
			}
		}
	}
	return resp, nil
}

func (e *RemoveBackgroundExecutor) buildResponse(resp *bgremoverrpc.RemoveBackgroundResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Remove_Background,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_RemoveBackground{
			RemoveBackground: &aiparameter.RemoveBackgroundInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = resp.Header
	out.ResultImages = resp.ResultImages
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
