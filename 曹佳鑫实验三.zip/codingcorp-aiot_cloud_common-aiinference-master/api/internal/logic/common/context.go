package common

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"encoding/json"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
)

type ContextManager struct {
	logx.Logger
	svcCtx      *svc.ServiceContext
	wsconn      *types.ConnectionInfo
	contexts    []*types.TranslateContext // 上下文信息
	readContext bool                      // 是否读取过上下文信息
}

func NewContextManager(log logx.Logger, svcCtx *svc.ServiceContext, wsconn *types.ConnectionInfo) *ContextManager {
	return &ContextManager{
		Logger: log,
		svcCtx: svcCtx,
		wsconn: wsconn,
	}
}

// getContexts 获取上下文信息
func (l *ContextManager) GetContext() []*types.TranslateContext {
	// 1. 判断是否启动上下文
	if !l.svcCtx.Config.AudioTranslate.EnableContext {
		return nil
	}

	// 2. 如果WebSocket是新连接，直接返回前置的上下文信息
	if len(l.contexts) > 0 || l.readContext {
		return l.contexts
	}
	l.readContext = true

	// 3. 否则需要从存储中获取上下文信息（暂定只有redis）
	redisConn := l.svcCtx.RedisConn
	if redisConn == nil {
		return nil
	}

	listKey := fmt.Sprintf(types.TranslateContextListDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	hashKey := fmt.Sprintf(types.TranslateContextHashDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	// 3.1 获取list数据
	values, err := redisConn.LrangeCtx(context.Background(), listKey, 0, -1)
	if err != nil {
		l.Errorf("AudioTranslate Redis Lrange failed, err: %v", err)
		return nil
	}
	if len(values) == 0 {
		return nil
	}

	// 3.2 获取hash数据
	hashValues, err := redisConn.HgetallCtx(context.Background(), hashKey)
	if err != nil {
		l.Errorf("AudioTranslate Redis Hgetall failed, err: %v", err)
		return nil
	}
	if len(hashValues) == 0 {
		return nil
	}

	// 3.3 解析数据
	resultContexts := make([]*types.TranslateContext, 0)
	for i := len(values) - 1; i >= 0; i-- {
		hashValue, ok := hashValues[values[i]]
		if !ok {
			return nil
		}
		var contexts []*types.TranslateContext
		err := json.Unmarshal([]byte(hashValue), &contexts)
		if err != nil {
			l.Errorf("AudioTranslate Unmarshal failed, err: %v", err)
			return nil
		}

		resultContexts = append(resultContexts, contexts...)
	}
	l.contexts = resultContexts
	return nil
}

func (l *ContextManager) SetContext(currMessageId, role, language, text string, textUpdate bool) {
	if !l.svcCtx.Config.AudioTranslate.EnableContext {
		return
	}

	// textUpdate 表示纠错已经说话的文本
	if textUpdate {
		for _, value := range l.contexts {
			if value.MessageId == currMessageId && value.Language == language {
				value.Text = text
				break
			}
		}
		return
	}

	// 流式：已有上下文最佳即可
	for _, value := range l.contexts {
		if value.MessageId == currMessageId && value.Language == language {
			value.Text += text
			return
		}
	}

	// 不存在时，添加上下文
	l.contexts = append(l.contexts, &types.TranslateContext{
		Role:      role,
		MessageId: currMessageId,
		Language:  language,
		Text:      text,
	})

	// 控制上下文数量
	num := l.svcCtx.Config.AudioTranslate.ContextNum
	if num == 0 {
		return
	}
	if len(l.contexts) > 2*num {
		l.contexts = l.contexts[1:]
	}
}

func (l *ContextManager) SaveContext(currMessageId string) {
	// 1. 判断是否启动上下文
	if !l.svcCtx.Config.AudioTranslate.EnableContext {
		return
	}
	if len(l.contexts) == 0 {
		return
	}

	redisConn := l.svcCtx.RedisConn
	if redisConn == nil {
		return
	}

	// 2. 获取当前messageId的上下文信息
	contexts := make([]*types.TranslateContext, 0)
	for _, value := range l.contexts {
		if value.MessageId == currMessageId {
			contexts = append(contexts, value)
		}
	}
	if len(contexts) == 0 {
		return
	}
	value, _ := json.Marshal(contexts)

	// 3. 更新数据
	listKey := fmt.Sprintf(types.TranslateContextListDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	hashKey := fmt.Sprintf(types.TranslateContextHashDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	num := l.svcCtx.Config.AudioTranslate.ContextNum
	period := l.svcCtx.Config.AudioTranslate.ContextPeriod

	script := `
local listKey = KEYS[1]
local hashKey = KEYS[2]
local currentMessageId = ARGV[1]
local contexts = ARGV[2]
local num = tonumber(ARGV[3])
local period = tonumber(ARGV[4])

local count = redis.call('LPUSH', listKey, currentMessageId)
redis.call('HSET', hashKey, currentMessageId, contexts)

if count > num and num ~= 0 then
    for i = 1, count - num do
        local value = redis.call('RPOP', listKey)
        redis.call('HDEL', hashKey, value)
    end
end

if period > 0 then
    redis.call('EXPIRE', listKey, period)
    redis.call('EXPIRE', hashKey, period)
end

return count
`
	keys := []string{listKey, hashKey}
	args := []interface{}{currMessageId, string(value), num, period}

	_, err := redisConn.EvalCtx(context.Background(), script, keys, args...)
	if err != nil {
		l.Errorf("AudioTranslate Redis Eval failed, err: %v", err)
		return
	}
}

// 根据角色和语言处理上下文
func (l *ContextManager) HandleContext(role, language string) (result bool) {
	// 1. 判断是否启动上下文
	if !l.svcCtx.Config.AudioTranslate.EnableContext {
		return
	}
	if len(l.contexts) == 0 {
		return
	}

	redisConn := l.svcCtx.RedisConn
	if redisConn == nil {
		return
	}

	// 2. 根据角色和语言判断是否要删除上下文
	isDelete := false
	for i := 0; i < len(l.contexts); i += 2 {
		if l.contexts[i].Role == role && l.contexts[i].Language != language {
			isDelete = true
			break
		}
	}
	if !isDelete {
		return
	}

	// 3. 删除数据
	l.contexts = make([]*types.TranslateContext, 0)
	listKey := fmt.Sprintf(types.TranslateContextListDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	hashKey := fmt.Sprintf(types.TranslateContextHashDataRedisKey, l.wsconn.AppId, l.wsconn.UserId, l.wsconn.SessionId)
	_, err := redisConn.DelCtx(context.Background(), listKey, hashKey)
	if err != nil {
		l.Errorf("AudioTranslate Redis Del failed, err: %v", err)
	}

	return true
}
