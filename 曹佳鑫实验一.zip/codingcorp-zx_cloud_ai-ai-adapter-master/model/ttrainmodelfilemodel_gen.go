package model

import (
	"context"
	"errors"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/cache"
	"gorm.io/gorm"
)

type (
	TTrainModelFileModel interface {
		Insert(ctx context.Context, data *TTrainModelFile) (int64, error)                                          // 返回的是受影响行数，如需获取自增id，请通过data参数获取
		TxInsert(ctx context.Context, tx *gorm.DB, data *TTrainModelFile) (int64, error)                           // 用于事务新增数据，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
		FindOne(ctx context.Context, id int64) (*TTrainModelFile, error)                                           // 通过主键id查找数据
		FindOneByInstanceName(ctx context.Context, instanceName string) (*TTrainModelFile, error)                  // 通过指定字段查找数据
		FindOneByModelName(ctx context.Context, modelName string) (*TTrainModelFile, error)                        // 通过指定字段查找数据
		FindOneByTaskId(ctx context.Context, taskId string) (*TTrainModelFile, error)                              // 通过指定字段查找数据
		Update(ctx context.Context, id int64, data *TTrainModelFile) (int64, error)                                // 通过主键id更新指定字段，零值不可更新，返回受影响行数
		UpdateOneMapById(ctx context.Context, id int64, data map[string]interface{}) (int64, error)                // 通过主键id更新字段，map参数为数据库需要更新的字段，返回受影响行数
		TxUpdateOneMapById(ctx context.Context, tx *gorm.DB, id int64, data map[string]interface{}) (int64, error) // 用于事务更新字段，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
		Delete(ctx context.Context, id int64) (int64, error)                                                       // 通过主键id删除数据，返回受影响行数
		Deletes(ctx context.Context, ids []int64) (int64, error)                                                   // 通过主键id批量删除数据，返回受影响行数

		// add extra method in here
	}

	defaultTTrainModelFileModel struct {
		DbEngin *gorm.DB
		Cache   cache.Cache
	}

	TTrainModelFile struct {
		Id           int64  `db:"id"`            // 自增长ID
		UserId       string `db:"user_id"`       // 用户ID
		TaskId       string `db:"task_id"`       // 任务ID
		InstanceName string `db:"instance_name"` // 数字分身实例名，全局唯一，作为关键词训练，并且用来命名模型
		TrainMethod  string `db:"train_method"`  // 模型训练方式
		BaseModel    string `db:"base_model"`    // 基础预训练模型
		DatasetPath  string `db:"dataset_path"`  // 用户上传图片数据集路径
		TaskState    int64  `db:"task_state"`    // 任务状态
		Progress     int64  `db:"progress"`      // 任务进度（0-100）
		ModelId      string `db:"model_id"`      // 模型ID，全剧唯一
		ModelName    string `db:"model_name"`    // 模型名称
		Type         string `db:"type"`          // 模型类型
		ModelPath    string `db:"model_path"`    // 模型model路径
		TimeTakenMs  int64  `db:"time_taken_ms"` // 训练时间，单位毫秒
		CreateTime   int64  `db:"create_time"`   // 创建时间，单位毫秒
		UpdateTime   int64  `db:"update_time"`   // 更新时间，单位毫秒
		DelFlag      int64  `db:"del_flag"`      // 1-删除
	}
)

func NewTTrainModelFileModel(conn *gorm.DB, c cache.CacheConf) TTrainModelFileModel {
	return &defaultTTrainModelFileModel{
		// Cache:   cache.New(c, cached.ExclusiveCalls, cached.Stats, sql.ErrNoRows),
		DbEngin: conn,
	}
}

// Insert 返回的是受影响行数，如需获取自增id，请通过data参数获取
func (d *defaultTTrainModelFileModel) Insert(ctx context.Context, data *TTrainModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	result := d.DbEngin.Debug().WithContext(ctx).Create(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// TxInsert // 用于事务新增数据，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
// tx：上层传递时请加上context
func (d *defaultTTrainModelFileModel) TxInsert(ctx context.Context, tx *gorm.DB, data *TTrainModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	result := tx.Debug().WithContext(ctx).Create(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// FindOne 通过主键id查找数据
func (d *defaultTTrainModelFileModel) FindOne(ctx context.Context, id int64) (*TTrainModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", id)

	var result TTrainModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// FindOneByInstanceName 通过指定字段查找数据
func (d *defaultTTrainModelFileModel) FindOneByInstanceName(ctx context.Context, instanceName string) (*TTrainModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", instanceName)

	var result TTrainModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`instance_name` = ?", instanceName).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// FindOneByModelName 通过指定字段查找数据
func (d *defaultTTrainModelFileModel) FindOneByModelName(ctx context.Context, modelName string) (*TTrainModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", modelName)

	var result TTrainModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`model_name` = ?", modelName).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// FindOneByTaskId 通过指定字段查找数据
func (d *defaultTTrainModelFileModel) FindOneByTaskId(ctx context.Context, taskId string) (*TTrainModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", taskId)

	var result TTrainModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`task_id` = ?", taskId).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// Update 通过主键id更新指定字段，零值不可更新，返回受影响行数
func (d *defaultTTrainModelFileModel) Update(ctx context.Context, id int64, data *TTrainModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// UpdateOneMapById 通过主键id更新字段，map参数为数据库需要更新的字段，返回受影响行数
func (d *defaultTTrainModelFileModel) UpdateOneMapById(ctx context.Context, id int64, data map[string]interface{}) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := d.DbEngin.Debug().WithContext(ctx).Model(&TTrainModelFile{}).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// TxUpdateOneMapById 用于事务更新字段，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
// tx：上层传递时请加上context
func (d *defaultTTrainModelFileModel) TxUpdateOneMapById(ctx context.Context, tx *gorm.DB, id int64, data map[string]interface{}) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := tx.Debug().WithContext(ctx).Model(&TTrainModelFile{}).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// Delete 通过主键id删除数据，返回受影响行数
func (d *defaultTTrainModelFileModel) Delete(ctx context.Context, id int64) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", id)

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).Delete(&TTrainModelFile{})
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// Deletes 通过主键id批量删除数据，返回受影响行数
func (d *defaultTTrainModelFileModel) Deletes(ctx context.Context, ids []int64) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", ids)

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` in ?", ids).Delete(&TTrainModelFile{})
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}
