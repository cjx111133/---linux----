package handler

import (
	"encoding/json"
	"net/http"
	"strings"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/channel"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/other"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/response"

	"github.com/zeromicro/go-zero/rest/httpx"
)

// AnkaHandler 处理Anka WebSocket和HTTP请求
func AnkaHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.AnkaRequest
		if err := httpx.Parse(r, &req); err != nil {
			httpx.Error(w, err)
			return
		}

		// 获取请求参数
		if len(req.Cmd) == 0 {
			req.Cmd = r.URL.Query().Get("cmd")
		}
		//req.Cmd = r.URL.Query().Get("cmd")
		req.SessionId = r.URL.Query().Get("session_id")

		// 检查是否是WebSocket连接请求
		if strings.EqualFold(r.Header.Get("Connection"), "Upgrade") {
			// 这里处理WebSocket连接
			handleWebSocketConnection(w, r, &req, svcCtx)
		} else {
			// 处理普通HTTP请求
			handleHTTPRequest(w, r, &req, svcCtx)
		}
	}
}

// handleWebSocketConnection 处理WebSocket连接
func handleWebSocketConnection(w http.ResponseWriter, r *http.Request, req *types.AnkaRequest, svcCtx *svc.ServiceContext) {
	// 封装WebSocket数据
	data := &types.WebSocketData{
		ConnectionInfo: &types.ConnectionInfo{
			HeaderEncryptData: types.HeaderEncryptData{
				XEncryptionInfo: r.Header.Get("X-Encryption-Info"),
				XRequestOnce:    r.Header.Get("X-Request-Once"),
				XRequestTs:      r.Header.Get("X-Request-Ts"),
				XKeyIdent:       r.Header.Get("X-Key-Ident"),
				XSignature:      r.Header.Get("X-Signature"),
			},
			Cmd:        req.Cmd,
			SessionId:  req.SessionId,
			AppId:      req.HeaderAppName,
			UserId:     req.HeaderInnerXUserId,
			LoginType:  types.LoginTypeAccount,
			AppVersion: req.HeaderAppVersion,
		},
	}

	// 设置用户ID（如果是游客，使用终端ID）
	if len(data.ConnectionInfo.UserId) == 0 {
		data.ConnectionInfo.OpenUuid = req.HeaderOpenUdid
		data.ConnectionInfo.UserId = req.HeaderTerminalID
		data.ConnectionInfo.LoginType = types.LoginTypeGuest
	}
	// 验证加密信息
	if code, body := wsVerifyEncryption(data, svcCtx.EncryptRedis); code != 0 {
		resultFinal, _ := json.Marshal(body)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(code)
		_, _ = w.Write(resultFinal)
		return
	}

	// 使用WebSocket管理器处理连接
	channel.WsManager.HandleConnection(w, r, data)
}

// handleHTTPRequest 处理HTTP请求
func handleHTTPRequest(w http.ResponseWriter, r *http.Request, req *types.AnkaRequest, svcCtx *svc.ServiceContext) {
	// 对于HTTP请求，使用常规的逻辑处理
	l := other.NewAnkaLogic(r.Context(), svcCtx)
	resp, err := l.Anka(req)
	response.Response(r, w, resp, err)
}
