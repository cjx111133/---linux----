package handler

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/other"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/response"
	"net/http"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

func AnkaTranslateHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.AnkaTranslateRequest
		if err := httpx.Parse(r, &req); err != nil {
			httpx.Error(w, err)
			return
		}

		l := other.NewAnkaTranslateLogic(r.Context(), svcCtx)
		resp, err := l.AnkaTranslate(&req)
		response.Response(r, w, resp, err)
	}
}
