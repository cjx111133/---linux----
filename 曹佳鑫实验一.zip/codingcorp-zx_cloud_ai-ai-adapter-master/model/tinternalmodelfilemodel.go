package model

var _ TInternalModelFileModel = (*defaultTInternalModelFileModel)(nil)
