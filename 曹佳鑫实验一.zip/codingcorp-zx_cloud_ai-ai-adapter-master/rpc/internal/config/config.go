package config

import (
	"fmt"
	"sync"

	gormconfig "e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/gorm/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/zrpc"
)

var DefaultConfig *CommonConfig
var SrvConfigs *SrvConfig

type CommonConfig struct {
	sync.RWMutex
	zrpc.RpcServerConf
	GormConfig        *gormconfig.GormConfig
	CloudStorRpc      zrpc.RpcClientConf
	PopArtRpc         zrpc.RpcClientConf
	BgRemoverRpc      zrpc.RpcClientConf
	ImageToVectorRpc  zrpc.RpcClientConf
	SpeechToTextRpc   zrpc.RpcClientConf
	TextToSpeechRpc   zrpc.RpcClientConf
	AudioProcessorRpc zrpc.RpcClientConf
	TranscribeRpc     zrpc.RpcClientConf
}

type Guardrail struct {
	GuardrailIdentifier string `json:"GuardrailIdentifier"`
	GuardrailVersion    string `json:"GuardrailVersion"`
	Enable              bool   `json:"Enable"`
}

type SrvConfig struct {
	sync.RWMutex
	AdapterType            string           `json:"AdapterType"`
	SageMaker              SageMaker        `json:"SageMaker"`
	AwsAccessKeyID         string           `json:"AwsAccessKeyID"`
	AwsSecretAccessKey     string           `json:"AwsSecretAccessKey"`
	AwsSessionToken        string           `json:"AwsSessionToken"`
	AwsPlusAccessKeyID     string           `json:"AwsPlusAccessKeyID"`
	AwsPlusSecretAccessKey string           `json:"AwsPlusSecretAccessKey"`
	AwsPlusSessionToken    string           `json:"AwsPlusSessionToken"`
	AwsBedRock             Guardrail        `json:"AwsBedRock"`
	SdDeployType           string           `json:"SdDeployType"`
	AwsSd                  AwsSd            `json:"AwsSd"`
	ModelFile              ModelFile        `json:"ModelFile"`
	ModelTrain             ModelTrain       `json:"ModelTrain"`
	ALiYun                 map[AppId]ALiYun `json:"ALiYun"`
	Azure                  map[AppId]Azure  `json:"Azure"`
	AnkerModel             AnkerModel       `json:"AnkerModel"`
	DifyWorkflow           DifyWorkflow     `json:"DifyWorkflow"`
	DifyChatflow           DifyChatflow     `json:"DifyChatflow"`
	Thumbnail              Thumbnail        `json:"Thumbnail"`    // 缩略图配置
	ImageMaxSize           int64            `json:"ImageMaxSize"` // 图片大小限制
	VadSaveAudio           bool             `json:"VadSaveAudio"`
	AsrSaveAudio           bool             `json:"AsrSaveAudio"`
	TtsSaveAudio           bool             `json:"TtsSaveAudio"`
}

type Thumbnail struct {
	PixLimit     int `json:"PixLimit"`
	ImageQuality int `json:"ImageQuality"`
}

type AnkerModel struct {
	LLMUrl string `json:"LLMUrl"`
	Token  string `json:"Token"`
}

type DifyWorkflow struct {
	Url                                   string `json:"Url"`
	Token                                 string `json:"Token"` // 暂时先假设在 dify 中是一个大应用
	ResponseMode                          string `json:"ResponseMode"`
	User                                  string `json:"User"`
	TextSummaryWorkflowKey                string `json:"TextSummaryWorkflowKey"`
	TranslateQuestionRecommendWorkflowKey string `json:"TranslateQuestionRecommendWorkflowKey"`
}

type DifyChatflow struct {
	Url                          string `json:"Url"`
	Token                        string `json:"Token"` // 暂时先假设在 dify 中是一个大应用
	ResponseMode                 string `json:"ResponseMode"`
	User                         string `json:"User"`
	ChatflowKey                  string `json:"ChatflowKey"`
	ChatflowSoundcoreManagerKey  string `json:"ChatflowSoundcoreManagerKey"`  // 默认是“”
	ChatflowHearingAidManagerKey string `json:"ChatflowHearingAidManagerKey"` // 默认是“”
	ChatflowDifmManagerKey       string `json:"ChatflowDifmManagerKey"`
	ChatflowEmotionKey           string `json:"ChatflowEmotionKey"`
	ChatflowQuestionKey          string `json:"ChatflowQuestionKey"`
}

type ALiYun struct {
	VoiceServerUrl  string   `json:"VoiceServerUrl"`
	AccessKeyID     string   `json:"AccessKeyID"`
	AccessKeySecret string   `json:"AccessKeySecret"`
	Token           string   `json:"Token"`
	TtsAppKey       string   `json:"TtsAppKey"`
	ZhAsrAppKey     string   `json:"ZhAsrAppKey"`
	EnAsrAppKey     string   `json:"EnAsrAppKey"`
	JaAsrAppKey     string   `json:"JaAsrAppKey"`
	DeAsrAppKey     string   `json:"DeAsrAppKey"`
	EsAsrAppKey     string   `json:"EsAsrAppKey"`
	FrAsrAppKey     string   `json:"FrAsrAppKey"`
	Region          string   `json:"Region"`
	LLMUrl          string   `json:"LLMUrl"`
	ApiKey          []string `json:"ApiKey"`
}

type Azure struct {
	VoiceServerKey    string   `json:"VoiceServerKey"`
	Region            string   `json:"Region"`
	LLMUrl            string   `json:"LLMUrl"`
	ApiKey            []string `json:"ApiKey"`
	FastTranscribeUrl string   `json:"FastTranscribeUrl"`
}

type SageMaker struct {
	Region                         string `json:"region"`
	PlusRegion                     string `json:"PlusRegion"`
	RoleArn                        string `json:"RoleArn"`
	FaceSwapEndpointName           string `json:"FaceSwapEndpointName"`
	UpscaleEndpointName            string `json:"UpscaleEndpointName"`
	StyleTransferEndpointName      string `json:"StyleTransferEndpointName"`
	StyleTransfer1EndpointName     string `json:"StyleTransfer1EndpointName"`
	StyleTransfer2EndpointName     string `json:"StyleTransfer2EndpointName"`
	StyleTransfer3EndpointName     string `json:"StyleTransfer3EndpointName"`
	PetPortraitEndpointName        string `json:"PetPortraitEndpointName"`
	TextToImageDesignEndpointName  string `json:"TextToImageDesignEndpointName"`
	InstantStyleEndpointName       string `json:"InstantStyleEndpointName"`
	InstantStylePlusEndpointName   string `json:"InstantStylePlusEndpointName"`
	DepthMapGenerationEndpointName string `json:"DepthMapGenerationEndpointName"`
	RemoveBackgroundEndpointName   string `json:"RemoveBackgroundEndpointName"`
	ComfyUIEndpointName            string `json:"ComfyUIEndpointName"`
	ComfyUI1EndpointName           string `json:"ComfyUI1EndpointName"`
	ComfyUI2EndpointName           string `json:"ComfyUI2EndpointName"`
	ComfyUI3EndpointName           string `json:"ComfyUI3EndpointName"`
	ComfyUI4EndpointName           string `json:"ComfyUI4EndpointName"`
	ComfyUI5EndpointName           string `json:"ComfyUI5EndpointName"`
}

type AwsSd struct {
	ApiGatewayUrl   string `json:"ApiGatewayUrl"`
	APIToken        string `json:"APIToken"`
	UserName        string `json:"UserName"`
	StableDiffusion string `json:"StableDiffusion"`
	VAE             string `json:"VAE"`
}

type ModelFile struct {
	StableDiffusion map[string]Model `json:"StableDiffusion"`
	Lora            map[string]Model `json:"Lora"`
	ControlNet      map[string]Model `json:"ControlNet"`
	VAE             map[string]Model `json:"VAE"`
}

type Model struct {
	ModelID   string `json:"ModelID"`
	ModelName string `json:"ModelName"`
	ModelPath string `json:"ModelPath"`
	ModelType string `json:"ModelType"`
}

type ModelTrain struct {
	TrainMethod         string     `json:"TrainMethod"`
	BaseModel           string     `json:"BaseModel"`
	FmType              string     `json:"FmType"`
	SaveEveryNEpochs    int32      `json:"SaveEveryNEpochs"`   // 每训练 N 个 epoch 保存一次预览 Lora 模型，默认 100
	MaxTrainEpochs      int32      `json:"MaxTrainEpochs"`     // 最大执行的 epoch 数量，默认 200
	SagemakerProgram    string     `json:"SagemakerProgram"`   // sagemaker 训练程序
	EnableWd14Tagger    bool       `json:"EnableWd14Tagger"`   // 是否启用 wd14 标签器
	CharacterThreshold  float32    `json:"CharacterThreshold"` // 自动打标，角色标签阈值
	GeneralThreshold    float32    `json:"GeneralThreshold"`   // 自动打标，一般标签阈值
	Bucket              string     `json:"Bucket"`             // bucket
	TrainImage          string     `json:"TrainImage"`
	InstanceType        string     `json:"InstanceType"`        // 训练实例类型
	InstanceCount       int64      `json:"InstanceCount"`       // 训练实例数量
	VolumeSizeInGB      int64      `json:"VolumeSizeInGB"`      // 训练实例的 EBS 卷大小
	MaxRuntimeInSeconds int64      `json:"MaxRuntimeInSeconds"` // 训练实例的最大运行时间
	TrainHost           string     `json:"TrainHost"`           // 训练实例地址 http://127.0.0.1:8080
	Tags                []KeyValue `json:"Tags"`
}

type KeyValue struct {
	Key   string `json:"Key"`
	Value string `json:"Value"`
}

func InitDefaultConfig(c string) error {
	DefaultConfig = &CommonConfig{}
	if err := conf.LoadFromJsonBytes([]byte(c), DefaultConfig); err != nil {
		return fmt.Errorf("json unmarshal DefaultConfig error:%v", err)
	}

	//初始化服务配置
	SrvConfigs = &SrvConfig{}
	if err := common.JsonToAny([]byte(c), SrvConfigs); err != nil {
		return fmt.Errorf("unmarshal SrvConfigs error:%v", err)
	}

	return nil
}

func GetDefaultConfig() *CommonConfig {
	DefaultConfig.RLock()
	defer DefaultConfig.RUnlock()
	return DefaultConfig
}

func InitDefaultConfigModelFile(modelFile ModelFile) {
	SrvConfigs.Lock()
	defer SrvConfigs.Unlock()
	SrvConfigs.ModelFile = modelFile
}

func UpdateSrvConfig(cfg *SrvConfig) {
	SrvConfigs.Lock()
	defer SrvConfigs.Unlock()
	SrvConfigs.AdapterType = cfg.AdapterType
	SrvConfigs.AwsAccessKeyID = cfg.AwsAccessKeyID
	SrvConfigs.AwsSecretAccessKey = cfg.AwsSecretAccessKey
	SrvConfigs.AwsSessionToken = cfg.AwsSessionToken
	SrvConfigs.SdDeployType = cfg.SdDeployType
	SrvConfigs.AwsSd = cfg.AwsSd
	SrvConfigs.SageMaker = cfg.SageMaker
	SrvConfigs.ModelTrain = cfg.ModelTrain
	SrvConfigs.ALiYun = cfg.ALiYun
	SrvConfigs.AnkerModel = cfg.AnkerModel
	SrvConfigs.DifyWorkflow = cfg.DifyWorkflow
	SrvConfigs.DifyChatflow = cfg.DifyChatflow
	SrvConfigs.Thumbnail = cfg.Thumbnail
	SrvConfigs.ImageMaxSize = cfg.ImageMaxSize
	SrvConfigs.VadSaveAudio = cfg.VadSaveAudio
	SrvConfigs.AsrSaveAudio = cfg.AsrSaveAudio
	SrvConfigs.TtsSaveAudio = cfg.TtsSaveAudio
}

func GetSrvConfig() *SrvConfig {
	SrvConfigs.RLock()
	defer SrvConfigs.RUnlock()
	return SrvConfigs
}
