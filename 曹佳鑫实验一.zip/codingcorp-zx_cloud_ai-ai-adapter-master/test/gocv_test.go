package main

import (
	"fmt"
	"gocv.io/x/gocv"
	"image"
	"runtime"
	"testing"
)

func TestGoCv(t *testing.T) {
	// 读取 Alpha 通道图片
	alphaImg := gocv.IMRead("./a1.png", gocv.IMReadUnchanged)
	if alphaImg.Empty() {
		fmt.Println("Error: Unable to read the alpha image.")
		return
	}
	defer alphaImg.Close()

	// 读取目标图片
	targetImg := gocv.IMRead("./sd.png", gocv.IMReadColor)
	if targetImg.Empty() {
		fmt.Println("Error: Unable to read the target image.")
		return
	}
	defer targetImg.Close()

	// 提取透明通道并直接调整大小，避免不必要的Mat创建和关闭
	targetSize := image.Point{X: targetImg.Cols(), Y: targetImg.Rows()}
	resizedAlpha := gocv.NewMat()
	defer resizedAlpha.Close()

	channels := gocv.Split(alphaImg)
	alphaChannel := channels[3]
	gocv.Resize(alphaChannel, &resizedAlpha, targetSize, 0, 0, gocv.InterpolationLanczos4)
	// 及时释放原始通道资源
	for _, c := range channels {
		c.Close()
	}

	// 拆分目标图片的通道，避免后续不必要的关闭操作
	targetChannels := gocv.Split(targetImg)

	// 创建一个新的 RGBA 图像，避免额外的Mat创建
	channelsToMerge := []gocv.Mat{
		targetChannels[0],
		targetChannels[1],
		targetChannels[2],
		resizedAlpha,
	}
	merged := gocv.NewMat()
	defer merged.Close()
	gocv.Merge(channelsToMerge, &merged)

	// 及时释放目标通道资源
	for _, c := range targetChannels {
		c.Close()
	}

	// 保存合并后的图片
	if !gocv.IMWrite("result_rgba.png", merged) {
		fmt.Println("Error: Unable to save the result image.")
		return
	}

	fmt.Println("Image saved successfully.")
}

func PrintMemUsage() {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	// For info on each, see: https://golang.org/pkg/runtime/#MemStats
	fmt.Printf("Alloc = %v MiB", bToMb(m.Alloc))
	fmt.Printf("\tTotalAlloc = %v MiB", bToMb(m.TotalAlloc))
	fmt.Printf("\tSys = %v MiB", bToMb(m.Sys))
	fmt.Printf("\tNumGC = %v\n", m.NumGC)
}
func bToMb(b uint64) uint64 {
	return b / 1024 / 1024
}

func TestImage(t *testing.T) {
	PrintMemUsage()
}
