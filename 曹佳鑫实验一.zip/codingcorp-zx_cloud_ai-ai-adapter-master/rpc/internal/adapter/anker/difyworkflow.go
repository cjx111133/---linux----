package anker

import (
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
)

func (s *AnkerAdapter) DifyWorkflowHandler(req *adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error) {
	url := config.GetSrvConfig().DifyWorkflow.Url
	token := config.GetSrvConfig().DifyWorkflow.Token

	// s.Logger.Infof("url %s", url)
	// s.Logger.Infof("token %s", token)
	// s.Logger.Infof("Body %+v", req.Body)
	// s.Logger.Infof("input %+v", string(input))

	input, err := common.AnyToJson(req.Body)
	if err != nil {
		return nil, fmt.Errorf("json marshal error: %v", err)
	}

	output, err := s.RequestWithJSON(s.ctx, "POST", url, token, input, 60)
	if err != nil {
		return nil, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if output == nil {
		return nil, fmt.Errorf("invoke endpoint error: output is nil")
	}

	var resp adaptermodel.DifyWorkflowResp
	err = common.JsonToAny(output, &resp)
	if err != nil {
		return nil, fmt.Errorf("json unmarshal error: %v", err)
	}
	return &resp, nil
}

func (s *AnkerAdapter) DifyWorkflowStreamHandler(request <-chan *adaptermodel.DifyWorkflowReq, response chan<- *adaptermodel.DifyWorkflowResp) error {
	return fmt.Errorf("DifyWorkflowStreamHandler not implemented")
}
