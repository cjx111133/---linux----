package logic

import (
	"context"
	"errors"
	"fmt"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/zeromicro/go-zero/core/logx"
)

type InferenceLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewInferenceLogic(ctx context.Context, svcCtx *svc.ServiceContext) *InferenceLogic {
	return &InferenceLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 模型推理
func (l *InferenceLogic) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	timeStart := time.Now()
	resp := &aiadapterrpc.InferenceResp{
		Header: &aicommon.RspHeader{
			Code:    codes.CodeOk,
			Message: "success",
		},
	}

	// check input
	if err := l.checkParam(in); err != nil {
		resp.Header.Code = codes.CodeInputParamInvalid
		resp.Header.Message = fmt.Sprintf("Inference check param failed, err: %v, task type: %v", err, in.TaskType.String())
		resp.Timestamp = time.Now().UnixMilli()
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	defer func() {
		l.Infof("Inference end, task id: %s, task type: %v, inference time: %v ms, total time: %v ms", in.Header.TaskId, in.TaskType.String(), resp.TimeTakenMs, time.Since(timeStart).Milliseconds())
	}()
	l.Infof("Inference start, task id: %s, task type: %v", in.Header.TaskId, in.TaskType.String())

	// create executor
	executor, err := executor.NewExecutor(l.ctx, l.svcCtx, in.TaskType)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("NewExecutor failed, task id: %s, task type: %v, err: %v", in.Header.TaskId, in.TaskType.String(), err)
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	result, err := executor.Inference(in)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("Inference executor failed, task id: %s, task type: %v, err: %v", in.Header.TaskId, in.TaskType.String(), err)
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)

		// 判断error类型，将错误码传递给调用端
		var grpcError *grpcerrors.GrpcError
		if errors.As(err, &grpcError) {
			return resp, grpcerrors.Errorf(int(grpcError.Code), resp.Header.Message, grpcerrors.FindCaller(1))
		}
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	if result == nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("Inference executor failed, task id: %s, task type: %v, result is nil", in.Header.TaskId, in.TaskType.String())
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	for i, resultImage := range result.ResultImages {
		if resultImage == nil {
			resp.Header.Code = codes.CodeSystemException
			resp.Header.Message = fmt.Sprintf("Inference executor failed, task id: %s, task type: %v, result image[%d] is nil", in.Header.TaskId, in.TaskType.String(), i)
			resp.Timestamp = time.Now().UnixMilli()
			l.Error(resp.Header.Message)
			return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
		}
	}

	resp.TimeTakenMs = result.TimeTakenMs
	resp.ResultImages = result.ResultImages
	resp.InferenceResultInfo = result.InferenceResultInfo
	resp.Timestamp = time.Now().UnixMilli()
	return resp, nil
}

func (l *InferenceLogic) checkParam(in *aiadapterrpc.InferenceReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.TaskId == "" {
		return fmt.Errorf("task id is empty")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}

	if in.TaskType == aiparameter.TaskType_TASK_TYPE_None {
		return fmt.Errorf("task type is none, TaskType: %v", in.TaskType.String())
	}
	return nil
}
