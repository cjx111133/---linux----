package azure

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/Microsoft/cognitive-services-speech-sdk-go/audio"
	"github.com/Microsoft/cognitive-services-speech-sdk-go/common"
	"github.com/Microsoft/cognitive-services-speech-sdk-go/speech"
	"github.com/zeromicro/go-zero/core/logx"
)

type AsrClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	index        int32
	segments     []*aicommon.Segment
	words        []*aicommon.Word
	startTime    time.Time
	errCh        chan error
	stop         chan bool
	perSize      int
	result       string
	isSegmentEnd bool

	request           <-chan *adaptermodel.SpeechToTextReq
	response          chan<- *adaptermodel.SpeechToTextResp
	first             *adaptermodel.SpeechToTextReq
	stream            *audio.PushAudioInputStream
	audioStreamFormat *audio.AudioStreamFormat
	audioConfig       *audio.AudioConfig
	speechConfig      *speech.SpeechConfig
	autoLangConfs     *speech.AutoDetectSourceLanguageConfig
	phraseListGrammar *speech.PhraseListGrammar
	sr                *speech.SpeechRecognizer
	lastText          string
}

func NewAsrClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.SpeechToTextReq,
	response chan<- *adaptermodel.SpeechToTextResp,
	first *adaptermodel.SpeechToTextReq) *AsrClient {
	return &AsrClient{
		ctx:          ctx,
		svcCtx:       svcCtx,
		Logger:       logx.WithContext(ctx),
		index:        1,
		segments:     make([]*aicommon.Segment, 0),
		words:        make([]*aicommon.Word, 0),
		startTime:    time.Now(),
		errCh:        make(chan error, 10),
		stop:         make(chan bool, 10),
		perSize:      6400,
		result:       "",
		isSegmentEnd: false,
		request:      request,
		response:     response,
		first:        first,
	}
}

func (c *AsrClient) SpeechTranscription() error {
	var err error
	c.stream, err = c.initClient()
	if err != nil {
		return fmt.Errorf("init asr client failed, err: %v", err)
	}
	defer c.stream.CloseStream()
	c.Info("speech transcription start")

	// send first package to Aliyun
	var buf = bytes.NewBuffer(c.first.Audio.Data)
	for buf.Len() > 0 {
		c.Debugf("send first audio data to azure, len: %d, perSize: %d", buf.Len(), c.perSize)
		err = c.stream.Write(buf.Next(c.perSize))
		if err != nil {
			return fmt.Errorf("send first audio data to azure failed, err: %v", err)
		}
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop speech transcription failed, err: %v", err)
	}

	err = <-c.sr.StopContinuousRecognitionAsync()
	if err != nil {
		return fmt.Errorf("StopContinuousRecognitionAsync failed, err: %v", err)
	}
	err = c.Wait(c.stop)
	if err != nil {
		return fmt.Errorf("wait stop failed, err: %v", err)
	}

	if !c.isSegmentEnd && c.lastText != "" {
		c.Errorf("the end packet returned by Azure was not received, supplement the end packet, lastText: %s", c.lastText)
		c.response <- &adaptermodel.SpeechToTextResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "success",
			},
			Language:    c.first.Audio.Language,
			SpeechEnd:   true,
			Text:        c.lastText,
			TimeTakenMs: int32(time.Since(c.startTime).Milliseconds()),
		}
		c.result += c.lastText
	}

	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		Language:    c.first.Audio.Language,
		SpeechEnd:   true,
		Text:        c.result,
		TimeTakenMs: int32(time.Since(c.startTime).Milliseconds()),
	}
	c.Infof("speech transcription end, SpeechEnd: %v, result: %v", true, c.result)
	return nil
}

func (c *AsrClient) loop() error {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("send audio data to azure end, ctx done")
			return nil
		case err, ok := <-c.errCh:
			if !ok {
				return nil
			}
			return fmt.Errorf("speech synthesis failed, err: %v", err)
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send audio data to azure end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send audio data to azure failed, request is nil")
			}
			if req.Audio == nil {
				c.Errorf("task id: %s, audio is nil", c.first.TaskId)
				continue
			}
			if len(req.Audio.Data) == 0 {
				c.Errorf("task id: %s, audio data is empty", c.first.TaskId)
				continue
			}

			var buf = bytes.NewBuffer(req.Audio.Data)
			for buf.Len() > 0 {
				c.Debugf("send audio data to azure, buf len: %d, perSize: %d", buf.Len(), c.perSize)
				err := c.stream.Write(buf.Next(c.perSize))
				if err != nil {
					return fmt.Errorf("send audio data to azure failed, err: %v", err)
				}
			}
		}
	}
}

func (c *AsrClient) initClient() (*audio.PushAudioInputStream, error) {
	var audioStreamFormat *audio.AudioStreamFormat
	var err error

	switch c.first.Audio.Format {
	case config.AUDIO_FORMAT_PCM, config.AUDIO_FORMAT_WAV:
		// init audio config
		// only WAV / PCM with 16-bit samples, 16 kHz sample rate, and a single channel (Mono) is supported.
		audioStreamFormat, err = audio.GetWaveFormatPCM(
			uint32(c.first.Audio.SampleRate),
			16,
			uint8(c.first.Audio.Channels))
		if err != nil {
			c.Errorf("GetWaveFormatPCM failed, err: %v", err)
			return nil, fmt.Errorf("GetWaveFormatPCM failed, err: %v", err)
		}
	case config.AUDIO_FORMAT_MP3:
		// init audio config
		audioStreamFormat, err = audio.GetCompressedFormat(
			audio.MP3,
		)
	default:
		c.Errorf("audio format not support, format: %s", c.first.Audio.Format)
		return nil, fmt.Errorf("audio format not support, format: %s", c.first.Audio.Format)
	}
	c.audioStreamFormat = audioStreamFormat

	stream, err := audio.CreatePushAudioInputStreamFromFormat(audioStreamFormat)
	if err != nil {
		c.Errorf("CreatePushAudioInputStreamFromFormat failed, err: %v", err)
		return nil, fmt.Errorf("CreatePushAudioInputStreamFromFormat failed, err: %v", err)
	}

	c.audioConfig, err = audio.NewAudioConfigFromStreamInput(stream)
	if err != nil {
		c.Errorf("NewAudioConfigFromStreamInput failed, err: %v", err)
		return nil, fmt.Errorf("NewAudioConfigFromStreamInput failed, err: %v", err)
	}

	// init connect config
	c.speechConfig, err = speech.NewSpeechConfigFromSubscription(
		config.GetSrvConfig().Azure[config.AppId(c.first.AppId)].VoiceServerKey,
		config.GetSrvConfig().Azure[config.AppId(c.first.AppId)].Region)
	if err != nil {
		c.Errorf("NewSpeechConfigFromSubscription failed, err: %v", err)
		return nil, fmt.Errorf(" NewSpeechConfigFromSubscription failed, err: %v", err)
	}
	err = c.speechConfig.RequestWordLevelTimestamps()
	if err != nil {
		c.Errorf("RequestWordLevelTimestamps failed, err: %v", err)
		return nil, fmt.Errorf("RequestWordLevelTimestamps failed, err: %v", err)
	}
	err = c.speechConfig.SetSpeechRecognitionLanguage(c.first.Audio.Language)
	if err != nil {
		c.Errorf("SetSpeechRecognitionLanguage failed, err: %v", err)
		return nil, fmt.Errorf("SetSpeechRecognitionLanguage failed, err: %v", err)
	}
	err = c.speechConfig.SetProperty(common.SegmentationSilenceTimeoutMs, fmt.Sprint(c.first.MaxSentenceSilence))
	if err != nil {
		c.Errorf("SetSpeechRecognitionLanguage failed, err: %v", err)
		return nil, fmt.Errorf("SetSpeechRecognitionLanguage failed, err: %v", err)
	}

	sr, err := speech.NewSpeechRecognizerFromConfig(c.speechConfig, c.audioConfig)
	if err != nil {
		c.Errorf("NewSpeechRecognizerFomAutoDetectSourceLangConfig failed, err: %v", err)
		return nil, fmt.Errorf("NewSpeechRecognizerFomAutoDetectSourceLangConfig failed, err: %v", err)
	}
	c.sr = sr

	c.phraseListGrammar, err = speech.NewPhraseListGrammarFromRecognizer(sr)
	if err != nil {
		c.Errorf("NewPhraseListGrammarFromRecognizer failed, err: %v", err)
		return nil, fmt.Errorf("NewPhraseListGrammarFromRecognizer failed, err: %v", err)
	}
	for _, wordList := range c.first.HotWordsList {
		for _, word := range wordList.Words {
			c.phraseListGrammar.AddPhrase(word)
		}
	}

	sr.SessionStarted(c.sessionStartedHandler)
	sr.SessionStopped(c.sessionStoppedHandler)
	sr.Recognizing(c.recognizingHandler)
	sr.Recognized(c.recognizedHandler)
	sr.Canceled(c.cancelledHandler)
	err = <-sr.StartContinuousRecognitionAsync()
	if err != nil {
		c.Errorf("StartContinuousRecognitionAsync failed, err: %v", err)
		return nil, fmt.Errorf("StartContinuousRecognitionAsync failed, err: %v", err)
	}

	return stream, nil
}

func (c *AsrClient) sessionStartedHandler(event speech.SessionEventArgs) {
	defer event.Close()
	c.Infof("recv Session Started from azure asr, SessionID: %s", event.SessionID)
}

func (c *AsrClient) sessionStoppedHandler(event speech.SessionEventArgs) {
	defer event.Close()
	c.Infof("recv Session Stopped from azure asr, SessionID: %s", event.SessionID)
	c.stop <- true
}

func (c *AsrClient) recognizingHandler(event speech.SpeechRecognitionEventArgs) {
	defer event.Close()
	if event.Result.Text == "" {
		return
	}

	startMs := int32(event.Result.Offset.Milliseconds())
	endMs := int32(event.Result.Duration.Milliseconds() + event.Result.Offset.Milliseconds())
	c.lastText = event.Result.Text
	c.isSegmentEnd = false
	c.Infof("recv Recognizing from azure asr, index: %d, text: %s, startMs: %d, endMs: %d", c.index, event.Result.Text, startMs, endMs)

	if !c.first.EnableWord {
		c.response <- &adaptermodel.SpeechToTextResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "success",
			},
			SegmentId:     c.index,
			SegmentEnd:    false,
			Text:          "",
			Language:      c.first.Audio.Language,
			Segments:      c.segments,
			UseTempResult: c.first.UseTempResult,
			TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
		}
		return
	}

	c.words = append(c.words, &aicommon.Word{
		Text:       event.Result.Text,
		StartMs:    startMs,
		EndMs:      endMs,
		Confidence: 1,
	})
	var segment = &aicommon.Segment{
		Id:         c.index,
		StartMs:    startMs,
		EndMs:      endMs,
		Text:       event.Result.Text,
		Confidence: 1,
		Words:      c.words,
	}

	var segments = make([]*aicommon.Segment, 0, len(c.segments)+1)
	segments = append(segments, c.segments...)
	segments = append(segments, segment)
	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SegmentId:     c.index,
		SegmentEnd:    false,
		Text:          event.Result.Text,
		Language:      c.first.Audio.Language,
		Segments:      segments,
		UseTempResult: c.first.UseTempResult,
		TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
	}
}

func (c *AsrClient) recognizedHandler(event speech.SpeechRecognitionEventArgs) {
	defer event.Close()
	startMs := int32(event.Result.Offset.Milliseconds())
	endMs := int32(event.Result.Duration.Milliseconds() + event.Result.Offset.Milliseconds())
	c.Infof("recv Recognized from azure asr, index: %d, text: [%s], startMs: %d, endMs: %d", c.index, event.Result.Text, startMs, endMs)

	if event.Result.Text == "" {
		if c.lastText == "" {
			c.Errorf("recv Recognized from azure asr, text is empty")
			return
		}
		c.Errorf("recv Recognized from azure asr, text is empty, use last text: [%s]", c.lastText)
		event.Result.Text = c.lastText
	}
	c.lastText = ""
	c.isSegmentEnd = true

	c.words = append(c.words, &aicommon.Word{
		Text:       event.Result.Text,
		StartMs:    startMs,
		EndMs:      endMs,
		Confidence: 1,
	})
	c.segments = append(c.segments, &aicommon.Segment{
		Id:         c.index,
		StartMs:    startMs,
		EndMs:      endMs,
		Text:       event.Result.Text,
		Confidence: 1,
		Words:      c.words,
	})

	c.response <- &adaptermodel.SpeechToTextResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SegmentId:     c.index,
		SegmentEnd:    true,
		Text:          event.Result.Text,
		Language:      c.first.Audio.Language,
		Segments:      c.segments,
		UseTempResult: c.first.UseTempResult,
		TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
	}
	c.index++
	c.result += event.Result.Text

	// c.segments只保留最新的 1 个
	if len(c.segments) > 1 {
		c.segments = c.segments[len(c.segments)-1:]
	}
	c.words = []*aicommon.Word{}
}

func (c *AsrClient) cancelledHandler(event speech.SpeechRecognitionCanceledEventArgs) {
	defer event.Close()
	c.Infof("recv Canceled from azure asr, Reason: %d, ErrorCode: %d, ErrorDetails: %s", event.Reason, event.ErrorCode, event.ErrorDetails)
	if event.ErrorCode != 0 {
		c.errCh <- fmt.Errorf("recv error from azure asr, Reason: %d, ErrorCode: %d, ErrorDetails: %s", event.Reason, event.ErrorCode, event.ErrorDetails)
	}
	c.stop <- true
}

func (c *AsrClient) Wait(ch chan bool) error {
	select {
	case message, done := <-ch:
		if !done {
			return errors.New("wait failed")
		}
		c.Infof("Wait done: %v", message)
	case <-time.After(10 * time.Second):
		return errors.New("Wait timeout")
	}
	return nil
}

func (c *AsrClient) Close() {
	if c.response != nil {
		close(c.response)
	}
	if c.errCh != nil {
		for len(c.errCh) > 0 {
			<-c.errCh
		}
	}
	if c.stop != nil {
		for len(c.stop) > 0 {
			<-c.stop
		}
	}

	if c.sr != nil {
		c.sr.Close()
	}
	if c.autoLangConfs != nil {
		c.autoLangConfs.Close()
	}
	if c.speechConfig != nil {
		c.speechConfig.Close()
	}
	if c.audioConfig != nil {
		c.audioConfig.Close()
	}
	if c.stream != nil {
		c.stream.Close()
	}
	if c.audioStreamFormat != nil {
		c.audioStreamFormat.Close()
	}
	if c.phraseListGrammar != nil {
		c.phraseListGrammar.Close()
	}
}
