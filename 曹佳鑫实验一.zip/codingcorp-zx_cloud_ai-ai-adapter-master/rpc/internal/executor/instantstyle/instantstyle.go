package instantstyle

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type InstantStyleExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewInstantStyleExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *InstantStyleExecutor {
	return &InstantStyleExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *InstantStyleExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *InstantStyleExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *InstantStyleExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.InstantStyleReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.InstantStyleInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if iPara.Image == nil || iPara.Image.FileData == "" {
		return nil, fmt.Errorf("InferenceParameter Image is nil")
	}
	inputImage := iPara.Image.FileData

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.InstantStyleExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.StyleImage == nil || ePara.StyleImage.FileData == "" {
		return nil, fmt.Errorf("ExtendedParameter StyleImage is nil")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	thumbUpTokens := ""
	if len(in.ThumbUpTokens) > 0 {
		thumbUpTokens = in.ThumbUpTokens[0]
	}
	req := &adaptermodel.InstantStyleReq{
		TaskId:                      in.Header.TaskId,
		StyleImage:                  ePara.StyleImage.FileData,
		InputImage:                  inputImage,
		Prompt:                      ePara.Prompt,
		NegativePrompt:              ePara.NegativePrompt,
		NegativeContentPrompt:       ePara.NegContentPrompt,
		NegativeContentScale:        ePara.NegContentScale,
		IpAdapterScale:              ePara.IpAdapterScale,
		ControlnetConditioningScale: ePara.ControlnetConditioningScale,
		NumInferenceSteps:           ePara.NumInferenceSteps,
		GuidanceScale:               ePara.GuidanceScale,
		ResultImageUpToken:          in.ResultUpTokens[0],
		ThumbnailImageUpToken:       thumbUpTokens,
	}
	return req, nil
}

func (e *InstantStyleExecutor) doInference(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.InstantStyleHandler(req)
	if err != nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("task id: %s, InstantStyleHandler failed, code: %d, message: %s", req.TaskId, result.Code, result.Message)
	}

	return result, nil
}

func (e *InstantStyleExecutor) buildResponse(resp *adaptermodel.InstantStyleResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Instant_Style,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_InstantStyle{
			InstantStyle: &aiparameter.InstantStyleInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
		FileData: resp.ResultImage,
		FileMd5:  resp.ImageMd5,
		FileSize: resp.ImageSize,
	})
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
