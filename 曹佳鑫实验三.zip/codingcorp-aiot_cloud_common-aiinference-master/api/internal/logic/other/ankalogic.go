package other

import (
	"context"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type AnkaLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewAnkaLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AnkaLogic {
	return &AnkaLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *AnkaLogic) Anka(req *types.AnkaRequest) (resp *types.AnkaResponse, err error) {
	// todo: add your logic here and delete this line

	return
}
