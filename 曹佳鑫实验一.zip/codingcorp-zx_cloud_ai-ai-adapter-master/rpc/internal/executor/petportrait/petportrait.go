package petportrait

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type PetPortraitExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewPetPortraitExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *PetPortraitExecutor {
	return &PetPortraitExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *PetPortraitExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *PetPortraitExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *PetPortraitExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.AiGenerateImageReq, error) {
	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	var ePara aiparameter.PetPortraitExtendedParameter
	err := common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.AiGenerateParameter == nil {
		return nil, fmt.Errorf("ExtendedParameter AiGenerateParameter is nil")
	}
	var imageData []byte
	if ePara.StyleImage != nil {
		if common.IsUrl(ePara.StyleImage.FileData) {
			imageData, err = common.DownloadFile(e.ctx, ePara.StyleImage.FileData)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", ePara.StyleImage.FileData, err)
			}
		} else if data, err := common.Base64ToBytes(ePara.StyleImage.FileData); err == nil {
			imageData = data
		} else {
			return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", ePara.StyleImage.FileData[1000])
		}
	}

	var controlnets []adaptermodel.Controlnet
	for _, controlnet := range ePara.AiGenerateParameter.Controlnets {
		controlnets = append(controlnets, adaptermodel.Controlnet{
			//InputImage:    imageData,
			Module:        controlnet.Module,
			Model:         controlnet.Model,
			Weight:        controlnet.Weight,
			Image:         imageData,
			ThresholdA:    controlnet.ThresholdA,
			ThresholdB:    controlnet.ThresholdB,
			GuidanceStart: controlnet.GuidanceStart,
			GuidanceEnd:   controlnet.GuidanceEnd,
		})
	}

	req := &adaptermodel.AiGenerateImageReq{
		TaskId:              in.Header.TaskId,
		TaskType:            in.TaskType,
		ResultImageUpTokens: in.ResultUpTokens,
		ThumbImageUpTokens:  in.ThumbUpTokens,
		GenerateImageParameter: adaptermodel.GenerateImageParameter{
			Prompt:            ePara.AiGenerateParameter.Prompt,
			NegativePrompt:    ePara.AiGenerateParameter.NegativePrompt,
			SamplerName:       ePara.AiGenerateParameter.SamplerName,
			BatchSize:         ePara.AiGenerateParameter.BatchSize,
			BatchCount:        ePara.AiGenerateParameter.BatchCount,
			Steps:             ePara.AiGenerateParameter.Steps,
			CfgScale:          ePara.AiGenerateParameter.CfgScale,
			Width:             ePara.AiGenerateParameter.Width,
			Height:            ePara.AiGenerateParameter.Height,
			DenoisingStrength: ePara.AiGenerateParameter.DenoisingStrength,
			Controlnet:        controlnets,
			SdModel:           ePara.AiGenerateParameter.SdModel,
			LoraModels:        ePara.AiGenerateParameter.LoraModels,
			VaeModel:          ePara.AiGenerateParameter.VaeModel,
			ControlnetModels:  ePara.AiGenerateParameter.ControlnetModels,
		},
	}
	return req, nil
}

func (e *PetPortraitExecutor) doInference(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.AiGenerateImageHandler(req)
	if err != nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, code: %d, message: %s", result.Code, result.Message)
	}

	return result, nil
}

func (e *PetPortraitExecutor) buildResponse(resp *adaptermodel.AiGenerateImageResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType:            aiparameter.TaskType_TASK_TYPE_Pet_Portrait,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_PetPortrait{},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	for _, imageInfo := range resp.ImageInfos {
		out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
			FileData: string(imageInfo.Data),
			FileMd5:  imageInfo.Md5,
			FileSize: imageInfo.Size,
		})
	}
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
