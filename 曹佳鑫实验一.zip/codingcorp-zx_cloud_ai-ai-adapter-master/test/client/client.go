package client

import (
	"context"
	"encoding/binary"
	"fmt"
	"os"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	pb "e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"

	"github.com/zeromicro/go-zero/core/logx"
	"google.golang.org/grpc"
)

type Client struct {
	conf *Config
	conn *grpc.ClientConn
	logx.Logger
}

func NewClient(conf *Config, conn *grpc.ClientConn) *Client {
	return &Client{
		conf: conf,
		conn: conn,
	}
}

func (c *Client) CreateTrain(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("CreateTrain start")

	para := &aiparameter.TrainInferenceParameter{
		InstanceName:    c.conf.Train.InstanceName,
		DatasetPath:     c.conf.Train.DatasetPath,
		OutputModelPath: c.conf.Train.OutputModelPath,
	}
	js, err := common.AnyToJson(para)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}

	rsp, err := client.CreateTrain(ctx, &pb.CreateTrainReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
		InferenceParameter: string(js),
	})
	if err != nil || rsp == nil {
		return fmt.Errorf("CreateTrain failed, err: %v, rsp: %v", err, rsp)
	}
	if rsp.Header.Code != 0 {
		return fmt.Errorf("CreateTrain failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	}

	c.Infof("CreateTrain success, rsp: %v", rsp)

	return nil
}

func (c *Client) GetTrain(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("GetTrain start")

	rsp, err := client.GetTrain(ctx, &pb.GetTrainReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
	})
	if err != nil || rsp == nil {
		return fmt.Errorf("GetTrain failed, err: %v, rsp: %v", err, rsp)
	}
	if rsp.Header.Code != 0 {
		return fmt.Errorf("GetTrain failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	}

	c.Infof("GetTrain success, rsp: %v", rsp)

	return nil
}

func (c *Client) StopTrain(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("StopTrain start")

	rsp, err := client.StopTrain(ctx, &pb.StopTrainReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
	})
	if err != nil || rsp == nil {
		return fmt.Errorf("StopTrain failed, err: %v, rsp: %v", err, rsp)
	}
	if rsp.Header.Code != 0 {
		return fmt.Errorf("StopTrain failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	}

	c.Infof("StopTrain success, rsp: %v", rsp)

	return nil
}

func (c *Client) Inference(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("Inference start, task type: %s", c.conf.Inference.TaskType)

	var tskType aiparameter.TaskType
	switch c.conf.Inference.TaskType {
	case AI_ADAPTER_ACTION_imageupscale:
		tskType = aiparameter.TaskType_TASK_TYPE_Image_Upscale
	case AI_ADAPTER_ACTION_removebackground:
		tskType = aiparameter.TaskType_TASK_TYPE_Remove_Background
	case AI_ADAPTER_ACTION_imagetovector:
		tskType = aiparameter.TaskType_TASK_TYPE_Image_To_Vector
	case AI_ADAPTER_ACTION_texttoimagedesign:
		tskType = aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design
	case AI_ADAPTER_ACTION_styletransfer:
		tskType = aiparameter.TaskType_TASK_TYPE_Style_Transfer
	case AI_ADAPTER_ACTION_popart:
		tskType = aiparameter.TaskType_TASK_TYPE_Pop_Art
	case AI_ADAPTER_ACTION_petportrait:
		tskType = aiparameter.TaskType_TASK_TYPE_Pet_Portrait
	case AI_ADAPTER_ACTION_faceswap:
		tskType = aiparameter.TaskType_TASK_TYPE_Face_Swap
	case AI_ADAPTER_ACTION_magiceraser:
		tskType = aiparameter.TaskType_TASK_TYPE_Magic_Eraser
	case AI_ADAPTER_ACTION_removebackfround:
		tskType = aiparameter.TaskType_TASK_TYPE_Remove_Foreground
	case AI_ADAPTER_ACTION_speechtotext:
		tskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
	case AI_ADAPTER_ACTION_texttospeech:
		tskType = aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	case AI_ADAPTER_ACTION_translate:
		tskType = aiparameter.TaskType_TASK_TYPE_Translate
	case AI_ADAPTER_ACTION_dialogue:
		tskType = aiparameter.TaskType_TASK_TYPE_Dialogue
	case AI_ADAPTER_ACTION_train:
		tskType = aiparameter.TaskType_TASK_TYPE_Train
	case AI_ADAPTER_ACTION_instantstyle:
		tskType = aiparameter.TaskType_TASK_TYPE_Instant_Style
	case AI_ADAPTER_ACTION_instantstyleplus:
		tskType = aiparameter.TaskType_TASK_TYPE_Instant_Style_Plus
	case AI_ADAPTER_ACTION_depthmapgeneration:
		tskType = aiparameter.TaskType_TASK_TYPE_Depth_Map_Generation
	case AI_ADAPTER_ACTION_styletransfer1:
		c.conf.Inference.TaskType = AI_ADAPTER_ACTION_styletransfer
		tskType = aiparameter.TaskType_TASK_TYPE_Style_Transfer1
	case AI_ADAPTER_ACTION_styletransfer2:
		c.conf.Inference.TaskType = AI_ADAPTER_ACTION_styletransfer
		tskType = aiparameter.TaskType_TASK_TYPE_Style_Transfer2
	case AI_ADAPTER_ACTION_styletransfer3:
		c.conf.Inference.TaskType = AI_ADAPTER_ACTION_styletransfer
		tskType = aiparameter.TaskType_TASK_TYPE_Style_Transfer3
	case AI_ADAPTER_ACTION_difyworkflow:
		tskType = aiparameter.TaskType_TASK_TYPE_Dify_Workflow
	case AI_ADAPTER_ACTION_difychatflow:
		tskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
	case AI_ADAPTER_ACTION_translatequestionrecommend:
		tskType = aiparameter.TaskType_TASK_TYPE_Translate_Question_Recommend
	}

	inferenceParameter, ok := c.conf.Inference.InferenceParameter[c.conf.Inference.TaskType]
	if !ok {
		return fmt.Errorf("InferenceParameter not found for task type: %s", c.conf.Inference.TaskType)
	}
	extendedParameter, ok := c.conf.Inference.ExtendedParameter[c.conf.Inference.TaskType]
	if !ok {
		return fmt.Errorf("ExtendedParameter not found for task type: %s", c.conf.Inference.TaskType)
	}

	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
		TaskType:           tskType,
		ResultUpTokens:     c.conf.Inference.ResultImageUpTokens,
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(ctx, req)
	if err != nil || rsp == nil {
		return fmt.Errorf("Inference failed, err: %v, rsp: %v", err, rsp)
	}
	if rsp.Header.Code != 0 {
		return fmt.Errorf("Inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	}

	c.Infof("Inference success, rsp: %v", rsp)

	return nil
}

func (c *Client) SpeechToTextStream(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("SpeechToTextStream start, task type: %s", c.conf.Inference.TaskType)

	tskType := aiparameter.TaskType_TASK_TYPE_Speech_To_Text
	var iPara = aiparameter.SpeechToTextInferenceParameter{
		Audio: &aicommon.AudioInfo{
			Data:       []byte{},
			SampleRate: 16000,
			BitRate:    16000,
			Channels:   1,
			Format:     "pcm",
			Language:   "zh-CN",
		},
	}
	var ePara = aiparameter.SpeechToTextExtendedParameter{
		TargetLanguage:     "zh",
		AddPunctuation:     true,
		EnableWord:         true,
		MaxSentenceSilence: 800,
		MaxStartSilence:    5000,
		MaxEndSilence:      2000,
		ServiceProvider:    "azure", // "aliyun" or "anker" or "azure"
		HotWordsList:       []*aicommon.HotWordsInfo{},
	}

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}

	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			rsp, err := stream.Recv()
			if err != nil {
				if err.Error() == "EOF" {
					c.Infof("SpeechToTextStream Recv success, err: %v", err)
					break
				}
				c.Errorf("SpeechToTextStream recv failed, err: %v", err)
				return
			}

			if rsp.Header.Code != 0 {
				c.Errorf("SpeechToTextStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
				return
			}

			c.Infof("SpeechToTextStream success, TimeTakenMs: %dms, result:%v", rsp.TimeTakenMs, rsp.InferenceResultInfo)

		}
	}()

	// 读取本地音频文件，循环发送给服务端，每次发送 1600字节数据
	AudioPath := "audio/dialog-test.wav"
	// AudioPath := c.conf.AudioPath
	audioData, err := os.ReadFile(AudioPath)
	if err != nil {
		return fmt.Errorf("ReadFile failed, err: %v", err)
	}
	c.Infof("ReadFile success, AudioPath: %s, audioData len: %d", AudioPath, len(audioData))
	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	fmt.Println("extendedParameter", string(extendedParameter))
	chunk := 3200
	for i := 0; i < len(audioData); i += chunk {
		end := i + chunk
		if end > len(audioData) {
			end = len(audioData)
		}
		iPara.Audio.Data = audioData[i:end]
		inferenceParameter, err := common.AnyToJson(iPara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		err = stream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: c.conf.UserId,
				TaskId: c.conf.TaskId,
			},
			TaskType:           tskType,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(extendedParameter),
		})
		if err != nil {
			return fmt.Errorf("SpeechToTextStream send failed, err: %v", err)
		}
		c.Infof("SpeechToTextStream send success, i: %d, end: %d", i, end)
		time.Sleep(50 * time.Millisecond)
	}

	err = stream.CloseSend()
	if err != nil {
		return fmt.Errorf("SpeechToTextStream CloseSend failed, err: %v", err)
	}

	wg.Wait()

	c.Infof("SpeechToTextStream success")
	return nil
}

func (c *Client) LanguageDetectStream(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("LanguageDetectStream start, task type: %s", c.conf.Inference.TaskType)

	tskType := aiparameter.TaskType_TASK_TYPE_Language_Detect
	var iPara = aiparameter.LanguageDetectInferenceParameter{
		Audio: &aicommon.AudioInfo{
			Data:       []byte{},
			SampleRate: 16000,
			BitRate:    16000,
			Channels:   1,
			Format:     "pcm",
			Language:   "zh",
		},
	}
	var ePara = aiparameter.LanguageDetectExtendedParameter{
		ServiceProvider: "anker", // "aliyun" or "anker" or "azure"
	}

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}

	// 读取本地音频文件，循环发送给服务端，每次发送 1600字节数据
	// audioPath := c.conf.AudioPath
	audioPath := "audio/es_16k.wav"
	audioData, err := os.ReadFile(audioPath)
	if err != nil {
		return fmt.Errorf("ReadFile failed, err: %v", err)
	}
	c.Infof("ReadFile success, audioData len: %d", len(audioData))
	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	c.Infof("LanguageDetectStream extendedParameter: %s", string(extendedParameter))

	var first time.Time
	var firstRecv int64

	var isRecv atomic.Bool
	isRecv.Store(false)

	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer func() {
			err = stream.CloseSend()
			if err != nil {
				c.Errorf("LanguageDetectStream CloseSend failed, err: %v", err)
			}
			wg.Done()
			c.Infof("LanguageDetectStream CloseSend success")
		}()

		chunk := 640
		for i := 0; i < len(audioData); i += chunk {
			if isRecv.Load() {
				break
			}

			end := i + chunk
			if end > len(audioData) {
				end = len(audioData)
			}
			iPara.Audio.Data = audioData[i:end]
			inferenceParameter, err := common.AnyToJson(iPara)
			if err != nil {
				c.Errorf("AnyToJson failed, err: %v", err)
				return
			}

			if isRecv.Load() {
				break
			}
			err = stream.Send(&pb.InferenceReq{
				Header: &aicommon.ReqHeader{
					UserId: c.conf.UserId,
					TaskId: c.conf.TaskId,
				},
				TaskType:           tskType,
				InferenceParameter: string(inferenceParameter),
				ExtendedParameter:  string(extendedParameter),
			})
			if err != nil {
				c.Errorf("LanguageDetectStream send failed, err: %v", err)
				return
			}
			if first.IsZero() {
				first = time.Now()
			}

			if isRecv.Load() {
				break
			}

			c.Infof("LanguageDetectStream send success, i: %d, end: %d", i, end)
			time.Sleep(20 * time.Millisecond)
		}
	}()

	for {
		rsp, err := stream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("LanguageDetectStream Recv success, err: %v", err)
				break
			}
			c.Errorf("LanguageDetectStream recv failed, err: %v", err)
			return fmt.Errorf("LanguageDetectStream recv failed, err: %v", err)
		}

		if rsp.Header.Code != 0 {
			c.Errorf("LanguageDetectStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
			return fmt.Errorf("LanguageDetectStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
		}

		if firstRecv == 0 {
			firstRecv = int64(time.Since(first).Milliseconds())
			isRecv.Store(true)
		}

		c.Infof("LanguageDetectStream success, rsp: %v, firstRecv: %dms", rsp, firstRecv)
	}

	wg.Wait()

	c.Infof("LanguageDetectStream success")
	return nil
}

func (c *Client) OpusDecodeStream(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("OpusDecodeStream start, task type: %s", c.conf.Inference.TaskType)

	tskType := aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
	var iPara = aiparameter.OpusWrapperInferenceParameter{
		Source: &aicommon.AudioInfo{
			Data:        []byte{},
			SampleRate:  16000,
			BitRate:     32000,
			Channels:    2,
			Format:      "opus",
			Language:    "zh",
			FrameSizeMs: 20, // 20ms
		},
		IsEnableEnc: true,
	}
	var ePara = aiparameter.OpusWrapperExtendedParameter{
		Target: &aicommon.AudioInfo{
			Data:        []byte{},
			SampleRate:  16000,
			BitRate:     256000,
			Channels:    1,
			Format:      "pcm",
			Language:    "zh",
			FrameSizeMs: 20, // 20ms
		},
	}

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}

	var wg sync.WaitGroup
	wg.Add(1)
	recvIndex := 0
	go func() {
		defer wg.Done()
		for {
			rsp, err := stream.Recv()
			if err != nil {
				if err.Error() == "EOF" {
					c.Infof("OpusDecodeStream Recv success, err: %v", err)
					break
				}
				c.Errorf("OpusDecodeStream recv failed, err: %v", err)
				return
			}

			if rsp.Header.Code != 0 {
				c.Errorf("OpusDecodeStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
				return
			}

			recvIndex++

			c.Infof("OpusDecodeStream success, recvIndex: %d, TimeTakenMs: %dms, result:%v", recvIndex, rsp.TimeTakenMs, len(rsp.InferenceResultInfo))
		}
	}()

	// 读取本地音频文件，循环发送给服务端，每次发送 1600字节数据

	// audioPath := c.conf.AudioPath
	audioPath := "audio/2mic_16k_32k_20ms.opus"
	audioData, err := os.ReadFile(audioPath)
	if err != nil {
		return fmt.Errorf("ReadFile failed, err: %v", err)
	}
	c.Infof("ReadFile success, audioData len: %d", len(audioData))

	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	c.Infof("OpusDecodeStream extendedParameter: %s", string(extendedParameter))

	chunk := 80
	sendIndex := 0
	for i := 0; i < len(audioData); i += chunk {
		end := i + chunk
		if end > len(audioData) {
			end = len(audioData)
		}
		iPara.Source.Data = audioData[i:end]
		inferenceParameter, err := common.AnyToJson(iPara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		err = stream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: c.conf.UserId,
				TaskId: c.conf.TaskId,
			},
			TaskType:           tskType,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(extendedParameter),
		})
		if err != nil {
			return fmt.Errorf("OpusDecodeStream send failed, err: %v", err)
		}

		sendIndex++
		c.Infof("OpusDecodeStream send success, sendIndex: %d, i: %d, end: %d", sendIndex, i, end)
		time.Sleep(20 * time.Millisecond)
	}

	err = stream.CloseSend()
	if err != nil {
		return fmt.Errorf("OpusDecodeStream CloseSend failed, err: %v", err)
	}
	wg.Wait()

	if recvIndex != sendIndex {
		return fmt.Errorf("OpusDecodeStream failed, recvIndex: %d, sendIndex: %d", recvIndex, sendIndex)
	}
	c.Infof("OpusDecodeStream success")
	return nil
}

func (c *Client) TextToSpeechStream(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("TextToSpeechStream start, task type: %s", c.conf.Inference.TaskType)

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}

	tskType := aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	var ePara = aiparameter.TextToSpeechExtendedParameter{
		Format:          "pcm",
		Language:        "zh-CN",
		Channels:        1,
		ServiceProvider: "azure", // "azure", "aliyun" or "anker"
		EnableSubtitle:  true,
	}
	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	fmt.Println("extendedParameter", string(extendedParameter))

	texts := []string{
		// ms-MY
		// "Bagaimana cuaca hari ini? ",
		// "Bolehkah saya tahu cara ke stesen kereta api yang terdekat?",
		// ar-SA
		// "كيف هو الطقس اليوم؟ من فضلك، كيف أصل إلى أقرب محطة قطار؟",
		// fil-PH
		// "Kumusta ang panahon ngayon? ",
		// "Puwede po bang itanong kung paano makarating sa pinakamalapit na istasyon ng tren?",
		// zh-CN
		"今天，阳光洒满了每一个角落，我的心情就像这明媚的天气一样，充满了温暖和喜悦。",
		"每一步走在这金色的阳光下，都感觉像是在跳跃的音符上跳舞，轻松而愉快。",
		"空气中弥漫着花香和清新，每一次呼吸都像是在品尝着幸福的滋味。",
		"体感温度22.5°C",
		"2025年5月6日",
	}
	for i, text := range texts {
		var iPara = aiparameter.TextToSpeechInferenceParameter{
			Text:       text,
			SentenceId: int32(i + 1),
		}
		inferenceParameter, err := common.AnyToJson(iPara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		err = stream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: c.conf.UserId,
				TaskId: c.conf.TaskId,
				AppId:  c.conf.AppId,
			},
			TaskType:           tskType,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(extendedParameter),
		})
		if err != nil {
			return fmt.Errorf("TextToSpeechStream send failed, err: %v", err)
		}
		c.Infof("TextToSpeechStream send success, text: %s", text)
	}

	err = stream.CloseSend()
	if err != nil {
		c.Errorf("TextToSpeechStream CloseSend failed, err: %v", err)
		return fmt.Errorf("TextToSpeechStream CloseSend failed, err: %v", err)
	}

	file, err := os.Create(fmt.Sprintf("audio/output-%s.wav", c.conf.TaskId))
	if err != nil {
		c.Errorf("create failed, err: %v", err)
		return fmt.Errorf("create failed, err: %v", err)
	}
	defer file.Close()

	for {
		rsp, err := stream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("TextToSpeechStream Recv success, err: %v", err)
				break
			}
			return fmt.Errorf("TextToSpeechStream recv failed, err: %v", err)
		}

		if rsp.Header.Code != 0 {
			return fmt.Errorf("TextToSpeechStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
		}

		var result TtsResult
		err = common.JsonToAny([]byte(rsp.InferenceResultInfo), &result)
		if err != nil {
			c.Errorf("JsonToAny failed, err: %v", err)
			return fmt.Errorf("JsonToAny failed, err: %v", err)
		}
		if result.InferenceResultInfo.TextToSpeech.SentenceStart {
			c.Infof("TextToSpeechStream success, sentence start")
		}

		n, err := file.Write(result.InferenceResultInfo.TextToSpeech.Audio.Data)
		if err != nil {
			c.Errorf("write failed, err: %v", err)
			return fmt.Errorf("write failed, err: %v", err)
		}
		c.Infof("TextToSpeechStream success, recv audio len: %d, SentenceStart: %v, index: %d, Subtitle: %v", n, result.InferenceResultInfo.TextToSpeech.SentenceStart, result.InferenceResultInfo.TextToSpeech.SentenceId, result.InferenceResultInfo.TextToSpeech.Subtitle)
	}

	c.Infof("TextToSpeechStream success")
	return nil
}

type LLMTranslateResult struct {
	BatchIndex       int       `json:"batch_index"`
	ContextLogits    float64   `json:"context_logits"`
	CumLogProbs      float64   `json:"cum_log_probs"`
	GenerationLogits float64   `json:"generation_logits"`
	ModelName        string    `json:"model_name"`
	ModelVersion     string    `json:"model_version"`
	OutputLogProbs   []float64 `json:"output_log_probs"`
	SequenceEnd      bool      `json:"sequence_end"`
	SequenceId       int       `json:"sequence_id"`
	SequenceStart    bool      `json:"sequence_start"`
	TextOutput       string    `json:"text_output"`
}

func (c *Client) extractTextFromResponse(text string, role string) string {
	// 分割文本并获取最后一部分
	parts := strings.Split(text, "[target]")
	lastPart := parts[len(parts)-1]

	// 移除'#'字符并去除两端空白
	lastPart = strings.ReplaceAll(lastPart, "#", "")
	lastPart = strings.TrimSpace(lastPart)

	// 使用正则表达式分割文本
	re := regexp.MustCompile(`\n{2,}`)
	splitParts := re.Split(lastPart, -1)
	transRet := splitParts[len(splitParts)-1]

	// 替换换行符和回车符为空格，并去除两端空白
	transRet = strings.ReplaceAll(transRet, "\n", " ")
	transRet = strings.ReplaceAll(transRet, "\r", " ")
	// 去掉 ROLE : 或者 ROLE:
	transRet = strings.ReplaceAll(transRet, role+":", "")
	transRet = strings.ReplaceAll(transRet, role+" :", "")
	transRet = strings.TrimSpace(transRet)
	return transRet
}

type AsrResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		SpeechToText struct {
			SegmentEnd bool   `json:"segment_end"`
			Text       string `json:"text"`
			Segments   []struct {
				ID         int     `json:"id"`
				StartMs    int     `json:"start_ms"`
				EndMs      int     `json:"end_ms"`
				Text       string  `json:"text"`
				Confidence float64 `json:"confidence"`
			} `json:"segments"`
		} `json:"SpeechToText"`
	} `json:"InferenceResultInfo"`
}

type TranslateResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		Translate struct {
			SentenceStart bool   `json:"sentence_start"`
			SentenceEnd   bool   `json:"sentence_end"`
			Text          string `json:"text"`
		} `json:"Translate"`
	} `json:"InferenceResultInfo"`
}

type DifyChatflowResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		DifyChatflow struct {
			Text string `json:"text"`
		} `json:"DifyChatflow"`
	} `json:"InferenceResultInfo"`
}

type TtsResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		TextToSpeech struct {
			SentenceId    int32                `json:"sentence_id"`
			Audio         *aicommon.AudioInfo  `json:"audio"`
			SentenceStart bool                 `json:"sentence_start"`
			Subtitle      []*aicommon.Subtitle `json:"subtitle"`
		} `json:"TextToSpeech"`
	} `json:"InferenceResultInfo"`
}

func createWAVHeader(dataSize int) []byte {
	header := make([]byte, 44)

	// RIFF chunk descriptor
	copy(header[0:4], []byte("RIFF"))
	binary.LittleEndian.PutUint32(header[4:8], uint32(dataSize+36))
	copy(header[8:12], []byte("WAVE"))

	// fmt sub-chunk
	copy(header[12:16], []byte("fmt "))
	binary.LittleEndian.PutUint32(header[16:20], 16)    // sub-chunk size
	binary.LittleEndian.PutUint16(header[20:22], 1)     // audio format (PCM)
	binary.LittleEndian.PutUint16(header[22:24], 1)     // num channels (mono)
	binary.LittleEndian.PutUint32(header[24:28], 16000) // sample rate
	binary.LittleEndian.PutUint32(header[28:32], 32000) // byte rate
	binary.LittleEndian.PutUint16(header[32:34], 2)     // block align
	binary.LittleEndian.PutUint16(header[34:36], 16)    // bits per sample

	// data sub-chunk
	copy(header[36:40], []byte("data"))
	binary.LittleEndian.PutUint32(header[40:44], uint32(dataSize))

	return header
}

func saveAudioFile(data []byte, filename string) error {

	// 提取音频数据
	audioData := data

	// 添加 WAV 文件头
	wavHeader := createWAVHeader(len(audioData))
	fullAudio := append(wavHeader, audioData...)

	// 保存文件
	err := os.WriteFile(filename, fullAudio, 0644)
	if err != nil {
		return fmt.Errorf("failed to write audio file: %v", err)
	}

	fmt.Printf("Audio saved to %s\n", filename)
	return nil
}

func (c *Client) SpeechToSpeech(ctx context.Context) (err error) {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)

	audioData, err := os.ReadFile(c.conf.AudioPath)
	if err != nil {
		return fmt.Errorf("open failed, err: %v", err)
	}

	asrText, err := c.performASR(ctx, client, audioData)
	if err != nil {
		return err
	}

	c.Infof("asr result: %s", asrText)

	translatedText, err := c.performTranslation(ctx, client, asrText)
	if err != nil {
		return err
	}

	c.Infof("translate result: %s", translatedText)

	err = c.performTTS(ctx, client, translatedText)
	if err != nil {
		return err
	}

	return nil
}

func (c *Client) SpeechDifyWorkflow(ctx context.Context) (err error) {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)

	audioData, err := os.ReadFile(c.conf.AudioPath)
	if err != nil {
		return fmt.Errorf("open failed, err: %v", err)
	}

	asrText, err := c.performASR(ctx, client, audioData)
	if err != nil {
		return err
	}

	c.Infof("asr result: %s", asrText)

	c.conf.Inference.InferenceParameter["dify_workflow"] = fmt.Sprintf("{\"text\": \"%s\"}", asrText)
	c.conf.Inference.TaskType = "dify_workflow"

	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
		TaskType:           aiparameter.TaskType_TASK_TYPE_Dify_Workflow,
		InferenceParameter: c.conf.Inference.InferenceParameter["dify_workflow"],
		ExtendedParameter:  c.conf.Inference.ExtendedParameter["dify_workflow"],
	}

	rsp, err := client.Inference(ctx, req)
	if err != nil || rsp == nil {
		return fmt.Errorf("Inference failed, err: %v, rsp: %v", err, rsp)
	}
	if rsp.Header.Code != 0 {
		return fmt.Errorf("Inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	}

	c.Infof("Inference success, rsp: %v", rsp)
	err = c.Inference(ctx)
	if err != nil {
		return err
	}

	// c.Infof("workflow result: %s", workflowText)

	// err = c.performTTS(ctx, client, workflowText)
	// if err != nil {
	// 	return err
	// }

	return nil
}

func (c *Client) SpeechDifyChatflowStream(ctx context.Context) (err error) {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)

	audioData, err := os.ReadFile(c.conf.AudioPath)
	if err != nil {
		return fmt.Errorf("open failed, err: %v", err)
	}

	asrText, err := c.performASR(ctx, client, audioData)
	if err != nil {
		return err
	}

	c.Infof("asr result: %s", asrText)

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return err
	}

	c.conf.Inference.InferenceParameter["dify_chatflow"] = fmt.Sprintf("{\"text\": \"%s\"}", asrText)
	c.conf.Inference.TaskType = "dify_chatflow"

	err = stream.Send(&pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
		TaskType:           aiparameter.TaskType_TASK_TYPE_Dify_Chatflow,
		ResultUpTokens:     c.conf.Inference.ResultImageUpTokens,
		InferenceParameter: c.conf.Inference.InferenceParameter["dify_chatflow"],
		ExtendedParameter:  c.conf.Inference.ExtendedParameter["dify_chatflow"],
	})
	if err != nil {
		return fmt.Errorf("SpeechDifyChatflowStream send failed, err: %v", err)
	}

	err = stream.CloseSend()
	if err != nil {
		return fmt.Errorf("SpeechDifyChatflowStream failed, err: %v", err)
	}

	var llmText string
	for {
		recv, err := stream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("recv success, err: %v", err)
				break
			}
			return fmt.Errorf("recv failed, err: %v", err)
		}
		c.Infof("recv success, rsp: %v", recv)
		var result DifyChatflowResult
		err = common.JsonToAny([]byte(recv.InferenceResultInfo), &result)
		if err != nil {
			return fmt.Errorf("JsonToAny failed, err: %v", err)
		}
		llmText += result.InferenceResultInfo.DifyChatflow.Text
		// c.Infof("SpeechToText success, rsp: %v", result)
	}
	fmt.Println("======>", llmText)

	err = c.performTTS(ctx, client, llmText)
	if err != nil {
		return fmt.Errorf("performTTS failed, err: %v", err)
	}

	return nil
}

func (c *Client) performASR(ctx context.Context, client pb.AiAdapterRpcClient, audioData []byte) (string, error) {
	asrStream, err := client.StreamInference(ctx)
	if err != nil {
		return "", fmt.Errorf("StreamInference failed, err: %v", err)
	}
	asrIParam := aiparameter.SpeechToTextInferenceParameter{
		Audio: &aicommon.AudioInfo{
			Data:       []byte{},
			SampleRate: 16000,
			BitRate:    16000,
			Channels:   1,
			Format:     "wav",
			Language:   "es-ES",
		},
	}
	asrEParam := aiparameter.SpeechToTextExtendedParameter{
		TargetLanguage:     "es-ES",
		AddPunctuation:     true,
		EnableWord:         true,
		MaxSentenceSilence: 800,
		MaxStartSilence:    5000,
		MaxEndSilence:      2000,
		HotWordsList:       []*aicommon.HotWordsInfo{},
		ServiceProvider:    "aliyun",
	}
	asrExtendParam, err := common.AnyToJson(asrEParam)
	if err != nil {
		return "", fmt.Errorf("send failed, err: %v", err)
	}
	chunk := 3200
	for i := 0; i < len(audioData); i += chunk {
		end := i + chunk
		if end > len(audioData) {
			end = len(audioData)
		}
		asrIParam.Audio.Data = audioData[i:end]
		inferenceParameter, err := common.AnyToJson(asrIParam)
		if err != nil {
			return "", fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		err = asrStream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: c.conf.UserId,
				TaskId: c.conf.TaskId,
			},
			TaskType:           aiparameter.TaskType_TASK_TYPE_Speech_To_Text,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(asrExtendParam),
		})
		if err != nil {
			return "", fmt.Errorf("SpeechToTextStream send failed, err: %v", err)
		}
		time.Sleep(50 * time.Millisecond)
	}

	err = asrStream.CloseSend()
	if err != nil {
		return "", fmt.Errorf("SpeechRecognition failed, err: %v", err)
	}

	var asrText string
	for {
		recv, err := asrStream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("recv success, err: %v", err)
				break
			}
			return "", fmt.Errorf("recv failed, err: %v", err)
		}

		c.Infof("recv success, rsp: %v", recv)
		var result AsrResult
		err = common.JsonToAny([]byte(recv.InferenceResultInfo), &result)
		if err != nil {
			return "", fmt.Errorf("JsonToAny failed, err: %v", err)
		}
		c.Logger.Info("======", result.InferenceResultInfo.SpeechToText.Text)
		asrText += result.InferenceResultInfo.SpeechToText.Text
		c.Infof("SpeechToText success, rsp: %v", result)
	}
	fmt.Println("======>", asrText)
	return asrText, nil
}

func (c *Client) performTranslation(ctx context.Context, client pb.AiAdapterRpcClient, asrText string) (string, error) {
	translateIparam := aiparameter.TranslateInferenceParameter{Text: asrText}
	translateEparam := aiparameter.TranslateExtendedParameter{
		EnableStream:    false,
		FromLang:        "zh",
		ToLang:          "en",
		Role:            "user_a",
		LlmType:         "qwen-max",
		ServiceProvider: "aliyun",
	}
	translateStream, err := client.StreamInference(ctx)
	if err != nil {
		return "", fmt.Errorf("StreamInference failed, err: %v", err)
	}
	translateInferenceParam, err := common.AnyToJson(translateIparam)
	if err != nil {
		return "", fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	translateExtendParam, err := common.AnyToJson(translateEparam)
	if err != nil {
		return "", fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	err = translateStream.Send(&pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			TaskId: c.conf.TaskId,
			UserId: c.conf.UserId,
		},
		TaskType:           aiparameter.TaskType_TASK_TYPE_Translate,
		InferenceParameter: string(translateInferenceParam),
		ExtendedParameter:  string(translateExtendParam),
	})
	if err != nil {
		return "", fmt.Errorf("Translate send failed, err: %v", err)
	}

	err = translateStream.CloseSend()
	if err != nil {
		return "", fmt.Errorf("Translate CloseSend failed, err: %v", err)
	}

	var translatedText string
	for {
		recv, err := translateStream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("Translate Recv success, err: %v", err)
				break
			}
			return "", fmt.Errorf("Translate recv failed, err: %v", err)
		}
		c.Infof("Translate Recv success, rsp: %v", recv)

		var result TranslateResult
		err = common.JsonToAny([]byte(recv.InferenceResultInfo), &result)
		if err != nil {
			return "", fmt.Errorf("JsonToAny failed, err: %v", err)
		}
		translatedText += result.InferenceResultInfo.Translate.Text
	}

	return translatedText, nil
}

func (c *Client) performTTS(ctx context.Context, client pb.AiAdapterRpcClient, translatedText string) error {
	ttsIparam := aiparameter.TextToSpeechInferenceParameter{
		Text: translatedText,
	}
	ttsEparam := aiparameter.TextToSpeechExtendedParameter{
		EnableSubtitle:  false,
		Language:        "en",
		Format:          "wav",
		BitRate:         16000,
		SampleRate:      16000,
		ServiceProvider: "aliyun",
	}
	ttsStream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}
	ttsInferenceParam, err := common.AnyToJson(ttsIparam)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}
	ttsExtendParam, err := common.AnyToJson(ttsEparam)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}

	err = ttsStream.Send(&pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			TaskId: c.conf.TaskId,
			UserId: c.conf.UserId,
		},
		TaskType:           aiparameter.TaskType_TASK_TYPE_Text_To_Speech,
		InferenceParameter: string(ttsInferenceParam),
		ExtendedParameter:  string(ttsExtendParam),
	})
	if err != nil {
		return fmt.Errorf("tts send failed, err: %v", err)
	}

	err = ttsStream.CloseSend()
	if err != nil {
		return fmt.Errorf("tts CloseSend failed, err: %v", err)
	}

	var datas []byte
	for {
		recv, err := ttsStream.Recv()
		if err != nil {
			if err.Error() == "EOF" {
				c.Infof("tts Recv success, err: %v", err)
				break
			}
			return fmt.Errorf("tts recv failed, err: %v", err)
		}

		var result TtsResult
		err = common.JsonToAny([]byte(recv.InferenceResultInfo), &result)
		if err != nil {
			return fmt.Errorf("JsonToAny failed, err: %v", err)
		}
		datas = append(datas, result.InferenceResultInfo.TextToSpeech.Audio.Data...)
	}

	err = saveAudioFile(datas, fmt.Sprintf("audio/output-%s.wav", c.conf.TaskId))
	if err != nil {
		return fmt.Errorf("write failed, err: %v", err)
	}
	return nil
}

func (c *Client) Translate(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("Translate start, task type: %s", c.conf.Inference.TaskType)

	tskType := aiparameter.TaskType_TASK_TYPE_Translate
	var history []*aicommon.TranslateContext
	history = append(history, &aicommon.TranslateContext{
		Role:     "user",
		Text:     "你好啊，我是野比大雄",
		Language: "zh-CN",
	})
	history = append(history, &aicommon.TranslateContext{
		Role:     "model",
		Text:     "Hello, I'm Nobita Nobi ",
		Language: "en-US",
	})
	var ePara = aiparameter.TranslateExtendedParameter{
		LlmType:         "gpt-4o",
		EnableStream:    true,
		FromLang:        "zh-CN",
		ToLang:          "en-US",
		Role:            "user",
		ServiceProvider: "azure", // "azure", "aliyun" or "anker"
		LlmTypeSentence: "gpt-4o-mini",
		Contexts:        history,
	}
	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			rsp, err := stream.Recv()
			if err != nil {
				if err.Error() == "EOF" {
					c.Infof("Translate Recv success, err: %v", err)
					break
				}
				c.Errorf("Translate recv failed, err: %v", err)
				return
			}

			c.Infof("Translate Recv success, rsp: %+v", rsp)

			if rsp.Header.Code != 0 {
				c.Errorf("Translate failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
				return
			}

			//c.Infof("Translate success, rsp: %v", rsp)
		}
	}()

	texts := []string{
		// "nigger.",
		// "Eu quero dizer só e que a minha filha isso aí isso aí.",
		// "在这优美的意思中。",
		// "One for human, one for kids.",
		// "Kumusta ang panahon ngayon? ",
		// 	"Puwede po bang itanong kung paano makarating sa pinakamalapit na istasyon ng tren?",
		// "Quel temps fait-il aujourd'hui?",
		// 	"Pouvez-vous me dire comment préparer ce plat ?",
		// 	"Le bus n° 225 traverse des attractions célèbres telles que le parc commémoratif et la place du Peuple.",
		// 	"Je suis très heureux de vous rencontrer."
		"今天，阳光洒满了每一个角落，我的心情就像这明媚的天气一样，充满了温暖和喜悦。",
		// "每一步走在这金色的阳光下，都感觉像是在跳跃的音符上跳舞，轻松而愉快。",
		// "空气中弥漫着花香和清新，每一次呼吸都像是在品尝着幸福的滋味。",
	}

	for _, text := range texts {
		var iPara = aiparameter.TranslateInferenceParameter{
			Text:       text,
			SentenceId: 1,
			IsSentence: true,
		}
		inferenceParameter, err := common.AnyToJson(iPara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		err = stream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: c.conf.UserId,
				TaskId: c.conf.TaskId,
			},
			TaskType:           tskType,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(extendedParameter),
		})
		if err != nil {
			return fmt.Errorf("Translate send failed, err: %v", err)
		}

		c.Infof("Translate send success, text: %s", text)
		time.Sleep(50 * time.Millisecond)
	}
	err = stream.CloseSend()
	// 直接退出 这里可以复现send on panic的问题
	time.Sleep(700 * time.Millisecond)

	if err != nil {
		return fmt.Errorf("Translate CloseSend failed, err: %v", err)
	}

	wg.Wait()

	c.Infof("Translate success")
	return nil
}

func (c *Client) TranslateQuestionRecommend(ctx context.Context) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("TranslateQuestionRecommend start, task type: %s", c.conf.Inference.TaskType)

	contexs := `[
     {
        "role": "user_a",
        "text": "请问最近的车站在哪里？",
        "language": "zh-CN"
     },
     {
        "role": "user_a",
        "text": "Where is the nearest station?",
        "language": "en-US"
     },
     {
        "role": "user_b",
        "text": "Turn right 100 meters ahead, next to the museum.",
        "language": "en-US"
     },
     {
        "role": "user_b",
        "text": "在前方右转100米，博物馆旁边。",
        "language": "zh-CN"
     },
     {
        "role": "user_a",
        "text": "请问博物馆有什么好玩的？",
        "language": "zh-CN"
     },
     {
        "role": "user_a",
        "text": "What's fun in the museum?",
        "language": "en-US"
     },
     {
        "role": "user_b",
        "text": "There are a lot of historical materials and artifacts, and you can also visit the botanical gardens.",
        "language": "en-US"
     },
     {
        "role": "user_b",
        "text": "有很多历史资料及文物，你也可以去植物园转一转。",
        "language": "zh-CN"
     },
     {
        "role": "user_a",
        "text": "我看看去。",
        "language": "zh-CN"
     }
    ]`

	tskType := aiparameter.TaskType_TASK_TYPE_Translate_Question_Recommend
	var history []*aicommon.TranslateContext
	err := common.JsonToAny([]byte(contexs), &history)
	if err != nil {
		return fmt.Errorf("JsonToAny failed, err: %v", err)
	}

	var ePara = aiparameter.TranslateQuestionRecommendExtendedParameter{
		ServiceProvider: "anker", // "azure", "aliyun" or "anker"
		TargetLanguage:  "en-US",
		QuestionsNum:    10,
		Contexts:        history,
	}
	extendedParameter, err := common.AnyToJson(ePara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}

	stream, err := client.StreamInference(ctx)
	if err != nil {
		return fmt.Errorf("StreamInference failed, err: %v", err)
	}
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			rsp, err := stream.Recv()
			if err != nil {
				if err.Error() == "EOF" {
					c.Infof("TranslateQuestionRecommend Recv success, err: %v", err)
					break
				}
				c.Errorf("TranslateQuestionRecommend recv failed, err: %v", err)
				return
			}

			c.Infof("TranslateQuestionRecommend Recv success, rsp: %+v", rsp)

			if rsp.Header.Code != 0 {
				c.Errorf("TranslateQuestionRecommend failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
				return
			}
		}
	}()

	var iPara = aiparameter.TranslateQuestionRecommendInferenceParameter{}
	inferenceParameter, err := common.AnyToJson(iPara)
	if err != nil {
		return fmt.Errorf("AnyToJson failed, err: %v", err)
	}

	err = stream.Send(&pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: c.conf.UserId,
			TaskId: c.conf.TaskId,
		},
		TaskType:           tskType,
		InferenceParameter: string(inferenceParameter),
		ExtendedParameter:  string(extendedParameter),
	})
	if err != nil {
		return fmt.Errorf("TranslateQuestionRecommend send failed, err: %v", err)
	}

	c.Info("TranslateQuestionRecommend send success")
	time.Sleep(50 * time.Millisecond)

	err = stream.CloseSend()
	if err != nil {
		return fmt.Errorf("TranslateQuestionRecommend CloseSend failed, err: %v", err)
	}

	wg.Wait()

	c.Infof("TranslateQuestionRecommend success")
	return nil
}
