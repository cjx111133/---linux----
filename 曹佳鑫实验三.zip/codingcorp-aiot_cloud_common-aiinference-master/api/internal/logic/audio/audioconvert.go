package audio

import (
	"encoding/base64"
	"encoding/json"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/logx"
)

type ConvertManage interface {
	// 处理流式任务响应数据
	ProcessStreamTaskRespData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq, index int32) (*types.RecvDataResp, bool, bool)
	// 将语音识别的结果转换为json字符串
	ConvertAsrData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq) (string, bool)
	// 将文本转语音的结果转换为json字符串
	ConvertTtsData(streamRecv *aimanagerrpc.StreamTaskResp) (string, bool)
	// 将翻译的结果转换为json字符串
	ConvertTranslateData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq) (string, bool)
	// 将语言检测的结果转换为json字符串
	ConvertLanguageDetectData(streamRecv *aimanagerrpc.StreamTaskResp) (string, string, bool)
	// 将 OPUS 包装的结果转换为json字符串
	ConvertOpusWrapper(streamRecv *aimanagerrpc.StreamTaskResp) string
}

type convertManager struct {
	logx.Logger
	config         config.Config
	contextManager *common.ContextManager
	connInfo       *types.ConnectionInfo
	utilLogic      *common.UtilLogic
}

func NewConvertManager(log logx.Logger, config config.Config, wsconn *types.ConnectionInfo, utilLogic *common.UtilLogic, contextManager *common.ContextManager) *convertManager {
	return &convertManager{
		Logger:         log,
		config:         config,
		contextManager: contextManager,
		connInfo:       wsconn,
		utilLogic:      utilLogic,
	}
}

type SpeechToTextData struct {
	Text string `json:"text"`
}

func (l *convertManager) ProcessStreamTaskRespData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq, index int32) (*types.RecvDataResp, bool, bool) {
	resp := types.RecvDataResp{
		Code:         types.RespCodeSuccess,
		SessionId:    l.connInfo.SessionId,
		MessageId:    req.MessageId,
		Timestamp:    time.Now().UnixMilli(),
		ReqStatus:    types.ReqStatusMiddle,
		Index:        index,
		Type:         req.Type,
		CustomFields: req.CustomFields,
	}
	var end bool
	resp.Type = int32(streamRecv.TaskType)
	switch streamRecv.TaskType {
	case aiparameter.TaskType_TASK_TYPE_Speech_To_Text:
		resp.Data, end = l.ConvertAsrData(streamRecv, req)
	case aiparameter.TaskType_TASK_TYPE_Text_To_Speech:
		resp.Data, end = l.ConvertTtsData(streamRecv)
	case aiparameter.TaskType_TASK_TYPE_Translate:
		resp.Data, end = l.ConvertTranslateData(streamRecv, req)
	case aiparameter.TaskType_TASK_TYPE_Language_Detect:
		resp.Data, resp.Lang, end = l.ConvertLanguageDetectData(streamRecv)
	case aiparameter.TaskType_TASK_TYPE_Opus_Wrapper:
		resp.Type = int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech)
		resp.Data = l.ConvertOpusWrapper(streamRecv)
	}
	if resp.Type == int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text) {
		// 返回的是一个str, 需要判断是否包含text
		var data SpeechToTextData
		err := json.Unmarshal([]byte(resp.Data), &data)
		if err != nil {
			l.Logger.Info("========> err %+v ", err)
		} else {
			if data.Text == "" {
				resp.Data = l.utilLogic.DataEncrypt(resp.Data)
				return &resp, false, false
			}
		}
	}
	if len(resp.Data) == 0 || resp.Data == "{}" {
		resp.Data = l.utilLogic.DataEncrypt(resp.Data)
		return &resp, false, false
	}

	resp.Data = l.utilLogic.DataEncrypt(resp.Data)

	return &resp, true, end
}

// convertAsrData 将语音识别的结果转换为json字符串
func (l *convertManager) ConvertAsrData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq) (string, bool) {
	asrResp := streamRecv.GetAsrResp()
	if asrResp == nil {
		l.Infof("AudioTranslate Recv: GetAsrResp data is nil")
		return "", false
	}

	// 如果是非流式识别，返回SegmentEnd为false，则跳过
	if !l.config.AudioTranslate.SpeechToTextParam.EnableWord && !asrResp.SegmentEnd {
		return "", false
	}

	data := types.SpeechToTextData{
		SegmentEnd: asrResp.SegmentEnd,
		Text:       asrResp.Text,
		Segments:   make([]*types.Segment, 0),
		SpeechEnd:  asrResp.SpeechEnd,
	}
	// 这里为了兼容speech end时会返回所有文本
	if asrResp.SpeechEnd {
		data.Text = ""
	}
	for _, segment := range asrResp.Segments {
		data.Segments = append(data.Segments, &types.Segment{
			Id:         segment.Id,
			StartMs:    segment.StartMs,
			EndMs:      segment.EndMs,
			Text:       segment.Text,
			Confidence: segment.Confidence,
			Words:      make([]*types.Word, 0),
		})

		for _, word := range segment.Words {
			data.Segments[len(data.Segments)-1].Words = append(data.Segments[len(data.Segments)-1].Words, &types.Word{
				Text:       word.Text,
				StartMs:    word.StartMs,
				EndMs:      word.EndMs,
				Confidence: word.Confidence,
			})
		}
	}

	v, _ := json.Marshal(data)
	value := string(v)
	l.Debugf("AudioTranslate Recv AsrData: %s message_id %s", value, req.MessageId)
	if data.SegmentEnd {
		l.Infof("AudioTranslate Recv AsrData: %s message_id %s", value, req.MessageId)
		l.contextManager.SetContext(req.MessageId, req.Role, req.SourceLanguage, asrResp.Text, false)
	}

	return value, data.SegmentEnd
}

// convertTtsData 将文本转语音的结果转换为json字符串
func (l *convertManager) ConvertTtsData(streamRecv *aimanagerrpc.StreamTaskResp) (string, bool) {
	ttsResp := streamRecv.GetTtsResp()
	if ttsResp == nil {
		l.Infof("AudioTranslate Recv: GetTtsResp data is nil")
		return "", false
	}
	data := types.TextToSpeechData{
		SentenceStart: ttsResp.SentenceStart,
		Audio:         base64.StdEncoding.EncodeToString(ttsResp.Audio.Data),
		Subtitle:      make([]*types.Subtitle, 0),
	}

	for _, subtitle := range ttsResp.Subtitle {
		data.Subtitle = append(data.Subtitle, &types.Subtitle{
			SentenceStart: subtitle.SentenceStart,
			Text:          subtitle.Text,
			StartMs:       subtitle.StartMs,
			EndMs:         subtitle.EndMs,
		})
	}

	l.Infof("AudioTranslate Recv TtsData: %+v", data)
	v, _ := json.Marshal(data)
	return string(v), data.SentenceStart
}

// convertTranslateData 将翻译的结果转换为json字符串
func (l *convertManager) ConvertTranslateData(streamRecv *aimanagerrpc.StreamTaskResp, req *types.AudioTranslateReq) (string, bool) {
	translateResp := streamRecv.GetTranslateResp()
	if translateResp == nil {
		l.Infof("AudioTranslate Recv: GetTranslateResp data is nil")
		return "", false
	}

	data := types.TranslateData{
		SentenceStart: translateResp.SentenceStart,
		SentenceEnd:   translateResp.SentenceEnd,
		Text:          translateResp.Text,
	}

	v, _ := json.Marshal(data)
	value := string(v)
	if data.SentenceEnd {
		l.Infof("AudioTranslate Recv TranslateData: %s", value)
		textUpdate := false
		if req.Type == types.ReqTypeText {
			textUpdate = true
		}
		l.contextManager.SetContext(req.MessageId, req.Role, req.TargetLanguage, translateResp.Text, textUpdate)
	}

	return value, data.SentenceEnd
}

// convertTtsData 将语言检测的结果转换为json字符串
func (l *convertManager) ConvertLanguageDetectData(streamRecv *aimanagerrpc.StreamTaskResp) (string, string, bool) {
	resp := streamRecv.GetLangDetectResp()
	if resp == nil {
		l.Errorf("AudioTranslate Recv: convertLanguageDetectData data is nil")
		return "", "", false
	}

	data := types.LanguageDetectData{
		Language:   resp.Language,
		Confidence: resp.Confidence,
	}

	l.Infof("ConvertLanguageDetectData, Recv lang detect: %+v", resp)
	v, err := json.Marshal(data)
	if err != nil {
		l.Errorf("AudioTranslate Recv: convertLanguageDetectData json.Marshal failed, err: %v", err)
		return "", "", false
	}
	return string(v), resp.Language, true
}

func (l *convertManager) ConvertOpusWrapper(streamRecv *aimanagerrpc.StreamTaskResp) string {
	resp := streamRecv.GetOpusWrapperResp()
	if resp == nil {
		l.Infof("AudioTranslate Recv: convertOpusWrapper data is nil")
		return ""
	}
	data := types.TextToSpeechData{
		Audio: base64.StdEncoding.EncodeToString(resp.Audio.Data),
	}

	//l.Infof("AudioTranslate Recv Opus Wrapper: %+v", data)
	v, _ := json.Marshal(data)
	return string(v)
}
