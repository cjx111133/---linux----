package imageupscale

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type ImageUpscaleExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewImageUpscaleExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *ImageUpscaleExecutor {
	return &ImageUpscaleExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *ImageUpscaleExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *ImageUpscaleExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *ImageUpscaleExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.ImageUpscaleReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.ImageUpscaleInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.ImageUpscaleExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.Outscale <= 1 || ePara.Outscale > 100 {
		return nil, fmt.Errorf("outscale is invalid, outscale: %f", ePara.Outscale)
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	thumbUpTokens := ""
	if len(in.ThumbUpTokens) > 0 {
		thumbUpTokens = in.ThumbUpTokens[0]
	}
	req := &adaptermodel.ImageUpscaleReq{
		TaskId:                in.Header.TaskId,
		ImageUrl:              iPara.Images[0].FileData,
		Outscale:              ePara.Outscale,
		Tile:                  ePara.Tile,
		TilePad:               ePara.TilePad,
		PrePad:                ePara.PrePad,
		AlphaUpsampler:        ePara.AlphaUpsampler,
		ResultImageUpToken:    in.ResultUpTokens[0],
		ThumbnailImageUpToken: thumbUpTokens,
	}
	return req, nil
}

func (e *ImageUpscaleExecutor) doInference(req *adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.ImageUpscaleHandler(req)
	if err != nil {
		return nil, fmt.Errorf("ImageUpscaleHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("ImageUpscaleHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("ImageUpscaleHandler failed, code: %d, message: %s", result.Code, result.Message)
	}

	return result, nil
}

func (e *ImageUpscaleExecutor) buildResponse(resp *adaptermodel.ImageUpscaleResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Image_Upscale,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_ImageUpscale{
			ImageUpscale: &aiparameter.ImageUpscaleInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
		FileData: resp.ResultImage,
		FileMd5:  resp.ImageMd5,
		FileSize: resp.ImageSize,
	})
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
