package anker

import (
	"context"
	"fmt"
	"io"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/vadserverrpc"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
	"google.golang.org/grpc/metadata"
)

type AsrClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	startTime time.Time
	index     int32
	segments  []*aicommon.Segment
	words     []*aicommon.Word
	result    string

	request  <-chan *adaptermodel.SpeechToTextReq
	response chan<- *adaptermodel.SpeechToTextResp
	first    *adaptermodel.SpeechToTextReq
}

func NewAsrClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.SpeechToTextReq,
	response chan<- *adaptermodel.SpeechToTextResp,
	first *adaptermodel.SpeechToTextReq) *AsrClient {
	return &AsrClient{
		ctx:       ctx,
		svcCtx:    svcCtx,
		Logger:    logx.WithContext(ctx),
		startTime: time.Now(),
		index:     1,
		segments:  make([]*aicommon.Segment, 0),
		words:     make([]*aicommon.Word, 0),
		request:   request,
		response:  response,
		first:     first,
	}
}

func (c *AsrClient) SpeechTranscription() error {
	md := metadata.New(map[string]string{
		"authorization": "Bearer " + config.GetDefaultConfig().SpeechToTextRpc.Token,
	})
	stream, err := c.svcCtx.SpeechToTextRpc.SpeechRecognition(
		metadata.NewOutgoingContext(c.ctx, md),
	)
	if err != nil {
		return fmt.Errorf("connect to asr engine failed, err: %v", err)
	}

	// send first message
	err = stream.Send(&vadserverrpc.InferenceReq{
		TaskId:             c.first.TaskId,
		PackIdx:            1,
		EnableTempResult:   c.first.EnableWord,
		AddPunc:            c.first.AddPunctuation,
		OriLang:            c.first.Audio.Language,
		TargetLang:         c.first.TargetLang,
		MaxSentenceSilence: c.first.MaxSentenceSilence,
		MaxStartSilence:    c.first.MaxStartSilence,
		MaxEndSilence:      c.first.MaxEndSilence,
		Audio: &vadserverrpc.AudioInfo{
			Data:       c.first.Audio.Data,
			SampleRate: c.first.Audio.SampleRate,
			BitRate:    c.first.Audio.BitRate,
			Channels:   c.first.Audio.Channels,
			Format:     c.first.Audio.Format,
		},
	})
	if err != nil {
		return fmt.Errorf("send first message to asr engine failed, err: %v", err)
	}

	ctx, cancel := context.WithTimeout(c.ctx, 7200*time.Second) // 2小时
	defer cancel()

	var wg sync.WaitGroup
	wg.Add(2)
	defer wg.Wait()

	errCh := make(chan error, 2)
	// recv message from stream
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- c.recv(ctx, stream)
	})
	// send message to stream
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- c.send(ctx, stream)
	})

	for i := 0; i < 2; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	c.Infof("speech transcription end")
	return nil
}

func (c *AsrClient) recv(ctx context.Context, stream vadserverrpc.VadServerRpc_SpeechRecognitionClient) error {
	// 在close之前发送一条end消息
	defer func() {
		c.response <- &adaptermodel.SpeechToTextResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "ok",
			},
			Language:    c.first.Audio.Language,
			SpeechEnd:   true,
			Text:        c.result,
			TimeTakenMs: int32(time.Since(c.startTime).Milliseconds()),
		}
		c.Infof("recv from asr end, SpeechEnd: %v, result: %v", true, c.result)
		close(c.response)
	}()

	for {
		resp, err := stream.Recv()
		if err != nil {
			if err == io.EOF || err == context.Canceled {
				c.Infof("recv resp from asr engine stream end, %v", err)
				return nil
			}
			return fmt.Errorf("recv resp from asr engine stream failed, err: %v", err)
		}

		select {
		case <-ctx.Done():
			c.Infof("recv resp from asr engine stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("recv resp from asr engine stream end, logic context done")
			return nil
		default:
			if resp == nil {
				return fmt.Errorf("recv resp from asr engine stream failed, resp is nil")
			}
			if resp.Code != 0 {
				c.Errorf("recv resp from asr engine stream, code: %d, message: %s", resp.Code, resp.Message)
				return fmt.Errorf("recv resp from asr engine stream failed, code: %d, message: %s", resp.Code, resp.Message)
			}

			c.Debugf("recv resp from asr engine stream, text: %s, segmentEnd: %v, code: %d, message: %s", resp.Text, resp.SegmentEnd, resp.Code, resp.Message)

			var segments []*aicommon.Segment
			if len(resp.Segments) > 0 {
				segments = make([]*aicommon.Segment, 0, len(resp.Segments))
			}
			for _, seg := range resp.Segments {
				segment := &aicommon.Segment{
					Id:         seg.Id,
					StartMs:    seg.StartMs,
					EndMs:      seg.EndMs,
					Text:       seg.Text,
					Confidence: seg.Confidence,
				}
				if len(seg.Words) > 0 {
					segment.Words = make([]*aicommon.Word, 0, len(seg.Words))
				}
				for _, word := range seg.Words {
					if word == nil {
						continue
					}
					segment.Words = append(segment.Words, &aicommon.Word{
						Text:       word.Text,
						StartMs:    word.StartMs,
						EndMs:      word.EndMs,
						Confidence: word.Confidence,
					})
				}
				segments = append(segments, segment)
			}

			c.response <- &adaptermodel.SpeechToTextResp{
				Header: &aicommon.RspHeader{
					Code:    resp.Code,
					Message: resp.Message,
				},
				SegmentId:     c.index,
				SegmentEnd:    resp.SegmentEnd,
				Text:          resp.Text,
				Language:      c.first.Audio.Language,
				Segments:      segments,
				UseTempResult: c.first.UseTempResult,
				TimeTakenMs:   resp.TimeTakenMs,
			}

			if resp.SegmentEnd {
				c.Infof("recv resp from asr engine stream, segment end, index: %d", c.index)
				c.index++
				c.result += resp.Text
			}
		}
	}
}

func (c *AsrClient) send(ctx context.Context, stream vadserverrpc.VadServerRpc_SpeechRecognitionClient) error {
	defer stream.CloseSend()
	packIdx := int32(1)

	for {
		select {
		case <-ctx.Done():
			c.Infof("send req to asr engine stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("send req to asr engine stream end, logic context done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				r := &vadserverrpc.InferenceReq{
					TaskId:  c.first.TaskId,
					PackIdx: -9999,
				}
				stream.Send(r)
				c.Infof("send req to asr engine stream end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send message failed, request is nil")
			}
			if req.Audio == nil {
				return fmt.Errorf("send message failed, audio is nil")
			}
			if len(req.Audio.Data) == 0 {
				c.Errorf("send message failed, audio data is empty")
				continue
			}

			packIdx++
			r := &vadserverrpc.InferenceReq{
				TaskId:             c.first.TaskId,
				PackIdx:            packIdx,
				EnableTempResult:   c.first.EnableWord,
				AddPunc:            c.first.AddPunctuation,
				OriLang:            c.first.Audio.Language,
				TargetLang:         c.first.TargetLang,
				MaxSentenceSilence: c.first.MaxSentenceSilence,
				MaxStartSilence:    c.first.MaxStartSilence,
				MaxEndSilence:      c.first.MaxEndSilence,
				Audio: &vadserverrpc.AudioInfo{
					Data:       req.Audio.Data,
					SampleRate: c.first.Audio.SampleRate,
					BitRate:    c.first.Audio.BitRate,
					Channels:   c.first.Audio.Channels,
					Format:     c.first.Audio.Format,
				},
			}
			if len(req.HotWordsList) > 0 {
				r.HotWordsList = make([]*vadserverrpc.HotWordsInfo, 0, len(req.HotWordsList))
				for _, hotWord := range req.HotWordsList {
					r.HotWordsList = append(r.HotWordsList, &vadserverrpc.HotWordsInfo{
						Mode:   hotWord.Mode,
						Words:  hotWord.Words,
						Weight: hotWord.Weight,
					})
				}
			}
			err := stream.Send(r)
			if err != nil {
				return fmt.Errorf("send message failed, err: %v", err)
			}
		}
	}
}

func (c *AsrClient) Close() {
}
