package imagetovector

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/imagetovectorrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type ImageToVectorExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewImageToVectorExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *ImageToVectorExecutor {
	return &ImageToVectorExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *ImageToVectorExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *ImageToVectorExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *ImageToVectorExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*imagetovectorrpc.ImageToVectorReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.ImageToVectorInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v, InferenceParameter: %s", err, in.InferenceParameter)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
	}
	if len(iPara.Images) != len(in.ResultUpTokens) {
		return nil, fmt.Errorf("InferenceParameter Images count is incorrect, expect: %d, actual: %d", len(in.ResultUpTokens), len(iPara.Images))
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.ImageToVectorExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v, ExtendedParameter: %s", err, in.ExtendedParameter)
	}
	if ePara.ColorNum < 1 {
		return nil, fmt.Errorf("ExtendedParameter ColorNum is incorrect, ColorNum: %d", ePara.ColorNum)
	}

	req := &imagetovectorrpc.ImageToVectorReq{
		Header:              in.Header,
		Images:              iPara.Images,
		ColorNum:            ePara.ColorNum,
		ResultImageUpTokens: in.ResultUpTokens,
	}
	return req, nil

}

func (e *ImageToVectorExecutor) doInference(req *imagetovectorrpc.ImageToVectorReq) (*imagetovectorrpc.ImageToVectorResp, error) {
	resp, err := e.svcCtx.ImageToVectorRpc.ImageToVector(e.ctx, req)
	if err != nil {
		return nil, fmt.Errorf("ImageToVector failed, err: %v", err)
	}
	if resp.Header == nil {
		return nil, fmt.Errorf("ImageToVector Header is nil")
	}
	if resp.Header.Code != codes.CodeOk {
		return nil, fmt.Errorf("ImageToVector failed, code: %v, message: %v", resp.Header.Code, resp.Header.Message)
	}
	if len(resp.ResultImages) != len(req.Images) {
		return nil, fmt.Errorf("ImageToVector result image count is incorrect, expect: %d, actual: %d", len(req.Images), len(resp.ResultImages))
	}

	return resp, nil
}

func (e *ImageToVectorExecutor) buildResponse(resp *imagetovectorrpc.ImageToVectorResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Image_To_Vector,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_ImageToVector{
			ImageToVector: &aiparameter.ImageToVectorInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = resp.Header
	out.ResultImages = resp.ResultImages
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
