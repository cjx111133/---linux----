package ping

import (
	"context"
	"encoding/json"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"github.com/zeromicro/go-zero/core/logx"
)

type PingLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
	data   *types.WebSocketData
	mu     sync.Mutex

	utilLogic *common.UtilLogic
}

func NewPing(ctx context.Context, svcCtx *svc.ServiceContext, data *types.WebSocketData) (*PingLogic, error) {
	return &PingLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
		data:   data,

		utilLogic: common.NewUtilLogic(ctx, svcCtx, data),
	}, nil
}

// Handle 处理ping消息
func (l *PingLogic) Handle(msg *types.WebSocketReq) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	req := &types.AudioTranslateReq{}
	code, tip, sendErr := int32(types.RespCodeSuccess), "", false
	defer func() {
		if sendErr {
			l.utilLogic.SendErrDataToRecv(req.CommonReq, code, tip)
		}
	}()
	req.CustomFields = msg.CustomFields
	req.MessageId = msg.MsgId

	// 1. 将msg进行反序列化，获取到语音识别的结果
	err := json.Unmarshal(msg.Data, req)
	if err != nil {
		l.Errorf("Ping Unmarshal failed, err: %v", err)
		code, tip, sendErr = types.RespCodeDataErr, "Failed to unmarshal data", true
		return err
	}

	// 2. 解密数据
	req.Data, err = l.utilLogic.DataDecrypt(req.Data)
	if err != nil {
		l.Errorf("AudioTranslate dataDecrypt failed, err: %v", err)
		code, tip, sendErr = types.RespCodeCodecErr, "Failed to decrypt data", true
		return err
	}

	req.Data = l.utilLogic.DataEncrypt(req.Data)
	resp := types.RecvDataResp{
		Code:      types.RespCodeSuccess,
		Message:   "",
		SessionId: l.data.ConnectionInfo.SessionId,
		MessageId: req.MessageId,
		Timestamp: time.Now().UnixMilli(),
		ReqStatus: req.ReqStatus,
		Index:     req.Index,
		Data:      req.Data,
	}
	l.utilLogic.SendSuccessDataToRecv(resp)
	return nil
}
