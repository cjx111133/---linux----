package config

import (
	"encoding/json"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

type DifyChatflowParam struct {
	ServiceProvider string                    `json:"service_provider"` // 选填，服务提供商，默认anker；目前支持：aliyun、anker
	NeedReply       bool                      `json:"need_reply"`       // 是否需要对话
	NeedQuestion    bool                      `json:"need_question"`    // 是否需要相似问题
	NeedEmotion     bool                      `json:"need_emotion"`     // 是否需要情绪识别
	HouseID         string                    `json:"house_id"`         // 选填，房屋ID
	Language        string                    `json:"language"`         // 选填，语言
	Timezone        string                    `json:"timezone"`         // 选填，时区
	Contexts        []*types.TranslateContext `json:"contexts"`         // 选填，翻译上下文
	ChatflowName    string                    `json:"chat_flow_name"`   // 选填，对话流程名称
	Params          map[string]string         `json:"params"`           // 选填，其他参数
}

// NewDefaultDifyChatFlowParams 创建默认的DifyChatFlowParam,默认是anker模型，需要回复，需要问题，不需要情绪识别
func NewDefaultDifyChatFlowParams(contexts []*types.TranslateContext) *DifyChatflowParam {
	return &DifyChatflowParam{
		ServiceProvider: types.ModelAnker,
		NeedReply:       true,
		NeedQuestion:    true,
		NeedEmotion:     false,
		Contexts:        contexts,
		ChatflowName:    "", // default value for ChatflowName
		Params:          make(map[string]string),
	}
}

func (p *DifyChatflowParam) Set(houseId, language, timezone string) {
	p.HouseID = houseId
	p.Language = language
	p.Timezone = timezone
}

func (p *DifyChatflowParam) String() string {
	marshal, err := json.Marshal(p)
	if err != nil {
		return ""
	}
	return string(marshal)
}
