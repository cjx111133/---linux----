package common

import (
	"path"
	"strings"
)

const DefaultContentType = "application/octet-stream"

// mimeTypes Map file extensions to corresponding MIME types
var mimeTypes = map[string]string{
	// text
	".txt":  "text/plain",
	".html": "text/html",
	".htm":  "text/html",
	".css":  "text/css",
	".csv":  "text/csv",
	".js":   "application/javascript",
	".json": "application/json",
	".xml":  "application/xml",

	// image
	".jpg":  "image/jpeg",
	".jpeg": "image/jpeg",
	".png":  "image/png",
	".gif":  "image/gif",
	".bmp":  "image/bmp",
	".svg":  "image/svg+xml",
	".webp": "image/webp",
	".ico":  "image/x-icon",

	// audio
	".mp3":  "audio/mpeg",
	".wav":  "audio/wav",
	".ogg":  "audio/ogg",
	".flac": "audio/flac",

	// video
	".mp4":  "video/mp4",
	".avi":  "video/x-msvideo",
	".mov":  "video/quicktime",
	".mkv":  "video/x-matroska",
	".webm": "video/webm",

	// documentation
	".pdf":  "application/pdf",
	".doc":  "application/msword",
	".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	".ppt":  "application/vnd.ms-powerpoint",
	".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
	".xls":  "application/vnd.ms-excel",
	".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

	// compressed
	".zip": "application/zip",
	".rar": "application/x-rar-compressed",
	".gz":  "application/gzip",
	".tar": "application/x-tar",
	".7z":  "application/x-7z-compressed",

	// bin
	".exe": "application/vnd.microsoft.portable-executable",
	".bin": "application/octet-stream",
	".dll": "application/x-msdownload",
	".iso": "application/x-iso9660-image",

	// other
	".rtf":   "application/rtf",
	".eot":   "application/vnd.ms-fontobject",
	".ttf":   "font/ttf",
	".woff":  "font/woff",
	".woff2": "font/woff2",
	".otf":   "font/otf",
	".md":    "text/markdown",
	".toml":  "application/toml",
}

func TypeByExtension(ext string) string {
	ext = strings.ToLower(path.Ext(ext))
	if contentType, ok := mimeTypes[ext]; ok {
		return contentType
	}
	return DefaultContentType
}
