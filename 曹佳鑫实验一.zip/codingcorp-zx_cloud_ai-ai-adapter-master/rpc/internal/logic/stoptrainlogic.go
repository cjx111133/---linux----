package logic

import (
	"context"
	"fmt"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type StopTrainLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewStopTrainLogic(ctx context.Context, svcCtx *svc.ServiceContext) *StopTrainLogic {
	return &StopTrainLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 停止训练
func (l *StopTrainLogic) StopTrain(in *aiadapterrpc.StopTrainReq) (*aiadapterrpc.StopTrainResp, error) {
	timeStart := time.Now()
	resp := &aiadapterrpc.StopTrainResp{
		Header: &aicommon.RspHeader{
			Code:    codes.CodeOk,
			Message: "success",
		},
	}

	// check input
	if err := l.checkParam(in); err != nil {
		resp.Header.Code = codes.CodeInputParamInvalid
		resp.Header.Message = fmt.Sprintf("StopTrain check param failed, err: %v", err)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	defer func() {
		l.Infof("StopTrain end, task id: %s, total time: %v ms", in.Header.TaskId, resp.TimeTakenMs)
	}()
	l.Infof("StopTrain start, task id: %s", in.Header.TaskId)

	// create adapter
	adapter, err := adapter.NewAdapter(l.ctx, l.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("NewAdapter failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	req := &adaptermodel.StopTrainReq{
		TaskId: in.Header.TaskId,
		UserId: in.Header.UserId,
	}
	err = adapter.StopTrainHandler(req)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("StopTrainHandler failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	resp.TimeTakenMs = int32(time.Since(timeStart).Milliseconds())
	return resp, nil
}

func (l *StopTrainLogic) checkParam(in *aiadapterrpc.StopTrainReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.TaskId == "" {
		return fmt.Errorf("task id is empty")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}

	return nil
}
