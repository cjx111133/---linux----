package chat

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"sync"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/helper"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
	"golang.org/x/net/context"
)

type ChatLogic struct {
	logx.Logger
	ctx       context.Context
	svcCtx    *svc.ServiceContext
	wsData    *types.WebSocketData
	utilLogic *common.UtilLogic

	mu          sync.Mutex
	msgLogicMap map[string]*ChatMessage
}

func NewChat(ctx context.Context, svcCtx *svc.ServiceContext, data *types.WebSocketData) (*ChatLogic, error) {
	l := &ChatLogic{
		Logger:    logx.WithContext(ctx),
		ctx:       ctx,
		svcCtx:    svcCtx,
		wsData:    data,
		utilLogic: common.NewUtilLogic(ctx, svcCtx, data),
	}
	l.msgLogicMap = make(map[string]*ChatMessage)
	l.listenForClose()
	return l, nil
}

func (l *ChatLogic) Handle(msg *types.WebSocketReq) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	req, code, tip, err := l.parse(msg.Data)
	if err != nil {
		if req != nil && req.ReqStatus == types.ReqStatusEnd {
			return nil
		}
		l.utilLogic.SendErrDataToRecv(&types.CommonReq{}, code, tip)
		return err
	}
	req.CustomFields = msg.CustomFields
	req.MessageId = msg.MsgId

	// 获取或创建ChatMessage实例
	msgLogic, exists := l.msgLogicMap[req.MessageId]
	if !exists {
		// 如果不是首包但没有对应的ChatMessage实例，返回错误
		if req.ReqStatus != types.ReqStatusAlone && req.ReqStatus != types.ReqStatusFirst {
			return errors.New("first data is empty")
		}
		// 创建新的ChatMessage实例
		msgLogic = NewChatMessage(l, req)
		l.msgLogicMap[req.MessageId] = msgLogic
	}
	// 处理消息
	return msgLogic.Send(req)
}

func (l *ChatLogic) checkParam(req *types.ChatReq) error {
	if req == nil {
		return errors.New("req data is empty")
	}
	if req.MessageId == "" {
		return errors.New("MessageId is empty")
	}
	if !helper.InInt32Array(req.ReqStatus, []int32{types.ReqStatusAlone, types.ReqStatusFirst, types.ReqStatusMiddle, types.ReqStatusEnd, types.ReqStatusStop}) {
		return errors.New("ReqStatus is invalid")
	}
	switch req.ReqStatus {
	case types.ReqStatusAlone:
		if req.Type != types.ReqTypeText && req.Type != types.MessageTypeTTS {
			return errors.New("type is invalid")
		}
	case types.ReqStatusFirst:
		if req.Type == types.ReqTypeAudio || req.Type == types.ReqTypeSimultaneous {
			if req.Timbre == "" {
				req.Timbre = "brian"
			}
			if req.Format == "" {
				return errors.New("format is empty")
			}
			if req.SampleRate == 0 {
				return errors.New("SampleRate is 0")
			}
			if req.Bits == 0 {
				return errors.New("bits is 0")
			}
			if req.Channels == 0 {
				return errors.New("channels is 0")
			}
		}
	case types.ReqStatusMiddle:
		if req.Data == "" {
			return errors.New("data is empty")
		}
		if req.Type == types.ReqTypeAudio || req.Type == types.ReqTypeSimultaneous {
			binaryData, err := base64.StdEncoding.DecodeString(req.Data)
			if err != nil {
				return errors.New("data is invalid")
			}
			if len(binaryData) == 0 {
				return errors.New("data is empty")
			}
			req.Data = string(binaryData)
		}
	case types.ReqStatusEnd:

	case types.ReqStatusStop:

	}
	return nil
}

// close 关闭发送
func (l *ChatLogic) listenForClose() {
	threading.GoSafe(func() {
		for {
			select {
			case <-l.wsData.StopWsChan: // 监听通道是否关闭
				l.Infof("Chat Stop")
				// 清理所有活跃的ChatMessage实例
				l.utilLogic.IncryModel(-1)
				return
			}
		}
	})
}

// parse 解析请求数据
func (l *ChatLogic) parse(msg []byte) (*types.ChatReq, int32, string, error) {
	req := &types.ChatReq{}
	code, tip := int32(types.RespCodeSuccess), ""

	// 1. 将msg进行反序列化，获取到语音识别的结果
	err := json.Unmarshal(msg, req)
	if err != nil {
		l.Errorf("Chat Unmarshal failed, err: %v", err)
		return nil, types.RespCodeDataErr, "Failed to unmarshal data", err
	}
	// 2. 解密数据
	req.Data, err = l.utilLogic.DataDecrypt(req.Data)
	if err != nil {
		l.Errorf("Chat dataDecrypt failed, err: %v", err)
		return nil, types.RespCodeCodecErr, "Failed to decrypt data", err
	}

	// 3. 参数校验
	err = l.checkParam(req)
	if err != nil {
		l.Errorf("Chat checkParam failed, err: %v", err)
		return req, types.RespCodeDataErr, err.Error(), err
	}

	// 4. 处理数据
	messageType, ok := req.Params["message_type"].(float64)
	if ok {
		req.MessageType = int(messageType)
	}
	return req, code, tip, nil
}
