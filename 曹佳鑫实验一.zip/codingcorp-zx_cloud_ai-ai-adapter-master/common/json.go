package common

import (
	"github.com/bytedance/sonic"
)

// start_ai_generated

func JsonToStrings(str string) (arr []string, err error) {
	err = sonic.Unmarshal([]byte(str), &arr)
	if err != nil {
		return nil, err
	}
	return
}

func JsonToInts(str string) (arr []int64, err error) {
	err = sonic.Unmarshal([]byte(str), &arr)
	if err != nil {
		return nil, err
	}
	return
}

func JsonToFloats(str string) (arr [][]float64, err error) {
	err = sonic.Unmarshal([]byte(str), &arr)
	if err != nil {
		return nil, err
	}
	return
}

func AnyToJson(val interface{}) ([]byte, error) {
	return sonic.Marshal(val)
}

func JsonToAny(buf []byte, val interface{}) error {
	return sonic.Unmarshal(buf, val)
}

// end_ai_generated
