package model

var _ TTrainModelFileModel = (*defaultTTrainModelFileModel)(nil)
