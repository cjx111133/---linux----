package translatequestionrecommend

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type TranslateQuestionRecommendExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewTranslateQuestionRecommendExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *TranslateQuestionRecommendExecutor {
	return &TranslateQuestionRecommendExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *TranslateQuestionRecommendExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}
	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	e.Info("TranslateQuestionRecommendExecutor Inference end")
	return out, nil
}

func (e *TranslateQuestionRecommendExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}
	e.Info("TranslateQuestionRecommendExecutor StreamInference end")
	return nil
}

func (e *TranslateQuestionRecommendExecutor) doInference(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	e.Infof("TranslateQuestionRecommendExecutor doInference, TaskId: %s, ServiceProvider: %s, TargetLanguage: %s, QuestionsNum: %d, Contexts: %+v", req.TaskId, req.ServiceProvider, req.TargetLanguage, req.QuestionsNumber, req.Contexts)

	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	resp, err := adapter.TranslateQuestionRecommendHandler(req)
	if err != nil {
		return nil, fmt.Errorf("TranslateQuestionRecommendHandler failed, err: %v", err)
	}
	if resp.Header.Code != codes.CodeOk {
		return nil, fmt.Errorf("TranslateQuestionRecommendHandler failed, code: %d, message: %s", resp.Header.Code, resp.Header.Message)
	}
	if len(resp.Questions) == 0 {
		return nil, fmt.Errorf("TranslateQuestionRecommendHandler failed, Questions is empty")
	}
	return resp, nil
}

func (e *TranslateQuestionRecommendExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("translate question recommend doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		e.Infof("translate question recommend doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("TranslateQuestionRecommendExecutor doStreamInference recv first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	tqrReq := make(chan *adaptermodel.TranslateQuestionRecommendReq, 100)
	tqrResp := make(chan *adaptermodel.TranslateQuestionRecommendResp, 100)
	tqrReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, tqrResp, cliResp)
	})
	// send message to llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, tqrReq, cliReq)
	})
	// handle message from llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.TranslateQuestionRecommendStreamHandler(tqrReq, tqrResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *TranslateQuestionRecommendExecutor) recv(ctx context.Context, tqrResp <-chan *adaptermodel.TranslateQuestionRecommendResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-tqrResp:
			if !ok {
				e.Infof("recv resp from dify end, tqrResp channel closed")
				return nil
			}

			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			e.Infof("recv resp from dify end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from dify end, logic context done")
			return nil
		}
	}
}

func (e *TranslateQuestionRecommendExecutor) send(ctx context.Context,
	tqrReq chan *adaptermodel.TranslateQuestionRecommendReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(tqrReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to dify end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to dify end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to dify end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to dify end, request is nil")
			}
			r, err := e.buildParameter(req)
			if err != nil {
				e.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			e.Infof("TranslateQuestionRecommend recv req, TaskId: %s, ServiceProvider: %s, TargetLanguage: %s, QuestionsNum: %d, Contexts: %+v", r.TaskId, r.ServiceProvider, r.TargetLanguage, r.QuestionsNumber, r.Contexts)

			tqrReq <- r
		}
	}

}

func (e *TranslateQuestionRecommendExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.TranslateQuestionRecommendReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.TranslateQuestionRecommendInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.TranslateQuestionRecommendExtendedParameter
	var contexts []*adaptermodel.TranslateContext

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	err = e.checkParameter(&iPara, &ePara)
	if err != nil {
		return nil, fmt.Errorf("checkParameter failed, err: %v", err)
	}
	if len(ePara.Contexts) > 0 {
		if len(ePara.Contexts) > 10 {
			// 只取最新的 10 个上下文
			ePara.Contexts = ePara.Contexts[len(ePara.Contexts)-10:]
		}
		contexts = make([]*adaptermodel.TranslateContext, 0, len(ePara.Contexts))
		for _, v := range ePara.Contexts {
			contexts = append(contexts, &adaptermodel.TranslateContext{
				Text: v.Text,
				Role: v.Role,
				Lang: v.Language,
			})
		}
	}

	req := &adaptermodel.TranslateQuestionRecommendReq{
		TaskId:          in.Header.TaskId,
		ServiceProvider: ePara.ServiceProvider,
		TargetLanguage:  ePara.TargetLanguage,
		QuestionsNumber: ePara.QuestionsNum,
		Contexts:        contexts,
	}
	return req, nil
}

func (e *TranslateQuestionRecommendExecutor) checkParameter(
	iPara *aiparameter.TranslateQuestionRecommendInferenceParameter,
	ePara *aiparameter.TranslateQuestionRecommendExtendedParameter) error {
	// check ePara
	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ANKER:
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
	}
	if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, ePara.TargetLanguage) {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, ePara.TargetLanguage) {
			return fmt.Errorf("ExtendedParameter TargetLanguage is invalid, TargetLanguage: %s", ePara.TargetLanguage)
		} else {
			ePara.TargetLanguage = common.LanguageToBcp47(ePara.TargetLanguage)
		}
	}
	if ePara.QuestionsNum < 1 || ePara.QuestionsNum > 10 {
		e.Errorf("ExtendedParameter QuestionsNum is invalid, QuestionsNum: %d", ePara.QuestionsNum)
		ePara.QuestionsNum = 3
	}

	return nil
}

func (e *TranslateQuestionRecommendExecutor) buildResponse(resp *adaptermodel.TranslateQuestionRecommendResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Translate_Question_Recommend,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_TranslateQuestionRecommend{
			TranslateQuestionRecommend: &aiparameter.TranslateQuestionRecommendInferenceResultInfo{
				Questions: resp.Questions,
				Language:  resp.Language,
				Timestamp: time.Now().UnixMilli(),
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
