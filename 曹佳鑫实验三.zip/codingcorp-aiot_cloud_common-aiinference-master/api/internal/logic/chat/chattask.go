package chat

import (
	"sync/atomic"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"go.uber.org/zap"
)

// ChatTaskInterface defines the common interface for all chat tasks
type ChatTaskInterface interface {
	// Process processes the main chat task
	Process(req *types.ChatReq) error
	// ProcessTimer handles sending messages
	ProcessTimer(req *types.ChatReq) error
	// ProcessReceive handles receiving messages
	ProcessReceive(req *types.ChatReq)
	// StreamClose closes the task stream
	StreamClose()
	// IsStreamClosed checks if the stream is closed
	IsStreamClosed() bool
	// GetStream returns the current stream
	GetStream() aimanagerrpc.AiManagerRpc_CreateStreamTaskClient
}

// BaseChatTask provides common fields and methods for chat tasks
type BaseChatTask struct {
	*ChatMessage
	stream      aimanagerrpc.AiManagerRpc_CreateStreamTaskClient
	isCloseSend atomic.Bool

	timerSend *time.Ticker
	isTimeUp  atomic.Bool
}

// NewBaseChatTask creates a new base chat task
func NewBaseChatTask(message *ChatMessage) *BaseChatTask {
	task := &BaseChatTask{
		ChatMessage: message,
	}
	return task
}

// IsStreamClosed implements ChatTaskInterface
func (b *BaseChatTask) IsStreamClosed() bool {
	return b.isCloseSend.Load()
}

// GetStream implements ChatTaskInterface
func (b *BaseChatTask) GetStream() aimanagerrpc.AiManagerRpc_CreateStreamTaskClient {
	return b.stream
}

// StreamClose implements ChatTaskInterface
func (b *BaseChatTask) StreamClose() {
	b.isCloseSend.Store(true)
	if b.stream != nil {
		err := b.stream.CloseSend()
		if err != nil {
			b.Logger.Error("Stream CloseSend failed", zap.Error(err))
		}
	}
}
