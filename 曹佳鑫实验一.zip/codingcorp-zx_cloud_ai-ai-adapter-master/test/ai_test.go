package main

import (
	"context"
	pb "e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"encoding/json"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"regexp"
	"testing"
)

var address = "127.0.0.1:28083"

var conn *grpc.ClientConn

func init() {
	var err error
	diaOpt := grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(100*1024*1024), grpc.MaxCallSendMsgSize(100*1024*1024))
	conn, err = grpc.Dial(address, grpc.WithTransportCredentials(insecure.NewCredentials()), diaOpt)
	if err != nil {
		panic(fmt.Errorf("failed to dial: %v", err))
	}
}

func TestPetPortComFyUi(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer
	img := &aicommon.FileInfo{
		FileData: "https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/input/faceswap_test/cat.jpg?response-content-disposition=inline&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEOP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJGMEQCIBH3pHi1gWD59NmI2v6SZ66jHNsG1RlEzTgvhPUoLJSIAiAbLyiQkNH2ltzMH1GAbd1nlTS7pUntoTDhcGVYnfFiRCqsBAgsEAEaDDg3NDUwNjY0NzIzNyIMhotbkqdfwRBD8nQ2KokEK7LM4lJFU3%2F%2F%2Fqb5EZIw3y%2Fy%2BJ8t12BaLAvzlajdho%2B%2F8aNdtF6uHyC59c93zDEcPrp18jflqON73iHxxk%2BqBEOoYL%2FFejPcyGYbjFGpiX7c04mG51G7wsiXuVP3Oh9v7frghA9eEVKOZi0pOzovy6%2F6pLx2b1sDHmRAHP0R%2BMAihC9Qt0LFP0sG1fzAaLSazchT3dCzVgr4KrlwldOroBGYk3Ee1Lwm%2FILkPmYDqpMw5AY49oWjHPcky8QU%2F09j9xOo89nci1JwgC59xoz0G0mptx2qsqivAipj1rjbhJop1hqE8OeVOXfl0veSwTKF6swQiDYyf7mw%2BVMBajvFrsBIDs9QBFaOcygw%2BzKEjyg99M0AvqGLBm2gkG5zkhGVztkiBiiawiVNTENO65502FL82EBx83E4S5VY2Twr2XcYVRQlAPBLs21ExXNsGaMhaCBu3jUkrCyiwKaXmrC0imaiXf7IhRhxpP3NHPwV7lqhSqCQ%2Fs3U8CS%2FFUKmND5B2VU5fPNqBwfNICVD6lDxXmfpvPc%2Frmv54QaNBRwfK1XB8AE50n5pg93C0w0G4ho2FdelXw6C24vfK9%2FnCT44ENPb2K74nOmeDh6t16Fhk5YRYe9mQ63symxqUxgX9TFDJtm6l4GRWddYu5Lpld773crPSb3snpzR70AMe7Do8emhaM146Wule8Iw3PWlvgY6xgJ01oYt0s3r9PrVdms3Z5F670hnbS%2BZNAgPpAyJC4W9QGemkgqqOFkUE9%2Bsq2EDvQHItdhj86cJa0K4ZVZw2p1Ea3qKk0YTxDHVKm0dFUqlsRnbN0ITkMC0mpyJNqaG2dVHh51%2FKIksMBTjzuZi83w0BKctPWvb17J%2Bhgieeop4TUuqNSy8TvMKQSdBl8DYhp83JlSD6wUE24FXgiS6W0Nlb4wlsui08pj2Jq%2B61p8TGGDtTUhQUoGhXp%2FXgEx5MU0Xpjm6al1mIVIaXbaTPSm0JNnDM7LdNdLpsUPIxSj1ysqZKZLsGCHrly7RJ6Ygtuwpy1oTKND9DW7UW3bIJ1anNbMSsIVwvpcwECa1%2Fj%2FLK1MTmIhpMIUwouDaCVP4WMemV1bLNABcAKST%2FWtnr8VQHmydh%2BMi0y6HraYf8Bn0KQZuBFKyKQ%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIA4XHFIO3CVMW3EV65%2F20250306%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250306T103741Z&X-Amz-Expires=7200&X-Amz-SignedHeaders=host&X-Amz-Signature=4bf11d7df4a64011322a47c883b1a61966fd7728c49f114896e070e08f4d929b",
		FileMd5:  "",
		FileSize: 0,
	}
	iParam := aiparameter.StyleTransferInferenceParameter{
		Images:         []*aicommon.FileInfo{img},
		ApplyInputMask: 0,
	}
	b, _ := json.Marshal(iParam)
	inferenceParameter := string(b)

	extendedParameter := "{\"ai_generate_parameter\":\"{\\\"prompt\\\":{\\\"42\\\":{\\\"inputs\\\":{\\\"delimiter\\\":\\\", \\\",\\\"clean_whitespace\\\":\\\"true\\\",\\\"text_a\\\":[\\\"99\\\",0],\\\"text_b\\\":[\\\"55\\\",0]},\\\"class_type\\\":\\\"Text Concatenate\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Text Concatenate\\\"}},\\\"43\\\":{\\\"inputs\\\":{\\\"strength\\\":0.1,\\\"start_percent\\\":0,\\\"end_percent\\\":1,\\\"positive\\\":[\\\"60\\\",0],\\\"negative\\\":[\\\"60\\\",1],\\\"control_net\\\":[\\\"67\\\",0],\\\"image\\\":[\\\"133\\\",0]},\\\"class_type\\\":\\\"ControlNetApplyAdvanced\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Apply ControlNet\\\"}},\\\"44\\\":{\\\"inputs\\\":{\\\"samples\\\":[\\\"76\\\",0],\\\"vae\\\":[\\\"73\\\",2]},\\\"class_type\\\":\\\"VAEDecode\\\",\\\"_meta\\\":{\\\"title\\\":\\\"VAE Decode\\\"}},\\\"45\\\":{\\\"inputs\\\":{\\\"max_width\\\":1236,\\\"max_height\\\":1236,\\\"min_width\\\":0,\\\"min_height\\\":0,\\\"crop_if_required\\\":\\\"no\\\",\\\"images\\\":[\\\"72\\\",0]},\\\"class_type\\\":\\\"ConstrainImage|pysssss\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Constrain Image ?\\\"}},\\\"46\\\":{\\\"inputs\\\":{\\\"model\\\":\\\"HuggingFaceM4/Florence-2-DocVQA\\\",\\\"precision\\\":\\\"fp16\\\",\\\"attention\\\":\\\"eager\\\"},\\\"class_type\\\":\\\"DownloadAndLoadFlorence2Model\\\",\\\"_meta\\\":{\\\"title\\\":\\\"DownloadAndLoadFlorence2Model\\\"}},\\\"47\\\":{\\\"inputs\\\":{\\\"model\\\":\\\"sam2.1_hiera_large.safetensors\\\",\\\"segmentor\\\":\\\"single_image\\\",\\\"device\\\":\\\"cuda\\\",\\\"precision\\\":\\\"fp16\\\"},\\\"class_type\\\":\\\"DownloadAndLoadSAM2Model\\\",\\\"_meta\\\":{\\\"title\\\":\\\"(Down)Load SAM2Model\\\"}},\\\"48\\\":{\\\"inputs\\\":{\\\"index\\\":\\\"\\\",\\\"batch\\\":false,\\\"data\\\":[\\\"63\\\",3]},\\\"class_type\\\":\\\"Florence2toCoordinates\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Florence2 Coordinates\\\"}},\\\"49\\\":{\\\"inputs\\\":{\\\"keep_model_loaded\\\":true,\\\"coordinates_positive\\\":[\\\"48\\\",0],\\\"individual_objects\\\":false,\\\"sam2_model\\\":[\\\"47\\\",0],\\\"image\\\":[\\\"45\\\",0],\\\"bboxes\\\":[\\\"48\\\",1]},\\\"class_type\\\":\\\"Sam2Segmentation\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Sam2Segmentation\\\"}},\\\"50\\\":{\\\"inputs\\\":{\\\"mask\\\":[\\\"49\\\",0]},\\\"class_type\\\":\\\"MaskPreview+\\\",\\\"_meta\\\":{\\\"title\\\":\\\"? Mask Preview\\\"}},\\\"51\\\":{\\\"inputs\\\":{\\\"expand\\\":-10,\\\"incremental_expandrate\\\":0,\\\"tapered_corners\\\":true,\\\"flip_input\\\":false,\\\"blur_radius\\\":5,\\\"lerp_alpha\\\":1,\\\"decay_factor\\\":1,\\\"fill_holes\\\":true,\\\"mask\\\":[\\\"49\\\",0]},\\\"class_type\\\":\\\"GrowMaskWithBlur\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Grow Mask With Blur\\\"}},\\\"55\\\":{\\\"inputs\\\":{\\\"text\\\":\\\"nthropomorphized animal, renaissance costume, ornate necklace, antique style, studio shot, textured cloak, 16th-century fashion, deep shadows, rich colors, old master painting style, detailed attiree, up body portrait, Transparent background\\\"},\\\"class_type\\\":\\\"TextInput_\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Text Input ♾️Mixlab\\\"}},\\\"59\\\":{\\\"inputs\\\":{\\\"text\\\":[\\\"42\\\",0],\\\"token_normalization\\\":\\\"none\\\",\\\"weight_interpretation\\\":\\\"comfy\\\",\\\"clip\\\":[\\\"78\\\",1]},\\\"class_type\\\":\\\"BNK_CLIPTextEncodeAdvanced\\\",\\\"_meta\\\":{\\\"title\\\":\\\"CLIP Text Encode (Advanced)\\\"}},\\\"60\\\":{\\\"inputs\\\":{\\\"strength\\\":0.1,\\\"start_percent\\\":0,\\\"end_percent\\\":1,\\\"positive\\\":[\\\"59\\\",0],\\\"negative\\\":[\\\"61\\\",0],\\\"control_net\\\":[\\\"66\\\",0],\\\"image\\\":[\\\"79\\\",0]},\\\"class_type\\\":\\\"ControlNetApplyAdvanced\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Apply ControlNet\\\"}},\\\"61\\\":{\\\"inputs\\\":{\\\"text\\\":\\\"(worst quality:2),(low quality:2),(normal quality:2),lowres,bad anatomy,bad hands,normal quality,((monochrome)),((grayscale),, (worst quality:2), (low quality:2), (normal quality:2), lowres, bad anatomy, bad hands, normal quality, ((monochrome)), ((grayscale),lower body,((human))\\\",\\\"token_normalization\\\":\\\"none\\\",\\\"weight_interpretation\\\":\\\"comfy\\\",\\\"clip\\\":[\\\"78\\\",1]},\\\"class_type\\\":\\\"BNK_CLIPTextEncodeAdvanced\\\",\\\"_meta\\\":{\\\"title\\\":\\\"CLIP Text Encode (Advanced)\\\"}},\\\"62\\\":{\\\"inputs\\\":{\\\"scale\\\":0.8,\\\"start_at\\\":0,\\\"end_at\\\":10000,\\\"model\\\":[\\\"78\\\",0],\\\"vae\\\":[\\\"73\\\",2],\\\"image\\\":[\\\"45\\\",0],\\\"mask\\\":[\\\"51\\\",1],\\\"brushnet\\\":[\\\"68\\\",0],\\\"positive\\\":[\\\"43\\\",0],\\\"negative\\\":[\\\"43\\\",1]},\\\"class_type\\\":\\\"BrushNet\\\",\\\"_meta\\\":{\\\"title\\\":\\\"BrushNet\\\"}},\\\"63\\\":{\\\"inputs\\\":{\\\"text_input\\\":\\\"head\\\",\\\"task\\\":\\\"caption_to_phrase_grounding\\\",\\\"fill_mask\\\":true,\\\"keep_model_loaded\\\":true,\\\"max_new_tokens\\\":1024,\\\"num_beams\\\":1,\\\"do_sample\\\":false,\\\"output_mask_select\\\":\\\"\\\",\\\"image\\\":[\\\"45\\\",0],\\\"florence2_model\\\":[\\\"46\\\",0]},\\\"class_type\\\":\\\"Florence2Run\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Florence2Run\\\"}},\\\"65\\\":{\\\"inputs\\\":{\\\"images\\\":[\\\"63\\\",0]},\\\"class_type\\\":\\\"PreviewImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Preview Image\\\"}},\\\"66\\\":{\\\"inputs\\\":{\\\"control_net_name\\\":\\\"diffusers_xl_canny_full.safetensors\\\"},\\\"class_type\\\":\\\"ControlNetLoader\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load ControlNet Model\\\"}},\\\"67\\\":{\\\"inputs\\\":{\\\"control_net_name\\\":\\\"diffusers_xl_depth_full.safetensors\\\"},\\\"class_type\\\":\\\"ControlNetLoader\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load ControlNet Model\\\"}},\\\"68\\\":{\\\"inputs\\\":{\\\"brushnet\\\":\\\"brushnet_xl/segmentation_mask_brushnet_ckpt_sdxl_v1.safetensors\\\",\\\"dtype\\\":\\\"float16\\\"},\\\"class_type\\\":\\\"BrushNetLoader\\\",\\\"_meta\\\":{\\\"title\\\":\\\"BrushNet Loader\\\"}},\\\"70\\\":{\\\"inputs\\\":{\\\"images\\\":[\\\"79\\\",0]},\\\"class_type\\\":\\\"PreviewImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Preview Image\\\"}},\\\"71\\\":{\\\"inputs\\\":{\\\"images\\\":[\\\"133\\\",0]},\\\"class_type\\\":\\\"PreviewImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Preview Image\\\"}},\\\"72\\\":{\\\"inputs\\\":{\\\"image\\\":\\\"{DOWNLOAD_URL}\\\",\\\"upload\\\":\\\"image\\\"},\\\"class_type\\\":\\\"LoadImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load Image\\\"}},\\\"73\\\":{\\\"inputs\\\":{\\\"ckpt_name\\\":\\\"albedobaseXL_v21.safetensors\\\"},\\\"class_type\\\":\\\"CheckpointLoaderSimple\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load Checkpoint\\\"}},\\\"76\\\":{\\\"inputs\\\":{\\\"seed\\\":1083354877379516,\\\"steps\\\":20,\\\"cfg\\\":7,\\\"sampler_name\\\":\\\"dpmpp_2m_sde_gpu\\\",\\\"scheduler\\\":\\\"karras\\\",\\\"denoise\\\":1,\\\"model\\\":[\\\"62\\\",0],\\\"positive\\\":[\\\"62\\\",1],\\\"negative\\\":[\\\"62\\\",2],\\\"latent_image\\\":[\\\"62\\\",3]},\\\"class_type\\\":\\\"KSampler\\\",\\\"_meta\\\":{\\\"title\\\":\\\"KSampler\\\"}},\\\"77\\\":{\\\"inputs\\\":{\\\"lora_name\\\":\\\"PetArtistic l 宠物艺术-中世纪_v1.0\\\",\\\"strength_model\\\":1,\\\"strength_clip\\\":2},\\\"class_type\\\":\\\"LoraLoader\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load LoRA\\\"}},\\\"78\\\":{\\\"inputs\\\":{\\\"lora_name\\\":\\\"AnkerMake_PetArtistic.safetensors\\\",\\\"strength_model\\\":0.5,\\\"strength_clip\\\":2,\\\"model\\\":[\\\"73\\\",0],\\\"clip\\\":[\\\"73\\\",1]},\\\"class_type\\\":\\\"LoraLoader\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Load LoRA\\\"}},\\\"79\\\":{\\\"inputs\\\":{\\\"low_threshold\\\":100,\\\"high_threshold\\\":200,\\\"resolution\\\":1024,\\\"image\\\":[\\\"72\\\",0]},\\\"class_type\\\":\\\"CannyEdgePreprocessor\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Canny Edge\\\"}},\\\"84\\\":{\\\"inputs\\\":{\\\"mask\\\":[\\\"51\\\",0]},\\\"class_type\\\":\\\"MaskPreview+\\\",\\\"_meta\\\":{\\\"title\\\":\\\"? Mask Preview\\\"}},\\\"99\\\":{\\\"inputs\\\":{\\\"Text\\\":\\\"a cat\\\"},\\\"class_type\\\":\\\"DF_Text\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Text\\\"}},\\\"133\\\":{\\\"inputs\\\":{\\\"ckpt_name\\\":\\\"depth_anything_vitl14.pth\\\",\\\"resolution\\\":1024,\\\"image\\\":[\\\"72\\\",0]},\\\"class_type\\\":\\\"DepthAnythingPreprocessor\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Depth Anything\\\"}},\\\"135\\\":{\\\"inputs\\\":{\\\"images\\\":[\\\"44\\\",0]},\\\"class_type\\\":\\\"PreviewImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Preview Image\\\"}},\\\"136\\\":{\\\"inputs\\\":{\\\"filename_prefix\\\":\\\"ComfyUI\\\",\\\"images\\\":[\\\"44\\\",0]},\\\"class_type\\\":\\\"SaveImage\\\",\\\"_meta\\\":{\\\"title\\\":\\\"Save Image\\\"}}}}\"}"

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/05.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250306%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250306T041042Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=fa134220109cb923cabeb184f74b7b5c21384e9dd29603a2145fa9ab4d1a6ab6"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}
	fmt.Println("fff", rsp)
	return
}

func TestFaceSwap(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Face_Swap
	inputImage := make([]string, 0)
	templateImage := make([]string, 0)
	inputImage = append(inputImage, "https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/03.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T074820Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=566027bd98c3fa53aed3466b1653f7c420c191b2efb020678f5edc7f492aa5f8")
	inputImage = append(inputImage, "https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/04.jpeg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T075007Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=e5678123ef542c702ba9f2f79ba3cfb2cf6447f4dff898ac08e73779473d1c59")

	templateImage = append(templateImage, "https://d3bqgm8i99ykl0.cloudfront.net/she12_00ac0ccfd2.png")
	templateImage = append(templateImage, "https://public-makeitreal-cms-qa-us.s3.us-west-2.amazonaws.com/faceswap_she_royal_23_345bc61d86.png")

	upToken := make([]string, 0)
	upToken = append(upToken, "https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/05.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250303%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250303T124006Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=f249e7a190868f981c27ddd5226c29fe5257c5ddac4350477465be6ebcb30568")
	upToken = append(upToken, "https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/06.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T075942Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=b84f972685fcde695a5f54019529f70d49073bb713de0d596aeb4e14af86d2a6")

	inferenceParameter := "{\"images\":[{\"file_data\":\"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/4c113365-dffd-47df-9bc0-c97c55978b86.png?response-content-disposition=inline&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEJ3%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJHMEUCIGS3DdbKzxG9L7dswTAJsjYmskhpm%2F7HBGPkyFfaCpqQAiEAkhFmRpKbCnEdrjwqEKbbxxevIGgS34SW6w7XrnNZkK8qtQQI1v%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARABGgw4NzQ1MDY2NDcyMzciDCdkJRzJETzzADsAcyqJBLz9KLVPGtWs%2FDUUue3Tu%2BhimTSo%2FkoO0ttLknXNbhyvAJaCLFOgN%2FUcepBnE%2Fj%2BL6ywnXjpYUzRZQmCHmRqUWPdaXGtMVFkiq%2B%2BFdWB1eRbQLtyy7TJxbCjzwg7fJuWhY2GFZmUBgezvJ2vp2N6%2FeLyqzaGWEHkXCLIXJXTOau3zPPUKltbGldCLPUvHnv6KtVhiC69aJ%2BjFuXo%2BWzEBRSv%2B%2FmDDCTLmekllPuQVznlJ8lt9jsjy5L9Hf2UAMo4ch2YLjc6YRuud8YyBJ8zBS7cK1mN%2BEuq65YeWtAJfVznqDmEAIX%2Fi8n%2Fvq8YbVWaJ6P87qe5e1YeP3Mc3FU2HwaU34DH%2BP7bP1qOXuM2oSIQpGarHxoWNAnFhIaEAxju5HfVEHCCoUQtJ0po1DbKYf6tW%2Bn%2FOSvNdLt1d5op%2FEwV5JRyjZwf3Lj%2FcPtBH%2BfyxKKXzXJ694JV6ZTSRZPrCU3SBfYV5fXniJvyyqX%2BhJPS3WLLURVAfgKTJMSeleireDLtRGptacdsSszWnTRXUTA7IL4IRv6U9tJN72V1LoEOYg%2BblHd3vOMpykxfYgmamMeVDA5oV2OR2fqzKhmgh%2FDfNJ8%2FVxAtukNk1oQ4J%2BlaSBqECon5zrHohyp77b1ind0CYl5Fw1ovmtMHHhvlQRSxhogolybERqXD5gC83bnlQ0191naRG4%2BZMJbDlr4GOsUCg0oez86RwJynIO3wBqMmncEzdw0489ecXRVx3XJvJ5dq78az88HgnodAqvkffoGEQFEHBjpn%2BBqm7qiajI3iJhC6l5SCCwiISTTA6EXsUy24i8S%2Fp6%2BHNEel92bJU%2FQpII8a9MwP09IrJOS720P27seTJSJMBIva4ieOTb8ZSHebP5AxQ%2BGiDJvPvx4d8GAuhBwEiJThc8oY7TdfcHRqiL7ylnT5f7fW%2BGYMrnft0ZAq4I6%2FyGUkQGGfR%2Frnw6GrsRznvChjj771LCR1fHAfMwLLK3%2FllxVa6yXrDSOZv4qTEeqDONFRNY8IGBiccQQWFeO40CHdlkHSEre8b2ISf651l2tYKwy1i5fjbPkqM%2FZChSyTfBM4Vmqmvjqe5IVbPKGab3s5OCpJo0P4jLlvBZDaEk9ZM4aJpU5hPTb0BhDudQNjxQ%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIA4XHFIO3CZQ67GUO2%2F20250303%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250303T123805Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=4e56d7d4c091b2dd9f73a4a02bf213f6e260ae0873445c008a65202c8edf20b5\"}]}"
	extendedParameter := "{\"template_image\":{\"file_data\":\"%s\"},\"facial_areas\":[{\"x1\":341.4746,\"y1\":237.02896,\"x2\":593.57196,\"y2\":566.14044}],\"prompt\":\"\",\"negative_prompt\":\"\",\"mask_strength\":0.5,\"ip_adapter_scale\":0.21,\"controlnet_conditioning_scale\":0.8,\"guidance_scale\":1.1,\"num_inference_steps\":7}"

	client := pb.NewAiAdapterRpcClient(conn)

	ch := make(chan struct{}, 1)
	for i := 0; i < 1; i++ {
		ch <- struct{}{}
		go func(i int) {
			n := i % 2
			//infer := fmt.Sprintf(inferenceParameter, inputImage[n])
			extend := fmt.Sprintf(extendedParameter, templateImage[n])
			var req = &pb.InferenceReq{
				Header: &aicommon.ReqHeader{
					UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
					TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
				},
				TaskType:           taskType,
				ResultUpTokens:     []string{upToken[n]},
				InferenceParameter: inferenceParameter,
				ExtendedParameter:  extend,
			}

			rsp, err := client.Inference(context.Background(), req)
			if err != nil {
				re := regexp.MustCompile(`desc\s*=\s*error:.*?code\s*=\s*(-?\d+)\s+reason\s*=\s*(.*?)(\s+task|\s+message|$)`)
				matches := re.FindStringSubmatch(err.Error())
				if len(matches) == 4 {
					fmt.Println("result", matches[1], matches[2])
				}
			}

			//if rsp.Header.Code != 0 {
			//	panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
			//}
			<-ch
			fmt.Println("执行结果", rsp)
		}(i)
	}
	fmt.Println("全部执行结果")
	select {}
}

func TestImageUpscale(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Image_Upscale

	inferenceParameter := "{\"images\":[{\"file_data\":\"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/03.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T074820Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=566027bd98c3fa53aed3466b1653f7c420c191b2efb020678f5edc7f492aa5f8\"}]}"
	extendedParameter := "{\"outscale\":2}"

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/05.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T075920Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=e100c20ca645406ec06051683aadefe080669874bc0823b5a98ef9261dc18a08"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/06.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250224%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250224T075942Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=b84f972685fcde695a5f54019529f70d49073bb713de0d596aeb4e14af86d2a6"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}

	fmt.Println("TestImageUpscale exec completed")
}

func TestInstantStyle(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Instant_Style

	inferenceParameter := "{\"image\":{\"file_data\":\"https://public-ankermake-us-qa.s3.amazonaws.com/security/JaCBxmoDLBQTbj1R/10.jpeg\"}}"
	extendedParameter := "{\"style_image\":{\"file_data\":\"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/brushstroke_test/20250212.png?response-content-disposition=inline&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPz%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJIMEYCIQCGNPf9MJcDzKgQSX272Z3av9UI0cFCHdtRZbzi3a%2FF4wIhAIGQiH6N9hDQkTNinew14ozieg20pFDvrGtvQxgaSxL2KqwECCQQARoMODc0NTA2NjQ3MjM3Igyfr0nIHvEZl7lqpPoqiQQkDc%2FWicRDUeEeZFJc%2B7%2BPKzzNaVmM5kHsf8hkDBcJ2CqcRkWzj5a1%2FphkSe%2BxHuEuPqbPaalQTxq7TtcB5%2BryIx7OzbCQSSHZLHsKMH%2BVeAd2tHL%2F%2BNEDT5GUfH9fkORUOHgleqY%2BmARhkhmXgKgQcnOzORd0FZkLlS7nrHzMwXJn1AVGAnHQcstvBlpPfwNjhcKF5vPUhG9cRq3W0dKXzFw2WhVizcJ6xKq%2FZXPfUvI5D8CWCEtWXItq5zD2bHcjAW1nU7DmhGu67aOkelL648e9ZR8%2Bd3muMPWxDNO2t8DwVV%2B1Jp%2FiDymmJQPieCswkkaKQO1AN1%2Bjo8SWzkf%2FT99QEcOuxSzaosGB71zGCeIxSUohZZazn8O2zmZOIrSUE5XQh0%2FAp5VNs5mpoxX%2Bdw8hotSsvlLI2qF4VWKWd80N%2FeqzYaUuzahvs%2BnrPz4%2B0gGQR3U4QsmasC2Ri3kexusLAK%2FzWtj%2BQ6U1ygzHF2VjJPpfZ1bByw6KJzqiH%2B6LMYkYwO87pAsVMGGtbMLu8zG4BCkRhWtv%2F9mPLrV51WpllMV0WFmnKyTdiszNYQut8NwYNbPj8okA5BA7SUOdFudt25d2z5GKl5ArN5Fzlv87chNJmVFdKEgUp9RsL3nd%2BvM3h2CN1EdrP%2FhF%2B7RwBc2d3N9%2BWC2Ih98bG6qeXP6q0OgMS2ziGDCh5rq9BjrEAu3lc6fGYMGpiYUVMcCbFNPwZciXs%2FRVbnaMhZ2r%2FxxCVD53B1e32X%2BDAPgXTRtHIdd3viHFIs93b9n%2FRx%2FLexcB63hPRaW0wfZv8l7%2FF0sz9TEt26hyezenybIh18Fke82Ax5%2B21MaOMX4IP8SRSiEy6SiRSrzon%2B1RQBCIwgIfmSPyL%2BCHowfVDQz6LV6i403SSTjhRZ5VFFbl%2FMPuZTb5OJfhUSfgarSwieq%2F7881N%2FPJpJB7ogqG%2B%2BC%2BXOZQvbbR21Ul0xG25M5Nd0B%2BWMwRfRcS3gjnkrY1ut3jpRodHjM2JnmGwiaLRy1dU%2B%2FCaicTLSuf2Nz4TvpV5Czjqu1vmTtnrkHp1vd44uaJLEvXGbDwA%2FlNah7xDz%2B8SXaXYX%2F76%2BkqnRnt9slRyNpieMrEPNFtxADpDTDvd7xPkvzqUYbiFA%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIA4XHFIO3CSMUWMNP2%2F20250214%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250214T032023Z&X-Amz-Expires=7200&X-Amz-SignedHeaders=host&X-Amz-Signature=6ac5f2a70f1507efd3ddf7088f4ce0e1fe5b026d0795df37a1e038d50e995cde\"},\"prompt\":\"\",\"negative_prompt\":\"\",\"neg_content_prompt\":\"\",\"neg_content_scale\":0.5,\"ip_adapter_scale\":0.5,\"controlnet_conditioning_scale\":0.8,\"guidance_scale\":5,\"num_inference_steps\":20}"

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_00.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=%2FufmBRIPvg58W0EGtkpVgCzCt9g%3D&content-type=image%2Fwebp&Expires=1739886654"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_01.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=dzNDcuvHpKz%2BecbPx5g15yHK8mg%3D&content-type=image%2Fwebp&Expires=1739886654"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}

	fmt.Println("TestInstantStyle exec completed")
}

func TestInstantStylePlus(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Instant_Style_Plus

	inferenceParameter := "{\"image\":{\"file_data\":\"https://makeitreal-aiot-ore-qa.s3.dualstack.us-west-2.amazonaws.com/makeitreal/makeitreal/editor_uploads/default/591f8cf2ae6d44124b230c794731bb48e0a4970e/uploads_cfec0ca11039b61fb1b9335a6f1c4b65.webp?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CQPCOG733%2F20250212%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250212T070329Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=3f3837fc50e9cdd5dc452b33e2416e41466cb18e7d4e14a0c0472465e60cc322\"}}"
	extendedParameter := "{\"style_image\":{\"file_data\":\"https://public-makeitreal-cms-qa-us.s3.us-west-2.amazonaws.com/3_c4f52af93d.png\"},\"prompt\":\"{PROMPT}, masterpiece, best quality, high quality, an oil painting, Touch strokes\",\"negative_prompt\":\"text, watermark, lowres, low quality, worst quality, deformed, glitch, low contrast, noisy, saturation, blurry, blush, Soft fur\",\"guidance_scale\":7,\"num_inference_steps\":50,\"num_inversion_steps\":20,\"num_renoise_steps\":1,\"controlnet_conditioning_scale\":0.55}"

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_00.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=%2FufmBRIPvg58W0EGtkpVgCzCt9g%3D&content-type=image%2Fwebp&Expires=1739886654"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_01.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=dzNDcuvHpKz%2BecbPx5g15yHK8mg%3D&content-type=image%2Fwebp&Expires=1739886654"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}

	fmt.Println("TestInstantStylePlus exec completed")
}

func TestRemoveBackground(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Remove_Background

	inferenceParameter := "{\"images\":[{\"file_data\":\"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/brushstroke_test/20250212.png?response-content-disposition=inline&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEOv%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJIMEYCIQCxSUHUoa0zTSJX9%2F2EyqH2GMiUWiO%2BPHhPDccteYrvMwIhAPMygc5zFJIpVdJQderNUg4EdLX5vD18REh22FvjGzpEKqwECBQQARoMODc0NTA2NjQ3MjM3IgwCA2wiPWkadr6qMCoqiQTGqMH%2FLRJrKKRkw4nMTO4%2FQofq0I4E9T7GwZGW5HUbQu%2Bq9yE66J7KmmD%2BTWvvBDchrCO0qKNwPF7dK9ueksf%2FMy1SaxygzIz%2BYlnvsWs%2FofLyTyURuIagt5AmDE5E8uUd%2FheOmK0MKSQk71n4kS4YaphUniTeYd%2BLmBte1KEupn%2F6fH%2Fk%2F37MPy4%2FkNzB25Gxvj3O%2BNkfX4BHKNH3hGpLsM%2FhB2%2BoGHbjG6HoGAp7VEOml13Arvph%2Bgipe4QOTCUAt4K4T5QdVGsBMCpAxoHKe22OMBxFHyYVFO%2FBfMQsTcapt6PUDFGmLqbaQb%2B9kntUspquWs%2B6pq0nc2Bw%2BwPtvfvQq%2FvXqm3aZFBnldOdwdOdCeWY7PlDp6pO%2FsCsO3fhcuMnk0kj8GJHiFPl%2FvtYmt1NN3xjl5qDytT7eZA%2FcHVBLWwkwbqnL1TW9siySIjjmkMKyWHWXtExuBUaBfIhDDylmfYuGfGzTpClVJ101wk6SvreW%2BgEtt%2FYiSJSY3jgCUazSJmnoisC8vsgtlOs%2BXg8j2UfqtPyx33NA14o9uH1QgWs2r3ZzQfT7n7Vo1I2McRKoGZQEPEIDcScE%2BUbsand06vAf4Q1nVL0iO810QxVSBhKsLKE2v4%2B%2B51rRl7k0%2BUapVaZz85Evj%2FAgRTJG9n0G0lHc7X2FGSuDg35mZwFC3OloBRWvzDfibe9BjrEAkAdCD3bjflvRJvFfC4%2F7ovOD8JU6WhAf2yWZE9HyXfJU337Ii1XZIW8hEOkWcEN%2BSNgwkbuPcEMIx2FlAdpNH6jTe3EwOnnq71pmS236%2FI7VRNOewYsuJpewsH7JDnr2lBzSYnHRC0n9QUFzbfv7xIegaa86Gou8%2BC5SVeUml1i%2Bw5Q6S1FT3wOyNOpg2rZjbTKkWi2n1qzFZ28ZasOoiPeJRZhhekLfwLlEnpRJeI2ErjTE0A2jFoKKfZ5ZCb6wuw86vH5TMMB31iXqD%2F9Vfad7USOtTU16E15Bg7LZ9CN84V7xi74GIW745vgJ0QFujODRiYRV8YUs5hb4OY4e8y1YCELH3c%2FcuA%2BbhzXHLfd9D%2BDHfEMldrsvMWec5KjBbhclcY9LCFKqxnWSv7d%2FWjHqHXNyBMYythbsYDbSQKZUpLK%2Bw%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIA4XHFIO3CXUXD7E3J%2F20250213%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250213T105404Z&X-Amz-Expires=7200&X-Amz-SignedHeaders=host&X-Amz-Signature=5e53c64bdc197a2fb2e38fcbc6ca9a217a7bf3ed812e51c6d2f2aafac77d28ff\"}]}"
	extendedParameter := ""

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_00.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=%2FufmBRIPvg58W0EGtkpVgCzCt9g%3D&content-type=image%2Fwebp&Expires=1739886654"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_01.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=dzNDcuvHpKz%2BecbPx5g15yHK8mg%3D&content-type=image%2Fwebp&Expires=1739886654"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}

	fmt.Println("TestInstantStylePlus exec completed")
}

func TestPetportrait(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Pet_Portrait

	inferenceParameter := "{}"
	extendedParameter := "{\"ai_generate_parameter\":{\"prompt\":\"(oil painting style.:1.2),(a Labrador dog:1.2),retriever dressed in an elaborate,regal military uniform reminiscent of 18th or 19th-century European nobility,(wears a richly decorated red coat adorned with gold embroidery:1.3),epaulettes,and various medals and decorations,coat features intricate patterns and a high collar,giving it a very formal and distinguished appearance,a blue sash runs diagonally across the chest,adding to the grandeur of the attire,background is dark and muted,which emphasizes the subject and gives the portrait a classic,incredibly absurdres, <lora:test_5bfa38f46cb4aa1a13676d816c316461-4:1.3>,\",\"negative_prompt\":\"NSFW,lowres,sketches,low quality,out of focus,watermark,signature,worstquality,\",\"init_image\":\"\",\"sampler_name\":\"DPM++ SDE Karras\",\"steps\":25,\"batch_size\":2,\"batch_count\":1,\"cfg_scale\":7,\"width\":1100,\"height\":1100,\"sd_model\":\"albedobaseXL_v21.safetensors\",\"lora_models\":[\"test_5bfa38f46cb4aa1a13676d816c316461-4.safetensors\"],\"vae_model\":\"Automatic\"}}"

	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_00.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=%2FufmBRIPvg58W0EGtkpVgCzCt9g%3D&content-type=image%2Fwebp&Expires=1739886654"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.amazonaws.com/image/output/brushstroke_test/oil_painting2_01.webp?AWSAccessKeyId=AKIA4XHFIO3CR2ZLOFMI&Signature=dzNDcuvHpKz%2BecbPx5g15yHK8mg%3D&content-type=image%2Fwebp&Expires=1739886654"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}

	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}
	if rsp.Header.Code != 0 {
		panic(fmt.Errorf("inference failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message))
	}

	fmt.Println("执行结果", rsp)
}

func TestStyleTransfer(t *testing.T) {
	taskType := aiparameter.TaskType_TASK_TYPE_Style_Transfer
	inferenceParameter := "{\"images\":[{\"file_data\":\"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/input/instantstyle_test/master_size5.png?response-content-disposition=inline&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEKD%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJIMEYCIQD7xO3gim2V8tgvt0Sc63SWtzDHCrbQ9S52T%2BMR%2BUooTAIhAMPBUqta%2B8PzGnkDeVPe9U%2FhLLT9fDyF8tT7sQvi5z4TKqwECCkQARoMODc0NTA2NjQ3MjM3IgzQYeGCoRp8FY00zaEqiQTWizO%2BVCOAe%2BhuAEGKYJpFBlf59BUKpAOKNsgbuxpWeu1OHL7SGZrcn8KUZ25Dco2hU%2FJL9kPp3OkNK%2ByLLLJC8Pcr0DEcNNSYi%2FI3PCzthKkcos%2F6go8P%2FQIqU6ZMwwsI6fwkhKK6R6vZKOu9xIqHmdqYQIiJfPL6mRajsRxSQPPV3spPEg4hslLUXCJv35H%2BowLzTXkSViFcgC80hO9GbgK50aRLMgW1ZaUeFVUm06SvkYmihMTYk0KRMoH1eNsmHka6TTDyIXMr7PqIUKFEZTulJKnpHRoqciXPhNJP7ZwZUmyrsu85E51n0DiWwyNA4fCnk0M43SFgaa8xF1OwEU6ZMqDkXxwzkAYFA6joCc7mniRnoZwY9QvpIrr34VOK0J9sksgHn73%2Fd%2B61vMu%2FOu2CbUpcumzB6DudbwFSYtCF0tIP9ZOdTZkWf4GmiChJeHMUggTpEPtNHf34YCfi25wNW7ZBIqkJ1g1apYDJESOYQ3XsDTQpjXdoSKMoRtjOOD6qqAnBpVBHjvucTkjPl9%2Fx6td0eBOcgjklcvnL6GnGyWG%2Fa2nCWcmwH0%2F1q5qy6Q8xnA22HKkO7ogLeuqgre3xuQ65UjNPYWPn%2FM9tls2Y%2FENQPgRA16qPDrSD8Ul%2B9sWGGxAHCeobO%2BmTSb%2B%2BV83NJ9uxuDf%2F0%2F6KsoUBzWPNUogKCU0%2BZzDLkfi%2FBjrEAtl7zVYVw%2BoDxkZFav8qbi%2FoMVoNCEswxYXTLGMn9XtpDZX6Qh5sY8q10WeW5DoTGeIJ6LP4dq1bknDvTaSu2fFomC%2BBGTNKqB7Yrcd8TTD%2BtG%2FQanOowzalXrEoXuhFwBsN%2BnzK7kbnfj1eosOVp7eqoNGtSxX0JdYvKHIKl0emdVx2y8BuKEn74GWlCgykye9DxbV56COAz48HPR9aISUylItQlUw234HQ4lX1MIIjxtzuHULGLOI%2Fjx1qW9a7UpGEGBqjJjFCt78IKRtsLy%2BhMFe7bTfmsblYxOxHZhKjCh9UiteI81cv6bBjieJb9hcPmx%2FCu7NHEh%2BeslZI3fczIqCGnGsVlVwAhjSiv84coxgLLho37poXaG2xSqxuO541Sj4maXZZZwAfjklkhfyXQSePLLoYFia2QQOhrH2nBE6CUA%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIA4XHFIO3C7TJQCZ64%2F20250415%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250415T072253Z&X-Amz-Expires=7200&X-Amz-SignedHeaders=host&X-Amz-Signature=a6ec5d6d6e14e62de598c529e435e97138b85e44c18faf126fcc5caa5eaa35c3\"}]}"
	extendedParameter := "{\"ai_generate_parameter\": {\"prompt\": \"(Portrait Painting:1.2),<lora:ankermake_sargent_oil_portrait_xl:0.8>,A sargent style oil painting,John Singer Sargent style,impressionism,(vintage:1.4),(oil on canvas:1.2),absurdres,(brush strokes:0.5),(paintbrush:0.5),hd,8k,masterpiece,best quality,{PROMPT}\",\"negative_prompt\": \"NSFW,sketches,cropped,low quality,worst quality,bad-hands-5,easynegative,(facial hair,mustache:1.2),(blush:1.2),(high saturation:1.2),extra fingers,fused fingers,poorly drawn hands,poorly drawn face,eyeshadow,mutation,deformed,dehydrated,bad anatomy,bad proportions,extra limbs,cloned face,disfigured,(deformed mouth, disfigured lips,distorted smile, mutated mouth:1.2),gross proportions,malformed limbs,signature,deformed,mutilated,mutation,watermark,\",\"sampler_name\": \"DPM++ 2M SDE Karras\",\"steps\": 30,\"batch_size\": 1,\"batch_count\": 1,\"cfg_scale\": 10,\"width\": 0,\"height\": 0,\"denoising_strength\": 0.5,\"controlnets\": [{\"module\": \"canny\",\"model\": \"diffusers_xl_canny_full\",\"weight\": 1,\"low_vram\": false,\"threshold_a\": 46,\"threshold_b\": 102,\"guidance_start\": 0,\"guidance_end\": 1,\"pixel_perfect\": true,\"control_mode\": \"Balanced\"},{\"module\": \"openpose_full\",\"model\": \"kohya_controllllite_xl_openpose_anime\",\"weight\": 1,\"low_vram\": false,\"guidance_start\": 0,\"guidance_end\": 1,\"pixel_perfect\": true,\"control_mode\": \"Balanced\"}],\"sd_model\": \"albedobaseXL_v21.safetensors\",\"lora_models\": [\"ankermake_sargent_oil_portrait_xl.safetensors\"],\"vae_model\": \"Automatic\",\"controlnet_models\": [\"diffusers_xl_canny_full.safetensors\", \"kohya_controllllite_xl_openpose_anime.safetensors\"]},\"image_to_prompt\":{\"model\":\"clip\"}}"
	//extendedParameter := "{\"ai_generate_parameter\":{\"init_image\":\"\",\"prompt\":\"depth_map,greyscale,monochrome,(simple background:1.3),(black background:1.3),masterpiece,best quality,<lora:depth_albedXL:1>,\",\"negative_prompt\":\"color:1.3,(blurry:1.3),lineart,lowres,worst quality,bad proportions,(bad anatomy:1.2),(shadow:1.3),(Reflection:1.3),watermark,\",\"sampler_name\":\"Euler a\",\"steps\":40,\"batch_size\":1,\"batch_count\":1,\"cfg_scale\":9,\"width\":1200,\"height\":1200,\"denoising_strength\":0.4,\"controlnets\":[{\"input_image\":\"\",\"module\":\"softedge_pidinet\",\"model\":\"sargezt_xl_softedge\",\"weight\":1,\"low_vram\":false,\"guidance_start\":0,\"guidance_end\":1,\"pixel_perfect\":true,\"control_mode\":\"ControlNet is more important\",\"threshold_a\":100,\"threshold_b\":200},{\"module\":\"none\",\"model\":\"diffusers_xl_depth_full\",\"weight\":1,\"low_vram\":false,\"guidance_start\":0,\"guidance_end\":1,\"pixel_perfect\":true,\"control_mode\":\"Balanced\"}],\"sd_model\":\"albedobaseXL_v21.safetensors\",\"lora_models\":[\"depth_albedXL.safetensors\"],\"vae_model\":\"Automatic\",\"controlnet_models\":[\"sargezt_xl_softedge.safetensors\",\"diffusers_xl_depth_full.safetensors\"]},\"depth_to_detail\": {\"apply_black_mask\": true,\"apply_gray_image\": true,\"gray_scale\": 0.9}}"
	//extendedParameter := "{\"ai_generate_parameter\":{\"init_image\":\"\",\"prompt\":\"depth_map,greyscale,monochrome,(simple background:1.3),(black background:1.3),masterpiece,best quality,<lora:depth_albedXL:1>,\",\"negative_prompt\":\"color:1.3,(blurry:1.3),lineart,lowres,worst quality,bad proportions,(bad anatomy:1.2),(shadow:1.3),(Reflection:1.3),watermark,\",\"sampler_name\":\"Euler a\",\"steps\":40,\"batch_size\":1,\"batch_count\":1,\"cfg_scale\":9,\"width\":1200,\"height\":1200,\"denoising_strength\":0.4,\"controlnets\":[{\"input_image\":\"\",\"module\":\"softedge_pidinet\",\"model\":\"sargezt_xl_softedge [b6f7415b]\",\"weight\":1,\"low_vram\":false,\"guidance_start\":0,\"guidance_end\":1,\"pixel_perfect\":true,\"control_mode\":\"2\"},{\"module\":\"none\",\"model\":\"diffusers_xl_depth_full\",\"weight\":1,\"low_vram\":false,\"guidance_start\":0,\"guidance_end\":1,\"pixel_perfect\":true,\"control_mode\":\"0\"}],\"sd_model\":\"albedobaseXL_v21.safetensors\",\"lora_models\":[\"depth_albedXL.safetensors\"],\"vae_model\":\"Automatic\",\"controlnet_models\":[\"sargezt_xl_softedge.safetensors\",\"diffusers_xl_depth_full.safetensors\"]}}"
	client := pb.NewAiAdapterRpcClient(conn)
	var req = &pb.InferenceReq{
		Header: &aicommon.ReqHeader{
			UserId: "262b363ea6e20f0ea2ee45225184aebac79fff08",
			TaskId: "test_5bfa38f46cb4aa1a13676d816c316461-7",
		},
		TaskType:           taskType,
		ResultUpTokens:     []string{"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/01.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250409%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250409T100949Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=df61e7aa36903b87da2049be2009cdf49bdc1191b3f7f05b7e9cdfec2ae4a3f7"},
		ThumbUpTokens:      []string{"https://makeitreal-ai-model-ore-qa.s3.us-west-2.amazonaws.com/image/output/faceswap_test/02.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA4XHFIO3CR2ZLOFMI%2F20250409%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20250409T101039Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=a48ced5cac7359544f603cc711b121d1fcedc4815401dfba1f3702fe35d6fec0"},
		InferenceParameter: inferenceParameter,
		ExtendedParameter:  extendedParameter,
	}
	rsp, err := client.Inference(context.Background(), req)
	if err != nil || rsp == nil {
		panic(fmt.Errorf("inference failed, err: %v, rsp: %v", err, rsp))
	}

	fmt.Println("执行结果", rsp)
}
