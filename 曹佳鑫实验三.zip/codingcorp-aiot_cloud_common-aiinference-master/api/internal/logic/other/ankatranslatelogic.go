package other

import (
	"context"
	"fmt"
	"io"
	"strings"
	"sync"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"github.com/google/uuid"
	"github.com/zeromicro/go-zero/core/threading"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type AnkaTranslateLogic struct {
	logx.Logger
	ctx       context.Context
	svcCtx    *svc.ServiceContext
	utilLogic *common.UtilLogic

	stream aimanagerrpc.AiManagerRpc_CreateStreamTaskClient
	result []string
}

func NewAnkaTranslateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AnkaTranslateLogic {
	return &AnkaTranslateLogic{
		Logger:    logx.WithContext(ctx),
		ctx:       ctx,
		svcCtx:    svcCtx,
		utilLogic: common.NewUtilLogic(ctx, svcCtx, nil),
		result:    make([]string, 0),
	}
}

func (l *AnkaTranslateLogic) AnkaTranslate(req *types.AnkaTranslateRequest) (resp *types.AnkaTranslateResponse, err error) {
	// 1. 参数校验

	// 2. 创建流式RPC连接
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		return nil, err
	}
	l.stream = stream

	// 3. 发送请求
	err = l.send(req)
	if err != nil {
		return nil, err
	}

	// 4. 接收结果
	wg := sync.WaitGroup{}
	wg.Add(1)
	errCh := make(chan error, 1)
	l.receiving(&wg, errCh)
	wg.Wait()

	// 检查接收过程中的错误
	select {
	case err := <-errCh:
		if err != nil {
			return nil, err
		}
	default:
	}

	// 5. 返回结果
	return &types.AnkaTranslateResponse{
		Data: strings.Join(l.result, ""),
	}, nil

}

func (l *AnkaTranslateLogic) send(req *types.AnkaTranslateRequest) error {
	translateParam := fmt.Sprintf(`{"from_lang": "%s","to_lang": "%s","llm_type": "%s","role": "%s","enable_stream": %t, "service_provider": "%s"}`, req.SourceLanguage, req.TargetLanguage, "gpt-4o", "user_a", false, l.svcCtx.Config.ExternalModel)
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: uuid.New().String(),
			UserId: req.HeaderInnerXUserId,
			AppId:  req.HeaderAppName,
		},
		TaskType: aiparameter.TaskType_TASK_TYPE_Translate,
		Workflow: []*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Translate), IsNeedResult: true, Parameters: translateParam},
		},
	}
	l.Debug("streamReq: ", streamReq)
	if err := l.stream.Send(streamReq); err != nil {
		l.Errorf("stream send failed: %v", err)
		return grpcerrors.New(types.RespCodeSendErr, "stream send failed", grpcerrors.FindCaller(1))
	}

	streamReq.Workflow = nil
	streamReq.Data = &aimanagerrpc.StreamTaskReq_TranslateReq{
		TranslateReq: &aiparameter.TranslateInferenceParameter{
			Text: req.Data,
		},
	}
	l.Debug("streamReq: ", streamReq)
	if err := l.stream.Send(streamReq); err != nil {
		l.Errorf("stream send failed: %v", err)
		return grpcerrors.New(types.RespCodeSendErr, "stream send failed", grpcerrors.FindCaller(1))
	}

	_ = l.stream.CloseSend()
	return nil
}

func (l *AnkaTranslateLogic) receiving(wg *sync.WaitGroup, errCh chan error) {
	threading.GoSafe(func() {
		defer func() {
			l.Infof("receiving goroutine exit")
			l.stream = nil
			wg.Done()
		}()

		for {
			resp, err := l.stream.Recv()
			if err == io.EOF {
				return
			}
			if err != nil {
				l.Errorf("stream receive failed: %v", err)
				errCh <- grpcerrors.New(types.RespCodeRecvErr, "stream receive failed", grpcerrors.FindCaller(1))
				return
			}

			// 读取翻译结果
			translateData := l.convertTranslateData(resp)
			if translateData != "" {
				l.result = append(l.result, translateData)
			}
		}
	})

}

// convertTranslateData 读取翻译结果
func (l *AnkaTranslateLogic) convertTranslateData(streamRecv *aimanagerrpc.StreamTaskResp) string {
	translateResp := streamRecv.GetTranslateResp()
	if translateResp == nil {
		l.Infof("AudioTranslate Recv: GetTranslateResp data is nil")
		return ""
	}

	l.Debug("translateResp: ", translateResp)
	if translateResp.SentenceEnd {
		return translateResp.Text
	}

	return ""
}
