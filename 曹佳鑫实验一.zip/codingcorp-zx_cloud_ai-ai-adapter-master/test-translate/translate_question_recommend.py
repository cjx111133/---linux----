question_list ={
    "he-IL": [
        {
            "id": "c740aea71abf271c9f9133979fc6209a",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "האם יש שירות אחסון מזוודות?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "a4ea2ed6869ba1baaa0da1d6469446b3",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "מה הסיסמה לרשת האלחוטית?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "80948711cb4dcf4657e9576469ea9a19",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "איפה השירותים בבקשה?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "88ab28bea515bcb08547264e897bb9dc",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "איפה אפשר להחליף מטבעות?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "3ee6856d360f331c15ecd34eb1245544",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "אפשר לשלם בכרטיס אשראי?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "e6c5c707fdf2de0e30a699f45ee4819e",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "סליחה, איפה תחנת הרכבת התחתית הקרובה ביותר?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "7d19dbe87521274a9af43c1a60507641",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "כמה זה עולה בבקשה?",
            "language_code": "he-IL",
            "audio_path": None
        },
        {
            "id": "4d2a42132642d60dc20088497fd02b11",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "יש מנות מקומיות מיוחדות?",
            "language_code": "he-IL",
            "audio_path": None
        }
    ],
    "ar-AE": [
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "37b4145501a3db0310ba0adfddcc128c",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هو رمز شبكة الواي فاي؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "07046f16905786b7e18f5eb0da87868a",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "من فضلك، أين دورة المياه؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "d948c3d5fc712f990f5c7fa2f1764e25",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن تحويل العملات؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "2d1ccc4785800fc406d4f587d8f3f6a9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع باستخدام بطاقة الائتمان؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "d49472b58e32c081f1c4347185d1ae9e",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "من فضلك، أين أقرب محطة مترو؟",
            "language_code": "ar-AE",
            "audio_path": None
        },
        {
            "id": "66946d74eb91fc521f05c8d73e79489b",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا؟",
            "language_code": "ar-AE",
            "audio_path": None
        }
    ],
    "az-AZ": [
        {
            "id": "7641cefba3d7fbc1c0a514968ea683e6",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Zəhmət olmasa, tualet haradadır?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "2e983637a522336b2d1fb0ec02da2c3d",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Harada valyuta dəyişdirilə bilər?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "1e6a429132074ff92a1cab7298f0771a",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kredit kartı ilə ödəmək mümkündür?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "e49b5bfd18350962124a54e48134fb53",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Zəhmət olmasa deyin, ən yaxın metro stansiyası haradadır?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "d47f46ed5deda7d110c123557f554459",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Zəhmət olmasa, bu nə qədərdir?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "6d487f82edc137dc4adc0086ed23ef13",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Burada yerli xüsusiyyətli yeməklər varmı?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "e9f06dea305146560f8d62965cbcf537",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Bağaj saxlama xidməti varmı?",
            "language_code": "az-AZ",
            "audio_path": None
        },
        {
            "id": "4609cffd4388c6a82dbef8b710eb9862",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Simsiz şəbəkənin parolu nədir?",
            "language_code": "az-AZ",
            "audio_path": None
        }
    ],
    "pa-IN": [
        {
            "id": "00b4691e028ea04bce2117f7fa3d24ca",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ਕਿੱਥੇ ਮੁਦਰਾ ਦੀ ਬਦਲੀ ਹੋ ਸਕਦੀ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "e9f0d09aacc6b1cc832949b087ef282b",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ਕੀ ਕ੍ਰੈਡਿਟ ਕਾਰਡ ਸਵਾਈਪ ਕਰ ਸਕਦੇ ਹਾਂ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "2f1e012331cea4e029a42465cd219a90",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ਕਿਰਪਾ ਕਰਕੇ ਦੱਸੋ, ਸਭ ਤੋਂ ਨੇੜਲਾ ਮੈਟ੍ਰੋ ਸਟੇਸ਼ਨ ਕਿੱਥੇ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "3e8092f50500390e730e9f08971d4cdf",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "ਇੱਥੇ ਕੋਈ ਸਥਾਨਕ ਵਿਸ਼ੇਸ਼ ਭੋਜਨ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "b79a04d80cee1af1176a289c21b9082b",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ਕਿਰਪਾ ਕਰਕੇ ਦੱਸੋ ਇਹ ਕਿੰਨੇ ਦਾ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "f17c57b3e3e1a44459145febb5a2b147",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "ਕੀ ਇੱਥੇ ਸਾਮਾਨ ਜਮ੍ਹਾਂ ਕਰਨ ਦੀ ਸੇਵਾ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "4b34b2df1dceec79b83758356d89531b",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ਵਾਇਰਲੈੱਸ ਨੈਟਵਰਕ ਦਾ ਪਾਸਵਰਡ ਕੀ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        },
        {
            "id": "c9b914f146d2a3a27a1bd30fa24280cc",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ਕਿਰਪਾ ਕਰਕੇ ਦੱਸੋ ਕਿ ਪ੍ਰਸਾਧ ਕਿੱਥੇ ਹੈ?",
            "language_code": "pa-IN",
            "audio_path": None
        }
    ],
    "uk-UA": [
        {
            "id": "daa63aee7163206a15888bf649a7b852",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Який пароль для бездротової мережі?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "2262366f3ab286acd231f3da5a265756",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Скажіть, будь ласка, де знаходиться туалет?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "2ddada738dfb4c03f2aa029ed932dbbd",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Де можна обміняти валюту?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "a5a769ecdc0a1432790fe9b213a1e5d9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Чи можна розрахуватися кредитною карткою?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "2a86dc9ccd60e669efa8f7e8448acb1e",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Скажіть, будь ласка, де знаходиться найближча станція метро?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "fadf662f0d96a093b16d7b519f466e87",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Чи є якісь місцеві страви?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "d583161fa37f32c73248dc4bfa22a488",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Скажіть, будь ласка, скільки це коштує?",
            "language_code": "uk-UA",
            "audio_path": None
        },
        {
            "id": "453d07f20034116365d93e15cc892755",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Чи є послуга зберігання багажу?",
            "language_code": "uk-UA",
            "audio_path": None
        }
    ],
    "eu-ES": [
        {
            "id": "09e74dbb24d704784d5b382f7b96a355",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "¿Cuánto cuesta esto?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "3eb443deb68cfbfb841ae8a21c3b1069",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "¿Hay algún plato típico local?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "d9a7766188cde9c8eee393fe706a4bd8",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "¿Hay servicio de consigna de equipaje?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "ed5fd2f9b69665f39a90d93ab947d370",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "¿Dónde está el baño?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "06eacdcd5c4600f3198a9585285c21c7",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "¿Cuál es la contraseña de la red inalámbrica?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "d009ce467ad276512fdcfa51f19653a6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "¿Dónde se puede cambiar moneda?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "e26a72a64f228dcbeb851b12b2332554",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "¿Se puede pagar con tarjeta de crédito?",
            "language_code": "eu-ES",
            "audio_path": None
        },
        {
            "id": "929e5b1c62e142f258a692f8a7138cc8",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "¿Dónde está la estación de metro más cercana?",
            "language_code": "eu-ES",
            "audio_path": None
        }
    ],
    "es-ES": [
        {
            "id": "3eb443deb68cfbfb841ae8a21c3b1069",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "¿Hay algún plato típico local?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "d9a7766188cde9c8eee393fe706a4bd8",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "¿Hay servicio de consigna de equipaje?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "06eacdcd5c4600f3198a9585285c21c7",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "¿Cuál es la contraseña de la red inalámbrica?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "ed5fd2f9b69665f39a90d93ab947d370",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "¿Dónde está el baño?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "d009ce467ad276512fdcfa51f19653a6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "¿Dónde se puede cambiar moneda?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "e26a72a64f228dcbeb851b12b2332554",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "¿Se puede pagar con tarjeta de crédito?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "929e5b1c62e142f258a692f8a7138cc8",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "¿Dónde está la estación de metro más cercana?",
            "language_code": "es-ES",
            "audio_path": None
        },
        {
            "id": "09e74dbb24d704784d5b382f7b96a355",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "¿Cuánto cuesta esto?",
            "language_code": "es-ES",
            "audio_path": None
        }
    ],
    "kn-IN": [
        {
            "id": "f5fc8110bec3ee083c067e4860a463fd",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "ಇಲ್ಲಿ ಸಾಮಾನು ಸಂಗ್ರಹಣೆ ಸೇವೆ ಇದೆಯೆ?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "b41d9472fd50a9a0de142807637f198d",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ವೈಫೈ ಪಾಸ್‌ವರ್ಡ್ ಏನು?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "9587a68bf6b91716c6c182179229a296",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ಕ್ಷಮಿಸಿ, ಶೌಚಾಲಯವು ಎಲ್ಲಿ ಇದೆ?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "69ddf49d0597fdf4ff601959d59def36",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ಕೋಡುಗಳನ್ನು ಎಲ್ಲಿ ವಿನಿಮಯ ಮಾಡಬಹುದು?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "8987f341d52887a687bded0e4027e16a",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ನೀವು ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್ ಬಳಸಿ ಪಾವತಿ ಮಾಡಬಹುದೆ?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "85c0af6fda77ef4f8a06583b861e0174",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ನಿಕಟದಲ್ಲಿರುವ ಮೆಟ್ರೋ ನಿಲ್ದಾಣ ಎಲ್ಲಿದೆ?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "880707d12a0986e664da23efc2ea0f6d",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ಈದು ಎಷ್ಟು ಹಣ?",
            "language_code": "kn-IN",
            "audio_path": None
        },
        {
            "id": "f7971dfdf0b79cb3d331b5d0af485db9",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "ಇಲ್ಲಿ ಯಾವ ಸ್ಥಳೀಯ ವಿಶೇಷ ಆಹಾರಗಳಿವೆ?",
            "language_code": "kn-IN",
            "audio_path": None
        }
    ],
    "sw-KE": [
        {
            "id": "43a2ed01ac0a57324c86cdaaf5259136",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Je, unaweza kutumia kadi ya mkopo?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "5fbdd26cfdbc4f0918cb25fbf4422324",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Wapi naweza kubadilisha fedha?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "d7b21a273719b4c0ae04f692a004cd1f",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Samahani, stesheni ya karibu ya treni ya chini ya ardhi iko wapi?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "97c4be68828a81f79fb5acd1b46dff1b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Je, kuna vyakula vya kienyeji maalum?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "0b75a40c39e4c969ce46ac686232124f",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Tafadhali, hii ni bei gani?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "753038ceb8aa66e7236408bb2e0f3607",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Je, kuna huduma ya kuhifadhi mizigo?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "5b573240bc5d387e8df657e03c7c2cc9",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Nenosiri ya mtandao wa wireless ni nini?",
            "language_code": "sw-KE",
            "audio_path": None
        },
        {
            "id": "d7499d8c9e9f3d07db41f2b65e4cf15a",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Tafadhali, choo kiko wapi?",
            "language_code": "sw-KE",
            "audio_path": None
        }
    ],
    "ar-SA": [
        {
            "id": "3e666b9d2572885baf1a74ac73ace388",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هو رمز مرور الشبكة اللاسلكية؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "07046f16905786b7e18f5eb0da87868a",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "من فضلك، أين دورة المياه؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "2bfa7bbbb38cff1207c93e901108b953",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن صرف العملات؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "392f0e298cb98298c0914db857d070e5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع ببطاقة الائتمان؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "f4399740984a9dbc737732c527d8fbd6",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "أين أقرب محطة مترو؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "2cc6541036f7a7d1526f13b5a887abbd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا من فضلك؟",
            "language_code": "ar-SA",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-SA",
            "audio_path": None
        }
    ],
    "fa-IR": [
        {
            "id": "c3aeda16e4d306fec7f987bde124c0d8",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "لطفاً بفرمایید این چقدر قیمت دارد؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "079bd716d4d6b66dacf06c8e18e0435b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "آیا غذای محلی خاصی وجود دارد؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "2cb9d6d967790c5f0e51826c1129fb27",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "آیا خدمات نگهداری چمدان وجود دارد؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "257e3468fd95a249575608244839afe2",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "رمز عبور شبکه بی‌سیم چیست؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "07a9d922a9aa98b68b997cafb2699cd7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "لطفاً بفرمایید دستشویی کجاست؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "b8b3f00ffb6ff1a7253220c7cc7c2fad",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "کجا می‌توان ارز را تبدیل کرد؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "7eadd94a57cf7e4ab37018bc4cfa2972",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "آیا می‌توان با کارت اعتباری پرداخت کرد؟",
            "language_code": "fa-IR",
            "audio_path": None
        },
        {
            "id": "6d09c02b53b32f8f3cab58254b904230",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "لطفاً بگویید نزدیک‌ترین ایستگاه مترو کجاست؟",
            "language_code": "fa-IR",
            "audio_path": None
        }
    ],
    "gu-IN": [
        {
            "id": "de2043e3f436066ccc00296a064e9d14",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "માફ કરશો, શૌચાલય ક્યાં છે?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "86abf9f52c7749603b5b17360502a490",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ક્યાં કરન્સી એક્સચેન્જ કરી શકાય?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "60013b1dafba4e9f455941fd2dcca95c",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "શું હું ક્રેડિટ કાર્ડથી ચૂકવણી કરી શકું?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "69b5e2451ab0a6c615f6e92252a6504f",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "કૃપા કરીને જણાવો નજીકનો મેટ્રો સ્ટેશન ક્યાં છે?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "34a4c237f9b468ee8c9317876bfe6edd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "કૃપા કરીને જણાવો કે આ કેટલાનું છે?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "aded0f0d94b91c232c0253474bce2bb7",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "સ્થાનિક વિશેષ ખોરાક有什么吗？",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "8fad30438a9b01615cb44e5f0e38fded",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "શું અહીં સામાન જમા કરાવવાની સેવા છે?",
            "language_code": "gu-IN",
            "audio_path": None
        },
        {
            "id": "fc05c69b72eb50b69ae4ee0e74aac0c4",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "વાયરલેસ નેટવર્કનો પાસવર્ડ શું છે?",
            "language_code": "gu-IN",
            "audio_path": None
        }
    ],
    "de-DE": [
        {
            "id": "7c819f78c86181dfb957b6641f83e4b4",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Wo kann man Geld wechseln?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "c94303f81226e2935678778ff3aa1f23",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kann man mit Kreditkarte bezahlen?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "39ab271a41808c2fac2b64dda46fa912",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Wo ist die nächste U-Bahn-Station?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "9320e5f3486134e7287485f5da9ad6bd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Wie viel kostet das bitte?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "8ae71cc6adabb9b712f1636402e8a0d5",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Gibt es hier lokale Spezialitäten?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "37f61a9c18678e4760f1e5aa374313fa",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Gibt es eine Gepäckaufbewahrung?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "40348d620d0798ba83ec1967ca1364a2",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Was ist das Passwort für das drahtlose Netzwerk?",
            "language_code": "de-DE",
            "audio_path": None
        },
        {
            "id": "41d0ee103c10f13cb108978cc8ef9c78",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Entschuldigung, wo ist die Toilette?",
            "language_code": "de-DE",
            "audio_path": None
        }
    ],
    "id-ID": [
        {
            "id": "f08128d1f1a14c01df540964cfe08c6f",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Maaf, boleh tahu di mana stasiun kereta bawah tanah terdekat?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "8694a0d778fd397b0d7a3fd4c853c399",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Berapa harga ini?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "92c1f8e7b1f420be500904cdc7c7132c",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Apakah ada hidangan khas lokal?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "ff5b665b495f1c7367e8e178ab5d1d24",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Apakah ada layanan penitipan barang?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "69a5634d6b0105a14d3a29c136f9143a",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Apa kata sandi jaringan nirkabel?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "8aa8800d7083e3ae6787e372fdf9f1b4",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Permisi, di mana kamar mandi?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "9d0ceef666eba45cda08ccdaad91307a",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Di mana saya bisa menukar mata uang?",
            "language_code": "id-ID",
            "audio_path": None
        },
        {
            "id": "8ca39af3e51e0bca076e6a98a57bc5b3",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Bisakah menggunakan kartu kredit?",
            "language_code": "id-ID",
            "audio_path": None
        }
    ],
    "hr-HR": [
        {
            "id": "c6269f1d09e1f06be6d40f6e8a445c7f",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Koja je lozinka za bežičnu mrežu?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "6213609df92c83fc2ee1dcd27c57c9e7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Molim vas, gdje se nalazi kupaonica?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "aa5543294e13f9f15079f1e480596b72",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Gdje mogu zamijeniti valutu?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "f32c072150282c78e63373fc3fc10d05",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Mogu li platiti kreditnom karticom?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "7daced88cdfa340338c4ac94b96715be",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Oprostite, gdje se nalazi najbliža stanica podzemne željeznice?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "88bec0ba1be09119429d5cb3ffed2a6c",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ima li lokalnih specijaliteta?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "87f56e4d10c16778ffb8f17dce6d6ca9",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Koliko ovo košta?",
            "language_code": "hr-HR",
            "audio_path": None
        },
        {
            "id": "80bc112053e4f424a078ba69bcc60402",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ima li uslugu čuvanja prtljage?",
            "language_code": "hr-HR",
            "audio_path": None
        }
    ],
    "so-SO": [
        {
            "id": "b637963c4a335acd0191939299974893",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ma jiraan adeeg kaydinta shandadaha?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "ed6f6271396a2e36e65b8e8473a85962",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Furahaanta shabakadda bilaa-waayirka ah waa maxay?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "56421ab80592d99e1c07d9c3285fc22e",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Fadlan, musqusha xaggee ayay ku taallaa?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "c33d052c09f3baab9d2f316425552718",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Xaggee ayaa lagu beddeli karaa lacagta?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "39df0dd1109d51ed0121d8c1d7ebc1db",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Ma ku bixin kartaa kaararka deynta?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "7a691213cbdbb5cf724101dcc09c7b6b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Ma ii meeshada ugu dhow ee tareenka dhulka hoostiisa mara ku taal?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "6f46860010237493e4c766628a0565f3",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ma jiraan cunto dhaqameed maxalli ah?",
            "language_code": "so-SO",
            "audio_path": None
        },
        {
            "id": "68d052ea3ce1e3dfd9ac96bc8d0443e1",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Fadlan, tan waa immisa?",
            "language_code": "so-SO",
            "audio_path": None
        }
    ],
    "lv-LV": [
        {
            "id": "e35dfead173d440ecc8c968e1693537f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Vai šeit ir kāds vietējais ēdiens?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "e240b80c322fe3b811cd17cc8cb62540",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Vai ir pieejams bagāžas glabāšanas pakalpojums?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "bc9395f19732b1fe63ce8eb9410e404a",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Kāds ir bezvadu tīkla parole?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "f2ae94434c1bc48957ae7408023761b6",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Atvainojiet, kur atrodas tualete?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "f8986776a3fafa033a69cf3e669ca856",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kur var apmainīt valūtu?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "9a386cedd851ce6233e7e016b24ba3c6",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Vai ir iespējams norēķināties ar kredītkarti?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "3d1dc5b38e9b5eaa8f4e7ef3c67c183f",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Atvainojiet, kur atrodas tuvākā metro stacija?",
            "language_code": "lv-LV",
            "audio_path": None
        },
        {
            "id": "4837b965a88f3409ff067522a66c0ecd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Cik tas maksā?",
            "language_code": "lv-LV",
            "audio_path": None
        }
    ],
    "hi-IN": [
        {
            "id": "a9f20b3f1152d1a8e06b2224a1c052e2",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "कृपया बताइए शौचालय कहाँ है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "ce6f62e8c00390f4681be59e0cc3225e",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "कहाँ मुद्रा का विनिमय किया जा सकता है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "6947186d1ed78cf8b4f1c5e1db26dd81",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "क्या मैं क्रेडिट कार्ड का उपयोग कर सकता हूँ?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "a33bff0779294b3c9605da187cf35a18",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "कृपया बताएं, सबसे नज़दीकी मेट्रो स्टेशन कहाँ है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "38d47e62e9552bb2bac312eea172cf8a",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "क्या आप बता सकते हैं कि यह कितने का है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "2144b54964d6828c39e891cd7d1c3664",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "क्या कोई स्थानीय विशेष व्यंजन है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "7370929d62fb985181be662c8d8e0101",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "क्या यहाँ सामान जमा करने की सुविधा है?",
            "language_code": "hi-IN",
            "audio_path": None
        },
        {
            "id": "e86b00dfdd912a67f2d040c281e3c6ba",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "वाई-फाई नेटवर्क का पासवर्ड क्या है?",
            "language_code": "hi-IN",
            "audio_path": None
        }
    ],
    "ko-KR": [
        {
            "id": "eaed5667ffcb3bc4517968a466c741f6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "어디에서 환전을 할 수 있나요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "fcdcd40022b2f7fcbaffb143292939a0",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "신용카드 사용 가능합니까?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "c2a1a286968257d4ed994934326a4912",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "가장 가까운 지하철역이 어디인가요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "8b13301ace96b42c805ae0630632b062",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "이거 얼마예요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "7c726c0cb933ee7838cd24c179d86e84",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "지역 특산 요리가 있나요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "e5cc4484f09f8aa65166744a759d5722",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "무선 네트워크 비밀번호는 무엇인가요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "4e0b377ab403db852e3ad31be552a8df",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "실례지만 화장실은 어디에 있나요?",
            "language_code": "ko-KR",
            "audio_path": None
        },
        {
            "id": "d41d8cd98f00b204e9800998ecf8427e",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "짐 보관 서비스는 있나요?",
            "language_code": "ko-KR",
            "audio_path": None
        }
    ],
    "ps-AF": [
        {
            "id": "bcb656d7dc5c377685aa737cd0d29af4",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Waar is die naaste moltreinstasie?",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "2122e8c1cdf229fd9b437612ddbf5cdf",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "څومره قیمت لري؟",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "f794f432e832c1de00fd5f4a60f080c5",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "آیا کوم ځایی ځانګړی خواړه شته؟",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "27f60024edf56d5ca95396d8866c4c20",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is daar 'n bagasie-bewaar diens?",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "b20a83aa912fc66bc4ee51315b2b317f",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wat is die WiFi-wagwoord?",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "b8fbeff0961d4a5ba999372158e3b52c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Waar is die badkamer?",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "de67eb7cde999e1045c29df0bef77341",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Waar kan ek valuta ruil?",
            "language_code": "ps-AF",
            "audio_path": None
        },
        {
            "id": "59ad06c72a8a673e3429900ca5c553a0",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan ek met 'n kredietkaart betaal?",
            "language_code": "ps-AF",
            "audio_path": None
        }
    ],
    "ar-KW": [
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "37b4145501a3db0310ba0adfddcc128c",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هو رمز شبكة الواي فاي؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "9e862282d27c36d20f1888ce07813a06",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "لو سمحت، وين الحمام؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "72fd3e09a28c7cb3aa3c4e9284659ae8",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "وين أقدر أصرف عملة؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "173ae03ddd58610b120d9cd27e49f9fa",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع بالبطاقة الائتمانية؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "75094acf7002394434f3bca4e2749212",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "لو سمحت، وين أقرب محطة مترو؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-KW",
            "audio_path": None
        },
        {
            "id": "66946d74eb91fc521f05c8d73e79489b",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا؟",
            "language_code": "ar-KW",
            "audio_path": None
        }
    ],
    "ja-JP": [
        {
            "id": "ea26189ef2f9d14a531318f21ec14907",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wi-Fiのパスワードは何ですか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "dbaa26ba7474a43cf351daa1960cdb66",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "お手洗いはどこですか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "a37fe997b59b88964a58e25e225a661e",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "どこで通貨を両替できますか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "c3d3b774491b3c7a69b0a2eb65a5a8bc",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "クレジットカードは使えますか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "141425ded5bf1eeecc2eae918361f9ba",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "すみません、最寄りの地下鉄駅はどこですか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "d3df4214f12fe616d16add7a2cf56b18",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "すみません、これはいくらですか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "27c9729ed4e634eca2751e3a108acdb8",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "地元の名物料理はありますか？",
            "language_code": "ja-JP",
            "audio_path": None
        },
        {
            "id": "22e8ab8f9e008dfb38be9e10234957cd",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "荷物の預かりサービスはありますか？",
            "language_code": "ja-JP",
            "audio_path": None
        }
    ],
    "ml-IN": [
        {
            "id": "eda4dedbc7b563d8fa3b57d65d022f2c",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "എന്തെങ്കിലും പ്രാദേശിക പ്രത്യേക ഭക്ഷണങ്ങളുണ്ടോ?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "5d7df1a566762d6e96667390c9e3a205",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "സാധനങ്ങൾ സൂക്ഷിക്കാൻ ഒരു സേവനം ഉണ്ടോ?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "605dcd94ab2b06dfbd77094bbb7d23d2",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "വൈഫൈ പാസ്‌വേഡ് എന്താണ്?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "be2f7178ccea6ddb2dc845140e3c5559",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ദയവായി പറയൂ, ശൗചാലയം എവിടെയാണ്?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "c3300f094556ca3250bec6278b2fed2d",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "എവിടെ നാണയം മാറ്റാം?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "46f9383e03064565889e2d7cff60bd60",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ക്രെഡിറ്റ് കാർഡ് ഉപയോഗിച്ച് പണമടക്കാൻ സാധിക്കുമോ?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "12e3a5c6be69468e48a306294873205f",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ദയവായി അടുത്ത മെട്രോ സ്റ്റേഷൻ എവിടെയാണ്?",
            "language_code": "ml-IN",
            "audio_path": None
        },
        {
            "id": "a9c80f7d4486c2023d7f86a6567dbc03",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ഈത് എത്ര രൂപയാണെന്ന് പറഞ്ഞുതരുമോ?",
            "language_code": "ml-IN",
            "audio_path": None
        }
    ],
    "ur-IN": [
        {
            "id": "d595e4b66e7c8deaef1fc7f7f6704661",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "براہ کرم بتائیں کہ واش روم کہاں ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "5bf377b674a7b53a820c76526be637b1",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "کہاں پر کرنسی کا تبادلہ کیا جا سکتا ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "021a294d13fb62b3f3063374aff230d8",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "کیا کریڈٹ کارڈ استعمال کر سکتے ہیں؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "38f46835e27af7f5ebcabad4c443fe87",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "براہ کرم بتائیں کہ قریب ترین میٹرو اسٹیشن کہاں ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "43824c24efe445f552a9f09a9dd1b65c",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "براہ کرم بتائیں یہ کتنے کا ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "fc1f09ca7b88fb26e39d590732ef862f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "کیا یہاں کوئی مقامی خاص کھانے ہیں؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "98441301cd63611da3836484a42c8f80",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "کیا سامان رکھنے کی سہولت موجود ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        },
        {
            "id": "f51060d45dc189bcc57c52bb5ba9934f",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "وائرلیس نیٹ ورک کا پاس ورڈ کیا ہے؟",
            "language_code": "ur-IN",
            "audio_path": None
        }
    ],
    "am-ET": [
        {
            "id": "8ff9b21bd3ec9c76e80eaabaa89a716f",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is there luggage storage service?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "461639a7803798622b21a728d6fc6c3f",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Where is the restroom, please?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "783297b9ba780e2427f04bad72011304",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "What is the Wi-Fi password?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "630e39b0eb1943fd7043dffa2c20f007",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Where can I exchange currency?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "20f2c4b3cfbcd8009a146f65e9342799",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Can I use a credit card?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "98fc61305011424bf1f363163f811fc6",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "እባኮትን ቀረባ የመሬት ባቡር ጣቢያ የት ነው?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "adf447f1f161534681d3e7917960df82",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "How much is this?",
            "language_code": "am-ET",
            "audio_path": None
        },
        {
            "id": "88bc7d41e97dbfde7ca92959d5b5ec42",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Are there any local specialty dishes?",
            "language_code": "am-ET",
            "audio_path": None
        }
    ],
    "cy-GB": [
        {
            "id": "81000b0d3c99ccf29cf0664002faffd6",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Can I pay by credit card?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "630e39b0eb1943fd7043dffa2c20f007",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Where can I exchange currency?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "3332bbeb69d5514693dcd51b709132de",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Ble mae'r orsaf metro agosaf os gwelwch yn dda?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "87bee0ae8b487ba9c35df6ea93678055",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "How much is this, please?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "60b22394e6e84b16c6fc41ba5d5bfa8a",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Oes gwasanaeth storio bagiau?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "a4ff2a0fb072ecca3a9724c84188c8bd",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Are there any local specialities?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "faa9e7e649fb8975c6df76a9d14c4afb",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "What's the Wi-Fi password?",
            "language_code": "cy-GB",
            "audio_path": None
        },
        {
            "id": "8365202f3904671054d631d90587a79c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Where's the toilet, please?",
            "language_code": "cy-GB",
            "audio_path": None
        }
    ],
    "mr-IN": [
        {
            "id": "07419c12a7764af510a1b1f158c1f447",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "कोणते स्थानिक खास पदार्थ आहेत का?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "3ffeb25b6bdb8d9ce056cc275a0c5a45",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "इथे सामान ठेवण्याची सेवा आहे का?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "f47c1c695f7e462216c7b673a684c470",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "वायरलेस नेटवर्कचा पासवर्ड काय आहे?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "2e41960efc5dd52a79a54c68020249e5",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "माफ करा, शौचालय कुठे आहे?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "8e57436d6ece6451c567541438d0d530",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "चलन कुठे विनिमय करता येईल?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "942e125a1a99a85a0febf4d7c027b03c",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "क्रेडिट कार्ड स्वाइप करू शकतो का?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "ce9b249d848564bc3b310716c630e697",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "कृपया सांगा, जवळचे मेट्रो स्टेशन कुठे आहे?",
            "language_code": "mr-IN",
            "audio_path": None
        },
        {
            "id": "279a1d3f34d0b80df18dab86d1a12f95",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "कृपया सांगा, हे कितीला आहे?",
            "language_code": "mr-IN",
            "audio_path": None
        }
    ],
    "yue-CN": [
        {
            "id": "b84a8f6328494e0fd6b71a18b0ec336d",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "請問最近嘅地鐵站喺邊度？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "0c1a396b91922bb08dd7488af4043719",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "請問呢個幾多錢？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "bd4e6a3b35710de60af1aa5b74766668",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有冇行李寄存服务？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "0ad9132bca876a7fbeb0dbec1759097b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有咩本地特色菜呀？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "7dd676a076dfe9261e2e0507f26f4501",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wi-Fi密码系咩呀？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "c35e72a914299267f19bda2f182232fd",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "請問洗手間喺邊度？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "36ca26c08478919da43d73740e4efeb5",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "邊度可以換錢？",
            "language_code": "yue-CN",
            "audio_path": None
        },
        {
            "id": "133fa32853312538d40a875e279222ca",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "可以用信用卡吗？",
            "language_code": "yue-CN",
            "audio_path": None
        }
    ],
    "gl-ES": [
        {
            "id": "93d75bc302ef0d49510ab4acf9d59e50",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Hai servizo de consigna de equipaxe?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "c63cf70e267e683525417081d8c0c388",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Cal é o contrasinal da rede inalámbrica?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "c2127dd1226d3f5ecc366ea16023f11b",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Podería dicirme onde está o baño?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "67c6de187d27a050476aa44f714b36c4",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Onde se pode cambiar moeda?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "cf42deeb68d0ce0d046fa1bda92278dc",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Pódese pagar con tarxeta de crédito?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "6708b1351de2834b7151ad704e89a911",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Podería dicirme onde está a estación de metro máis próxima?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "e6226e726070908a549468e9eaa4cd9d",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Canto custa isto?",
            "language_code": "gl-ES",
            "audio_path": None
        },
        {
            "id": "a899f7df0c011e7cff6ef5d76f07870e",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Hai algunha especialidade local?",
            "language_code": "gl-ES",
            "audio_path": None
        }
    ],
    "mt-MT": [
        {
            "id": "9486050c720b81586f355277300da2fe",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "X'inhu l-password tan-netwerk mingħajr fili?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "f686223f777572108fd019c2fb1ffade",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Tista' tgħidli fejn hi l-kamra tal-banju?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "ac879fa8b648b49ed90de35e81851882",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Fejn nista' nippjana l-munita?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "46c830d6e8866c8b58628aa61b6166c4",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Tista tuża l-karta ta’ kreditu?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "512f9705d6531ef7114d3e9dd8a1ee86",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Tista' tgħidli fejn hu l-eqreb stazzjon tal-metro?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "4a03e177f112bf890078e6e39fb383a6",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Kemm jiswa dan jekk jogħġbok?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "055a4e6fe2fbd2336f09c7b01840fd33",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Hemm xi ikel tipiku lokali?",
            "language_code": "mt-MT",
            "audio_path": None
        },
        {
            "id": "2b7b228e4589078d1d30512451cdffd0",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Hemm servizz ta’ ħżin tal-bagalji?",
            "language_code": "mt-MT",
            "audio_path": None
        }
    ],
    "uz-UZ": [
        {
            "id": "794b5a10e105553fccf26b87120a83be",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Iltimos, hojatxona qayerda?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "505d3163be78589903277327abecce8b",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Qayerda valyuta almashtirish mumkin?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "c1a0f1a24a65ba96f5aa669fbf5d8f31",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kredit karta orqali to‘lash mumkinmi?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "24e360d77b62936ec8b15107692350f4",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Iltimos, yaqinroq metro bekati qayerda?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "c4b91268b32aed285f30881de686162a",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Mahalliy o‘ziga xos taomlar bormi?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "2f03592ddcd3d5a81e52b5008eb3040c",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Iltimos, bu qancha turadi?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "f846a7ef1d5da55ff97b1e8eaf63fde8",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Yuk saqlash xizmati bormi?",
            "language_code": "uz-UZ",
            "audio_path": None
        },
        {
            "id": "fab56e72108b67679930a95efc03c8c7",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Simsiz tarmoq paroli nima?",
            "language_code": "uz-UZ",
            "audio_path": None
        }
    ],
    "kk-KZ": [
        {
            "id": "3df72fc13858b6d41e44b9a3ee0be2a5",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Ақшаны қай жерде айырбастауға болады?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "8954773c6b11c241f186e038d4b7da60",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Несие картасын пайдалануға бола ма?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "fd8e983662570fe24639eff6871dfc2b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Кешіріңіз, ең жақын метро станциясы қай жерде?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "86bf03de47e24a82f9317fbcb6e12d9c",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Бұл қанша тұрады?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "a1355d1b99a7858971ee0c987c0eff1d",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Жүк сақтау қызметі бар ма?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "46beae7c10fa60238cbfd88ca435388d",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Бұл жерде жергілікті ерекше тағамдар бар ма?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "4ca3e1ccd0861800050b4af96a842b71",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wi-Fi желісінің құпия сөзі қандай?",
            "language_code": "kk-KZ",
            "audio_path": None
        },
        {
            "id": "ffb70f4c10caf41f25aae5919885b268",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Жуынатын бөлме қай жерде?",
            "language_code": "kk-KZ",
            "audio_path": None
        }
    ],
    "jv-ID": [
        {
            "id": "92b1ddbaeaccf22e5530af216aba40cc",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Pinten regane iki?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "a567c80135373260863799a8ad7a6348",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ana panganan khas lokal?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "86d5a8edb2bfb94a58d55b80faad39dc",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Apa ana layanan titip bagasi?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "22650adc5e1eaa43e1d632900d8b9771",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Sandi jaringan nirkabelé apa?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "88e2a1cc2e903f89934b367638bdffc2",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Nyuwun sewu, kamar mandi ing ngendi?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "31e44fbaa85e444eb0eebd0efa3c8f82",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Pundi endi sing bisa kanggo ngijolke mata uang?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "ad6a3e4f6e3fa3b8242f8bf96ab8b44f",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Bisa nganggo kertu kredit?",
            "language_code": "jv-ID",
            "audio_path": None
        },
        {
            "id": "d720aa19ae71d386a2b42737b71a5abd",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Punten, stasiun sepur bawah tanah sing paling cedhak ana ing endi?",
            "language_code": "jv-ID",
            "audio_path": None
        }
    ],
    "nl-NL": [
        {
            "id": "a8337559648d70b8627216bdc1f91feb",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Zijn er lokale specialiteiten?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "e24588509a6c032754bdeb78ffac21ca",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hoeveel kost dit?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "789e0645fa0554626b9014f9c79ad502",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is er een bagageopslagservice?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "653c3f5bb9af498cdf890acc20081549",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wat is het wachtwoord van het draadloze netwerk?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "e8ca6889e6c60632dc536019396f3e96",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Waar is het toilet, alstublieft?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "39f380ab7599c76d13f0fc3d560c1bfe",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Waar kan ik valuta wisselen?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "4f9dda9c1f309eff3c084d9faafb8838",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan ik met een creditcard betalen?",
            "language_code": "nl-NL",
            "audio_path": None
        },
        {
            "id": "ffade38e7fe4d733675b5ddea2d75ea3",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Kunt u me vertellen waar het dichtstbijzijnde metrostation is?",
            "language_code": "nl-NL",
            "audio_path": None
        }
    ],
    "ar-BH": [
        {
            "id": "b89a0fb2870ca74766d6021f0f8ddfe6",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "أين تقع أقرب محطة مترو؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "66946d74eb91fc521f05c8d73e79489b",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "05a251d86090e85f6fe4d66b84ff09b9",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة مرور شبكة الواي فاي؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "9e862282d27c36d20f1888ce07813a06",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "لو سمحت، وين الحمام؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "2bfa7bbbb38cff1207c93e901108b953",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن صرف العملات؟",
            "language_code": "ar-BH",
            "audio_path": None
        },
        {
            "id": "392f0e298cb98298c0914db857d070e5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع ببطاقة الائتمان؟",
            "language_code": "ar-BH",
            "audio_path": None
        }
    ],
    "lt-LT": [
        {
            "id": "8b79b634424e6cc744269669f2548075",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kur galima išsikeisti valiutą?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "acf042188ded9f1bb3cc8a4a1b749d5d",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Ar galima atsiskaityti kreditine kortele?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "d90e94643febdc23af6726ae98176385",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Atsiprašau, kur yra artimiausia metro stotis?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "a3784ed5a928f0dbc8e080e1a5dd2616",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ar turite vietinių patiekalų?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "c433d6f705fa960b1cb9d9cadca12f60",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Kiek tai kainuoja?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "b09cc5d245e7f5f540ceed980f37895f",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ar yra bagažo saugojimo paslauga?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "0cfd746420db6ecff2bfca7cb13474d4",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Koks yra belaidžio tinklo slaptažodis?",
            "language_code": "lt-LT",
            "audio_path": None
        },
        {
            "id": "f8ba923c354fa954d5b82054f8e1b653",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Atsiprašau, kur yra tualetas?",
            "language_code": "lt-LT",
            "audio_path": None
        }
    ],
    "si-LK": [
        {
            "id": "217818bc9816425f51caa1faee54b6ad",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "මෙහි දේශීය විශේෂ ආහාර වේලක් ඇත්ද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "a46121d86fc4c741f460a12e10b12002",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "කරුණාකර මට කියන්න මේක කොපමණ මුදලක්ද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "89821914f2cfb01f80346c6d2943d586",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "මෙහි මූල්‍ය භාණ්ඩ තැන්පත් සේවාවක් තිබේද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "03af147600bc85fcf40781d709e014f3",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "වයිෆයි ජාලයේ මුරපදය කුමක්ද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "82596a97c9b3bc04c898e55728c0cd3b",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "කරුණාකර සෝචි ගෘහය කොහෙද කියන්නද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "d84def420bf3c3f94005195b48b9b219",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "මුදල් මාරු කරගැනීම සඳහා කුමන ස්ථානයක් ඇතද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "9babb85efb70e31659a5c4003e659a48",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ක්‍රෙඩිට් කාඩ්පතෙන් ගෙවීම කළ හැකිද?",
            "language_code": "si-LK",
            "audio_path": None
        },
        {
            "id": "3d35a16c895c9cbdf36ed8dcfaf80b8c",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "කරුණාකර කියන්න ළඟම මහනගර දුම්රිය ස්ථානය කොහිද?",
            "language_code": "si-LK",
            "audio_path": None
        }
    ],
    "sw-TZ": [
        {
            "id": "5e91d9c1dd07b7ccae12fa5f8a112a38",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Nenosiri ya mtandao wa wireless ni ipi?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "9b794a702a3d5e17dd1a6597dee6b872",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Samahani, choo kiko wapi?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "620da0527076030b83ba4332d89411e0",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Wapi naweza kubadilisha pesa?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "b7309c53a3f44df31d73513855403233",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Je, unaweza kulipia kwa kadi ya mkopo?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "cc50fcff342ca4012c7555aac08a6a14",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Samahani, stesheni ya karibu ya metro iko wapi?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "95fa7d334723830f80a3d371ade91e7a",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Samahani, hii ni bei gani?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "a3c22fb08b823453b99cbe5b505fc94f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Je, kuna vyakula vya kipekee vya hapa?",
            "language_code": "sw-TZ",
            "audio_path": None
        },
        {
            "id": "753038ceb8aa66e7236408bb2e0f3607",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Je, kuna huduma ya kuhifadhi mizigo?",
            "language_code": "sw-TZ",
            "audio_path": None
        }
    ],
    "ar-DZ": [
        {
            "id": "2b5a8c606287dfe6916005279f5e3f3b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "من فضلك، وين توجد أقرب محطة مترو؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "184b144570dbfbe860554586bb06c285",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل كاين أطباق محلية مميزة؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "3613afaf6c91f1a5a1ce969fb794f2b0",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "بصح، شحال حق هذا؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "b45eb5beb15235264a10a27ef4c489c8",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "واش هو الكود تاع الواي فاي؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "1c2fc4d615671b496d56cddc318929fc",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "وين توجد دورة المياه؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "373a64c041e62ebceca4322f1610ff4c",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "فين نقدر نبدل العملة؟",
            "language_code": "ar-DZ",
            "audio_path": None
        },
        {
            "id": "c580bd36603501c0c92c572d0336799c",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "واش نقدر نخلص بالكارت كريدي؟",
            "language_code": "ar-DZ",
            "audio_path": None
        }
    ],
    "nb-NO": [
        {
            "id": "6816c2ab1bba0fecccd881c70c36b1da",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hvor mye koster dette?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "68d8de9a801364f765387f3d44983a65",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Finnes det noen lokale spesialiteter?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "e3453072b6af3db93e84f944a780f8bc",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Er det bagasjeoppbevaring?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "e734b302721ef31f93b93179e3dbb099",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Hva er passordet til det trådløse nettverket?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "4478e9a0f4c8fffc3fe0d40afb1f42a1",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Hvor er toalettet?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "0196c15c7989606b62875e99d8eed787",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Hvor kan jeg veksle valuta?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "a26f3ed8be5309fca247d35a666058bf",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan jeg betale med kredittkort?",
            "language_code": "nb-NO",
            "audio_path": None
        },
        {
            "id": "e3714e4fc0ad21a68f6019d42f7a5771",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Kan du fortelle meg hvor den nærmeste T-banestasjonen er?",
            "language_code": "nb-NO",
            "audio_path": None
        }
    ],
    "my-MM": [
        {
            "id": "b546ee0cff7a9db161850a61a8202199",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ဘယ်မှာငွေလဲလို့ရမလဲ။",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "383ecfb0f25387b445e74be5d11be107",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "အကြွေးဝယ်ကတ်ဖြင့်ငွေရှင်းလို့ရပါသလား?",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "6fb47cbd9303fc9f1e2010154d24bb8b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "နောက်ဆုံးရောက်ရှိနိုင်တဲ့ မြေအောက်ရထားဘူတာရုံ ဘယ်မှာရှိပါသလဲ။",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "983012469d349a832d247732d56ed5ea",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "အရပ်ဒေသဆိုင်ရာ အထူးဟင်းလျာတွေရှိပါသလား။",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "a9082d294114035915481f6f4be6c35f",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ဒါဘယ်လောက်ပါလဲ။",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "f6a96896c8e745d585494c723ec272ed",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "အိတ်ထည့်ထားနိုင်တဲ့ဝန်ဆောင်မှုရှိไหม?",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "ac340ec5c8b5015e4dc946622b2042dc",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "မိုဘိုင်းအင်တာနက်လျှို့ဝှက်နံပါတ်ကဘာလဲ။",
            "language_code": "my-MM",
            "audio_path": None
        },
        {
            "id": "ecfd5dd0a9af20d5dc6a7508380cde22",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ကျေးဇူးပြု၍ ရေချိုးခန်းဘယ်မှာရှိပါသလဲ။",
            "language_code": "my-MM",
            "audio_path": None
        }
    ],
    "ar-JO": [
        {
            "id": "bb1da51d056d9d8355c839b672c0f703",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "من فضلك، أين الحمام؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "0ce9147718be5bbdf4351a7e88fcd393",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن تبديل العملات؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "392f0e298cb98298c0914db857d070e5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع ببطاقة الائتمان؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "20e67dab9e080fd639e4abc7ee539b04",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "أين تقع أقرب محطة مترو من فضلك؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "2cc6541036f7a7d1526f13b5a887abbd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا من فضلك؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-JO",
            "audio_path": None
        },
        {
            "id": "05a251d86090e85f6fe4d66b84ff09b9",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة مرور شبكة الواي فاي؟",
            "language_code": "ar-JO",
            "audio_path": None
        }
    ],
    "ar-OM": [
        {
            "id": "2b3238310c5bb6dfd0bda85e3791e664",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "عذرًا، أين تقع أقرب محطة مترو؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "2cc6541036f7a7d1526f13b5a887abbd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا من فضلك؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "f9f5627189e6565b9451de875bbd4085",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة مرور الشبكة اللاسلكية؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "f0dfaf9340a368b8b23c2d2dda4e8b9b",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "أين تقع دورة المياه؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "2bfa7bbbb38cff1207c93e901108b953",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن صرف العملات؟",
            "language_code": "ar-OM",
            "audio_path": None
        },
        {
            "id": "2d1ccc4785800fc406d4f587d8f3f6a9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع باستخدام بطاقة الائتمان؟",
            "language_code": "ar-OM",
            "audio_path": None
        }
    ],
    "wuu-CN": [
        {
            "id": "a5fa054826da85ebf04fc9f5ae2e4e4d",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有啥本地特色菜伐？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "1a326a2aacc529b07c383a743123f395",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "请问这个几多钱？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "2545bd0260dc926ede5a178ca83b86f6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服务伐？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "07362f190fd2984f7e50d00f1b23ab84",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "请问厕所在伐？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "246b495af429707562518bb5464875fc",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "无线上网密码啥个？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "e8f8f4dd69c05b209dde9329dba4ba84",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪能兑银子？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "dbcb552fa2e6ac77daa49aa804c75870",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "能刷信用卡伐？",
            "language_code": "wuu-CN",
            "audio_path": None
        },
        {
            "id": "4dedd87938c29f14fc765a45577974e8",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "请问最近个地铁站在哪能？",
            "language_code": "wuu-CN",
            "audio_path": None
        }
    ],
    "zh-CN-shandong": [
        {
            "id": "8cb5c282afbf7a292a7af569b142a971",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "无线网络密码是啥？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "9aff39885b8e9502ff5b53ae6e3111fb",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "请问厕所在哪儿？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "78b226c21e93d6ef9699eeebab5275a7",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪儿能换钱？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "20eb5961173cc1d9983500e5cfe17758",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "能刷信用卡不？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "6792fbecfaf16f0786f4b964eb04d346",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "请问最近的地铁站在哪儿啊？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "22a7d9cd128f6ccc90e1cc76e772a75c",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有啥地儿特色菜啊？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "2a20c0d2380d491907d0701824303f83",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "俺问下，这个得多少钱？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        },
        {
            "id": "c6708e7657315fac466bcfd8365b2c09",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服务不？",
            "language_code": "zh-CN-shandong",
            "audio_path": None
        }
    ],
    "ar-QA": [
        {
            "id": "888d233e5966c2395b2b113cf1ebddba",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "كلمة مرور شبكة الواي فاي؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "0c60d90580d5d2043076cd3575d90cf6",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ممكن تخبرني وين الحمّام؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "31da33f37a2a456359a4ca126e7bbfd7",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "وين أقدر أبدّل العملة؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "2247fc5c010884ea8cce051fd4b880e7",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع بواسطة بطاقة الائتمان؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "35a41f048313c286b42ba6ebc6f38c4d",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "وين أقرب محطة مترو؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "82cbf8e2fe7c1b411346ef79636c1d14",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "بكم هذا من فضلك؟",
            "language_code": "ar-QA",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-QA",
            "audio_path": None
        }
    ],
    "ar-EG": [
        {
            "id": "c6063cdfa078a8d40911598e81776175",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل يوجد أي أطباق محلية مميزة؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "1560b02d812db28eefaaf0fa0d298382",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ممكن أعرف ده بكام؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "a54e9244eb9485567ce67f251537be18",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة سر شبكة الواي فاي؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "bb1da51d056d9d8355c839b672c0f703",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "من فضلك، أين الحمام؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "1733377f39eb79161b1231d2a274faec",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكنني صرف العملات؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "f4c82cd25531dfff6e823dca1a1a40c3",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ممكن أدفع بالكريدت كارد؟",
            "language_code": "ar-EG",
            "audio_path": None
        },
        {
            "id": "d49472b58e32c081f1c4347185d1ae9e",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "من فضلك، أين أقرب محطة مترو؟",
            "language_code": "ar-EG",
            "audio_path": None
        }
    ],
    "te-IN": [
        {
            "id": "a6fefc06f643841093ed8e474fc48fad",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ఎక్కడ కరెన్సీని మార్చుకోవచ్చు?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "c6034f531a9f91a72e019e6bf4e6cde5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "క్రెడిట్ కార్డ్ ఉపయోగించవచ్చా?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "c65113fb86875f7087c520d81642c2b1",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "దయచేసి చెప్పండి, సమీపంలోని మెట్రో స్టేషన్ ఎక్కడ ఉంది?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "98f9915ffbe2b86aa347a9a59df4d386",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "దయచేసి ఇది ఎంత ధర?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "d12f271ef0373d92463af7d4414e83bb",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "ఏమైనా స్థానిక ప్రత్యేకత వంటకాలు ఉన్నాయా?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "4e6cdd7dae2cc0f07699933263b542a4",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "మీరు సామాను నిల్వ సేవ అందిస్తారా?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "2db5c72b3116a25c307854e56ee34597",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "వైఫై పాస్‌వర్డ్ ఏమిటి?",
            "language_code": "te-IN",
            "audio_path": None
        },
        {
            "id": "8bf171fea89be6f7df35287eac5216cc",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "క్షమించండి, టాయిలెట్ ఎక్కడ ఉంది?",
            "language_code": "te-IN",
            "audio_path": None
        }
    ],
    "vi-VN": [
        {
            "id": "5338622cc00b5260f3fa8dd7a8ad6c48",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Ở đâu có thể đổi tiền?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "14e2ab93c7835ec139d5049cc331833a",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Có thể thanh toán bằng thẻ tín dụng không?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "41774f4313a6be86719114df77e44745",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Xin hỏi ga tàu điện ngầm gần nhất ở đâu?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "bde8d4599a1b9f099d24fcf15b57ad37",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Xin hỏi cái này giá bao nhiêu?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "ef0941602897dfcdc6797886a70c2cff",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Có món đặc sản địa phương nào không?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "8ba9026872582c64a853c1bd8190984d",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Có dịch vụ gửi hành lý không?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "362dbb4e258607f84f5d098c7b174afa",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Mật khẩu mạng không dây là gì?",
            "language_code": "vi-VN",
            "audio_path": None
        },
        {
            "id": "a890e89c580ff1b9a08319cd32cafdde",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Xin hỏi nhà vệ sinh ở đâu?",
            "language_code": "vi-VN",
            "audio_path": None
        }
    ],
    "fr-FR": [
        {
            "id": "d79f1c8ade45d216afaa268fcefa7617",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Quel est le mot de passe du réseau sans fil ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "48af63246f47fa65073bb7dc59cc8aa7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Où se trouvent les toilettes, s'il vous plaît ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "dd34013392d353ee85c2e65b7886772b",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Où peut-on échanger des devises ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "edaa99ca6224cbdaf45fb7a75849c7fa",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Peut-on payer par carte de crédit ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "75747cec89e1460e581045494c03aac3",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Excusez-moi, où se trouve la station de métro la plus proche ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "45742d95dc55e7273d82fd5f4521e4c9",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Combien ça coûte, s'il vous plaît ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "e93f487696eb1f262f3e1d2acd158656",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Y a-t-il des spécialités locales ?",
            "language_code": "fr-FR",
            "audio_path": None
        },
        {
            "id": "b942fd9898e803c11d58e1ecf7210bc5",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Y a-t-il un service de consigne pour les bagages ?",
            "language_code": "fr-FR",
            "audio_path": None
        }
    ],
    "en-US": [
        {
            "id": "630e39b0eb1943fd7043dffa2c20f007",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Where can I exchange currency?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "20f2c4b3cfbcd8009a146f65e9342799",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Can I use a credit card?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "d1db11d3ace5ca484f03885d6233fe1a",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Excuse me, where is the nearest subway station?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "87bee0ae8b487ba9c35df6ea93678055",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "How much is this, please?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "88bc7d41e97dbfde7ca92959d5b5ec42",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Are there any local specialty dishes?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "ba1e1c65681fadb7990490355534e637",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is there a luggage storage service?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "783297b9ba780e2427f04bad72011304",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "What is the Wi-Fi password?",
            "language_code": "en-US",
            "audio_path": None
        },
        {
            "id": "461639a7803798622b21a728d6fc6c3f",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Where is the restroom, please?",
            "language_code": "en-US",
            "audio_path": None
        }
    ],
    "ar-LB": [
        {
            "id": "e3c6839bd808d1a5fddfaa1017c3e3be",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "قديش حق هيدا؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "af181e33dfcfe75c977f3b2c8fda8c18",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "فيه أطباق محلية مميزة؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "e27522a6538fadf8a21167ea0b9594f8",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "في خدمة تخزين الأمتعة؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "7fd4b29618f21db204f1eca1d1b1fc28",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "شو كلمة سر الواي فاي؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "0c60d90580d5d2043076cd3575d90cf6",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ممكن تخبرني وين الحمّام؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "cd95582405cd8d03f3ac54e96f28ba93",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "وين فيني صرّف عملة؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "96282725705786149ee492deacf3dae6",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "فيك تدفع بالبطاقة المصرفية؟",
            "language_code": "ar-LB",
            "audio_path": None
        },
        {
            "id": "75094acf7002394434f3bca4e2749212",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "لو سمحت، وين أقرب محطة مترو؟",
            "language_code": "ar-LB",
            "audio_path": None
        }
    ],
    "el-GR": [
        {
            "id": "028af785dc687905cb8fa0be94c00408",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Ποιος είναι ο κωδικός του ασύρματου δικτύου;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "d4f3b415f2246307b30b3bde75c255df",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Μπορείτε να μου πείτε πού είναι η τουαλέτα;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "d32708663cca2267198927ffd600cd68",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Πού μπορώ να ανταλλάξω νόμισμα;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "a9d87afd4ca80681e83ac96ef829912d",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Μπορώ να πληρώσω με πιστωτική κάρτα;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "a122f002d602a4fb5cc07349e0d21359",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Μπορείτε να μου πείτε πού βρίσκεται ο πλησιέστερος σταθμός του μετρό;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "ad52f91fa2c07ef30dc6ba520f7ca4ea",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Μπορείτε να μου πείτε πόσο κοστίζει αυτό;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "e847d1a32407193b5f6c417c2fb67216",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Υπάρχουν τοπικά παραδοσιακά πιάτα;",
            "language_code": "el-GR",
            "audio_path": None
        },
        {
            "id": "1b0bb43654c0535725fe95fc3021541b",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Υπάρχει υπηρεσία φύλαξης αποσκευών;",
            "language_code": "el-GR",
            "audio_path": None
        }
    ],
    "ar-LY": [
        {
            "id": "ce5991091a633e70ccfb04bc50ce3d90",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "بكم هذا؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "6298d2fc0617bc097fce33c05f9196a6",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "شنو كلمة سر الشبكة اللاسلكية؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "e2d2a762c670381609d7219de61b00e7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "فين موجود الحمّام؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "373a64c041e62ebceca4322f1610ff4c",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "فين نقدر نبدل العملة؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "392f0e298cb98298c0914db857d070e5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع ببطاقة الائتمان؟",
            "language_code": "ar-LY",
            "audio_path": None
        },
        {
            "id": "c5d49008bf2e2e6129d1c579f388408b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "وين محطة المترو القريبة؟",
            "language_code": "ar-LY",
            "audio_path": None
        }
    ],
    "bn-IN": [
        {
            "id": "b2302d1b289f08cfef53668a7d977cc0",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "কোথায় মুদ্রা বিনিময় করা যেতে পারে?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "a42f752104cb00c8047d3b032fed5819",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ক্রেডিট কার্ড ব্যবহার করা যাবে কি?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "4ae788fa3606f225a73a6ff9fcd9b4ea",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "নিকটতম মেট্রো স্টেশন কোথায় আছে, দয়া করে বলবেন?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "354f13e82b79ee2ac1f92ca44921aa1e",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "দয়া করে বলবেন, এটা কত দাম?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "5dcb04e227cf760b9673b3534a24eca3",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "কোনো স্থানীয় বিশেষ খাবার আছে কি?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "583d47b6b57b627142170a9d8607bf96",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "এখানে কি লাগেজ জমা রাখার সেবা আছে?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "b4a88ec1ec67c65763f7ce453ab189e7",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ওয়াইফাই নেটওয়ার্কের পাসওয়ার্ড কী?",
            "language_code": "bn-IN",
            "audio_path": None
        },
        {
            "id": "87fe24761d58c82e3e91532b892c9f3a",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "অনুগ্রহ করে বলুন, শৌচালয় কোথায়?",
            "language_code": "bn-IN",
            "audio_path": None
        }
    ],
    "ar-SY": [
        {
            "id": "2cc6541036f7a7d1526f13b5a887abbd",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا من فضلك؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "c6063cdfa078a8d40911598e81776175",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل يوجد أي أطباق محلية مميزة؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "52a3df609ddbff79378ac74b2b1be009",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة تخزين الأمتعة؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "f9f5627189e6565b9451de875bbd4085",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة مرور الشبكة اللاسلكية؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "1faf5a97c62d6e7816f2c2d8275121e7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "لو سمحت، أين الحمام؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "0ce9147718be5bbdf4351a7e88fcd393",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن تبديل العملات؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "2247fc5c010884ea8cce051fd4b880e7",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع بواسطة بطاقة الائتمان؟",
            "language_code": "ar-SY",
            "audio_path": None
        },
        {
            "id": "64b96ae6a3e0fb3e5cf2c8c47f1022c3",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "لو سمحت، أين أقرب محطة مترو؟",
            "language_code": "ar-SY",
            "audio_path": None
        }
    ],
    "km-KH": [
        {
            "id": "47934346e0560408da959e0fec345e20",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ពាក្យសម្ងាត់បណ្តាញអ៊ីនធឺណិតគ្មានខ្សែគឺអ្វី?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "1b889767822b2cd5dc732948dc0c6d5c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "សូមសួរ បន្ទប់ទឹកនៅឯណា?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "7118be62bc4be8a6ee039bb8c87c8955",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "តើអាចដូរប្រាក់បាននៅឯណា?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "830a66d082f7b75e93e48f08aa2a76d4",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "អាចទូទាត់ដោយកាតឥណទានបានទេ?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "5c677cd4462e9b52dd15df2e1712c7f6",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "សុំទោស ស្ថានីយរថភ្លើងក្រោមដីដែលនៅជិតបំផុតនៅកន្លែងណា?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "e390cdc3c3f597fce1e6abd3b3ee4c88",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "សុំទោស ប៉ុន្តែតើអីវ៉ាន់នេះមានតម្លៃប៉ុន្មាន?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "a784ce30af1ef0af21ce888c6edef72a",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "មានម្ហូបពិសេសតំបន់អ្វីខ្លះទេ?",
            "language_code": "km-KH",
            "audio_path": None
        },
        {
            "id": "1da5325e9e778bdeb600795cd5c7876b",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "មានសេវាកម្មផ្ទុកវ៉ាន់ដាក់ទុកដែរឬទេ?",
            "language_code": "km-KH",
            "audio_path": None
        }
    ],
    "ga-IE": [
        {
            "id": "94433a8d0a76577e11be50b4977bd437",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Cá háit is féidir airgeadra a mhalartú?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "566977647e42a05a94a6c036fbc4865c",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "An féidir cárta creidmheasa a úsáid?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "140816a1c61ee3f4199c2e526414b5a1",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "An féidir leat a rá liom cá bhfuil an stáisiún meitreo is gaire?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "487d7e31919141bd972ad1f7f15bd797",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Cé mhéad atá air seo, le do thoil?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "75c0005b0030e9b0500a81d0257dd1ce",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "An bhfuil aon bhia áitiúil speisialta ann?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "368b519f22072e85ee5eff6b90270d1a",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "An bhfuil seirbhís stórála bagáiste ar fáil?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "527ef102bf085489451be041cd00cc90",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Cad é pasfhocal an líonra gan sreang?",
            "language_code": "ga-IE",
            "audio_path": None
        },
        {
            "id": "dc58b63f4eb8010888e19a3b3dd75d43",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "An bhfuil an leithreas anseo?",
            "language_code": "ga-IE",
            "audio_path": None
        }
    ],
    "af-ZA": [
        {
            "id": "7141a6b29ea673b7315ce1e9f4ef58d2",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hoeveel kos hierdie asseblief?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "97f4abc9ff3249873e703bdbc3bda3de",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Is daar enige plaaslike spesialiteitsgeregte?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "34d190c223ca08ba0e9bd749b56444b7",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is daar 'n bagasiebewaaringsdiens?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "c6e4d1dda7461c46bfb8f5c7043cfe13",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wat is die wagwoord vir die draadlose netwerk?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "b8fbeff0961d4a5ba999372158e3b52c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Waar is die badkamer?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "d23b4c31b08a60f69acdd1ac16b1f452",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Waar kan ek geld wissel?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "c645792e1f377fcebea9a92bd47774aa",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan ek 'n kredietkaart gebruik?",
            "language_code": "af-ZA",
            "audio_path": None
        },
        {
            "id": "12b35286c62647a9ef440ca73e4287cf",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Verskoon, ek is nie in staat om te help met daardie versoek nie.",
            "language_code": "af-ZA",
            "audio_path": None
        }
    ],
    "mn-MN": [
        {
            "id": "cbe355f4c9367288890057f56c8c107e",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Утасгүй сүлжээний нууц үг юу вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "3a8e7129b006f8dda33220f2ef1ffc6b",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Уучлаарай, бие засах газар хаана байдаг вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "ead3116e620c9465c7fe1c29bafa80fd",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Валютыг хаана солиулж болох вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "ee18ee71ff407166899495be14c2a805",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Кредит карт уншуулж болох уу?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "88b7f64df52f9dc04d6728672d384812",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Уучлаарай, хамгийн ойрын метроны буудал хаана байна вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "3a0970930407a8b32be2a10a22b3c1ff",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Уучлаарай, энэ хэдэн төгрөгийн үнэтэй вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "d0e84ab11c51d36ba9253ea62c7364b2",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Энд ямар орон нутгийн онцлог хоол байдаг вэ?",
            "language_code": "mn-MN",
            "audio_path": None
        },
        {
            "id": "99b1ac822f214e60df7edaba556deea6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Танд ачаа хадгалах үйлчилгээ бий юу?",
            "language_code": "mn-MN",
            "audio_path": None
        }
    ],
    "mk-MK": [
        {
            "id": "463789de55323bd285b1a5cbdc7f3c5e",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Каде може да се размени валута?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "dd3598f4aa829779c6625f888384c55e",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Може ли да се плати со кредитна картичка?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "dababf581d818b212f31407fc502426b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Можете ли да ми кажете каде се наоѓа најблиската метро станица?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "686c3fe985d0665250d3936e09a005a4",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Колку чини ова?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "4d0437034b02c095985ecc5d622abf88",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Има ли некое локално специјално јадење?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "616c81d0acfe00f628c7dd43710bc11a",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Дали имате услуга за чување багаж?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "c5fa4c4fff23fc4beefa49edf8b817d7",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Која е лозинката за безжичната мрежа?",
            "language_code": "mk-MK",
            "audio_path": None
        },
        {
            "id": "775070e24ea47a66d243cec4a09d87a3",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Извинете, каде се наоѓа тоалетот?",
            "language_code": "mk-MK",
            "audio_path": None
        }
    ],
    "ro-RO": [
        {
            "id": "175c1d748de0a6a8f7be3779b2927040",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Care este parola rețelei wireless?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "40fe0b4b96216e06ef330ffd9df961a5",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Unde este toaleta, vă rog?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "8a9dcb86a18cd989458180b1be808f08",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Unde pot schimba valuta?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "c53c0f5828e24e7df2ea657cd1cb9c94",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Se poate plăti cu cardul de credit?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "6721bc3625cbbed73bfea758baa2f8de",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Unde este cea mai apropiată stație de metrou?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "bad18600a0926acee5cc34b085047260",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Există vreun fel de mâncare local specific?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "4ae447c8fa093ddaf17aea8764c3ec94",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Cât costă acesta?",
            "language_code": "ro-RO",
            "audio_path": None
        },
        {
            "id": "a0dafd44c8cc90cc7e94c837b1d4e661",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Există servicii de depozitare a bagajelor?",
            "language_code": "ro-RO",
            "audio_path": None
        }
    ],
    "fil-PH": [
        {
            "id": "b038697ab9b1bad3f41bae9b34db9c13",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Magkano po ito?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "caaa1d1a4e814b4241ef5d28f2115e6f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Mayroon bang mga lokal na espesyalidad?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "a8daefe6e3f94ca88d27bba9ddf8216e",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "May serbisyo ba para sa pag-iimbak ng bagahe?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "83525a22cf410ee7ffd528493dd3642c",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Ano ang password ng wireless network?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "7a9797aa3e46e4055e4f4000e863f703",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Pwede po bang malaman kung saan ang banyo?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "4d182b7abe7c744b7680ce6a1d8e5154",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Saan maaaring magpalit ng pera?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "d298b1ac8a936fc8a12bcaec0e5cf482",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Pwede bang gumamit ng credit card?",
            "language_code": "fil-PH",
            "audio_path": None
        },
        {
            "id": "b831bff1d2e5ed6b86e8bbc4f286a66b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Pwede po bang itanong kung saan ang pinakamalapit na istasyon ng tren?",
            "language_code": "fil-PH",
            "audio_path": None
        }
    ],
    "ta-IN": [
        {
            "id": "893304ee9ee5fed829d7f21923145ceb",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "நாணயத்தை எங்கு மாறுபடுத்தலாம்?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "dba9ee4f735e4a0ff73b00aeee7d2cdc",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "கிரெடிட் கார்டு பயன்படுத்தலாமா?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "fef099495352d221bb432d3c4ca39d50",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "மன்னிக்கவும், அருகிலுள்ள மெட்ரோ நிலையம் எங்கு உள்ளது?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "ddd19bb261594abf41d5053ac3d2be23",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "ஏதேனும் உள்ளூரின் சிறப்பு உணவுகள் இருக்கிறதா?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "fef2f757256a4fd37998d9f9ecee4a0f",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "இந்தது எவ்வளவு?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "e5e3b8ae9ba8b4dd1a799ce0d56964ef",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "இங்கே பயணப்பொருள் சேமிப்பு சேவை உள்ளதா?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "3214c313b7a4ba61938ec58342a5200a",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "வயர்லெஸ் நெட்வொர்க் கடவுச்சொல் என்ன?",
            "language_code": "ta-IN",
            "audio_path": None
        },
        {
            "id": "c8b48d9e43dfab0aec7905e9ea0b7aeb",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "குழம்பறை எங்கு உள்ளது?",
            "language_code": "ta-IN",
            "audio_path": None
        }
    ],
    "hu-HU": [
        {
            "id": "6dbeaad7a9eb40699c050a3c31700b00",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Mennyibe kerül ez, kérem?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "52ae070c384126dac1a118bdc35bc08e",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Van valamilyen helyi specialitás?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "26a098364c75e4f4071f1a2f6423c457",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Van csomagmegőrző szolgáltatás?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "2812d808774a065e3334e4bb4a89e2f5",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Mi a vezeték nélküli hálózat jelszava?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "dac97beebe465d62ab7f7bf6aaec33a6",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Hol van a mosdó, kérem?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "6e9b4e9c478fc0cab8cb21cd3a9cab0a",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Hol lehet valutát váltani?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "90cb13ccdaf14efee29770e84640b13a",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Lehet bankkártyával fizetni?",
            "language_code": "hu-HU",
            "audio_path": None
        },
        {
            "id": "fed88611436760579265d6562bae72ed",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Elnézést, hol van a legközelebbi metróállomás?",
            "language_code": "hu-HU",
            "audio_path": None
        }
    ],
    "sr-RS": [
        {
            "id": "c6269f1d09e1f06be6d40f6e8a445c7f",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Koja je lozinka za bežičnu mrežu?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "04494627b385e5843e13cff3cac876ac",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Извините, где је тоалет?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "566a1138d363ae15db84f7ded5f6ea6e",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Gde mogu da zamenim novac?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "3299337be2a978ea2ef61faef72d39c9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Da li mogu platiti kreditnom karticom?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "2bbb4c9d24aadefd1eb8064573eb9348",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Извините, где је најближа метро станица?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "09d316e6c5086999c5df23d4a212fda6",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Da li imate neko lokalno specijalno jelo?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "8e6e90eb4689dba181c04d3381c5f74d",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Извините, колико ово кошта?",
            "language_code": "sr-RS",
            "audio_path": None
        },
        {
            "id": "69c848dc069d5af08e7eb8d44706f97f",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Da li imate uslugu čuvanja prtljaga?",
            "language_code": "sr-RS",
            "audio_path": None
        }
    ],
    "th-TH": [
        {
            "id": "6ce7984910ad3e1022f257e473e5c3ff",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ที่ไหนสามารถแลกเปลี่ยนเงินตราได้?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "dcc8cc3de185d04962450f7e80b626de",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "สามารถรูดบัตรเครดิตได้ไหม?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "11e696576d85cb235f89129144eab9ac",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ขอโทษครับ/คะ สถานีรถไฟฟ้าที่ใกล้ที่สุดอยู่ที่ไหน?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "e060cc86dfecb693c2c0f0586e4fc4e1",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "มีอาหารท้องถิ่นจานพิเศษอะไรบ้าง?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "6986b338d151ab689ff4c50c00f619fe",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ขอถามหน่อยว่าอันนี้ราคาเท่าไหร่?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "4c8b18c0b5eb71f61fc070ae3bb6e5a3",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "มีบริการรับฝากสัมภาระไหม?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "16f788f2238628e33e94315bc593d785",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "รหัสผ่านเครือข่ายไร้สายคืออะไร?",
            "language_code": "th-TH",
            "audio_path": None
        },
        {
            "id": "f43f926e1d343181d890a545170c914d",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ขอโทษนะครับ/ค่ะ ห้องน้ำอยู่ที่ไหน?",
            "language_code": "th-TH",
            "audio_path": None
        }
    ],
    "hy-AM": [
        {
            "id": "c895422979c38deca94357458e57f48f",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Կարո՞ղ եք ասել՝ սա որքան արժե։",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "0ef956836a2a7368f7c548e51a688861",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Կա՞ն տեղական առանձնահատուկ ուտեստներ:",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "817cd248c68b673e402efb37124c3b95",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ունե՞ք ուղեբեռի պահեստավորման ծառայություն։",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "57b21662945f4fe2107e2dbe6e69678a",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Անլար ցանցի գաղտնաբառը ինչպե՞ս է։",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "eaff01736ad890effce5d85721ed1e38",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Կներեք, որտե՞ղ է գտնվում զուգարանը։",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "5303fd43efe4683604f7bc152d474211",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Որտեղ կարելի է փոխանակել արժույթը՞:",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "2d66b5fc6e2993a6cf5ac304a154dd3e",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Կարելի՞ է վճարել վարկային քարտով:",
            "language_code": "hy-AM",
            "audio_path": None
        },
        {
            "id": "fe5a0671b3e196920bb8bc73a998f214",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Կարո՞ղ եք ասել՝ որտեղ է մոտակա մետրոյի կայարանը:",
            "language_code": "hy-AM",
            "audio_path": None
        }
    ],
    "zu-ZA": [
        {
            "id": "d0098575998eeaba5b005dda5a798f9d",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Iyini iphasiwedi yenethiwekhi engenantambo?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "ebb93230b79e4011b2a8d9017328875e",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Ngicela ukubuza, ithoyilethi ikuphi?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "62af7ceb68f7b050a684d8de1bd17980",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kuphi lapho ungashintshanisa khona imali?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "f0e87db3b6d7c89490bac1ea5d988c57",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Ngabe ningakhokha ngekhadi lesikweletu?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "43ffc780ca565be684834377037dcc66",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Ngicela ukubuza, isiteshi esiseduze kakhulu semetro sikuphi?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "3782699940b437cafaea8b05cac77a15",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ingabe kukhona ukudla okwehlukile kwasendaweni?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "fe319611be7d6a03a15491bd6962f26c",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Ngicela ukubuza, lokhu kubiza malini?",
            "language_code": "zu-ZA",
            "audio_path": None
        },
        {
            "id": "762feb68666d52325d1921b41746f09b",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ngabe kunenkonzo yokugcina izimpahla?",
            "language_code": "zu-ZA",
            "audio_path": None
        }
    ],
    "ka-GE": [
        {
            "id": "b679411e6adf6e2c95a5411ce4030cab",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "არის რაიმე ადგილობრივი ტრადიციული კერძი?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "9690f6946d1e4bc0c811138257ec65a9",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "გთხოვთ, ეს რამდენი ღირს?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "35adb320a1c3b6d9990bf7fccbf41822",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "აქვს ბარგის შენახვის სერვისი?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "c9510764d93a7fa2db8c84c774b65534",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "რა არის უკაბელო ქსელის პაროლი?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "b85a37db2d9de62a51e058bae7cd98de",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ბოდიშით, სად არის საპირფარეშო?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "659ce401659063cefc00bfd68d8f533a",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "სად შეიძლება ვალუტის გადაცვლა?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "ea4ec04378605d577b841612209dbb77",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "შეგიძლიათ საკრედიტო ბარათით გადახდა?",
            "language_code": "ka-GE",
            "audio_path": None
        },
        {
            "id": "54ba88a7c44c8b6334fcbd243e2b4db9",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "გთხოვთ, მითხრათ, სად არის უახლოესი მეტროს სადგური?",
            "language_code": "ka-GE",
            "audio_path": None
        }
    ],
    "ar-IQ": [
        {
            "id": "8487e50d840a25770a1a4d1a0d8bbffd",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "شنو رمز الشبكة اللاسلكية؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "4a0564129e118e259dc5b1816686c3cd",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ممكن أعرف وين الحمام؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "481530f43022deff3199d23cd35f6c87",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "وين أگدر أصرف العملة؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "0c5292bf3f432e50674c0322eb2494aa",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "تكدر تدفع بالبطاقة الائتمانية؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "9b8e677799e24e703dfd13b7cb12b0c2",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ممكن تعرفني وين أقرب محطة مترو؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "df4b9a787a692df1a5fd86fc06eac5db",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "شقد سعر هذا؟",
            "language_code": "ar-IQ",
            "audio_path": None
        },
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-IQ",
            "audio_path": None
        }
    ],
    "pt-PT": [
        {
            "id": "3c4203a2e1fe97468c922419f3702e7f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Há algum prato típico local?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "5d63136af605441632724ff0dccd5757",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Quanto custa isto, por favor?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "645e01baca2e1c0b29551e8a7f587f7e",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Há serviço de armazenamento de bagagem?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "0dc447766da52d26e0098658e41b5f4c",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Qual é a palavra-passe da rede sem fios?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "b157c7a1a323b7b87747117b86927fd5",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Onde fica a casa de banho?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "241387d34928f4cd6b70f80baef291c6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Onde posso trocar moeda?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "cd8129def92b7a0916092befbef87c05",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Posso pagar com cartão de crédito?",
            "language_code": "pt-PT",
            "audio_path": None
        },
        {
            "id": "792645503be88fd55d4be19b5d8e2a59",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Onde fica a estação de metro mais próxima, por favor?",
            "language_code": "pt-PT",
            "audio_path": None
        }
    ],
    "bs-BA": [
        {
            "id": "cbbfd50ddfd5effcfe1a21fa777a9be9",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Koja je šifra za Wi-Fi mrežu?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "92f4cebbd746dcfcb8b58e5024525590",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Izvinite, gdje je toalet?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "933348404abb8731df95d357d728928a",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Gdje se može zamijeniti valuta?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "3299337be2a978ea2ef61faef72d39c9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Da li mogu platiti kreditnom karticom?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "93a24712eb210ad40d3694fc7dae3166",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Molim vas, gdje se nalazi najbliža stanica metroa?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "87f56e4d10c16778ffb8f17dce6d6ca9",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Koliko ovo košta?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "f676446807b06f0eaaccac78ad8b2427",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ima li nekih lokalnih specijaliteta?",
            "language_code": "bs-BA",
            "audio_path": None
        },
        {
            "id": "52457b393f3b7791887ae83c746470b5",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ima li usluga čuvanja prtljaga?",
            "language_code": "bs-BA",
            "audio_path": None
        }
    ],
    "lo-LA": [
        {
            "id": "40413b385f328b0b3fe81fde659aaad6",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ລະຫັດຜ່ານເຄືອຂ່າຍໄຮ້ສາຍແມ່ນຫຍັງ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "5003896cb6c6c42c3508881cf4dd66bd",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "ຂໍຖາມຫ້ອງນ້ຳຢູ່ໃສ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "ace821b9b4e7204e06c9601837d4b2b8",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "ທີ່ໃດສາມາດແລກປ່ຽນເງິນໄດ້?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "365dc75da3edd00e52d249ded2e33d94",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "ສາມາດໃຊ້ບັດເຄຣດິດໄດ້ບໍ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "8d6b98a805f54e223db69ab6ae47b11c",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "ຂໍຖາມວ່າສະຖານີລົດໄຟໄຕ້ທີ່ໃກ້ທີ່ສຸດຢູ່ໃສ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "6bb2e06a6317a328c1365649cbd3bb44",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "ມີອາຫານທ້ອງຖິ່ນທີ່ເປັນເອກະລັກບໍ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "21963be08244e25ca23930da4c9225ce",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "ຂໍຖາມວ່າອັນນີ້ລາຄາເທົ່າໃດ?",
            "language_code": "lo-LA",
            "audio_path": None
        },
        {
            "id": "167c84e81efaa6d5030ddccbaa0971c8",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "ມີບໍລິການຝາກເຄື່ອງບໍ?",
            "language_code": "lo-LA",
            "audio_path": None
        }
    ],
    "bg-BG": [
        {
            "id": "29a2bc9ebecea65f6f65f6137b9e5639",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Колко струва това?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "4e3aef45df138228345b3b1b6d61d31a",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Има ли някакви местни специалитети?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "0f2937ac297756dc6582f9ea952f54a6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Има ли услуга за съхранение на багаж?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "2a08c69e6d8c33bb54299657b0cd9ccf",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Каква е паролата за безжичната мрежа?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "2acd887fc96681ef4a3ae405eadf48fe",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Извинете, къде се намира тоалетната?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "b663a32afb522cf0998dcd3d0165b76d",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Къде мога да обменя валута?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "6a4c609ded6d38a8a63183903afcba7d",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Може ли да платите с кредитна карта?",
            "language_code": "bg-BG",
            "audio_path": None
        },
        {
            "id": "edf2cf3997c71e14d0a2d2572919b9b1",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Извинете, къде се намира най-близката метростанция?",
            "language_code": "bg-BG",
            "audio_path": None
        }
    ],
    "tr-TR": [
        {
            "id": "79b73746bfa539918514c483bae14231",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Kablosuz ağ şifresi nedir?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "ee85d26f15a1e5d7a42aa1f5f6b9f17c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Affedersiniz, tuvalet nerede?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "1628c78ab6a9d4c3976753800b7b540b",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Nerede para bozdurabilirim?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "76b0e9026ae81c88217d16891b62c414",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kredi kartı geçerli mi?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "920d61784a6abb23c584ae3af0648d1c",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "En yakın metro istasyonu nerede?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "7a61f6d06898f4faa139e17da4a4050b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Yerel özel yemekler var mı?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "07a7d7815eee016ab670d5c9875d53c2",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Bu ne kadar?",
            "language_code": "tr-TR",
            "audio_path": None
        },
        {
            "id": "d9a710502227df2e1465ccf79f1d02ef",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Bagaj emanet hizmeti var mı?",
            "language_code": "tr-TR",
            "audio_path": None
        }
    ],
    "ms-MY": [
        {
            "id": "8694a0d778fd397b0d7a3fd4c853c399",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Berapa harga ini?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "4f119300b71e971fffc4cfc39e5d8833",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Adakah terdapat hidangan tempatan yang istimewa?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "2d06228d078746ea61695ebd09f5ca79",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Adakah terdapat perkhidmatan simpanan bagasi?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "14aa55843bbfc49cd8c328f5ba68d112",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Apakah kata laluan rangkaian tanpa wayar?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "a6279575e2248bacaba0c1249e60624c",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Boleh saya tahu di mana tandas?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "a69157a570fbfab8b0dcb24ee756fda7",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Di mana boleh menukar mata wang?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "8949a11bb639764487007d6bbc7d23a2",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Boleh bayar dengan kad kredit?",
            "language_code": "ms-MY",
            "audio_path": None
        },
        {
            "id": "72f33ce68d1a85a7efaf91120a8d41d0",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Boleh saya tahu di mana stesen metro yang terdekat?",
            "language_code": "ms-MY",
            "audio_path": None
        }
    ],
    "sv-SE": [
        {
            "id": "a861ebed11a3179444fdccaa47fb88f3",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Vad är lösenordet till det trådlösa nätverket?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "da06903d1de48aeb81c6eb0d2626b6e1",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Ursäkta, var ligger toaletten?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "1066c42374fec18fbc1b2480bfa6460b",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Var kan man växla valuta?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "7e812008dc86b986f464b7125bf9821b",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan jag betala med kreditkort?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "bc087ccd2fb0daf863d926b2a1c0ecb2",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Ursäkta, var ligger den närmaste tunnelbanestationen?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "17e4dfc8d2c98260f200de053251c972",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Finns det några lokala specialiteter?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "cbd8361f28d4a6f57763e44f81f2259f",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Ursäkta, hur mycket kostar detta?",
            "language_code": "sv-SE",
            "audio_path": None
        },
        {
            "id": "95c3b0ed3ca8523419dbb820f3a4b265",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Finns det bagageförvaring?",
            "language_code": "sv-SE",
            "audio_path": None
        }
    ],
    "zh-TW": [
        {
            "id": "0286b608315721c58790e1a8b43bb330",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有什麼當地特色菜嗎？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "2222482762e8e091535ac05e86e9582b",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服務嗎？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "e91b771cbcf4a9ae615d1ba17ae4c8ae",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "請問這個多少錢？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "457bab5d622a4c93272a956650417083",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "無線網路密碼是什麼？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "e7df95ac69a57dfa1725ba6c9002f731",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "請問洗手間在哪裡？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "d7ac066ff5bcb4dc81f5406674b71494",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪裡可以兌換貨幣？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "3c3a1c5dd6603c087b6ab0ef0f1ac9d9",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "可以刷信用卡嗎？",
            "language_code": "zh-TW",
            "audio_path": None
        },
        {
            "id": "304a805639ed66096ba5c007ab90ea80",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "請問最近的捷運站在哪裡？",
            "language_code": "zh-TW",
            "audio_path": None
        }
    ],
    "et-EE": [
        {
            "id": "324b29a4f3482978ba37770c6bef770e",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Mis on WiFi parool?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "29a398770262fbdbd41e365fb267ce91",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Vabandage, kus asub tualett?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "28852d806d2c33697951c391b75271a8",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kus saab valuutat vahetada?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "85a01dc6d51f223169c1b6e1ba69023d",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kas ma saan maksta krediitkaardiga?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "a399871b69bd21ce623fc14be0c76c6b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Vabandage, kus asub lähim metroojaam?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "6b20e43b0b65ba5deb286b3962bd514d",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Kas on mingeid kohalikke roogasid?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "a1f2aaaad98c1bed7300e172f81977a1",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Kui palju see maksab?",
            "language_code": "et-EE",
            "audio_path": None
        },
        {
            "id": "5ca4dcf7073fde9b65ad58720f350e4c",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Kas teil on pagasihoiu teenust?",
            "language_code": "et-EE",
            "audio_path": None
        }
    ],
    "nl-BE": [
        {
            "id": "653c3f5bb9af498cdf890acc20081549",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Wat is het wachtwoord van het draadloze netwerk?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "e8ca6889e6c60632dc536019396f3e96",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Waar is het toilet, alstublieft?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "39f380ab7599c76d13f0fc3d560c1bfe",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Waar kan ik valuta wisselen?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "68f8561afa5d6e6318037afb7acf6aa8",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan ik met een kredietkaart betalen?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "9ceaec355cdded834b9c53afb213002d",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Waar is het dichtstbijzijnde metrostation, alstublieft?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "a8337559648d70b8627216bdc1f91feb",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Zijn er lokale specialiteiten?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "c603b92cb81ddeed9945e0b58296aa0e",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hoeveel kost dit, alstublieft?",
            "language_code": "nl-BE",
            "audio_path": None
        },
        {
            "id": "936c28ccd5881e581756c611bf022c5e",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Is er een bagagedepotservice?",
            "language_code": "nl-BE",
            "audio_path": None
        }
    ],
    "pl-PL": [
        {
            "id": "c2555f5f9445676763ba026474fad135",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Jakie jest hasło do sieci bezprzewodowej?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "346dc7140abe4b483b9486bb73bbc032",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Przepraszam, gdzie znajduje się toaleta?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "513e0ae6cb7a1dac7a8e1ab33cc91a94",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Gdzie można wymienić walutę?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "eb939d01cc0c23b242433cbe28bf5e17",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Czy można płacić kartą kredytową?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "f0bc8d3da9da007c70422d28f7164313",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Przepraszam, gdzie znajduje się najbliższa stacja metra?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "32f76e57be42cbe8fc413fb456bf2ba0",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Czy są jakieś lokalne specjały?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "bcbb1987902cf263d8cbde989ca50aa4",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Przepraszam, ile to kosztuje?",
            "language_code": "pl-PL",
            "audio_path": None
        },
        {
            "id": "d27dbec185237ed06ae3ddedced158eb",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Czy jest dostępna usługa przechowywania bagażu?",
            "language_code": "pl-PL",
            "audio_path": None
        }
    ],
    "ar-TN": [
        {
            "id": "ce8b5a96e21c20c768fd61a408948060",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "شنو كلمة السر متاع الواي فاي؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "0bce63152f0be126828336a447a25dc4",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "عفوًا، وين موجود المرحاض؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "2bfa7bbbb38cff1207c93e901108b953",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن صرف العملات؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "fd575a9cfa88fe641108ac4e168c69f1",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "يمكن الدفع بالكارت البنكي؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "25a1084c9d0f122901139442c3315e41",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "عفواً، وين أقرب محطة مترو؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "3689b3740f0705d85186029389505863",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أكلات محلية مميزة؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "909641baea7dcb01e6df44dc60f50b65",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "قدّاش تكلّف هذي؟",
            "language_code": "ar-TN",
            "audio_path": None
        },
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-TN",
            "audio_path": None
        }
    ],
    "ca-ES": [
        {
            "id": "64f1bc2707e6dea0bfd01ea49a7583e2",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Quina és la contrasenya de la xarxa sense fils?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "3b73dc85ae78de8769acd2d684e94246",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Perdoni, on és el lavabo?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "274a7335feac8b30bc0d9c5a02337f01",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "On es pot canviar moneda?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "152ba2f10d875b80eeac691fe7f9fdbb",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Es pot pagar amb targeta de crèdit?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "9df49e9dc263d8c1ca566da556bdb1d0",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Perdoni, on és l'estació de metro més propera?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "9b5d6b774c1fb82dd8ebf1c90b0c0ded",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Hi ha algun plat típic de la zona?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "1db7501cc3dea42bbcde624895968b1a",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Quant costa això, si us plau?",
            "language_code": "ca-ES",
            "audio_path": None
        },
        {
            "id": "07145312fb4245aa1019d7be20a22cb5",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Hi ha servei de consigna d'equipatges?",
            "language_code": "ca-ES",
            "audio_path": None
        }
    ],
    "cs-CZ": [
        {
            "id": "9e96a8f4923269fb52a088e6b0f0791b",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Jaké je heslo k bezdrátové síti?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "0633fd13d03948b869a501cc5ef82f04",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Kde je prosím toaleta?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "36ba60e8ca6bd3f25f383d9a24d9ea4a",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kde lze vyměnit měnu?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "556608229e71f7680a053cfec0442aaf",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Mohu platit kreditní kartou?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "bd576fd36229706574b3f1f7ac3ec01c",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Můžete mi prosím říct, kde je nejbližší stanice metra?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "cb083c9ec1601469843922d1924d9351",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Kolik to stojí, prosím?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "8ec44bc5e3f33dde04ca230ba46c7384",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Máte nějaké místní speciality?",
            "language_code": "cs-CZ",
            "audio_path": None
        },
        {
            "id": "c25c7dafab7200343aa93972e4018c2d",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Je k dispozici služba úschovy zavazadel?",
            "language_code": "cs-CZ",
            "audio_path": None
        }
    ],
    "ne-NP": [
        {
            "id": "40a07c2d093583bc65d9141ba77db69b",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "वाइफाइ पासवर्ड के हो?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "2ae2a3ef28a9b854907de635a7244ec1",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "शौचालय कहाँ छ?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "5cd6972fd3ce9865f1931f8dbb000ce6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "कहाँ मुद्रा साट्न सकिन्छ?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "172e00685ef40439a5fc7a43af16a872",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "क्रेडिट कार्ड प्रयोग गर्न मिल्छ?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "0039439e3c1ebaa707f94149eed7210b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "नजिकैको मेट्रो स्टेशन कहाँ छ?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "35dbc071b09a16145daceefd2f7e123d",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "कृपया भन्नुहोस्, यो कति मूल्यको हो?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "19ae7b42ab0d44f322464974deb69a48",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "यहाँ कुनै स्थानीय विशेष परिकार छ?",
            "language_code": "ne-NP",
            "audio_path": None
        },
        {
            "id": "ac5fdaeff0bd21c032b282294d44dc50",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "यहाँ सामान राख्ने सुविधा छ?",
            "language_code": "ne-NP",
            "audio_path": None
        }
    ],
    "sl-SI": [
        {
            "id": "48dcb300daa7f91c983ba7565aea2c2b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ali imate kakšno lokalno specialiteto?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "33137ee7872eeb9a231f79c6f1ecbede",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Ali imate storitev za shranjevanje prtljage?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "9d880f4c250b48a51ff6ccf1db1b97c4",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Kakšno je geslo za brezžično omrežje?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "048564aa7e981f2a4ffb3e843af02d97",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Ali mi lahko poveste, kje je stranišče?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "6b0cba060ca123e860598db7ce9ac408",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kje lahko zamenjam valuto?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "4c1f32e8679075130c0f405eec95e473",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Ali lahko plačam s kreditno kartico?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "381cf8c6e41357995d02e8c614f1d530",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Oprostite, kje je najbližja postaja podzemne železnice?",
            "language_code": "sl-SI",
            "audio_path": None
        },
        {
            "id": "d41d8cd98f00b204e9800998ecf8427e",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Koliko to stane?",
            "language_code": "sl-SI",
            "audio_path": None
        }
    ],
    "sk-SK": [
        {
            "id": "878af95656c6424e97b77f6fa2613782",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Aké je heslo na bezdrôtovú sieť?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "c289374310c6df452d750b5e1a26590b",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Prosím, kde sú toalety?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "f19800996ec0779532c26dd06979eae0",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Kde môžem vymeniť menu?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "0fa5ed9f46c47441cb8c32c24a0208f0",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Môžem zaplatiť kreditnou kartou?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "81e3b073c52b9c0fc68f3528985ab13b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Kde sa nachádza najbližšia stanica metra?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "9288a2bb4a0a2816f5852dddc3c7e056",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Koľko to stojí, prosím?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "3e727ae112307f9ca133d02a931183b8",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Máte nejaké miestne špeciality?",
            "language_code": "sk-SK",
            "audio_path": None
        },
        {
            "id": "620e6718f10fc8fc92adfcfd71b66162",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Máte službu na úschovu batožiny?",
            "language_code": "sk-SK",
            "audio_path": None
        }
    ],
    "zh-CN-sichuan": [
        {
            "id": "bd9aff487591506ce438d8d9fdde4be6",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有啥子本地特色菜哦？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "b189e78be3e3d7439869ddd671e17d54",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服务没得？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "e1a5148d80f6893ce568c7e7e6d31eb4",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "这个好多钱哦？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "51b92bc74c6cfb2052cfebfb54b4380d",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "无线网络密码是啥子？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "f8cb3b28ee2531065a3af980183c78a7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "请问厕所在哪儿哦？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "ad48510a2a74e51aff811d3bf0cbf5b6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪里可以换钱哦？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "dc14112621f88990355da69af10dcd7e",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "可以刷信用卡不嘛？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        },
        {
            "id": "53bebf96e040ddf92e4ff9ecf957140e",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "请问最近的地铁站在哪儿喃？",
            "language_code": "zh-CN-sichuan",
            "audio_path": None
        }
    ],
    "zh-CN": [
        {
            "id": "2c48c147175eeb852e7b0a5530880680",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "请问洗手间在哪里？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "e88c507dacbeccc9fe465af23550f492",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "无线网络密码是什么？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪里可以兑换货币？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "e101684f655b0418aa2dcc686195da88",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "可以刷信用卡吗？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "请问最近的地铁站在哪里？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "请问这个多少钱？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有什么当地特色菜吗？",
            "language_code": "zh-CN",
            "audio_path": None
        },
        {
            "id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服务吗？",
            "language_code": "zh-CN",
            "audio_path": None
        }
    ],
    "sq-AL": [
        {
            "id": "e8c33295c6fd400f77a3a73848c06259",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Fjalëkalimi i rrjetit pa kabëll cili është?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "f578c19f7897a0ece57a3d2586c326b5",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Ku është tualeti, ju lutem?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "796e58567eab8a4402ceba615bf618e6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Ku mund të shkëmbehen monedhat?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "52d783dd230524e2aeb5c7bc21b973fa",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "A mund të përdorni kartën e kreditit?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "380246cb645a3a06b8aab557328470a0",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Më falni, ku ndodhet stacioni më i afërt i metrosë?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "871a61e5420a87dc7c2701d5b6171587",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "A ka ndonjë specialitet lokal?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "39ca30b1176562e7143d65afc9dd83c9",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Sa më kushton kjo?",
            "language_code": "sq-AL",
            "audio_path": None
        },
        {
            "id": "e7fc35ef892dd99c1a01bdaca286c94d",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "A ka shërbim për ruajtjen e bagazhit?",
            "language_code": "sq-AL",
            "audio_path": None
        }
    ],
    "is-IS": [
        {
            "id": "8db9eab94f7927c601465fddbb876f19",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Eru til staðar einhverjar sérkenndar staðbundnar réttir?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "ef2cfc70fc481c659929cedc8cd4af18",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hvað kostar þetta?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "808bf32e0aef6f8887e9a7aaea415193",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Er hægt að geyma farangur hér?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "5a848cc91cb6ed0c0d5ffd21612b9be8",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Hver er lykilorðið fyrir þráðlausa netið?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "c6ef94441b2fea4d5f1099a450bf62ba",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Hvar er snyrtingin?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "211a312f6379776f6b86c30947436287",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Hvar er hægt að skipta gjaldeyri?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "439d73890f3ad49bdeaa608686727984",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Getur maður borgað með kreditkorti?",
            "language_code": "is-IS",
            "audio_path": None
        },
        {
            "id": "b7e69906fcce28005a10fd7463a3fe82",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Hvar er næsta neðanjarðarlestarstöð?",
            "language_code": "is-IS",
            "audio_path": None
        }
    ],
    "zh-HK": [
        {
            "id": "2cf00732eba0f6546d8ecc7d19743af9",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "無線網絡密碼係咩？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "c35e72a914299267f19bda2f182232fd",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "請問洗手間喺邊度？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "d7ac066ff5bcb4dc81f5406674b71494",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "哪裡可以兌換貨幣？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "9923573af2a32c41724e055931dd3d46",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "可以用信用卡嗎？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "8b56b0d15c069577bc321e852ab8dbe5",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "請問最近的地鐵站在哪裏？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "f31edf174cd79881b6d16250875a59fc",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "有咩本地特色菜？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "d0742b3eb0fec82fce3d8faa983984b7",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "請問這個幾錢？",
            "language_code": "zh-HK",
            "audio_path": None
        },
        {
            "id": "2222482762e8e091535ac05e86e9582b",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "有行李寄存服務嗎？",
            "language_code": "zh-HK",
            "audio_path": None
        }
    ],
    "ar-MA": [
        {
            "id": "a5c292677dcd6d50ae90aa3318c3d07f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "واش كاين شي أكلات محلية مميزة؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "4b2edb0a35c739b5c30f2be7097ec2f8",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "عفاك، شحال ثمن هاد الشي؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "34d61153860e7761c09ca8200b69e185",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "واش كاينة خدمة تخزين الأمتعة؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "37b4145501a3db0310ba0adfddcc128c",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هو رمز شبكة الواي فاي؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "a89ff65f8ca6570dd03d5ba1e5b5adb3",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "من فضلك، أين توجد دورة المياه؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "069213e6d13e5ea5c03aa5136e4faaa9",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "فين ممكن نصرف العملة؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "c7d0694a1023c20a77c094f49d17ba54",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "واش يمكن نخلص بالكارت ديال الكريدي؟",
            "language_code": "ar-MA",
            "audio_path": None
        },
        {
            "id": "451099cee32c4072deefcd6e0bb84145",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "فين كاين أقرب محطة ديال المترو؟",
            "language_code": "ar-MA",
            "audio_path": None
        }
    ],
    "it-IT": [
        {
            "id": "7c27a5c124040ec76dd835aca49da706",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Quanto costa questo?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "43cd8da4dade9fb5ffb026ed1d098b5e",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Ci sono piatti tipici locali?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "3ee182ecd3f4802de3389940fd8fed81",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "C'è un servizio di deposito bagagli?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "27bd9d7b964a6cb073ef889281e08579",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Qual è la password della rete Wi-Fi?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "4c4a248c168a39c17619a924e4c847b7",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Mi scusi, dove si trova il bagno?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "f373a0a44bd97f11cf88cfb65befb0e3",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Dove si possono cambiare le valute?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "273c4c818d865675741c6eddb009901b",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Si può pagare con carta di credito?",
            "language_code": "it-IT",
            "audio_path": None
        },
        {
            "id": "de9177a0965f953950e024237ac5560b",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Scusi, dov'è la stazione della metropolitana più vicina?",
            "language_code": "it-IT",
            "audio_path": None
        }
    ],
    "ar-YE": [
        {
            "id": "8be5c70ed10ae8a8f91c29f7853c5d49",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "هل توجد أي أطباق محلية مميزة؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "66946d74eb91fc521f05c8d73e79489b",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "كم سعر هذا؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "46fa3b2193f96794b5779f7a886f9cb6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "هل توجد خدمة حفظ الأمتعة؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "f9f5627189e6565b9451de875bbd4085",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "ما هي كلمة مرور الشبكة اللاسلكية؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "78abc1dd28ab9d41ef3b6c71a852308f",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "لو سمحت، أين توجد دورة المياه؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "2bfa7bbbb38cff1207c93e901108b953",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "أين يمكن صرف العملات؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "392f0e298cb98298c0914db857d070e5",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "هل يمكن الدفع ببطاقة الائتمان؟",
            "language_code": "ar-YE",
            "audio_path": None
        },
        {
            "id": "b89a0fb2870ca74766d6021f0f8ddfe6",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "أين تقع أقرب محطة مترو؟",
            "language_code": "ar-YE",
            "audio_path": None
        }
    ],
    "ru-RU": [
        {
            "id": "c65a342801c69faee315c9596ffb0768",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Скажите, сколько это стоит?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "c864b292c28e7b5e785abfa4890cb476",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Есть ли какие-нибудь местные блюда?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "8fba0b4ea675517dbca701b48eb5b396",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Есть ли услуга хранения багажа?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "e3cd95a5c519fc798786bedfe1017a58",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Какой пароль от беспроводной сети?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "ccae5509e23953de8332a9bbc2f5bdbd",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Подскажите, где находится туалет?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "2c98fab5f693c92eb0c9d7a192ecd82c",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Где можно обменять валюту?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "97bcfad884b6e998577b0d132830eca7",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Можно оплатить кредитной картой?",
            "language_code": "ru-RU",
            "audio_path": None
        },
        {
            "id": "36f7b527c386e2474dc0bd94457b2d4d",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Скажите, пожалуйста, где находится ближайшая станция метро?",
            "language_code": "ru-RU",
            "audio_path": None
        }
    ],
    "pt-BR": [
        {
            "id": "3c4203a2e1fe97468c922419f3702e7f",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Há algum prato típico local?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "55b988720b030d865a614615c34b9d9c",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Por favor, quanto custa isso?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "ea51cab56334733404eace8f06cced47",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Existe serviço de guarda-volumes?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "22b273f712b3ff995555be392c399cb8",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Qual é a senha da rede sem fio?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "c2cce0d533e1e825cf7386972cecee0a",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Por favor, onde fica o banheiro?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "241387d34928f4cd6b70f80baef291c6",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Onde posso trocar moeda?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "cd8129def92b7a0916092befbef87c05",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Posso pagar com cartão de crédito?",
            "language_code": "pt-BR",
            "audio_path": None
        },
        {
            "id": "dc87864106f2ea952560855ac65a8adc",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Por favor, onde fica a estação de metrô mais próxima?",
            "language_code": "pt-BR",
            "audio_path": None
        }
    ],
    "da-DK": [
        {
            "id": "c0b36ce2df0048629df5b0614aacbbd0",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Er der bagageopbevaring?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "a824b895fe2963653c9f692498f37f50",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Hvor meget koster dette?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "29523bad0c54542cf68db9b92dabb05b",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Er der nogle lokale specialiteter?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "ddadbd47786136e561cc4e020f503be5",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Hvad er adgangskoden til det trådløse netværk?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "a4557a41ce447f1d251b39e1f7e18cab",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Undskyld, hvor er toilettet?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "672f9a44edae822bf0ca84087c52f999",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Hvor kan man veksle valuta?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "c10cc62e2c1e1cce638bbf764617df32",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Kan man betale med kreditkort?",
            "language_code": "da-DK",
            "audio_path": None
        },
        {
            "id": "eb040903ae933298c99602ff2e9e939c",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Undskyld, hvor ligger den nærmeste metrostation?",
            "language_code": "da-DK",
            "audio_path": None
        }
    ],
    "fi-FI": [
        {
            "id": "ac2cfb308728692eedb2351ceb2b94b1",
            "ori_id": "580907cd27707892dd19e9d0ecc1fc6e",
            "ori_text": "请问这个多少钱？",
            "scene": 5,
            "text": "Kuinka paljon tämä maksaa?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "ce61358745479c39c1119a09387e52a6",
            "ori_id": "9a8334a9e34b92e3f7cd0b45009bd2ba",
            "ori_text": "有行李寄存服务吗？",
            "scene": 5,
            "text": "Onko täällä matkatavaroiden säilytyspalvelua?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "05bd297198b69dbe48b6b8bb805fada7",
            "ori_id": "f97ecfb87101c44f71e75de7e70afb42",
            "ori_text": "有什么当地特色菜吗？",
            "scene": 5,
            "text": "Onko täällä jotain paikallisia erikoisuuksia?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "70af6b5b563f500aeee32705d3ceecca",
            "ori_id": "e88c507dacbeccc9fe465af23550f492",
            "ori_text": "无线网络密码是什么？",
            "scene": 5,
            "text": "Mikä on langattoman verkon salasana?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "59f19ba5292051fc81c322989f38dd81",
            "ori_id": "2c48c147175eeb852e7b0a5530880680",
            "ori_text": "请问洗手间在哪里？",
            "scene": 5,
            "text": "Missä on wc?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "7ab347b66329b1e9d44bc3ca0c3ba730",
            "ori_id": "d7d7ab4747b08ebe865dcd6f7f7eb963",
            "ori_text": "哪里可以兑换货币？",
            "scene": 5,
            "text": "Missä voi vaihtaa valuuttaa?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "3f14db9617db2ec7224b055bebf14972",
            "ori_id": "e101684f655b0418aa2dcc686195da88",
            "ori_text": "可以刷信用卡吗？",
            "scene": 5,
            "text": "Voiko maksaa luottokortilla?",
            "language_code": "fi-FI",
            "audio_path": None
        },
        {
            "id": "a9ded5cc29be68c69ab864d73279aad4",
            "ori_id": "98f6b3cf806eb0bb29214e3ecc45e806",
            "ori_text": "请问最近的地铁站在哪里？",
            "scene": 5,
            "text": "Missä on lähin metroasema?",
            "language_code": "fi-FI",
            "audio_path": None
        }
    ]
}

import random

def main(target_lang: str, questions_num: int) -> dict:
    """
    根据输入的目标语言和数量，返回推荐问题列表
    :param target_lang: 目标语言
    :param questions_num: 推荐问题数量
    :return: 推荐问题列表
    """
    # 根据输入的目标语言 查询对应的推荐问题列表
    questions = question_list.get(target_lang, [])
    # 如果目标语言不存在，则返回错误信息
    if not questions:
        return {
            "code": 1,
            "message": "target language not supported",
            "recommended_questions": [],
            "language": target_lang
        }

    len_questions = len(questions)    
    if questions_num > len_questions:
        questions_num = len_questions
    if questions_num < 1:
        return {
            "code": 2,
            "message": "questions num should be greater than 0",
            "recommended_questions": [],
            "language": target_lang
        }

    random.seed(None)  # 设置随机种子为None，表示使用系统时间
    # 从列表中随机选择 num 个问题
    recommended_questions = random.sample(
        [item["text"] for item in questions], questions_num
    )
    # 返回结果
    return {
        "code": 0,
        "message": "success",
        "recommended_questions": recommended_questions,
        "language": target_lang
    }

# ret = main("en-US", 3)
# print(ret)
