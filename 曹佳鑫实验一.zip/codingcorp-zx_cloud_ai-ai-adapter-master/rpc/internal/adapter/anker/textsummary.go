package anker

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/zeromicro/go-zero/core/logx"

	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
)

// WorkflowReq 工作流请求
type WorkflowReq struct {
	User         string           `json:"user"`
	ResponseMode string           `json:"response_mode"`
	Inputs       TextSummaryInput `json:"inputs"`
}

// WorkflowResp 工作流响应
type WorkflowResp struct {
	TaskID        string       `json:"task_id"`
	WorkflowRunID string       `json:"workflow_run_id"`
	Data          WorkflowData `json:"data"`
}

// WorkflowData 工作流数据
type WorkflowData struct {
	Id          string            `json:"id"`
	WorkflowId  string            `json:"workflow_id"`
	Status      string            `json:"status"`
	Outputs     TextSummaryOutput `json:"outputs"`
	Error       string            `json:"error"`
	ElapsedTime float64           `json:"elapsed_time"`
	TotalTokens int32             `json:"total_tokens"`
	TotalSteps  int32             `json:"total_steps"`
	CreatedAt   int32             `json:"created_at"`
	FinishedAt  int32             `json:"finished_at"`
}

type FileInfo struct {
	TransferMethod string `json:"transfer_method"`
	Url            string `json:"url"`
	Type           string `json:"type"`
}

// TextSummaryInput 文本摘要输入
type TextSummaryInput struct {
	Language  string     `json:"language"`
	Nonce     string     `json:"nonce"`
	AesKey    string     `json:"aes_key"`
	Template  string     `json:"template"`
	TextFiles []FileInfo `json:"text_files"`
}

// TextSummaryOutput 文本摘要输出
type TextSummaryOutput struct {
	Summary  string `json:"summary"`         // 会议纪要
	Keywords string `json:"keywords"`        // 关键词
	Advice   string `json:"advice"`          // 建议
	Error    string `json:"error,omitempty"` // 错误信息
}

type TextSummaryClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	start   time.Time
	user    string
	host    string
	key     string
	client  *resty.Client
	taskDir string
}

func NewTextSummaryClient(ctx context.Context, svcCtx *svc.ServiceContext, user, host, apiKey string) *TextSummaryClient {
	client := resty.New().
		SetTimeout(time.Minute).
		SetHeader("Authorization", fmt.Sprintf("Bearer %s", apiKey)).
		SetHeader("Content-Type", "application/json")

	return &TextSummaryClient{
		ctx:    ctx,
		svcCtx: svcCtx,
		user:   user,
		host:   host,
		key:    apiKey,
		start:  time.Now(),
		client: client,
		Logger: logx.WithContext(ctx),
	}
}

// ExtractTextSummary handles the text summary request
func (t *TextSummaryClient) ExtractTextSummary(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	workflowResp := WorkflowResp{}

	// Check request parameters
	if err := t.checkParam(req); err != nil {
		t.Errorf("checkParam failed: %v", err)
		return nil, fmt.Errorf("checkParam failed: %v", err)
	}

	// Create task directory
	taskDir, err := t.createTaskDirectory(req.TaskId)
	if err != nil {
		return nil, fmt.Errorf("create task directory error: %v", err)
	}
	defer t.cleanupDirectory(taskDir) // Ensure cleanup after processing

	// Build workflow request
	workflowReq := t.buildWorkflowReq(req)
	if workflowReq == nil {
		t.Errorf("buildWorkflowReq failed")
		return nil, fmt.Errorf("buildWorkflowReq failed")
	}

	// Send the request to workflow
	resp, err := t.client.R().
		SetBody(workflowReq).
		SetResult(&workflowResp).
		Post(t.host)

	if err != nil {
		t.Errorf("send request failed: %v", err)
		return nil, fmt.Errorf("send request failed: %v", err)
	}

	if resp.StatusCode() != http.StatusOK {
		t.Errorf("API request failed, status code: %d, body: %s", resp.StatusCode(), resp.String())
		return nil, fmt.Errorf("API request failed, status code: %d , error : %d", resp.StatusCode(), resp.Error())
	}

	if workflowResp.Data.Error != "" {
		t.Errorf("dify response error: %s", workflowResp.Data.Error)
		return nil, fmt.Errorf("dify response error: %s", workflowResp.Data.Error)
	}

	// Marshal result
	output, err := json.Marshal(&workflowResp.Data.Outputs)
	if err != nil {
		t.Errorf("marshal result error: %v", err)
		return nil, fmt.Errorf("marshal result error: %v", err)
	}

	// Save the result
	filePath := filepath.Join(t.taskDir, common.GetFileNameFromUrl(req.ResultUrl))
	if err := os.WriteFile(filePath, output, 0644); err != nil {
		return nil, fmt.Errorf("save result error: %v", err)
	}

	// Upload file
	err = common.UploadFileFromPath(t.ctx, req.ResultUrl, filePath)
	if err != nil {
		return nil, err
	}

	// Prepare and return the response
	return &adaptermodel.TextSummaryResp{
		Code:        codes.CodeOk,
		Message:     "success",
		TimeTakenMs: int32(time.Since(t.start).Milliseconds()),
	}, nil
}

func (t *TextSummaryClient) buildWorkflowReq(req *adaptermodel.TextSummaryReq) *WorkflowReq {
	textFiles := make([]FileInfo, len(req.TextUrls))

	for i, url := range req.TextUrls {
		textFiles[i] = FileInfo{
			Url:            url,
			Type:           "custom",
			TransferMethod: "remote_url",
		}
	}

	if len(req.Language) == 0 {
		req.Language = "en-US"
	}

	return &WorkflowReq{
		User:         t.user,
		ResponseMode: "blocking",
		Inputs: TextSummaryInput{
			Language:  req.Language,
			Nonce:     "",
			AesKey:    req.AesKey,
			Template:  req.TemplateContent,
			TextFiles: textFiles,
		},
	}
}

// Create a directory for the task using task ID
func (t *TextSummaryClient) createTaskDirectory(taskId string) (string, error) {
	t.taskDir = filepath.Join(os.TempDir(), taskId)
	if err := os.MkdirAll(t.taskDir, os.ModePerm); err != nil {
		return "", fmt.Errorf("create directory error: %v", err)
	}
	return t.taskDir, nil
}

// Cleanup the task directory after processing
func (t *TextSummaryClient) cleanupDirectory(dir string) {
	if err := os.RemoveAll(dir); err != nil {
		t.Errorf("failed to remove task directory %s: %v", dir, err)
	} else {
		t.Infof("task directory removed: %s", dir)
	}
}

// Check parameters
func (t *TextSummaryClient) checkParam(req *adaptermodel.TextSummaryReq) error {
	if req == nil {
		return fmt.Errorf("request is nil")
	}
	if len(req.TextUrls) == 0 {
		return fmt.Errorf("text_urls is empty")
	}
	for i, url := range req.TextUrls {
		if url == "" {
			return fmt.Errorf("text_urls[%d] is empty", i)
		}
		if !req.MultiTextMode {
			req.TextUrls = []string{url}
			break
		}
	}
	return nil
}
