package aliyun

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type AliyunAdapter struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewAliyunAdapter(ctx context.Context, svcCtx *svc.ServiceContext) *AliyunAdapter {
	return &AliyunAdapter{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (s *AliyunAdapter) TrainHandler(req *adaptermodel.CreateTrainReq) error {
	return fmt.Errorf("TrainHandler not implemented")
}

func (s *AliyunAdapter) GetTrainHandler(req *adaptermodel.GetTrainReq) (*adaptermodel.GetTrainResp, error) {
	return nil, fmt.Errorf("GetTrainHandler not implemented")
}

func (s *AliyunAdapter) StopTrainHandler(req *adaptermodel.StopTrainReq) error {
	return fmt.Errorf("StopTrainHandler not implemented")
}

func (s *AliyunAdapter) FaceSwapHandler(req *adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error) {
	return nil, fmt.Errorf("FaceSwapHandler not implemented")
}

func (s *AliyunAdapter) AiGenerateImageHandler(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	return nil, fmt.Errorf("AiGenerateImageHandler not implemented")
}

func (s *AliyunAdapter) ImageUpscaleHandler(req *adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error) {
	return nil, fmt.Errorf("ImageUpscaleHandler not implemented")
}

func (s *AliyunAdapter) InstantStyleHandler(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error) {
	return nil, fmt.Errorf("InstantStyleHandler not implemented")
}

func (s *AliyunAdapter) InstantStylePlusHandler(req *adaptermodel.InstantStylePlusReq) (*adaptermodel.InstantStylePlusResp, error) {
	return nil, fmt.Errorf("InstantStylePlusHandler not implemented")
}

func (s *AliyunAdapter) DepthMapGenerationHandler(req *adaptermodel.DepthMapGenerationReq) (*adaptermodel.DepthMapGenerationResp, error) {
	return nil, fmt.Errorf("DepthMapGenerationHandler not implemented")
}

func (s *AliyunAdapter) RemoveBackgroundHandler(req *adaptermodel.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	return nil, fmt.Errorf("RemoveBackgroundHandler not implemented")
}

func (s *AliyunAdapter) TranslateHandler(req *adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	if req == nil {
		return nil, fmt.Errorf("request is nil")
	}

	if cfg, ok := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)]; !ok {
		return nil, fmt.Errorf("appId %s not found in aliyun llm config", req.AppId)
	} else {
		if len(cfg.LLMUrl) == 0 ||
			len(cfg.ApiKey) == 0 {
			return nil, grpcerrors.New(codes.CodeSystemException, " ali llm config error", grpcerrors.FindCaller(1))
		}
	}

	url := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)].LLMUrl
	client := NewTranslateClient(s.ctx, s.svcCtx, url, nil, nil, req)
	return client.Translate(req)
}

func (s *AliyunAdapter) TranslateQuestionRecommendHandler(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	return nil, fmt.Errorf("TranslateQuestionRecommendHandler not implemented")
}

func (s *AliyunAdapter) FastTranscribeHandler(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	return nil, fmt.Errorf("FastTranscribeHandler not implemented")
}

func (s *AliyunAdapter) TextSummaryHandler(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	return nil, fmt.Errorf("TextSummaryHandler not implemented")
}

func (s *AliyunAdapter) SpeechToTextStreamHandler(request <-chan *adaptermodel.SpeechToTextReq, response chan<- *adaptermodel.SpeechToTextResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.Audio == nil {
		return fmt.Errorf("audio is nil")
	}

	if _, ok := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in aliyun asr config", req.AppId)
	}

	client := NewAsrClient(s.ctx, s.svcCtx, request, response, req)
	defer client.Close()

	err := client.SpeechTranscription()
	if err != nil {
		return fmt.Errorf("SpeechTranscription failed, err: %v", err)
	}

	return nil
}

func (s *AliyunAdapter) TextToSpeechStreamHandler(request <-chan *adaptermodel.TextToSpeechReq, response chan<- *adaptermodel.TextToSpeechResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}

	if _, ok := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in aliyun tts config", req.AppId)
	}

	client := NewTtsClient(s.ctx, s.svcCtx, request, response, req)
	defer client.Close()

	err := client.SpeechSynthesis()
	if err != nil {
		return fmt.Errorf("SpeechSynthesis failed, err: %v", err)
	}

	return nil
}

func (s *AliyunAdapter) TranslateStreamHandler(request <-chan *adaptermodel.TranslateReq, response chan<- *adaptermodel.TranslateResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.LlmType == "" {
		return fmt.Errorf("llm type is empty")
	}
	if req.Role == "" {
		return fmt.Errorf("role is empty")
	}

	if _, ok := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in aliyun llm config", req.AppId)
	}

	url := config.GetSrvConfig().ALiYun[config.AppId(req.AppId)].LLMUrl
	client := NewTranslateClient(s.ctx, s.svcCtx, url, request, response, req)
	err := client.TranslateStream()

	if err != nil {
		return fmt.Errorf("TranslateStreamHandler failed, err: %v", err)
	}
	return nil

}

func (s *AliyunAdapter) DifyWorkflowHandler(*adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error) {
	return nil, fmt.Errorf("DifyWorkflowHandler not implemented")
}

func (s *AliyunAdapter) DifyWorkflowStreamHandler(request <-chan *adaptermodel.DifyWorkflowReq, response chan<- *adaptermodel.DifyWorkflowResp) error {
	return fmt.Errorf("DifyWorkflowStreamHandler not implemented")
}

func (s *AliyunAdapter) DifyChatflowHandler(*adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error) {
	return nil, fmt.Errorf("DifyChatflowHandler not implemented")
}

func (s *AliyunAdapter) DifyChatflowStreamHandler(request <-chan *adaptermodel.DifyChatflowReq, response chan<- *adaptermodel.DifyChatflowResp) error {
	return fmt.Errorf("DifyChatflowStreamHandler not implemented")
}

func (s *AliyunAdapter) LanguageDetectStreamHandler(<-chan *adaptermodel.LanguageDetectReq, chan<- *adaptermodel.LanguageDetectResp) error {
	return fmt.Errorf("LanguageDetectStreamHandler not implemented")
}

func (s *AliyunAdapter) ComfyUiStyleTransferHandler(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error) {
	//TODO implement me
	return nil, fmt.Errorf("PetPortraitComfyHandler not implemented")
}

func (s *AliyunAdapter) OpusWrapperStreamHandler(request <-chan *adaptermodel.OpusWrapperReq, response chan<- *adaptermodel.OpusWrapperResp) error {
	return fmt.Errorf("OpusWrapperStreamHandler not implemented")
}

func (s *AliyunAdapter) TranslateQuestionRecommendStreamHandler(request <-chan *adaptermodel.TranslateQuestionRecommendReq, response chan<- *adaptermodel.TranslateQuestionRecommendResp) error {
	return fmt.Errorf("TranslateQuestionRecommendStreamHandler not implemented")
}
