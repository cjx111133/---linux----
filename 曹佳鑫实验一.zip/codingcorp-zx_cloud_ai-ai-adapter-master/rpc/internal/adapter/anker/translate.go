package anker

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"github.com/zeromicro/go-zero/core/logx"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/go-resty/resty/v2"
)

const (
	TranslatePromptTemplate = `
	Translate the %s sentence into the %s sentence.
	<start_of_turn>user
	%s<end_of_turn>
	<start_of_turn>model
		`

	TranslatePromptTemplateAutoDetectLanguage = `
	Translate the sentence into the %s sentence.
	<start_of_turn>user
	%s<end_of_turn>
	<start_of_turn>model
		`

	TranslatePromptTemplateWithContext = `
	Translate the %s sentence into the %s sentence.
	%s
	<start_of_turn>user
	%s<end_of_turn>
	<start_of_turn>model
	`

	TranslatePromptTemplateAutoDetectLanguageWithContext = `
	Translate the sentence into the %s sentence.
	%s
	<start_of_turn>user
	%s<end_of_turn>
	<start_of_turn>model
	`
)

type TranslateParameters struct {
	MaxTokens   int     `json:"max_tokens"`
	BadWords    string  `json:"bad_words"`
	StopWords   string  `json:"stop_words"`
	Temperature float64 `json:"temperature"`
	TopP        float64 `json:"top_p"`
	TopK        int     `json:"top_k"`
	TextInput   string  `json:"text_input"`
	Stream      bool    `json:"stream"`
}

type TranslateResponse struct {
	BatchIndex       int       `json:"batch_index"`
	ContextLogits    float64   `json:"context_logits"`
	CumLogProbs      float64   `json:"cum_log_probs"`
	GenerationLogits float64   `json:"generation_logits"`
	ModelName        string    `json:"model_name"`
	ModelVersion     string    `json:"model_version"`
	OutputLogProbs   []float64 `json:"output_log_probs"`
	SequenceEnd      bool      `json:"sequence_end"`
	SequenceID       int       `json:"sequence_id"`
	SequenceStart    bool      `json:"sequence_start"`
	TextOutput       string    `json:"text_output"`
}

type ChatStreamResponse struct {
	BatchIndex       int     `json:"batch_index"`
	ContextLogits    float64 `json:"context_logits"`
	CumLogProbs      float64 `json:"cum_log_probs"`
	GenerationLogits float64 `json:"generation_logits"`
	ModelName        string  `json:"model_name"`
	ModelVersion     string  `json:"model_version"`
	//OutputLogProbs   []int   `json:"output_log_probs"`
	SequenceEnd   bool   `json:"sequence_end"`
	SequenceID    int    `json:"sequence_id"`
	SequenceStart bool   `json:"sequence_start"`
	TextOutput    string `json:"text_output"`
}

type TranslateClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	start time.Time
	index int32
	Host  string
	Key   string

	request  <-chan *adaptermodel.TranslateReq
	response chan<- *adaptermodel.TranslateResp
	first    *adaptermodel.TranslateReq
}

func NewTranslateClient(ctx context.Context, svcCtx *svc.ServiceContext,
	host, apiKey string,
	request <-chan *adaptermodel.TranslateReq,
	response chan<- *adaptermodel.TranslateResp,
	first *adaptermodel.TranslateReq) *TranslateClient {

	return &TranslateClient{
		ctx:      ctx,
		svcCtx:   svcCtx,
		Logger:   logx.WithContext(ctx),
		start:    time.Now(),
		index:    0,
		Host:     host,
		Key:      apiKey,
		request:  request,
		response: response,
		first:    first,
	}
}

func (c *TranslateClient) Translate(text string) (*adaptermodel.TranslateResp, error) {
	c.start = time.Now()
	c.index++

	params := c.getTranslateParams()
	// 拼接prompt
	params.TextInput = c.composePrompt(text)
	c.Infof("Translate promot: %s", params.TextInput)

	restyReq := resty.New().SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
		SetTimeout(60*time.Second).R().
		SetContext(c.ctx).
		SetDoNotParseResponse(true).
		SetHeader("Authorization", c.Key).
		SetBody(params)

	for i := 0; i < 3; i++ {
		ret, err := restyReq.Post(c.Host)
		if err != nil {
			c.Errorf("error sending LLM request: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		defer ret.RawBody().Close()

		if ret.StatusCode() != http.StatusOK {
			c.Errorf("LLM response status code: %d, error : %s", ret.StatusCode(), string(ret.Body()))
			time.Sleep(500 * time.Millisecond)
			continue
		}

		fullText := ""
		scanner := bufio.NewScanner(ret.RawBody())
		for scanner.Scan() {
			line := scanner.Text()
			c.Debugf("Translate, recv response, index: %d, line: %s, cost: %vms", c.index, line, time.Since(c.start).Milliseconds())

			line = strings.Replace(line, "data:", "", 1)
			if line == "" {
				continue
			}

			var response ChatStreamResponse
			err = common.JsonToAny([]byte(line), &response)
			if err != nil {
				return nil, fmt.Errorf("failed to unmarshal response: %+v, err: %v", line, err)
			}

			fullText += response.TextOutput
		}

		c.Infof("Translate, recv response, index: %d, full text: %s", c.index, fullText)
		return &adaptermodel.TranslateResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "",
			},
			SentenceId:    c.index,
			SentenceEnd:   true,
			SentenceStart: true,
			Text:          fullText,
			Language:      c.first.ToLang,
			TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
		}, nil
	}

	c.Errorf("failed to get response from LLM for three times")
	return nil, fmt.Errorf("failed to get response from LLM for three times")
}

func (c *TranslateClient) TranslateStream() (err error) {
	defer close(c.response)
	c.start = time.Now()
	// send first package to Aliyun
	err = c.translateStream(c.first.Text)
	if err != nil {
		return fmt.Errorf("TranslateStream, send first package failed, err: %v", err)
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop translate failed, err: %v", err)
	}
	return
}

func (c *TranslateClient) loop() (err error) {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("send text to anker llm end, ctx done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send text to anker llm end, request channel closed")
				return
			}
			if req == nil {
				c.Errorf("send text to anker llm end, the request is nil")
				return fmt.Errorf("send text to anker llm end, the request is nil")
			}

			err = c.translateStream(req.Text)
			if err != nil {
				return fmt.Errorf("loop translate failed, err: %v", err)
			}
		}
	}
}

func (c *TranslateClient) translateStream(text string) error {
	if text == "" {
		c.Errorf("translateStream, send text to aliyun llm warning, the first text is nil")
		return nil
	}

	if !c.first.EnableStream {
		resp, err := c.Translate(text)
		if err != nil || resp == nil {
			return fmt.Errorf("translateStream, EnableStream:%v, Translate failed, err: %v", c.first.EnableStream, err)
		}

		resp.TimeTakenMs = int32(time.Since(c.start).Milliseconds())
		c.response <- resp
		c.cacheContexts(text, resp.Text)
		return nil
	}

	c.index++
	params := c.getTranslateParams()
	// 拼接prompt
	params.TextInput = c.composePrompt(text)
	c.Infof("translateStream promot: %s", params.TextInput)
	restyReq := resty.New().SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
		SetTimeout(60*time.Second).R().
		SetContext(c.ctx).
		SetDoNotParseResponse(true).
		SetHeader("Authorization", c.Key).
		SetBody(params)

	for i := 0; i < 3; i++ {
		ret, err := restyReq.Post(c.Host)
		if err != nil {
			c.Errorf("error sending LLM request: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		defer ret.RawBody().Close()

		if ret.StatusCode() != http.StatusOK {
			c.Errorf("LLM response status code: %d, error : %s", ret.StatusCode(), string(ret.Body()))
			time.Sleep(500 * time.Millisecond)
			continue
		}

		fullText := ""
		firstPackage := true
		scanner := bufio.NewScanner(ret.RawBody())
		for scanner.Scan() {
			line := scanner.Text()
			c.Debugf("translateStream, recv response, index: %d, line: %s, cost: %vms", c.index, line, time.Since(c.start).Milliseconds())

			line = strings.Replace(line, "data:", "", 1)
			if line == "" || line == "[DONE]" {
				continue
			}

			var streamResponse ChatStreamResponse
			err = json.Unmarshal([]byte(line), &streamResponse)
			if err != nil {
				return fmt.Errorf("failed to unmarshal stream response: %+v, err: %v", line, err)
			}

			if streamResponse.TextOutput == "" {
				continue
			}

			fullText += streamResponse.TextOutput

			c.response <- &adaptermodel.TranslateResp{
				Header: &aicommon.RspHeader{
					Code:    0,
					Message: "success",
				},
				SentenceId:    c.index,
				SentenceStart: firstPackage,
				SentenceEnd:   false,
				Text:          fullText,
				Language:      c.first.ToLang,
				TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
			}

			if firstPackage {
				firstPackage = false
			}
		}

		c.Infof("translateStream, recv response, index: %d, full text: %s", c.index, fullText)
		c.response <- &adaptermodel.TranslateResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "success",
			},
			SentenceId:    c.index,
			SentenceStart: firstPackage,
			SentenceEnd:   false,
			Text:          fullText,
			Language:      c.first.ToLang,
			TimeTakenMs:   int32(ret.Time().Milliseconds()),
		}

		c.cacheContexts(text, fullText)
		return nil
	}

	c.Errorf("failed to get response from LLM for three times")
	return fmt.Errorf("failed to get response from LLM for three times")
}

func (c *TranslateClient) getTranslateParams() TranslateParameters {
	return TranslateParameters{
		MaxTokens:   1000,
		BadWords:    "",
		StopWords:   "<eos>",
		Temperature: 1.0,
		TopP:        0.3,
		TopK:        40,
		Stream:      true, // 由于支持流输出以后就不支持非流， 这里的stream 只能为true
	}
}

func (c *TranslateClient) composePrompt(text string) string {
	fromLang := strings.ToLower(c.first.FromLang)
	toLang := strings.ToLower(c.first.ToLang)
	historyContent := ""
	if len(c.first.Contexts) > 0 {
		template := "<start_of_turn>%s\n%s<end_of_turn> "
		for _, v := range c.first.Contexts {
			historyContent += fmt.Sprintf(template, v.Role, v.Text)
		}

	}

	if historyContent != "" {
		if fromLang == "auto" {
			return fmt.Sprintf(TranslatePromptTemplateAutoDetectLanguageWithContext, common.Bcp47ToLanguage(toLang), historyContent, text)
		}
		return fmt.Sprintf(TranslatePromptTemplateWithContext, common.Bcp47ToLanguage(fromLang), common.Bcp47ToLanguage(toLang), historyContent, text)
	}

	if fromLang == "auto" {
		return fmt.Sprintf(TranslatePromptTemplateAutoDetectLanguage, common.Bcp47ToLanguage(toLang), text)
	}
	return fmt.Sprintf(TranslatePromptTemplate, common.Bcp47ToLanguage(fromLang), common.Bcp47ToLanguage(toLang), text)
}

func (c *TranslateClient) cacheContexts(original, translation string) {
	c.first.Contexts = append(c.first.Contexts, &adaptermodel.TranslateContext{
		Role: c.first.Role,
		Lang: c.first.FromLang,
		Text: original,
	})
	c.first.Contexts = append(c.first.Contexts, &adaptermodel.TranslateContext{
		Role: c.first.Role,
		Lang: c.first.ToLang,
		Text: translation,
	})
}
