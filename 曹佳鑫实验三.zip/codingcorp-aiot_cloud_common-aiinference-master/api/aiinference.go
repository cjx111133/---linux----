package main

import (
	"fmt"
	"strconv"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/channel"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/handler"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/ankerservice"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/constants"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/response"
	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/core/threading"
	"github.com/zeromicro/go-zero/core/trafficcontrol"
	"github.com/zeromicro/go-zero/rest"
)

const (
	NacosGroupID = "aiinference-api"
	NacosDataID  = "service-basic"
)

func main() {
	conBytes := ankerservice.GetServiceConfig(NacosGroupID)
	if conBytes == nil {
		fmt.Printf("get config empty error")
		return
	}

	var c config.Config
	err := conf.LoadFromJsonBytes(conBytes, &c)
	if err != nil {
		fmt.Printf("json unmarshal error:%+v", err)
		return
	}
	channel.InitConfig(c)

	if len(*ankerservice.ServicePort) > 0 {
		c.Port, _ = strconv.Atoi(*ankerservice.ServicePort)
	}
	c.ServiceConf.TrafficControl = trafficcontrol.NacosConfig{
		NacosServerConfig: trafficcontrol.NacosServerConfig{
			IpAddr: *ankerservice.NacosIP,
			Port:   uint64(*ankerservice.NacosPort),
		},
		NacosClientConfig: trafficcontrol.NacosClientConfig{
			NamespaceId:         *ankerservice.NacosNameSpace,
			TimeoutMs:           5000,
			NotLoadCacheAtStart: true,
			LogDir:              "./logs/",
			CacheDir:            "./logs/",
			RotateTime:          "1h",
			LogLevel:            "debug",
			Username:            *ankerservice.NacosUserName,
			Password:            *ankerservice.NacosPassWord,
		},
		DataId: NacosDataID,
		Group:  constants.NacosTrafficControlGroupID,
	}

	response.SetResponseIsEncrypt(1)
	ctx := svc.NewServiceContext(c)
	server := rest.MustNewServer(c.RestConf)
	defer server.Stop()

	serviceGroup := service.NewServiceGroup()
	defer serviceGroup.Stop()
	for _, mq := range handler.RegisterService(c, ctx) {
		serviceGroup.Add(mq)
	}
	threading.GoSafe(func() {
		fmt.Println("ServiceGroup start")
		serviceGroup.Start()
	})
	// 初始化ws管理器
	channel.InitWebSocketManager(ctx)

	handler.RegisterHandlers(server, ctx)

	// 监听配置变化
	ankerservice.WatchServiceConfig(&ctx.Config, func() {
		fmt.Printf("config changed, reload config\n")
		channel.InitConfig(ctx.Config)
	})

	fmt.Printf("Starting server at %s:%d...\n", c.Host, c.Port)
	server.Start()
}
