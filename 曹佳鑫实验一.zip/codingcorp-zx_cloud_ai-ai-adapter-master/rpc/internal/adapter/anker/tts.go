package anker

import (
	"context"
	"fmt"
	"io"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/ttsenginerpc"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
	"google.golang.org/grpc/metadata"
)

type TtsClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	startTime time.Time
	index     int32

	request  <-chan *adaptermodel.TextToSpeechReq
	response chan<- *adaptermodel.TextToSpeechResp
	first    *adaptermodel.TextToSpeechReq
}

func NewTtsClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.TextToSpeechReq,
	response chan<- *adaptermodel.TextToSpeechResp,
	first *adaptermodel.TextToSpeechReq) *TtsClient {
	return &TtsClient{
		ctx:       ctx,
		svcCtx:    svcCtx,
		Logger:    logx.WithContext(ctx),
		startTime: time.Now(),
		index:     1,
		request:   request,
		response:  response,
		first:     first,
	}
}

func (c *TtsClient) SpeechSynthesis() error {
	md := metadata.New(map[string]string{
		"authorization": "Bearer " + config.GetDefaultConfig().TextToSpeechRpc.Token,
	})
	stream, err := c.svcCtx.TextToSpeechRpc.SpeechSynthesis(
		metadata.NewOutgoingContext(c.ctx, md),
	)
	if err != nil {
		return fmt.Errorf("connect to ttsengine failed, err: %v", err)
	}

	// send first message
	err = stream.Send(&ttsenginerpc.InferenceReq{
		TaskId:         c.first.TaskId,
		PackIdx:        1,
		EnableSubtitle: c.first.EnableSubtitle,
		Language:       c.first.Language,
		Format:         c.first.Format,
		BitRate:        c.first.Bitrate,
		SampleRate:     c.first.SampleRate,
		Voice:          c.first.Voice,
		Speed:          c.first.Speed,
		Volume:         c.first.Volume,
		Pitch:          c.first.Pitch,
		Text:           c.first.Text,
	})
	if err != nil {
		return fmt.Errorf("send first message to tts engine failed, err: %v", err)
	}

	ctx, cancel := context.WithTimeout(c.ctx, 7200*time.Second) // 2小时
	defer cancel()

	var wg sync.WaitGroup
	wg.Add(2)
	defer wg.Wait()

	errCh := make(chan error, 2)
	// recv message from tts engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- c.recv(ctx, stream)
	})
	// send message to tts engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- c.send(ctx, stream)
	})

	for i := 0; i < 2; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	c.Infof("speech synthesis end")
	return nil
}

func (c *TtsClient) recv(ctx context.Context, stream ttsenginerpc.TtsEngineRpc_SpeechSynthesisClient) error {
	defer close(c.response)

	for {
		resp, err := stream.Recv()
		if err != nil {
			//close(response) // close response channel
			if err == io.EOF || err == context.Canceled {
				c.Infof("recv resp from tts engine stream end, %v", err)
				return nil
			}
			return fmt.Errorf("recv resp from tts engine stream failed, err: %v", err)
		}

		select {
		case <-ctx.Done():
			c.Infof("recv resp from tts engine stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("recv resp from tts engine stream end, logic context done")
			return nil
		default:
			if resp == nil {
				return fmt.Errorf("recv resp from asr engine stream failed, resp is nil")
			}
			if resp.Code != 0 {
				c.Errorf("recv resp from tts engine stream, code: %d, message: %s", resp.Code, resp.Message)
				return fmt.Errorf("recv resp from tts engine stream failed, code: %d, message: %s", resp.Code, resp.Message)
			}

			if resp.SentenceStart {
				c.index++
			}

			c.Debugf("recv resp from tts engine stream, index: %d, code: %d, message: %s, data len: %d, sentence start: %t, time taken: %d ms", c.index, resp.Code, resp.Message, len(resp.Data), resp.SentenceStart, resp.TimeTakenMs)

			r := &adaptermodel.TextToSpeechResp{
				Header: &aicommon.RspHeader{
					Code:    resp.Code,
					Message: resp.Message,
				},
				SentenceId: c.index,
				Audio: &aicommon.AudioInfo{
					Data:       resp.Data,
					SampleRate: c.first.SampleRate,
					BitRate:    c.first.Bitrate,
					Channels:   c.first.Channels,
					Format:     c.first.Format,
					Language:   c.first.Language,
				},
				SentenceStart: resp.SentenceStart,
				TimeTakenMs:   resp.TimeTakenMs,
			}

			if len(resp.Subtitle) > 0 {
				r.Subtitles = make([]*aicommon.Subtitle, 0, len(resp.Subtitle))
				for _, sub := range resp.Subtitle {
					r.Subtitles = append(r.Subtitles, &aicommon.Subtitle{
						SentenceStart: sub.SentenceStart,
						Text:          sub.Text,
						StartMs:       sub.StartMs,
						EndMs:         sub.EndMs,
					})
				}
			}

			c.response <- r
		}
	}
}

func (c *TtsClient) send(ctx context.Context, stream ttsenginerpc.TtsEngineRpc_SpeechSynthesisClient) error {
	defer stream.CloseSend()
	packIdx := int32(1)

	for {
		select {
		case <-ctx.Done():
			c.Infof("send req to tts engine stream end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("send req to tts engine stream end, logic context done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				r := &ttsenginerpc.InferenceReq{
					TaskId:  c.first.TaskId,
					PackIdx: -9999,
				}
				stream.Send(r)
				c.Infof("send req to tts engine stream end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send message failed, request is nil")
			}
			if req.Text == "" {
				c.Errorf("send message failed, text is empty")
				continue
			}

			packIdx++
			r := &ttsenginerpc.InferenceReq{
				TaskId:         c.first.TaskId,
				PackIdx:        packIdx,
				EnableSubtitle: c.first.EnableSubtitle,
				Language:       c.first.Language,
				Format:         c.first.Format,
				BitRate:        c.first.Bitrate,
				SampleRate:     c.first.SampleRate,
				Voice:          c.first.Voice,
				Speed:          c.first.Speed,
				Volume:         c.first.Volume,
				Pitch:          c.first.Pitch,
				Text:           req.Text,
			}
			err := stream.Send(r)
			if err != nil {
				return fmt.Errorf("send message failed, err: %v", err)
			}
		}
	}
}
