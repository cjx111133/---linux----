import os
import dashscope
import time

messages = [
    {'role': 'system', 'content': 'You are a language translation assistant.'},
    {'role': 'user', 'content': 'Translate the [source] Chinese sentence to [target] English sentence, remember only output the translation result without anything else.\n[source]\n铃声 (Ring) 公司还与竞争对手 ADT 安保公司在一起官司中达成了庭外和解。\n[target]\nRing also settled a lawsuit with competing security company, the ADT Corporation.\n[source]\n公交225路途径纪念公园、人民广场等知名景点。\n[target]'}
    ]

dashscope.base_http_api_url = 'https://prem.dashscope.aliyuncs.com/api/v1'

import concurrent.futures

def make_request():
    start_time = time.time()

    response = dashscope.Generation.call(
        # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
        api_key="sk-5231102843fa4a7ead0eb04e0e805b41",
        model="qwen-max-latest",
        messages=messages,
        result_format='message',
        stream=False,
    )

    end_time = time.time()
    elapsed_time = end_time - start_time

    return response, elapsed_time

num_requests = 10
total_time = 0

with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = [executor.submit(make_request) for _ in range(num_requests)]
    for future in concurrent.futures.as_completed(futures):
        response, elapsed_time = future.result()
        print(response)
        print(f"Request took {elapsed_time:.2f} seconds")
        total_time += elapsed_time

average_time = total_time / num_requests
print(f"Average request time: {average_time:.2f} seconds")
