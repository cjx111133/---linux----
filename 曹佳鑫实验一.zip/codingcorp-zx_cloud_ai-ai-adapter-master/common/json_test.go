// start_ai_generated
package common

import (
	"reflect"
	"testing"
)

func TestBuilder_jsonToStrings(t *testing.T) {
	tests := []struct {
		name    string
		str     string
		want    []string
		wantErr bool
	}{
		{
			name:    "valid json with multiple strings",
			str:     `["hello", "world"]`,
			want:    []string{"hello", "world"},
			wantErr: false,
		},
		{
			name:    "valid json with single string",
			str:     `["hello"]`,
			want:    []string{"hello"},
			wantErr: false,
		},
		{
			name:    "empty json array",
			str:     `[]`,
			want:    []string{},
			wantErr: false,
		},
		{
			name:    "invalid json format",
			str:     `"hello", "world"`, // Missing outer array brackets
			want:    nil,
			wantErr: true,
		},
		{
			name:    "empty string",
			str:     ``,
			want:    nil,
			wantErr: true,
		},
		// Add more test cases for performance if needed
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := JsonToStrings(tt.str)
			if (err != nil) != tt.wantErr {
				t.Errorf("Builder.jsonToStrings() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Builder.jsonToStrings() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBuilder_jsonToInts(t *testing.T) {
	tests := []struct {
		name    string
		str     string
		want    []int64
		wantErr bool
	}{
		{
			name:    "valid json with multiple integers",
			str:     `[1, 2, 3, 4, 5]`,
			want:    []int64{1, 2, 3, 4, 5},
			wantErr: false,
		},
		{
			name:    "valid json with single integer",
			str:     `[7]`,
			want:    []int64{7},
			wantErr: false,
		},
		{
			name:    "empty json array",
			str:     `[]`,
			want:    []int64{},
			wantErr: false,
		},
		{
			name:    "invalid json format",
			str:     `1, 2, 3, 4, 5`, // Missing outer array brackets
			want:    nil,
			wantErr: true,
		},
		{
			name:    "empty string",
			str:     ``,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed json",
			str:     `["invalid", "json"]`,
			want:    nil,
			wantErr: true,
		},
		// Add more test cases for performance if needed
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := JsonToInts(tt.str)
			if (err != nil) != tt.wantErr {
				t.Errorf("Builder.jsonToInts() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Builder.jsonToInts() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBuilder_jsonToFloats(t *testing.T) {
	tests := []struct {
		name    string
		str     string
		want    [][]float64
		wantErr bool
	}{
		{
			name:    "valid json with multiple arrays",
			str:     `[[1.1, 2.2, 3.3], [4.4, 5.5, 6.6]]`,
			want:    [][]float64{{1.1, 2.2, 3.3}, {4.4, 5.5, 6.6}},
			wantErr: false,
		},
		{
			name:    "valid json with single array",
			str:     `[[7.7, 8.8, 9.9]]`,
			want:    [][]float64{{7.7, 8.8, 9.9}},
			wantErr: false,
		},
		{
			name:    "empty json array",
			str:     `[]`,
			want:    [][]float64{},
			wantErr: false,
		},
		{
			name:    "invalid json format",
			str:     `[1.1, 2.2, 3.3]`, // Missing outer array brackets
			want:    nil,
			wantErr: true,
		},
		{
			name:    "empty string",
			str:     ``,
			want:    nil,
			wantErr: true,
		},
		{
			name:    "malformed json",
			str:     `[["invalid", "json"]]`,
			want:    nil,
			wantErr: true,
		},
		// Add more test cases for performance if needed
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := JsonToFloats(tt.str)
			if (err != nil) != tt.wantErr {
				t.Errorf("Builder.jsonToFloats() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Builder.jsonToFloats() = %v, want %v", got, tt.want)
			}
		})
	}
}

// end_ai_generated
