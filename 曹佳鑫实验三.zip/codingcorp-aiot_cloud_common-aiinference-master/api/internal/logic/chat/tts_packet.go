package chat

import (
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

// TTSPacket implements ChatPacketInterface for Text-to-Speech
type TTSPacket struct {
	task *BaseChatTask
}

func NewTTSPacket(task *BaseChatTask) *TTSPacket {
	return &TTSPacket{
		task: task,
	}
}

// Send handles sending TTS messages
func (p *TTSPacket) Send(req *types.ChatReq) error {
	switch req.ReqStatus {
	case types.ReqStatusAlone:
		err := p.SendAlone(req)
		if err != nil {
			return err
		}
	case types.ReqStatusFirst:
		err := p.SendFirst(req)
		if err != nil {
			return err
		}
		p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
	case types.ReqStatusMiddle:
		err := p.SendMiddle(req)
		if err != nil {
			return err
		}
	case types.ReqStatusEnd:
		p.task.Infof("TTS CloseSend")
		p.task.stream.CloseSend()
	case types.ReqStatusStop:
		p.task.Infof("TTS Stop")
		select {
		case <-p.task.stopChan:
			p.task.Infof("TTS Stop: stopChan already closed")
		default:
			close(p.task.stopChan)
		}
	}

	return nil
}

// CreateAloneStreamTaskReq creates a standalone TTS stream task request
func (p *TTSPacket) CreateAloneStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	// For standalone TTS request, set TTS directly
	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	streamReq.Workflow = []*aimanagerrpcclient.Node{
		{
			TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech),
			IsNeedResult: true,
			Parameters:   p.task.svcCtx.Config.Chat.TextToSpeechParam.String(req.Format, req.SampleRate, DefaultBitRate, req.Channels, req.SourceLanguage),
		},
	}

	// If the request format is opus, add opus wrapper node
	if req.Format == types.AudioFormatOpus {
		streamReq.Workflow[0].IsNeedResult = false
		encodeParams := fmt.Sprintf(`{
			"service_provider": "anker",
			"target": {
				"sample_rate": %d,
				"bit_rate": %d,
				"channels": %d,
				"format": "%s",
				"frame_size_ms": %d
			}
		}`, DefaultSampleRate, DefaultBitRate, DefaultChannels, types.AudioFormatOpus, DefaultFrameSizeMs)

		streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
			TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
			IsNeedResult: true,
			Parameters:   encodeParams,
		})
	}

	return streamReq
}

func (p *TTSPacket) getChatflowParam(req *types.ChatReq) *config.DifyChatflowParam {
	chatflowParam := config.NewDefaultDifyChatFlowParams(p.GetContext(req))
	chatflowParam.Set(common.InterfaceToString(req.Params["house_id"]), common.InterfaceToString(req.Params["language"]), common.InterfaceToString(req.Params["timezone"]))
	for key, value := range req.Params {
		chatflowParam.Params[key] = common.InterfaceToString(value)
	}
	return chatflowParam
}

// CreateFirstStreamTaskReq creates the first TTS stream task request
func (p *TTSPacket) CreateFirstStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	streamReq.Data = &aimanagerrpc.StreamTaskReq_TtsReq{
		TtsReq: &aiparameter.TextToSpeechInferenceParameter{
			Text:       req.Data,
			SentenceId: 1,
		},
	}
	streamReq.Workflow = append(
		streamReq.Workflow,
		[]*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech), IsNeedResult: false, Parameters: p.task.svcCtx.Config.Chat.TextToSpeechParam.String(types.AudioFormatPcm, DefaultSampleRate, DefaultBitRate, DefaultChannels, req.SourceLanguage)},
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper), IsNeedResult: true, Parameters: fmt.Sprintf(`{"service_provider": "anker", "target": {"sample_rate": %d, "bit_rate": %d, "channels": %d, "format": "%s", "language": "%s", "frame_size_ms": 60}}`,
				DefaultSampleRate, DefaultBitRate, DefaultChannels, types.AudioFormatOpus, req.SourceLanguage),
			},
		}...)
	return streamReq
}

// CreateMiddleStreamTaskReq creates a middle TTS stream task request
func (p *TTSPacket) CreateMiddleStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	// For TTS middle request, we're sending text data
	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	streamReq.Data = &aimanagerrpc.StreamTaskReq_TtsReq{
		TtsReq: &aiparameter.TextToSpeechInferenceParameter{
			Text:       req.Data,
			SentenceId: 1,
		},
	}

	return streamReq
}

// SendAlone sends standalone TTS request
func (p *TTSPacket) SendAlone(req *types.ChatReq) error {
	// 1. 无需创建连接的场景
	if !p.task.isCreateGrpcConn(req) {
		return nil
	}

	// 2. 创建连接的场景
	streamReq := p.CreateAloneStreamTaskReq(req)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("TTS Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)

	// Send TTS text data
	if req.Data != "" {
		streamReq.Workflow = nil
		streamReq.Data = &aimanagerrpc.StreamTaskReq_TtsReq{
			TtsReq: &aiparameter.TextToSpeechInferenceParameter{
				Text: req.Data,
			},
		}
		if err := p.task.stream.Send(streamReq); err != nil {
			p.task.Errorf("TTS Send failed, err: %v", err)
			p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
			return err
		}
	}
	return nil
}

// SendFirst sends first TTS data
func (p *TTSPacket) SendFirst(req *types.ChatReq) error {
	streamReq := p.CreateFirstStreamTaskReq(req)
	p.task.Infof("TTS first Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("TTS Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// SendMiddle sends middle TTS data
func (p *TTSPacket) SendMiddle(req *types.ChatReq) error {
	streamReq := p.CreateMiddleStreamTaskReq(req)
	p.task.Infof("TTS middle Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("TTS Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// GetContext gets the context for the request
func (p *TTSPacket) GetContext(req *types.ChatReq) []*types.TranslateContext {
	if len(req.Data) == 0 {
		return nil
	}

	// For TTS, we don't need context from previous conversations
	return nil
}
