package common

import (
	"bytes"
	"context"
	"fmt"
	"github.com/chai2010/webp"
	"github.com/disintegration/imaging"
	"github.com/nfnt/resize"
	"github.com/zeromicro/go-zero/core/logx"
	"gocv.io/x/gocv"
	"golang.org/x/image/bmp"
	"golang.org/x/image/draw"
	"golang.org/x/image/tiff"
	"image"
	"image/color"
	"image/gif"
	"image/jpeg"
	"image/png"
	"runtime"
	"sort"
)

// RemovePNGExif remove PNG Exif
func RemovePNGExif(data []byte) ([]byte, error) {
	img, format, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("decode image failed, error:%s", err)
	}
	if format != "png" {
		return nil, fmt.Errorf("image not png")
	}
	var newImg bytes.Buffer
	if err := png.Encode(&newImg, img); err != nil {
		return nil, fmt.Errorf("encode image failed, error:%s", err)
	}
	return newImg.Bytes(), nil
}

func PngToWebp(data []byte) ([]byte, error) {
	buf := bytes.NewReader(data)
	img, err := png.Decode(buf)
	if err != nil {
		return nil, fmt.Errorf("decode image failed, error:%s", err)
	}
	var newImg bytes.Buffer
	if err = webp.Encode(&newImg, img, nil); err != nil {
		return nil, fmt.Errorf("encode image failed, error:%s", err)
	}
	return newImg.Bytes(), nil
}

// ImageResizeRate 图像缩放(按比例)
func ImageResizeRate(imgData []byte, rate float32) (image.Image, error) {
	// 解码图片
	img, _, err := image.Decode(bytes.NewReader(imgData))
	if err != nil {
		return nil, err
	}
	// 按比例缩放
	w := uint(img.Bounds().Dx())
	y := uint(img.Bounds().Dy())
	newWidth := float32(w) * rate
	newHeight := float32(y) * rate
	thumbnail := resize.Thumbnail(uint(newWidth), uint(newHeight), img, resize.Lanczos3)
	return thumbnail, nil
}

// ImageResize 图像缩放(按宽高)
/*func ImageResize(imgData []byte, thumbnailPixLimit int) (image.Image, error) {
	// 解码图片
	img, _, err := image.Decode(bytes.NewReader(imgData))
	if err != nil {
		return nil, err
	}
	var thumbnail image.Image
	// 计算宽高值
	origWidth := img.Bounds().Dx()
	origHeight := img.Bounds().Dy()
	if (origWidth * origHeight) > thumbnailPixLimit {
		rate := math.Sqrt(float64(origWidth*origHeight) / float64(thumbnailPixLimit))
		w := int32(float64(origWidth) / rate)
		h := int32(float64(origHeight) / rate)
		w = int32(float64(w/16) * 16)
		h = int32(float64(h/16) * 16)

		if rate > 1 {
			origWidth = int(w)
			origHeight = int(h)
		}
		targetW := int(origWidth/16) * 16
		targetH := int(origHeight/16) * 16
		// 固定尺寸，超过原图的按照原图尺寸返回
		thumbnail = resize.Resize(uint(targetW), uint(targetH), img, resize.Lanczos3)
	} else {
		// 返回原图
		return img, nil
	}
	return thumbnail, nil
}*/

func ImageResize(imgData []byte, thumbnailPixLimit int) (image.Image, error) {
	// 解码图片
	img, _, err := image.Decode(bytes.NewReader(imgData))
	if err != nil {
		return nil, err
	}
	defer func() {
		img = nil
	}()
	var thumbnail image.Image
	// 计算宽高值
	origWidth := img.Bounds().Dx()
	origHeight := img.Bounds().Dy()

	targetW := 0
	targetH := 0
	if origWidth > origHeight && origWidth > thumbnailPixLimit {
		targetW = thumbnailPixLimit
	}
	if origWidth < origHeight && origHeight > thumbnailPixLimit {
		targetH = thumbnailPixLimit
	}
	if origWidth == origHeight && origWidth > thumbnailPixLimit {
		targetW = thumbnailPixLimit
	}
	if origWidth <= thumbnailPixLimit && origHeight <= thumbnailPixLimit {
		return img, nil
	}

	thumbnail = resize.Resize(uint(targetW), uint(targetH), img, resize.Lanczos3)
	return thumbnail, nil
}

func ImageEncode(img image.Image, format string, quality int) ([]byte, error) {
	if quality == 0 {
		quality = 100
	}
	var buf bytes.Buffer
	var err error
	switch format {
	case ".jpeg", ".jpg":
		err = jpeg.Encode(&buf, img, &jpeg.Options{Quality: quality})
	case ".webp":
		err = webp.Encode(&buf, img, &webp.Options{Quality: float32(quality)})
	case ".gif":
		err = gif.Encode(&buf, img, nil)
	case ".bmp":
		err = bmp.Encode(&buf, img)
	case ".png":
		err = png.Encode(&buf, img)
	case ".tiff":
		err = tiff.Encode(&buf, img, nil)
	}
	if err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func IsExitSuffix(format string) bool {
	switch format {
	case ".jpeg", ".jpg":
		return true
	case ".webp":
		return true
	case ".gif":
		return true
	case ".bmp":
		return true
	case ".png":
		return true
	case ".tiff":
		return true
	}
	return false
}

func ResizeImageToMaxPix(imgByte []byte, maxPix int, imageMaxSize int64) ([]byte, error) {
	// 将字节数组转换为 Reader
	reader := bytes.NewReader(imgByte)

	// 解析图片配置（仅读取元数据）
	imageConfig, format, err := image.DecodeConfig(reader)
	if err != nil {
		return imgByte, err
	}
	channelNum, _ := GetImageChannel(imageConfig)
	if channelNum == 0 {
		channelNum = 4 //按照最大值取
	}

	imageMemSize := imageConfig.Width * imageConfig.Height * channelNum
	// 大于配置图片的最大值，则不进行resize操作，原因: 图片像素值太大会导致服务OOM
	if int64(imageMemSize) > imageMaxSize {
		return imgByte, nil
	}

	defer func() {
		// 这里对图片的处理非常耗内存, 等待自动内存回收的过程比较漫长, 这里手动回收内存
		runtime.GC()
	}()

	extStr := ".png"
	ext := "." + format
	if IsExitSuffix(ext) {
		extStr = ext
	}
	ctx := context.Background()
	logx.WithContext(ctx).Infof("image decode config, width: %d, height: %d, ext: %s", imageConfig.Width, imageConfig.Height, extStr)

	logx.WithContext(ctx).Infof("image decode before, memory usage: %d MiB", GetMemoryUsage())

	img, _, err := image.Decode(bytes.NewReader(imgByte))
	if err != nil {
		return nil, fmt.Errorf("ResizeImageToMaxPix image decode err %v", err)
	}
	logx.WithContext(ctx).Infof("image decode after, memory usage: %d MiB", GetMemoryUsage())

	if img.Bounds().Dx() <= maxPix && img.Bounds().Dy() <= maxPix {
		return imgByte, nil
	}

	if img.Bounds().Dx() > img.Bounds().Dy() {
		img = resize.Resize(uint(maxPix), 0, img, resize.Lanczos3)
	} else {
		img = resize.Resize(0, uint(maxPix), img, resize.Lanczos3)
	}

	logx.WithContext(ctx).Infof("image resize after, memory usage: %d MiB", GetMemoryUsage())
	return ImageEncode(img, extStr, 100)
}

// CalcuImageSize 返回的单位是MB
func CalcuImageSize(img []byte) int {
	byteSize := len(img)
	if byteSize != 0 {
		return byteSize / 1024 / 1024
	}
	return 0
}

// MinMax 计算图像像素值的最小值和最大值
func MinMax(img image.Image) (min, max uint8) {
	min = 255
	max = 0
	bounds := img.Bounds()
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			r, _, _, _ := img.At(x, y).RGBA()
			gray := uint8((r + r>>8) >> 8)
			if gray < min {
				min = gray
			}
			if gray > max {
				max = gray
			}
		}
	}
	return
}

// blendImages 实现图像混合功能
func blendImages(img1, img2 image.Image, alpha float64) *image.RGBA {
	bounds := img1.Bounds()
	result := image.NewRGBA(bounds)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			c1 := color.RGBAModel.Convert(img1.At(x, y)).(color.RGBA)
			c2 := color.RGBAModel.Convert(img2.At(x, y)).(color.RGBA)

			r := uint8(float64(c1.R)*(1-alpha) + float64(c2.R)*alpha)
			g := uint8(float64(c1.G)*(1-alpha) + float64(c2.G)*alpha)
			b := uint8(float64(c1.B)*(1-alpha) + float64(c2.B)*alpha)
			a := uint8(float64(c1.A)*(1-alpha) + float64(c2.A)*alpha)

			result.SetRGBA(x, y, color.RGBA{R: r, G: g, B: b, A: a})
		}
	}

	return result
}

// DepthGrayAdd 灰度图垫底
func DepthGrayAdd(depthImg, rgbImg image.Image, grayScale float64) (image.Image, error) {
	// 1. 读取并将 RGB 图像转换为灰度图
	grayImg := imaging.Grayscale(rgbImg)

	// 2. 读取深度图并调整尺寸（如果需要）
	if depthImg.Bounds().Size() != grayImg.Bounds().Size() {
		depthImg = imaging.Resize(depthImg, grayImg.Bounds().Size().X, grayImg.Bounds().Size().Y, imaging.Lanczos)
	}
	// 3. 将深度图叠加到灰度图上（例如叠加到亮度通道）
	result := blendImages(grayImg, depthImg, grayScale)
	return result, nil
}

// ExtractAlphaChannel 提取图像的 Alpha 通道
func ExtractAlphaChannel(img image.Image) *image.Gray {
	bounds := img.Bounds()
	alphaChannel := image.NewGray(bounds)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			_, _, _, a := img.At(x, y).RGBA()
			alphaChannel.SetGray(x, y, color.Gray{Y: uint8(a >> 8)})
		}
	}

	return alphaChannel
}

func OptimizeWhiteMaskWeighted(rgbaImage image.Image, alphaWeight float64) *image.Gray {
	bounds := rgbaImage.Bounds()
	mask := image.NewGray(bounds)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			r, g, b, a := rgbaImage.At(x, y).RGBA()

			// 将16位色值转换为8位
			red_ := float64(uint8(r >> 8))
			green_ := float64(uint8(g >> 8))
			blue_ := float64(uint8(b >> 8))
			alpha_ := float64(uint8(a >> 8))

			// 计算亮度
			luminance := 0.299*red_ + 0.587*green_ + 0.114*blue_

			// 归一化亮度和alpha
			normLuminance := luminance / 255.0
			normAlpha := alpha_ / 255.0

			// 完全不透明区域 (alpha > 127)
			if alpha_ > 127 {
				mask.SetGray(x, y, color.Gray{Y: 255})
			} else if alpha_ > 30 && alpha_ <= 127 {
				// 半透明区域 (30 < alpha <= 127)
				// 在边缘区域应用加权计算
				edgeWeight := normAlpha*alphaWeight + normLuminance*(1-alphaWeight)

				// 应用阈值到边缘权重
				if edgeWeight > 0.5 {
					mask.SetGray(x, y, color.Gray{Y: 255})
				} else {
					mask.SetGray(x, y, color.Gray{Y: 0})
				}
			} else {
				mask.SetGray(x, y, color.Gray{Y: 0})
			}
		}
	}

	return mask
}

func HandleApplyMask(rgbImage, rgbaImage image.Image) (image.Image, error) {
	// 手动回收内存
	defer func() {
		runtime.GC()
	}()
	// 检查 RGBA 图像是否包含 alpha 通道
	rgbaBounds := rgbaImage.Bounds()
	hasAlpha := false
	for y := rgbaBounds.Min.Y; y < rgbaBounds.Max.Y; y++ {
		for x := rgbaBounds.Min.X; x < rgbaBounds.Max.X; x++ {
			_, _, _, a := rgbaImage.At(x, y).RGBA()
			if a > 0 {
				hasAlpha = true
				break
			}
		}
		if hasAlpha {
			break
		}
	}
	if !hasAlpha {
		// 当用户选择不去背时,图片为RGB格式,直接返回
		return nil, nil
	}

	// 提取 alpha 通道并优化白色区域
	alphaChannel := OptimizeWhiteMaskWeighted(rgbaImage, 0.7)

	// 调整 Alpha 通道大小以匹配目标 RGB 图像大小
	alphaResized := imaging.Resize(alphaChannel, rgbImage.Bounds().Dx(), rgbImage.Bounds().Dy(), imaging.NearestNeighbor)

	// 归一化 alpha 通道到 [0, 1]
	overlayResult := imaging.New(rgbImage.Bounds().Dx(), rgbImage.Bounds().Dy(), color.RGBA{})
	for y := 0; y < overlayResult.Bounds().Dy(); y++ {
		for x := 0; x < overlayResult.Bounds().Dx(); x++ {
			// 从 RGB 图像中获取当前像素的颜色值
			r, g, b, _ := rgbImage.At(x, y).RGBA()
			// 将调整大小后的 Alpha 通道图像的当前像素颜色转换为灰度值
			grayColor := color.GrayModel.Convert(alphaResized.At(x, y)).(color.Gray)
			// 归一化 Alpha 值到 [0, 1] 范围
			aN := float64(grayColor.Y) / 255.0
			// 根据 Alpha 值计算混合后的 RGB 颜色值
			rBlended := uint8(float64(uint8(r>>8)) * aN)
			gBlended := uint8(float64(uint8(g>>8)) * aN)
			bBlended := uint8(float64(uint8(b>>8)) * aN)
			// 将混合后的颜色值设置到结果图像的对应像素位置
			overlayResult.Set(x, y, color.RGBA{rBlended, gBlended, bBlended, 255})
		}
	}
	return ToGrayscale(overlayResult), nil
}

// ToGrayscale 将 image.Image 转换为单通道灰度图
func ToGrayscale(img image.Image) *image.Gray {
	bounds := img.Bounds()
	grayImg := image.NewGray(bounds)

	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			// 获取原始图像中该像素的颜色
			c := img.At(x, y)
			// 将颜色转换为灰度值
			gray := color.GrayModel.Convert(c).(color.Gray)
			// 将灰度值设置到新的灰度图像中
			grayImg.SetGray(x, y, gray)
		}
	}

	return grayImg
}

// AddInputMask 风格迁移实现去背效果
// img1:前端输入图
// img2:SD返回图
func AddInputMask(img1, img2 image.Image) image.Image {
	rgbaImage, ok := img1.(*image.RGBA)
	if !ok {
		rgbaImage = convertToRGBA(img1)
	}

	// 提取 alpha 通道
	alpha := extractAlpha(rgbaImage)

	// 调整 alpha 通道的大小以匹配 RGB 图像的大小
	alphaResized := resizeAlpha(alpha, img2.Bounds().Size())

	// 将 alpha 通道和 RGB 图像合并为 RGBA 图像
	return mergeAlpha(img2, alphaResized)
}

// convertToRGBA 将图像转换为 RGBA 格式
func convertToRGBA(img image.Image) *image.RGBA {
	bounds := img.Bounds()
	rgba := image.NewRGBA(bounds)
	draw.Draw(rgba, bounds, img, bounds.Min, draw.Src)
	return rgba
}

// extractAlpha 从 RGBA 图像中提取 alpha 通道
func extractAlpha(img *image.RGBA) *image.Alpha {
	bounds := img.Bounds()
	alpha := image.NewAlpha(bounds)
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			_, _, _, a := img.At(x, y).RGBA()
			alpha.SetAlpha(x, y, color.Alpha{A: uint8(a >> 8)})
		}
	}
	return alpha
}

// resizeAlpha 调整 alpha 通道的大小
func resizeAlpha(alpha *image.Alpha, size image.Point) *image.Alpha {
	resized := image.NewAlpha(image.Rect(0, 0, size.X, size.Y))
	draw.CatmullRom.Scale(resized, resized.Bounds(), alpha, alpha.Bounds(), draw.Src, nil)
	return resized
}

// mergeAlpha 将 alpha 通道和 RGB 图像合并为 RGBA 图像
func mergeAlpha(rgb image.Image, alpha *image.Alpha) *image.RGBA {
	bounds := rgb.Bounds()
	rgba := image.NewRGBA(bounds)
	draw.Draw(rgba, bounds, rgb, bounds.Min, draw.Src)
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			r, g, b, _ := rgb.At(x, y).RGBA()
			alphaColor := alpha.At(x, y)
			a, ok := alphaColor.(color.Alpha)
			if !ok {
				continue
			}
			rgba.SetRGBA(x, y, color.RGBA{
				R: uint8(r >> 8),
				G: uint8(g >> 8),
				B: uint8(b >> 8),
				A: a.A,
			})
		}
	}
	return rgba
}

func AddInputMaskNew(img1, img2 []byte) (image.Image, error) {
	alphaImg, err := gocv.IMDecode(img1, gocv.IMReadUnchanged)
	defer alphaImg.Close()
	if alphaImg.Empty() {
		return nil, fmt.Errorf("alphaImg error: Unable to read the target image")
	}
	if err != nil {
		return nil, err
	}
	if alphaImg.Channels() != 4 {
		return nil, fmt.Errorf("alphaImg error: The alpha image must be in RGBA format")
	}

	targetImg, err := gocv.IMDecode(img2, gocv.IMReadUnchanged)
	if err != nil {
		return nil, err
	}
	defer targetImg.Close()
	if targetImg.Empty() {
		return nil, fmt.Errorf("targetImg error: Unable to read the target image")
	}
	if targetImg.Channels() != 3 {
		return nil, fmt.Errorf("targetImg error: The target image must be in RGB format")
	}

	// 提取透明通道并直接调整大小，避免不必要的Mat创建和关闭
	targetSize := image.Point{X: targetImg.Cols(), Y: targetImg.Rows()}
	resizedAlpha := gocv.NewMat()
	defer resizedAlpha.Close()

	channels := gocv.Split(alphaImg)
	alphaChannel := channels[3]
	gocv.Resize(alphaChannel, &resizedAlpha, targetSize, 0, 0, gocv.InterpolationLanczos4)

	// 及时释放原始通道资源
	for _, c := range channels {
		c.Close()
	}

	// 拆分目标图片的通道，避免后续不必要的关闭操作
	targetChannels := gocv.Split(targetImg)

	// 创建一个新的 RGBA 图像，避免额外的Mat创建
	channelsToMerge := []gocv.Mat{
		targetChannels[0],
		targetChannels[1],
		targetChannels[2],
		resizedAlpha,
	}
	merged := gocv.NewMat()
	defer merged.Close()

	gocv.Merge(channelsToMerge, &merged)

	// 及时释放目标通道资源
	for _, c := range targetChannels {
		c.Close()
	}

	return merged.ToImage()
}

// GetMemoryUsage 获取当前运行内存
func GetMemoryUsage() uint64 {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	return m.Alloc / 1024 / 1024
}

// GetImageChannel 获取图像通道数(肯能不准确)
func GetImageChannel(config image.Config) (int, error) {
	// 根据颜色模型推断通道数
	switch config.ColorModel {
	case color.RGBAModel:
		return 4, nil
	case color.NRGBAModel:
		return 3, nil
	case color.GrayModel:
		return 1, nil
	default:
		return 0, nil
	}
}

// AdjustLowestGray 调整图像中最低灰度值的像素
func AdjustLowestGray(img image.Image, percentage float64) (image.Image, error) {
	// 获取图像尺寸
	bounds := img.Bounds()
	width, height := bounds.Max.X, bounds.Max.Y

	// 创建灰度图像
	grayImg := image.NewGray(bounds)
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			grayImg.Set(x, y, img.At(x, y))
		}
	}

	// 收集所有灰度值
	totalPixels := width * height
	pixels := make([]struct {
		value uint8
		x, y  int
		index int
	}, totalPixels)

	idx := 0
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			pixels[idx] = struct {
				value uint8
				x, y  int
				index int
			}{
				value: grayImg.GrayAt(x, y).Y,
				x:     x,
				y:     y,
				index: idx,
			}
			idx++
		}
	}

	// 按灰度值排序
	sort.Slice(pixels, func(i, j int) bool {
		return pixels[i].value < pixels[j].value
	})

	// 计算需要调整的像素数量
	pixelsToAdjust := int(float64(totalPixels) * percentage / 100)

	// 找到新的灰度值（除最低百分比外的最低灰度值）
	var newValue uint8 = 255
	if pixelsToAdjust < totalPixels {
		newValue = pixels[pixelsToAdjust].value
	}

	// 创建新的灰度图像用于输出
	outputImg := image.NewGray(bounds)

	// 复制原始图像到输出图像
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			outputImg.Set(x, y, grayImg.At(x, y))
		}
	}

	// 调整最低灰度值的像素
	for i := 0; i < pixelsToAdjust; i++ {
		p := pixels[i]
		outputImg.SetGray(p.x, p.y, color.Gray{Y: newValue})
	}

	return outputImg, nil
}
