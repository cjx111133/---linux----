package types

type ChatReq struct {
	*CommonReq
	Timbre         string `json:"timbre"`          // 音色
	Format         string `json:"format"`          // 编码格式
	SampleRate     int32  `json:"sample_rate"`     // 音频采样率
	Bits           int32  `json:"bits"`            // 位长
	Channels       int32  `json:"channels"`        // 声道数
	SourceLanguage string `json:"source_language"` // 源语言
	Data           string `json:"data"`            // 加密数据
	FrameSizeMs    int32  `json:"frame_size_ms"`   // 帧大小
	//Context        []ChatContext `json:"context"`
	ChatContext []TranslateContext `json:"context"`
}

type CommonReq struct {
	MessageId    string                 `json:"message_id"` // 每条消息id，客户端生成
	Timestamp    int64                  `json:"timestamp"`  // 时间戳，毫秒
	ReqStatus    int32                  `json:"req_status"` // 1-首包 2-中间包 3-结束包
	Index        int32                  `json:"index"`      // 包序号 从0开始，依次递增
	Cmd          string                 `json:"cmd"`        // 命令 chat translate
	SubCmd       string                 `json:"sub_cmd"`    // 子命令类型
	Params       map[string]interface{} `json:"params"`     // 业务附加可选参数
	MessageType  int                    `json:"-"`          // 消息类型
	CanRetry     bool                   `json:"-"`          // 是否可以重试
	Type         int32                  `json:"type"`       // 对话类型 0-音频 1-文本 2-实时翻译(音频模式)
	CustomFields string                 `json:"-"`          // 自定义字段
}
