package audio

import (
	"context"
	"fmt"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/threading"
	"golang.org/x/text/language"
)

type LanguageDetectTask struct {
	*BaseAITask
}

func NewLanguageDetectTask(message *AudioMessage) *LanguageDetectTask {
	return &LanguageDetectTask{
		BaseAITask: NewBaseAITask(message),
	}
}

func (l *LanguageDetectTask) setLanguageDetect() error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		return fmt.Errorf("failed to create stream RPC connection: %w", err)
	}

	l.stream = stream
	l.isCloseSend.Store(false)
	l.workFlow = aiparameter.TaskType_TASK_TYPE_Language_Detect
	return nil
}

// Process implements AITaskInterface
func (l *LanguageDetectTask) Process(first *types.AudioTranslateReq) error {
	// 1. set language detect
	err := l.setLanguageDetect()
	if err != nil {
		return fmt.Errorf("set language detect failed: %s", err)
	}

	var errCh = make(chan error, 2)

	// 2. Receiving
	threading.GoSafe(func() {
		err := l.ProcessReceive(l.ctx, first)
		if err != nil {
			errCh <- fmt.Errorf("language detection receive failed: %s", err)
		}
	})

	// 3. Send requests
	threading.GoSafe(func() {
		err := l.ProcessTimer(l.ctx, first)
		if err != nil {
			errCh <- fmt.Errorf("language detection timer failed: %s", err)
		}
	})

	// 4. Wait for completion
	for i := 0; i < 2; i++ {
		if err := <-errCh; err != nil {
			l.Errorf("Language detection error: %s", err)
			return fmt.Errorf("language detection error: %s", err)
		}
	}
	return nil
}

// ProcessTimer implements AITaskInterface
func (l *LanguageDetectTask) ProcessTimer(ctx context.Context, first *types.AudioTranslateReq) error {
	l.Infof("Language detection ProcessTimer start, msgId: %s, LangDetectPeriod: %d", first.MessageId, l.svcCtx.Config.AudioTranslate.LangDetectPeriod)

	// 循环读取音频数据发送，直到读取到结束或者超时
	//定时器100ms
	timerSend := time.NewTicker(100 * time.Millisecond)
	l.timer = time.NewTicker(time.Second * time.Duration(l.svcCtx.Config.AudioTranslate.LangDetectPeriod))

	defer func() {
		l.Close()
		timerSend.Stop()
		if l.timer != nil {
			l.timer.Stop()
		}
		l.Infof("Language detection ProcessTimer stop, msgId: %s", first.MessageId)
	}()

	for {
		select {
		case <-l.timer.C: // 超时之后要由接收的goroutine关闭
			l.Errorf("Language detection timer up, messageId: %s", first.MessageId)
			l.isTimeUp.Store(true)
			return nil
		case <-l.wsStopChan:
			l.Errorf("Language detection stop, websocket stop, messageId: %s", first.MessageId)
			return nil
		case <-l.closeCh:
			l.Errorf("Language detection stop, close channel, messageId: %s", first.MessageId)
			return nil
		case <-timerSend.C:
			if l.audioIndex >= len(l.audios) {
				continue
			}
			for _, audio := range l.audios[l.audioIndex:] {
				l.audioIndex++
				if audio == nil {
					l.Errorf("Language detection audio is nil, messageId: %s", first.MessageId)
					continue
				}

				// 发送音频数据
				err := l.packetLogic.Send(audio)
				if err != nil {
					return fmt.Errorf("failed to send audio data: %s", err)
				}
				if audio.ReqStatus == types.ReqStatusEnd {
					return nil
				}
			}
		}
	}
}

// ProcessReceive implements AITaskInterface
func (l *LanguageDetectTask) ProcessReceive(ctx context.Context, req *types.AudioTranslateReq) error {
	l.Infof("Language detection ProcessReceive start, messageId: %s", req.MessageId)

	defer func() {
		l.Infof("Language detection ProcessReceive Recv End, messageId: %s", req.MessageId)
	}()

	var result types.RecvDataResp
	for {
		resp, err := l.stream.Recv()
		if isStreamEOF(err) {
			if l.isTimeUp.Load() {
				// 判断是否超时
				l.Errorf("Language detection Recv EOF, messageId: %s, err:%v", req.MessageId, err)
				l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeDetectLanguageTimeout, "Detect language timeout")
				return fmt.Errorf("language detection recv EOF: %w", err)
			}

			// 发送数据给前端
			l.Infof("Language detection Recv EOF, messageId: %s, err:%v, result: %+v", req.MessageId, err, result)
			l.utilLogic.SendSuccessDataToRecv(result)
		}
		if err != nil {
			l.Errorf("Language detection Recv failed, messageId: %s, err:%v", req.MessageId, err)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to receive data")
			return fmt.Errorf("language detection recv failed: %w", err)
		}

		// 如果不是语种检测的结果，则跳过
		if resp.TaskType != aiparameter.TaskType_TASK_TYPE_Language_Detect {
			l.Errorf("Language detection Recv TaskType Error, messageId: %s, TaskType: %v", req.MessageId, resp.TaskType)
			continue
		}

		// 将语音翻译的结果发送给前端
		ret, _, _ := l.convertManager.ProcessStreamTaskRespData(resp, req, 0)
		// 判断语种是否一致，一直则返回错误
		if isSameBaseLang(req.TargetLanguage, ret.Lang) {
			l.Errorf("Detect Language Equal, messageId: %s, SourceLanguage: %s, TargetLanguage: %s, DetectLanguage: %s", req.MessageId, req.SourceLanguage, req.TargetLanguage, ret.Lang)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeDetectLanguageEqual, "Detect Language Fail")
			return fmt.Errorf("detect language equal: %w", err)
		}

		if ret.Lang != "" {
			l.lang = ret.Lang
		}

		result = *ret
	}
}

func (l *LanguageDetectTask) Close() {
	l.StreamClose()
	if l.closeCh != nil {
		close(l.closeCh) // 确保关闭 channel
		l.closeCh = nil
	}
}

// 判断语种是否一致
func isSameBaseLang(lang1, lang2 string) bool {
	tag1, err := language.Parse(lang1)
	if err != nil {
		return false
	}

	tag2, err := language.Parse(lang2)
	if err != nil {
		return false
	}
	b1, _ := tag1.Base()
	b2, _ := tag2.Base()
	return b1.String() == b2.String()
}
