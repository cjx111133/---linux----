package constants

const (
	BedRockLowLevel    = "LOW"
	BedRockMediumLevel = "MEDIUM"
	BedRockHighLevel   = "HIGH"

	BedRockSexualType       = "SEXUAL"        // 性
	BedRockViolenceType     = "VIOLENCE"      // 暴力
	BedRockHateType         = "HATE"          // 恨
	BedRockInsultsType      = "INSULTS"       // 侮辱
	BedRockPromptAttackType = "PROMPT_ATTACK" // 提示词攻击
	BedRockMisconductType   = "MISCONDUCT"    // 不当行为

	BedRockNone = "NONE"

	Qualifiers = "guard_content"
	Source     = "INPUT"
)
