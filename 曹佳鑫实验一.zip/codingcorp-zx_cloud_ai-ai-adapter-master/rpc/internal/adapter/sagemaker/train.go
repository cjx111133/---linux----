package sagemaker

import (
	"fmt"
	"regexp"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/cloudstorrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/model"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/sagemaker"
)

func (s *SagemakerAdapter) TrainHandler(req *adaptermodel.CreateTrainReq) error {
	// 1.上传json和toml文件
	tomlPath, err := s.uploadTrainingTomlFile(req)
	if err != nil {
		return fmt.Errorf("upload training toml file failed: %v", err)
	}
	paraPath, err := s.uploadTrainingJsonFile(req, tomlPath)
	if err != nil {
		return fmt.Errorf("upload training json file failed: %v", err)
	}

	// 2.创建训练任务
	tags := make([]*sagemaker.Tag, 0, len(config.GetSrvConfig().ModelTrain.Tags))
	for _, tag := range config.GetSrvConfig().ModelTrain.Tags {
		tags = append(tags, &sagemaker.Tag{
			Key:   aws.String(tag.Key),
			Value: aws.String(tag.Value),
		})
	}

	trainingJobName := s.getJobName(req.TaskId)
	x := &sagemaker.CreateTrainingJobInput{
		AlgorithmSpecification: &sagemaker.AlgorithmSpecification{
			TrainingImage:     &config.GetSrvConfig().ModelTrain.TrainImage,
			TrainingInputMode: aws.String("File"),
		},
		HyperParameters: map[string]*string{
			"s3_location": aws.String(fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, paraPath)),
		},
		OutputDataConfig: &sagemaker.OutputDataConfig{
			S3OutputPath: aws.String(fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.OutputModelPath)),
		},
		ResourceConfig: &sagemaker.ResourceConfig{
			InstanceCount:  aws.Int64(config.GetSrvConfig().ModelTrain.InstanceCount),
			InstanceType:   aws.String(config.GetSrvConfig().ModelTrain.InstanceType),
			VolumeSizeInGB: aws.Int64(config.GetSrvConfig().ModelTrain.VolumeSizeInGB),
		},
		StoppingCondition: &sagemaker.StoppingCondition{
			MaxRuntimeInSeconds: aws.Int64(config.GetSrvConfig().ModelTrain.MaxRuntimeInSeconds),
		},
		TrainingJobName: aws.String(trainingJobName),
		RoleArn:         aws.String(config.GetSrvConfig().SageMaker.RoleArn),
		Tags:            tags,
	}

	s.Infof("create training job, input: %v", x)
	sgmClient := GetSgmClient().SgmClient
	sageOutput, err := sgmClient.CreateTrainingJobWithContext(s.ctx, x)
	if err != nil {
		return fmt.Errorf("create training job failed: %v", err)
	}
	if sageOutput == nil {
		return fmt.Errorf("create training job failed: sageOutput is nil")
	}

	_, err = s.svcCtx.TrainModelFileModel.Insert(s.ctx, &model.TTrainModelFile{
		UserId:       req.UserId,
		TaskId:       req.TaskId,
		InstanceName: req.InstanceName,
		TrainMethod:  config.GetSrvConfig().ModelTrain.TrainMethod,
		BaseModel:    config.GetSrvConfig().ModelTrain.BaseModel,
		DatasetPath:  req.DatasetPath,
		TaskState:    int64(aicommon.TaskStatus_TASK_STATUS_PENDING),
		Progress:     0,
		ModelId:      req.InstanceName,
		ModelName:    fmt.Sprint(req.InstanceName, ".safetensors"),
		Type:         "Lora",
		// /makeitreal/editor_uploads/default/262b363ea6e20f0ea2ee45225184aebac79fff08
		ModelPath:   req.OutputModelPath,
		TimeTakenMs: 0,
		CreateTime:  time.Now().Local().UnixMilli(),
		UpdateTime:  time.Now().Local().UnixMilli(),
		DelFlag:     0,
	})
	if err != nil {
		return fmt.Errorf("insert train model file failed: %v", err)
	}

	s.Infof("create training job success, training job name: %s", trainingJobName)
	return nil
}

func (s *SagemakerAdapter) GetTrainHandler(req *adaptermodel.GetTrainReq) (*adaptermodel.GetTrainResp, error) {
	// 获取训练任务状态
	trainModel, err := s.svcCtx.TrainModelFileModel.FindOneByTaskId(s.ctx, req.TaskId)
	if err != nil {
		return nil, fmt.Errorf("find train model file failed: %v", err)
	}
	if trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_COMPLETED) ||
		trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_FAILED) ||
		trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_CANCELLED) {
		return &adaptermodel.GetTrainResp{
			Code:      codes.CodeOk,
			Message:   "success",
			Status:    aicommon.TaskStatus(trainModel.TaskState),
			Progress:  int32(trainModel.Progress),
			ModelPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, trainModel.ModelPath),
		}, nil
	}

	x := &sagemaker.DescribeTrainingJobInput{
		TrainingJobName: aws.String(s.getJobName(req.TaskId)),
	}
	sgmClient := GetSgmClient().SgmClient
	sageOutput, err := sgmClient.DescribeTrainingJobWithContext(s.ctx, x)
	if err != nil {
		return nil, fmt.Errorf("describe training job failed: %v", err)
	}
	if sageOutput == nil {
		return nil, fmt.Errorf("describe training job failed: sageOutput is nil")
	}
	s.Infof("describe training job success, training job status: %s", *sageOutput.TrainingJobStatus)

	var resp = &adaptermodel.GetTrainResp{
		Code:    codes.CodeOk,
		Message: "success",
	}
	switch *sageOutput.TrainingJobStatus {
	case sagemaker.TrainingJobStatusInProgress:
		resp.Status = aicommon.TaskStatus_TASK_STATUS_RUNNING
		resp.Progress = 20
	case sagemaker.TrainingJobStatusCompleted:
		resp.Status = aicommon.TaskStatus_TASK_STATUS_COMPLETED
		resp.Progress = 100
		if sageOutput.ModelArtifacts != nil {
			resp.ModelPath = *sageOutput.ModelArtifacts.S3ModelArtifacts
		} else {
			return resp, fmt.Errorf("training job completed, but model path is nil")
		}
	case sagemaker.TrainingJobStatusFailed:
		resp.Status = aicommon.TaskStatus_TASK_STATUS_FAILED
		resp.Progress = 100
		resp.Message = *sageOutput.FailureReason
	case sagemaker.TrainingJobStatusStopping:
		resp.Status = aicommon.TaskStatus_TASK_STATUS_RUNNING
		resp.Progress = 80
	case sagemaker.TrainingJobStatusStopped:
		resp.Status = aicommon.TaskStatus_TASK_STATUS_CANCELLED
		resp.Progress = 0
		s.Infof("training job stoped, sageOutput: %s", *sageOutput)
	}

	// 更新训练任务状态
	trainModel.TaskState = int64(resp.Status)
	trainModel.Progress = int64(resp.Progress)
	trainModel.TimeTakenMs = time.Now().Local().UnixMilli() - trainModel.CreateTime
	trainModel.UpdateTime = time.Now().Local().UnixMilli()
	_, err = s.svcCtx.TrainModelFileModel.Update(s.ctx, trainModel.Id, trainModel)
	if err != nil {
		return nil, fmt.Errorf("update train model file failed: %v", err)
	}

	s.Infof("get training job success, status: %s, progress: %d", resp.Status, resp.Progress)
	return resp, nil
}

func (s *SagemakerAdapter) StopTrainHandler(req *adaptermodel.StopTrainReq) error {
	sgmClient := GetSgmClient().SgmClient
	x := &sagemaker.StopTrainingJobInput{
		TrainingJobName: aws.String(s.getJobName(req.TaskId)),
	}
	sageOutput, err := sgmClient.StopTrainingJobWithContext(s.ctx, x)
	if err != nil {
		return fmt.Errorf("stop training job failed: %v", err)
	}
	if sageOutput == nil {
		return fmt.Errorf("stop training job failed: sageOutput is nil")
	}

	s.Infof("stop training job success")
	return nil
}

func (s *SagemakerAdapter) uploadTrainingJsonFile(req *adaptermodel.CreateTrainReq, tomlPath string) (string, error) {
	modelPath, err := s.getBaseModelPath()
	if err != nil {
		return "", fmt.Errorf("get base model path failed: %v", err)
	}

	para := &adaptermodel.TrainPara{
		ID:               req.TaskId,
		TrainingID:       req.TaskId,
		SagemakerProgram: config.GetSrvConfig().ModelTrain.SagemakerProgram,
		Params: adaptermodel.Params{
			EnableWd14Tagger: config.GetSrvConfig().ModelTrain.EnableWd14Tagger,
			Wd14TaggerParamsSageMaker: adaptermodel.Wd14TaggerParamsSageMaker{
				CharacterThreshold: fmt.Sprint(config.GetSrvConfig().ModelTrain.CharacterThreshold),
				GeneralThreshold:   fmt.Sprint(config.GetSrvConfig().ModelTrain.GeneralThreshold),
			},
			TrainingParams: adaptermodel.TrainingParams{
				// s3://makeitreal-aiot-ore-ci/makeitreal/makeitreal/train_dataset/default/2231de8a8ae40f0934b3a66def736033ce685237/338e085f22df750ec5955ed91ee201234
				DatasetPath:          fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.DatasetPath),
				TrainingInstanceType: config.GetSrvConfig().ModelTrain.InstanceType,
				ModelPath:            modelPath,
				FmType:               config.GetSrvConfig().ModelTrain.FmType,
				// s3://makeitreal-aiot-ore-ci/makeitreal/makeitreal/train_input/default/2231de8a8ae40f0934b3a66def736033ce685237/mt_7434ac69440e3681c7dd7e88400077ab/kohya_config_cloud.toml
				S3TomlPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, tomlPath),
			},
			ConfigParams: adaptermodel.ConfigParams{
				SavingArguments: adaptermodel.SavingArguments{
					OutputName:       req.InstanceName,
					SaveEveryNEpochs: config.GetSrvConfig().ModelTrain.SaveEveryNEpochs,
				},
				TrainingArguments: adaptermodel.TrainingArguments{
					MaxTrainEpochs: config.GetSrvConfig().ModelTrain.MaxTrainEpochs,
				},
			},
			TrainingType: "kohya",
		},
		// s3://makeitreal-aiot-ore-ci/makeitreal/makeitreal/train_output/default/2231de8a8ae40f0934b3a66def736033ce685237/mt_7434ac69440e3681c7dd7e88400077ab
		S3InputPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.DatasetPath),
		// s3://makeitreal-aiot-ore-ci/makeitreal/makeitreal/editor_uploads/default/2231de8a8ae40f0934b3a66def736033ce685237
		S3OutputPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.OutputModelPath),
		TrainingType: "kohya",
	}

	paraFile := fmt.Sprintf("para-%s.json", req.TaskId)
	contentType := common.TypeByExtension(paraFile)
	upToken, err := s.svcCtx.CloudstorRpc.GetUpToken(s.ctx, &cloudstorrpc.GetUpTokenReq{
		AppId:       string(config.APP_ID_MAKE_IT_REAL),
		ContentType: &contentType,
		UpTokenData: &cloudstorrpc.UpToken{
			FileType: cloudstorrpc.FileType_Type3DTrainInput,
			FileName: paraFile,
			UserId:   req.UserId,
			DeviceSn: req.TaskId,
		}})
	if err != nil {
		return "", fmt.Errorf("get up token failed: %v", err)
	}
	paraBytes, err := common.AnyToJson(para)
	if err != nil {
		return "", fmt.Errorf("json marshal failed: %v", err)
	}
	_, err = common.UploadFile(s.ctx, paraBytes, upToken.UpToken, contentType)
	if err != nil {
		return upToken.KeyPrefix, fmt.Errorf("upload json file failed: %v", err)
	}
	return upToken.KeyPrefix, nil
}

func (s *SagemakerAdapter) uploadTrainingTomlFile(req *adaptermodel.CreateTrainReq) (string, error) {
	var fileName string
	tomlFile := adaptermodel.TomlFile
	if config.GetSrvConfig().ModelTrain.FmType == adaptermodel.SAGEMAKER_TRAIN_FM_TYPE_SD_1_5 {
		fileName = adaptermodel.SAGEMAKER_TRAIN_KOHYA_TOML_FILE_NAME
		tomlFile = s.replaceString(tomlFile, "SD_MODEL_PATH", adaptermodel.SAGEMAKER_TRAIN_KOHYA_PRETRAINED_MODEL_PATH)
		tomlFile = s.replaceString(tomlFile, "NO_HALF_VAE", "false")
	} else if config.GetSrvConfig().ModelTrain.FmType == adaptermodel.SAGEMAKER_TRAIN_FM_TYPE_SD_XL {
		fileName = adaptermodel.SAGEMAKER_TRAIN_KOHYA_XL_TOML_FILE_NAME
		tomlFile = s.replaceString(tomlFile, "SD_MODEL_PATH", adaptermodel.SAGEMAKER_TRAIN_KOHYA_XL_PRETRAINED_MODEL_PATH)
		tomlFile = s.replaceString(tomlFile, "NO_HALF_VAE", "true")
	} else {
		return "", fmt.Errorf("invalid fm type: %s", config.GetSrvConfig().ModelTrain.FmType)
	}
	tomlFile = s.replaceString(tomlFile, "OUTPUT_NAME", req.InstanceName)
	tomlFile = s.replaceString(tomlFile, "SAVE_EVERY_N_EPOCHS", fmt.Sprint(config.GetSrvConfig().ModelTrain.SaveEveryNEpochs))
	tomlFile = s.replaceString(tomlFile, "MAX_TRAIN_EPOCHS", fmt.Sprint(config.GetSrvConfig().ModelTrain.MaxTrainEpochs))

	contentType := common.TypeByExtension(fileName)
	upToken, err := s.svcCtx.CloudstorRpc.GetUpToken(s.ctx, &cloudstorrpc.GetUpTokenReq{
		AppId:       string(config.APP_ID_MAKE_IT_REAL),
		ContentType: &contentType,
		UpTokenData: &cloudstorrpc.UpToken{
			FileType: cloudstorrpc.FileType_Type3DTrainInput,
			FileName: fileName,
			UserId:   req.UserId,
			DeviceSn: req.TaskId,
		}})
	if err != nil {
		return "", fmt.Errorf("get up token failed: %v", err)
	}

	_, err = common.UploadFile(s.ctx, []byte(tomlFile), upToken.UpToken, contentType)
	if err != nil {
		return upToken.KeyPrefix, fmt.Errorf("upload toml file failed: %v", err)
	}
	return upToken.KeyPrefix, nil
}

func (s *SagemakerAdapter) getBaseModelPath() (string, error) {
	path, ok := config.GetSrvConfig().ModelFile.StableDiffusion[config.GetSrvConfig().ModelTrain.BaseModel]
	if !ok {
		return "", fmt.Errorf("model name not found, model name: %s", config.GetSrvConfig().ModelTrain.BaseModel)
	}
	return fmt.Sprintf("%s/%s", path.ModelPath, path.ModelName), nil
}

// 替换字符串中的字符串
func (s *SagemakerAdapter) replaceString(str, old, new string) string {
	return strings.Replace(str, old, new, -1)
}

func (s *SagemakerAdapter) getJobName(taskId string) string {
	// 将所有非字母数字字符替换为"-"
	re := regexp.MustCompile(`[^a-zA-Z0-9]+`)
	return re.ReplaceAllString(taskId, "-")
}
