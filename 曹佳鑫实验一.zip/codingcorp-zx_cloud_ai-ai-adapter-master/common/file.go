package common

import (
	"bytes"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"io"
	"net/http"
	"time"
)

type UploadFileBatch struct {
	Files       []byte
	ContentType string
	Url         string
}

// start_ai_generated

func IsUrl(url string) bool {
	if url == "" {
		return false
	}
	if len(url) < 8 {
		return false
	}
	if url[:4] != "http" {
		return false
	}
	return true
}

func DownloadFile(ctx context.Context, url string) (data []byte, err error) {
	if url == "" {
		return nil, fmt.Errorf("download file from s3 failed, url is empty")
	}

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("create http request failed, error:%s", err)
	}

	client := &http.Client{}
	response, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("get file from s3 failed, error:%s", err)
	}
	defer response.Body.Close()

	// 检查服务器响应的HTTP状态码
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("download file from s3 failed, status:%s", response.Status)
	}

	data, err = io.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("read response body failed, error:%s", err)
	}

	if len(data) < 10 {
		return nil, fmt.Errorf("download file from s3 failed, data is too short, len:%d", len(data))
	}

	return data, nil
}

func UploadFile(ctx context.Context, data []byte, url, contentType string) (n int64, err error) {
	dataLen := int64(len(data))
	if dataLen <= 10 {
		return dataLen, fmt.Errorf("upload file to s3 failed, data is too short, len:%d", dataLen)
	}
	if url == "" {
		return 0, fmt.Errorf("upload file to s3 failed, url is empty")
	}

	//req, err := http.NewRequestWithContext(ctx, "PUT", url, nil)
	//if err != nil {
	//	return 0, fmt.Errorf("create http request failed, error:%s", err)
	//}
	//req.ContentLength = dataLen
	//req.Header.Set("Content-Type", contentType)
	//req.Body = io.NopCloser(bytes.NewReader(data))

	var client = &http.Client{}
	var resp *http.Response
	var req *http.Request
	for i := 0; i < 3; i++ {
		// 防止第一次上传失败后情况body
		req, err = http.NewRequestWithContext(ctx, "PUT", url, nil)
		if err != nil {
			return 0, fmt.Errorf("create http request failed, error:%s", err)
		}
		req.ContentLength = dataLen
		req.Header.Set("Content-Type", contentType)
		req.Body = io.NopCloser(bytes.NewReader(data))

		// 增加http请求失败的重试机制
		if resp, err = client.Do(req); err == nil {
			break
		}
		time.Sleep(500 * time.Millisecond)
		logx.Infof("retry upload file to s3, url: %s, error: %v", url, err)
	}
	if resp == nil || err != nil {
		return 0, fmt.Errorf("put file to s3 failed, error:%s", err)
	}
	defer resp.Body.Close()

	// 检查HTTP响应状态码
	if resp.StatusCode != http.StatusOK {
		return 0, fmt.Errorf("upload file to s3 failed, status:%s", resp.Status)
	}
	return dataLen, nil
}

// end_ai_generated
