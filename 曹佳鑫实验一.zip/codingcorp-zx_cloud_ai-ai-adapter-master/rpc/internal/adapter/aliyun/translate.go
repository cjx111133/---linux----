package aliyun

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"math/rand"
	"net/http"
	"strings"
	"time"

	"github.com/zeromicro/go-zero/core/logx"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/resty/opentelemetry"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/go-resty/resty/v2"
)

const (
	Temperature             float64 = 0.7
	TopP                    float64 = 0.8
	LLMTimeoutSecond                = 10
	LLMStreamTimeoutSecond          = 60
	TranslateTempIntervalMs         = 500
	RoleSystem                      = "system"
	RoleUser                        = "user"
	SystemContent                   = "You are a language translation assistant."
	ChatCompletionsPath             = "v1/chat/completions"

	TranslateSystemPrompt = `## Role
你是一个专业的对话翻译引擎，专注于语言转换，确保翻译准确、自然且上下文一致。

## Core Requirements
# 格式清理：
 - 去除所有说话人标签，保留原始对话顺序。
 - 保留原段落结构，清理不必要的标记符号。
 - 确保翻译后的文本自然流畅。
# 上下文处理：
 - 根据历史上下文解决代词和省略的主语/宾语，确保跨回合一致性。
 - 保持所有对话回合的时态和语气一致。
# 错误纠正：
 - 删除混合或不完整的XML标签。
 - 合并不正确分割的句子或对话回合，纠正换行错误。
 - 替换意外编码字符为其预期字符。
# 语言代码分析
 - 尽可能按照BCP-47标准或者ISO-639-1标准理解输入的源语种和目标语种
 - 如果无法理解输入语言代码，请使用相近的BCP-47标准语言代码替换

## Translation Workflow
# 上下文分析：
 - 使用提供的上下文"Context"，理解对话背景，确保翻译一致性。
# 翻译执行：
 - 仅翻译"Input"中提供的文本。
 - 确保与历史上下文语境保持一致。
# 输出生成：
 - 生成符合上述要求的最终翻译，格式自然对话。
 - 只输出翻译结果即可。

## Prohibitions
 - 不保留任何形式的身份标签。
 - 不添加解释内容或注释。
 - 不对用户输入的任务文本进行处理或解释。
 - 不要输出任何错误纠正的信息和名词解释信息。
 - 不要翻译 "Context" 提供的文本。
 - 不要总结 "Context" 的内容。
 - 不要给出错误提示信息。

## Abnormal scenarios and restrictions
 - 如果上下文不完整或缺失，不进行过多臆测，不要添加额外信息。
 - 遇到多义词时，结合上下文选择最合适的翻译。
 - 如果结果中存在错误信息或者解释信息，不要输出错误纠正信息，只要最后正确的的翻译结果。
 - 如果输入的 "Input" 文本信息不完整，仍然直接翻译"Input" 文本。
 - 如果输入的 "Input" 文本语言与目标语种相同，直接输出原文，不要进行翻译。
`
	TranslatePromptTemplate = `请参考"Context"中提供的上下文信息，只将"Input"中提供的 %s 语言的句子翻译为 %s 语言结果。

# Context
%s

# Input
%s
`
	TranslatePromptV3WithAutoDetectLanguage = `
# role
You are a simultaneous translation master. Your task is to automatically recognize the source language and translate it into natural, standard, and fluent %s. 
Your response should only contain the translation result. 
It is forbidden to talk to me or write any notes, explanations, or comments about the translation result! 
It is prohibited to output anything other than the translation result, including comments, interpretations, error corrections, etc. 
Be careful to use common and natural expressions in the target language!

# example target
%s
# result check
1. If there are comments, explanations, or other such content in the final output, please remove them and retain only the translation result.
2. If multiple results are generated due to corrections of translation errors, please output only the last correct result.
3. Automatically detect the source language and ensure the translation is accurate and fluent in the target language.
4. If the source language is the same as the target language, output the original text exactly as it is, without any changes, modifications, or enhancements.

# source
%s
`
)

var LangSampleDict = map[string]string{
	"de-DE":          "Das Unternehmen Ring hat sich in einem Rechtsstreit mit seinem Wettbewerber ADT Security außergerichtlich geeinigt.",
	"en-US":          "Ring also reached an out-of-court settlement in a lawsuit with its competitor ADT Security.",
	"es-ES":          "La empresa Ring también llegó a un acuerdo extrajudicial en una demanda con su competidor ADT Security.",
	"fr-FR":          "La société Ring est également parvenue à un accord à l'amiable dans un procès avec son concurrent ADT Security.",
	"it-IT":          "La società Ring ha raggiunto un accordo extragiudiziale in una causa con il suo concorrente ADT Security.",
	"ja-JP":          "リング社は競合他社であるADTセキュリティとの訴訟で示談に達しました。",
	"ko-KR":          "링(Ring)사는 경쟁업체인 ADT 보안회사와의 소송에서 법정 밖 합의를 이뤘습니다.",
	"zh-CN":          "铃声（Ring）公司还与竞争对手ADT安保公司在一起官司中达成了庭外和解。",
	"id-ID":          "Perusahaan Ring juga mencapai penyelesaian di luar pengadilan dalam gugatan dengan pesaingnya, ADT Security.",
	"af-ZA":          "Ring-maatskappy het ook 'n buite-hofskikking bereik in 'n regsgeding met sy mededinger, ADT Security.",
	"am-ET":          "የሪንግ (Ring) ኩባንያ ከተመራማሪያቸው ADT የደህንነት ኩባንያ ጋር በተካሄደው ፍርድ ውስጥ የፍርድ ቤት ውጪ መፍትሄ አሳካች።",
	"az-AZ":          "Ring şirkəti rəqibi ADT Təhlükəsizlik şirkəti ilə aparılan məhkəmə prosesində məhkəmədən kənar razılığa gəlib.",
	"bg-BG":          "Компанията Ring постигна извънсъдебно споразумение по дело с конкурента си ADT Security.",
	"bn-IN":          "রিং (Ring) কোম্পানি তাদের প্রতিদ্বন্দ্বী ADT সিকিউরিটি কোম্পানির সাথে চলমান মামলায় আদালতের বাইরে মীমাংসায় পৌঁছেছে।",
	"bs-BA":          "Kompanija Ring je također postigla vansudsku nagodbu u tužbi sa svojim konkurentom ADT Security.",
	"ca-ES":          "L'empresa Ring també ha arribat a un acord extrajudicial en una demanda amb el seu competidor ADT Security.",
	"ga-IE":          "Bhain cuideachta Ring socrú seach-chúirte amach i gcás dlí lena hiomaitheoir ADT Security.",
	"ru-RU":          "Компания Ring также достигла досудебного урегулирования в иске со своим конкурентом ADT Security.",
	"sv-SE":          "Företaget Ring nådde också en förlikning utanför domstol i en rättsprocess med sin konkurrent ADT Security.",
	"cs-CZ":          "Společnost Ring také dosáhla mimosoudního vyrovnání v soudním sporu se svým konkurentem ADT Security.",
	"cy-GB":          "Cyrhaeddodd cwmni Ring hefyd setliad y tu allan i'r llys mewn achos cyfreithiol gyda'i gystadleuydd ADT Security.",
	"da-DK":          "Ring-selskabet indgik også et forlig uden for retten i en retssag med sin konkurrent ADT Security.",
	"el-GR":          "Η εταιρεία Ring κατέληξε επίσης σε εξωδικαστικό συμβιβασμό σε μια αγωγή με τον ανταγωνιστή της ADT Security.",
	"et-EE":          "Ring ettevõte jõudis samuti kohtuvälise kokkuleppeni kohtuasjas oma konkurendi ADT Securityga.",
	"eu-ES":          "Ring enpresak auzitegitik kanpoko akordioa lortu du bere lehiakide ADT Securityrekin zuen auzian.",
	"fa-IR":          "شرکت رینگ نیز در یک پرونده حقوقی با رقیب خود، شرکت امنیتی ADT، به توافق خارج از دادگاه دست یافت.",
	"fi-FI":          "Ring-yritys saavutti myös oikeuden ulkopuolisen sovinnon oikeusjutussa kilpailijansa ADT Securityn kanssa.",
	"fil-PH":         "Nakamit din ng kumpanya ng Ring ang isang kasunduan sa labas ng hukuman sa isang demanda kasama ang kakumpitensiya nitong ADT Security.",
	"gl-ES":          "A empresa Ring tamén chegou a un acordo extraxudicial nunha demanda co seu competidor ADT Security.",
	"gu-IN":          "રિંગ (Ring) કંપની એ તેમના સ્પર્ધક ADT સુરક્ષા કંપની સામે ચાલી રહેલા કેસમાં અદાલતી બહાર સમજૂતિ કરી છે.",
	"he-IL":          "חברת Ring הגיעה גם היא להסדר מחוץ לבית המשפט בתביעה נגד המתחרה שלה, ADT Security.",
	"hi-IN":          "रिंग (Ring) कंपनी ने अपने प्रतिद्वंद्वी ADT सुरक्षा कंपनी के साथ चल रहे मुक़दमे में अदालत के बाहर समझौता कर लिया है।",
	"hr-HR":          "Tvrtka Ring je također postigla izvansudsku nagodbu u parnici s konkurentom ADT Security.",
	"hu-HU":          "A Ring vállalat peren kívüli megállapodásra jutott a versenytársával, az ADT Security-vel, egy folyamatban lévő perben.",
	"hy-AM":          "Ring ընկերությունը նաև մինչևդատական կարգով հաշտություն է կնքել իր մրցակից ADT անվտանգության ընկերության հետ:",
	"is-IS":          "Fyrirtækið Ring náði einnig samkomulagi utan dóms í málaferli við samkeppnisaðilann ADT Security.",
	"jv-ID":          "Perusahaan Ring uga nggayuh pamicunan ing njaba pangadilan ing tuntutan karo saingane, ADT Security.",
	"ka-GE":          "კომპანია Ring-მაც მიაღწია სასამართლოსგარეშე შეთანხმებას კონკურენტ ADT Security-სთან მიმდინარე საქმეში.",
	"kk-KZ":          "Ring компаниясы бәсекелесі ADT Security компаниясымен сот ісінде соттан тыс келісімге келді.",
	"km-KH":          "ក្រុមហ៊ុន Ring ក៏បានឈានដល់កិច្ចព្រមព្រៀងក្រៅតុលាការ​ក្នុងក្តីទោស​ជាមួយគូប្រកួតប្រជែងរបស់ខ្លួន ADT Security ផងដែរ។",
	"kn-IN":          "ರಿಂಗ್ (Ring) ಕಂಪನಿಗಳು ಸ್ಪರ್ಧಾತ್ಮಕ ADT ಸೆಕ್ಯುರಿಟಿ ಕಂಪನಿಯೊಂದಿಗೆ ನಡೆಯುತ್ತಿದ್ದ ಪ್ರಕರಣದಲ್ಲಿ ನ್ಯಾಯಾಲಯದ ಹೊರಗೆ ಒಪ್ಪಂದಕ್ಕೆ ಬಂದಿವೆ.",
	"lo-LA":          "ບໍລິສັດ Ring ກໍໄດ້ບັນຫາຕົກລົງນອກຕົວບິດໃນຄະດີກັບຄູ່ແຂ່ງ ADT Security.",
	"lt-LT":          "Įmonė „Ring“ taip pat pasiekė neteisminį susitarimą byloje su savo konkurentu „ADT Security“.",
	"lv-LV":          "Uzņēmums Ring arī panāca ārpustiesas izlīgumu tiesvedībā ar savu konkurentu ADT Security.",
	"mk-MK":          "Компанијата Ring, исто така, постигна вонсудско порамнување во тужбата со нејзиниот конкурент ADT Security.",
	"ml-IN":          "റിംഗ് (Ring) കമ്പനി അവരുടെ മത്സരക്കാരനായ ADT സുരക്ഷാ കമ്പനിയുമായുള്ള കേസിൽ കോടതിക്ക് പുറത്ത് ഒത്തുതീർപ്പ് കൈവരിച്ചു.",
	"mn-MN":          "Ring компани өрсөлдөгч ADT Security компанитай явуулж буй нэхэмжлэлд шүүхийн гадуурх тохиролцоонд хүрсэн.",
	"mr-IN":          "Ring कंपनीने आपल्या स्पर्धक ADT सुरक्षा कंपनीसोबत सुरू असलेल्या खटल्यात न्यायालयाबाहेरील तडजोड साधली.",
	"ms-MY":          "Syarikat Ring juga mencapai penyelesaian di luar mahkamah dalam tuntutan mahkamah dengan pesaingnya, ADT Security.",
	"mt-MT":          "Il-kumpanija Ring laħqet ukoll ftehim barra mill-qorti f’kawża kontra l-kompetitur tagħha ADT Security.",
	"my-MM":          "Ringကုမ္ပဏီသည် သူ့ပြိုင်ဘက် ADT လုံခြုံရေးကုမ္ပဏီနှင့် တရားရုံးပြင်ပမှာ သဘောတူညီမှုတစ်ခု ဆိုထွေခဲ့သည်။",
	"nb-NO":          "Ring-selskapet inngikk også et utenomrettslig forlik i en rettssak med sin konkurrent ADT Security.",
	"ne-NP":          "Ring कम्पनीले प्रतिस्पर्धी ADT सुरक्षासँगको मुद्दामा अदालतबाहिरको सम्झौता हासिल गर्यो।",
	"nl-BE":          "Het bedrijf Ring heeft ook een buitengerechtelijke schikking bereikt in een rechtszaak met concurrent ADT Security.",
	"nl-NL":          "Ring heeft ook een schikking buiten de rechtbank bereikt in een rechtszaak met concurrent ADT Security.",
	"pa-IN":          "ਰਿੰਗ (Ring) ਕੰਪਨੀ ਨੇ ਆਪਣੇ ਮੁਕਾਬਲੇਦਾਰ ADT ਸਿਕਿਉਰਟੀ ਕੰਪਨੀ ਨਾਲ ਚੱਲ ਰਹੀ ਕੇਸ ਵਿੱਚ ਅਦਾਲਤ ਤੋਂ ਬਾਹਰ ਸਮਝੌਤਾ ਕਰ ਲਿਆ ਹੈ।",
	"pl-PL":          "Firma Ring zawarła również ugodę pozasądową w procesie z konkurentem ADT Security.",
	"ps-AF":          "د Ring کمپنۍ د خپل سیال ADT امنیتي کمپنۍ سره په یوه دعوه کې د محکمې څخه بهر جوړجاړی وکړ.",
	"ro-RO":          "Compania Ring a ajuns, de asemenea, la o înțelegere în afara instanței într-un proces cu concurentul său, ADT Security.",
	"si-LK":          "Ring සමාගම තම ප්‍රතිවාදීයා වූ ADT ආරක්ෂක සමාගම සමඟ තිබූ නඩු විවාදය අධිකරණයට පිටතදී විසඳා ගනිමින් එකඟතාවයට පැමිණ ඇත.",
	"sk-SK":          "Spoločnosť Ring taktiež dosiahla mimosúdnu dohodu v spore so svojím konkurentom ADT Security.",
	"sl-SI":          "Podjetje Ring je prav tako doseglo izvensodno poravnavo v tožbi s svojim konkurentom ADT Security.",
	"so-SO":          "Shirkadda Ring waxay sidoo kale heshiis ka baxsan maxkamadda la gaadhay tartankeeda ADT Security dacwadooda dhex taallay.",
	"sq-AL":          "Kompania Ring arriti gjithashtu një marrëveshje jashtë gjykate në një padi me konkurrentin e saj ADT Security.",
	"sr-RS":          "Kompanija Ring je takođe postigla vansudsko poravnanje u tužbi protiv konkurentske kompanije ADT Security.",
	"sw-KE":          "Kampuni ya Ring pia ilifikia makubaliano nje ya mahakama katika kesi na mshindani wake ADT Security.",
	"sw-TZ":          "Kampuni ya Ring pia ilifikia makubaliano nje ya mahakama katika kesi na mpinzani wake ADT Security.",
	"ta-IN":          "ரிங் (Ring) நிறுவனம் தனது போட்டியாளரான ADT பாதுகாப்பு நிறுவனத்துடன் உள்ள வழக்கில் நீதிமன்றத்திற்கு வெளியே ஒரு ஒப்பந்தத்தை எட்டியுள்ளது.",
	"te-IN":          "రింగ్ (Ring) కంపెనీ తమ పోటీదారైన ADT భద్రతా కంపెనీతో ఉన్న కేసులో కోర్ట్ వెలుపల ఒప్పందానికి చేరుకుంది.",
	"th-TH":          "บริษัท Ring ยังได้บรรลุข้อตกลงนอกศาลในคดีความกับคู่แข่ง ADT Security",
	"tr-TR":          "Ring şirketi, rakibi ADT Security ile olan davada mahkeme dışı bir anlaşmaya vardı.",
	"uk-UA":          "Компанія Ring також досягла позасудового врегулювання у позові зі своїм конкурентом ADT Security.",
	"ur-IN":          "رِنگ (Ring) کمپنی نے اپنے حریف ADT سیکیورٹی کمپنی کے ساتھ جاری مقدمے میں عدالتی کارروائی سے باہر تصفیہ کر لیا۔",
	"uz-UZ":          "Ring kompaniyasi raqibi ADT Security bilan olib borilgan sud ishida suddan tashqari kelishuvga erishdi.",
	"vi-VN":          "Công ty Ring cũng đã đạt được thỏa thuận ngoài tòa án trong vụ kiện với đối thủ ADT Security.",
	"wuu-CN":         "Ring公司还同对手ADT安保公司官司里达成了法庭外和解。",
	"yue-CN":         "Ring公司同競爭對手ADT保安公司喺官司入面達成咗庭外和解。",
	"zh-CN-shandong": "Ring公司还同对手ADT安保公司官司里达成了法庭外和解。",
	"zh-CN-sichuan":  "Ring公司还同对手ADT安保公司官司里达成了法庭外和解。",
	"zh-HK":          "Ring公司亦與其競爭對手ADT保安公司於訴訟中達成庭外和解。",
	"zh-TW":          "Ring公司也與競爭對手ADT安保公司在訴訟中達成了庭外和解。",
	"zu-ZA":          "Inkampani iRing iphinde yafinyelela esivumelwaneni sangaphandle kwenkantolo ecaleni elibhekene nembangi yayo, i-ADT Security.",
	"ar-AE":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-BH":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-DZ":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-EG":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-IL":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-IQ":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-JO":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-KW":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-LB":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-LY":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-MA":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-OM":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-PS":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-QA":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-SA":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-SY":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-TN":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"ar-YE":          "توصلت شركة Ring أيضًا إلى تسوية ودية خارج المحكمة في دعوى قضائية مع منافستها شركة ADT للأمن.",
	"pt-BR":          "A empresa Ring também chegou a um acordo extrajudicial em um processo com sua concorrente ADT Security.",
	"pt-PT":          "A empresa Ring também chegou a um acordo extrajudicial num processo com a sua concorrente ADT Security.",
}

var LangSampleDict2 = map[string]string{
	"de-DE":          "Das ist die Stimme von Kara.",
	"en-US":          "This is Kara's voice.",
	"es-ES":          "Esta es la voz de Kara.",
	"fr-FR":          "C’est la voix de Kara.",
	"it-IT":          "Questa è la voce di Kara.",
	"ja-JP":          "これはカラの声です。",
	"ko-KR":          "이것은 카라의 목소리입니다.",
	"zh-CN":          "这是卡拉的声音。",
	"id-ID":          "Ini adalah suara Kara.",
	"af-ZA":          "Dit is Kara se stem.",
	"am-ET":          "ይህ የካራ ድምፅ ነው።",
	"az-AZ":          "Bu, Karanın səsidir.",
	"bg-BG":          "Това е гласът на Кара.",
	"bn-IN":          "এটি কারার কণ্ঠ।",
	"bs-BA":          "Ovo je Karin glas.",
	"ca-ES":          "Aquesta és la veu de Kara.",
	"ga-IE":          "Seo guth Kara.",
	"ru-RU":          "Это голос Кары.",
	"sv-SE":          "Det här är Karas röst.",
	"cs-CZ":          "To je hlas Kary.",
	"cy-GB":          "Dyma lais Kara.",
	"da-DK":          "Dette er Karas stemme.",
	"el-GR":          "Αυτή είναι η φωνή της Κάρα.",
	"et-EE":          "See on Kara hääl.",
	"eu-ES":          "Hau da Kararen ahotsa.",
	"fa-IR":          "این صدای کارا است.",
	"fi-FR":          "Tämä on Karan ääni.",
	"fil-PH":         "Ito ang boses ni Kara.",
	"gl-ES":          "Esta é a voz de Kara.",
	"gu-IN":          "આ કારાની અવાજ છે.",
	"he-IL":          "זה הקול של קארה.",
	"hi-IN":          "यह कारा की आवाज़ है।",
	"hr-HR":          "Ovo je Karin glas.",
	"hu-HU":          "Ez Kara hangja.",
	"hy-AM":          "Սա Կարայի ձայնն է։",
	"is-IS":          "Þetta er rödd Kara.",
	"jv-ID":          "Iki swarane Kara.",
	"ka-GE":          "ეს არის ქარას ხმა.",
	"kk-KZ":          "Бұл Караның дауысы.",
	"km-KH":          "នេះคือសំឡេងរបស់ការ៉ា។",
	"kn-IN":          "ಇದು ಕಾರಾದ ಧ್ವನಿ.",
	"lo-LA":          "ນີ້ແມ່ນສຽງຂອງ Kara.",
	"lt-LT":          "Tai yra Karos balsas.",
	"lv-LV":          "Šī ir Karas balss.",
	"mk-MK":          "Ова е гласот на Кара.",
	"ml-IN":          "ഇത് കാരയുടെ ശബ്ദമാണ്.",
	"mn-MN":          "Энэ бол Карагийн дуу хоолой.",
	"mr-IN":          "हा काराचा आवाज आहे.",
	"ms-MY":          "Ini suara Kara.",
	"mt-MT":          "Dan huwa l-vuċi ta’ Kara.",
	"my-MM":          "ဒါက ကရာရဲ့ အသံပါ။",
	"nb-NO":          "Dette er stemmen til Kara.",
	"ne-NP":          "यो काराको आवाज हो।",
	"nl-BE":          "Dit is de stem van Kara.",
	"nl-NL":          "Dit is de stem van Kara.",
	"pa-IN":          "ਇਹ ਕਾਰਾ ਦੀ ਆਵਾਜ਼ ਹੈ।",
	"pl-PL":          "To jest głos Kary.",
	"ps-AF":          "دا د کارا غږ دی.",
	"ro-RO":          "Aceasta este vocea Karei.",
	"si-LK":          "මේ කාරාගේ ස්වරයයි.",
	"sk-SK":          "Toto je Karin hlas.",
	"sl-SI":          "To je Karin glas.",
	"so-SO":          "Kani waa codka Kara.",
	"sq-AL":          "Ky është zëri i Kara-s.",
	"sr-RS":          "Ovo je Karin glas.",
	"sw-KE":          "Huu ni sauti ya Kara.",
	"sw-TZ":          "Huu ni sauti ya Kara.",
	"ta-IN":          "இது காராவின் குரல்.",
	"te-IN":          "ఇది కారా యొక్క గొంతు.",
	"th-TH":          "นี่คือเสียงของคาร่า",
	"tr-TR":          "Bu, Kara'nın sesi.",
	"uk-UA":          "Це голос Кари.",
	"ur-IN":          "یہ کارا کی آواز ہے۔",
	"uz-UZ":          "Bu Karaning ovozi.",
	"vi-VN":          "Đây là giọng của Kara.",
	"wuu-CN":         "这许是嘎拉个声音。",
	"yue-CN":         "呢個係Kara嘅聲音。",
	"zh-CN-shandong": "这是卡拉的声音。",
	"zh-CN-sichuan":  "这是卡拉的声音。",
	"zh-HK":          "這是卡拉的聲音。",
	"zh-TW":          "這是卡拉的聲音。",
	"zu-ZA":          "Lena yizwi lika Kara.",
	"ar-AE":          "هذا هو صوت كارا.",
	"ar-BH":          "هذا هو صوت كارا.",
	"ar-DZ":          "هذا هو صوت كارا.",
	"ar-EG":          "هذا هو صوت كارا.",
	"ar-IL":          "هذا هو صوت كارا.",
	"ar-IQ":          "هذا هو صوت كارا.",
	"ar-JO":          "هذا هو صوت كارا.",
	"ar-KW":          "هذا هو صوت كارا.",
	"ar-LB":          "هذا هو صوت كارا.",
	"ar-LY":          "هذا هو صوت كارا.",
	"ar-MA":          "هذا هو صوت كارا.",
	"ar-OM":          "هذا هو صوت كارا.",
	"ar-PS":          "هذا هو صوت كارا.",
	"ar-QA":          "هذا هو صوت كارا.",
	"ar-SA":          "هذا هو صوت كارا.",
	"ar-SY":          "هذا هو صوت كارا.",
	"ar-TN":          "هذا هو صوت كارا.",
	"ar-TE":          "هذا هو صوت كارا.",
	"pt-BR":          "Esta é a voz da Kara.",
	"pt-PT":          "Esta é a voz da Kara.",
}

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatRequest struct {
	Model       string    `json:"model"`
	Temperature float64   `json:"temperature"` // [0, 2)
	Messages    []Message `json:"messages"`
	Stream      bool      `json:"stream"`
	TopP        float64   `json:"top_p"`
}

type ChatResponse struct {
	Choices           []Choices `json:"choices"`
	Object            string    `json:"object"`
	Usage             Usage     `json:"usage"`
	Created           int       `json:"created"`
	SystemFingerprint string    `json:"system_fingerprint"`
	Model             string    `json:"model"`
	ID                string    `json:"id"`
}
type ChatStreamResponse struct {
	Choices []struct {
		FinishReason interface{} `json:"finish_reason"`
		Delta        struct {
			Content string `json:"content"`
		} `json:"delta"`
		Index int `json:"index"`
	} `json:"choices"`
	Object            string      `json:"object"`
	Usage             interface{} `json:"usage"`
	Created           int         `json:"created"`
	SystemFingerprint interface{} `json:"system_fingerprint"`
	Model             string      `json:"model"`
	Id                string      `json:"id"`
	SentenceEnd       bool
}

type Choices struct {
	Message      Message `json:"message"`
	FinishReason string  `json:"finish_reason"`
	Index        int     `json:"index"`
	Logrobs      string  `json:"logprobs"`
}
type Usage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

type TranslateClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	restyCli *resty.Client
	start    time.Time
	record   map[int32]*adaptermodel.TranslateRecord

	request  <-chan *adaptermodel.TranslateReq
	response chan<- *adaptermodel.TranslateResp
	first    *adaptermodel.TranslateReq
}

func NewTranslateClient(ctx context.Context, svcCtx *svc.ServiceContext,
	host string,
	request <-chan *adaptermodel.TranslateReq,
	response chan<- *adaptermodel.TranslateResp,
	first *adaptermodel.TranslateReq) *TranslateClient {

	first.FromLang = common.LanguageToIso6391(first.FromLang)
	first.ToLang = common.LanguageToIso6391(first.ToLang)

	restyCli := opentelemetry.WithTrace(resty.New()).
		SetTimeout(10*time.Second).
		SetTLSClientConfig(&tls.Config{InsecureSkipVerify: true}).
		SetHeader("Content-Type", "application/json").
		SetBaseURL(host)
	return &TranslateClient{
		ctx:      ctx,
		svcCtx:   svcCtx,
		Logger:   logx.WithContext(ctx),
		restyCli: restyCli,
		start:    time.Now(),
		record:   make(map[int32]*adaptermodel.TranslateRecord),
		request:  request,
		response: response,
		first:    first,
	}
}

func (c *TranslateClient) Translate(req *adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	if req.SentenceId <= 0 {
		return nil, fmt.Errorf("Translate, SentenceId is invalid: %d", req.SentenceId)
	}

	// 传入的字句非完整句子，特殊处理
	if !req.IsSentence {
		if !c.isProcessTmp(req.SentenceId, req.Text) {
			c.Debugf("Translate, not process tmp, SentenceId: %d, IsSentence: %t, text: %s", req.SentenceId, req.IsSentence, req.Text)
			return nil, nil
		}

		defer func() {
			// 记录处理时间
			c.recordProcessTime(req.SentenceId, req.Text)
		}()
	}

	c.start = time.Now()
	if req.Text == "" {
		return &adaptermodel.TranslateResp{
			Header:        &aicommon.RspHeader{Code: 0, Message: "success"},
			SentenceId:    req.SentenceId,
			SentenceStart: true,
			SentenceEnd:   true && req.IsSentence,
			Text:          "",
			Language:      c.first.ToLang,
			TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
		}, nil
	}

	request := c.buildRequest(req.Text)
	request.Stream = false // 单次请求不允许stream
	response := new(ChatResponse)
	if !req.IsSentence {
		request.Model = c.first.LlmTypeSentence
	}

	c.Infof("Translate, SentenceId: %d, request: %+v", req.SentenceId, *request)

	// 重试三次
	for i := 0; i < 3; i++ {
		ctx, cancel := context.WithTimeout(c.ctx, LLMTimeoutSecond*time.Second)
		defer cancel()

		// 从数组config.GetSrvConfig().ALiYun.ApiKey 中随机挑选一个字符串，作为apiKey
		apiKey := config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)].ApiKey[rand.Intn(len(config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)].ApiKey))]
		res, err := c.restyCli.R().
			SetHeader("Authorization", fmt.Sprintf("Bearer %s", apiKey)).
			SetContext(ctx).
			SetResult(response).
			SetBody(request).
			Post(ChatCompletionsPath)
		if err != nil {
			c.Errorf("error sending LLM request: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}

		if res.StatusCode() != http.StatusOK {
			c.Errorf("LLM response status code: %d, error : %s", res.StatusCode(), string(res.Body()))
			time.Sleep(500 * time.Millisecond)
			continue
		}

		if len(response.Choices) == 0 {
			c.Errorf("empty response from LLM")
			time.Sleep(500 * time.Millisecond)
			continue
		}

		response.Choices[0].Message.Content = c.extractTextFromResponse(response.Choices[0].Message.Content, req.Role)

		c.Infof("Translate, recv aliyun translate response %+v, SentenceId: %d, cost: %vms", response, req.SentenceId, res.Time().Milliseconds())
		return &adaptermodel.TranslateResp{
			Header:        &aicommon.RspHeader{Code: 0, Message: "success"},
			SentenceId:    req.SentenceId,
			SentenceStart: true,
			SentenceEnd:   true && req.IsSentence,
			Text:          response.Choices[0].Message.Content,
			Language:      c.first.ToLang,
			TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
		}, nil
	}

	return nil, fmt.Errorf("failed to get response from LLM for three times")
}

func (c *TranslateClient) TranslateStream() (err error) {
	defer close(c.response)
	c.start = time.Now()

	// send first package to Aliyun
	err = c.translateStream(c.first)
	if err != nil {
		return fmt.Errorf("TranslateStream, send first package failed, err: %v", err)
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop translate failed, err: %v", err)
	}
	return
}

func (c *TranslateClient) loop() (err error) {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("send text to aliyun llm end, ctx done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send text to aliyun llm end, request channel closed")
				return
			}
			if req == nil {
				c.Errorf("send text to aliyun llm end, the request is nil")
				return fmt.Errorf("send text to aliyun llm end, the request is nil")
			}

			err = c.translateStream(req)
			if err != nil {
				return fmt.Errorf("loop translate failed, err: %v", err)
			}
		}
	}
}

// TranslateStream
func (c *TranslateClient) translateStream(req *adaptermodel.TranslateReq) error {
	if req.Text == "" {
		c.Errorf("translateStream, send text to aliyun llm warning, the first text is nil")
		return nil
	}
	if req.SentenceId <= 0 {
		return fmt.Errorf("translateStream, SentenceId is invalid: %d", req.SentenceId)
	}

	// 非流式返回
	if !c.first.EnableStream {
		resp, err := c.Translate(req)
		if err != nil {
			return fmt.Errorf("translateStream, EnableStream:%v, Translate failed, err: %v", c.first.EnableStream, err)
		}

		if resp == nil {
			return nil
		}

		resp.TimeTakenMs = int32(time.Since(c.start).Milliseconds())
		c.response <- resp

		// 缓存完整子句的上下文
		if req.IsSentence {
			c.cacheContexts(req.Text, resp.Text)
		}
		return nil
	}

	// 传入的字句非完整句子，特殊处理
	if !req.IsSentence {
		if !c.isProcessTmp(req.SentenceId, req.Text) {
			c.Debugf("translateStream, not process tmp, SentenceId: %d, IsSentence: %t, text: %s", req.SentenceId, req.IsSentence, req.Text)
			return nil
		}

		defer func() {
			// 记录处理时间
			c.recordProcessTime(req.SentenceId, req.Text)
		}()
	}

	request := c.buildRequest(req.Text)
	if !req.IsSentence {
		request.Model = c.first.LlmTypeSentence
	}

	c.Infof("translateStream, SentenceId: %d, request: %+v", req.SentenceId, *request)
	for i := 0; i < 3; i++ {
		ctx, cancel := context.WithTimeout(c.ctx, LLMStreamTimeoutSecond*time.Second)
		defer cancel()

		// 从数组config.GetSrvConfig().ALiYun.ApiKey 中随机挑选一个字符串，作为apiKey
		apiKey := config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)].ApiKey[rand.Intn(len(config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)].ApiKey))]
		ret, err := c.restyCli.R().SetContext(ctx).
			SetHeader("Authorization", fmt.Sprintf("Bearer %s", apiKey)).
			SetDoNotParseResponse(true).
			SetBody(request).
			Post(ChatCompletionsPath)
		if err != nil {
			c.Errorf("error sending LLM request: %v", err)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		defer ret.RawBody().Close()

		if ret.StatusCode() != http.StatusOK {
			c.Errorf("LLM response status code: %d, error : %s", ret.StatusCode(), string(ret.Body()))
			time.Sleep(500 * time.Millisecond)
			continue
		}

		firstPackage := true
		fullText := ""
		scanner := bufio.NewScanner(ret.RawBody())
		for scanner.Scan() {
			line := scanner.Text()
			line = strings.Replace(line, "data: ", "", 1)
			if line == "" {
				continue
			}

			// 如果是结束标志
			if line == "[DONE]" {
				continue
			}

			var streamResponse ChatStreamResponse
			err = common.JsonToAny([]byte(line), &streamResponse)
			if err != nil {
				return fmt.Errorf("failed to unmarshal stream response: %+v, err: %v", line, err)
			}

			if len(streamResponse.Choices) == 0 {
				return fmt.Errorf("empty response from LLM, response: %v", streamResponse)
			}
			if streamResponse.Choices[0].Delta.Content == "" {
				continue
			}

			c.Debugf("TranslateStream, SentenceId: %d, recv aliyun translate response: [%+v]", req.SentenceId, streamResponse)
			fullText += streamResponse.Choices[0].Delta.Content

			c.response <- &adaptermodel.TranslateResp{
				Header:        &aicommon.RspHeader{Code: 0, Message: "success"},
				SentenceStart: firstPackage,
				SentenceEnd:   false && req.IsSentence,
				Text:          fullText,
				SentenceId:    req.SentenceId,
				Language:      c.first.ToLang,
				TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
			}

			if firstPackage {
				firstPackage = false
			}
		}

		c.response <- &adaptermodel.TranslateResp{
			Header:        &aicommon.RspHeader{Code: 0, Message: "success"},
			SentenceStart: firstPackage,
			SentenceEnd:   true && req.IsSentence,
			Text:          fullText,
			SentenceId:    req.SentenceId,
			Language:      c.first.ToLang,
			TimeTakenMs:   int32(time.Since(c.start).Milliseconds()),
		}

		c.cacheContexts(req.Text, fullText)
		c.Infof("TranslateStream, recv aliyun translate response: [%s], SentenceId: %d, cost: %vms", fullText, req.SentenceId, ret.Time().Milliseconds())
		return nil
	}

	c.Errorf("failed to get response from LLM for three times")
	return fmt.Errorf("failed to get response from LLM for three times")
}

func (c *TranslateClient) isProcessTmp(sentenceId int32, text string) bool {
	c.Debugf("isProcessTmp, SentenceId: %d, text: %s, c.record: %v", sentenceId, text, c.record)
	if len(text) < 3 {
		return false
	}

	if _, ok := c.record[sentenceId]; !ok {
		c.record[sentenceId] = &adaptermodel.TranslateRecord{
			SentenceId: sentenceId,
			StartTime:  time.Now(),
		}
	} else {
		// 0.5s内不处理
		if time.Since(c.record[sentenceId].EndTime) < time.Millisecond*TranslateTempIntervalMs {
			return false
		}
	}
	c.Debugf("isProcessTmp, SentenceId: %d, c.record: %v", sentenceId, c.record)
	return true
}

func (c *TranslateClient) recordProcessTime(sentenceId int32, text string) {
	if r, ok := c.record[sentenceId]; ok {
		if r != nil {
			r.EndTime = time.Now()
			r.Text = text
		} else {
			c.Errorf("recordProcessTime, SentenceId: %d, record is nil", sentenceId)
			c.record[sentenceId] = &adaptermodel.TranslateRecord{
				SentenceId: sentenceId,
				StartTime:  time.Now(),
				EndTime:    time.Now(),
				Text:       text,
			}
		}
	}
}

func (c *TranslateClient) extractTextFromResponse(text string, role string) string {
	// 分割文本并获取最后一部分
	parts := strings.Split(text, "[target]")
	lastPart := parts[len(parts)-1]

	// 移除'#'字符并去除两端空白
	lastPart = strings.ReplaceAll(lastPart, "#", "")
	lastPart = strings.TrimSpace(lastPart)

	transRet := text

	// 替换换行符和回车符为空格，并去除两端空白
	transRet = strings.ReplaceAll(transRet, "\n", " ")
	transRet = strings.ReplaceAll(transRet, "\r", " ")
	// 去掉 ROLE : 或者 ROLE:
	transRet = strings.ReplaceAll(transRet, role+":", "")
	transRet = strings.ReplaceAll(transRet, role+" :", "")
	transRet = strings.TrimSpace(transRet)
	return transRet
}

func (c *TranslateClient) cacheContexts(original, translation string) {
	c.first.Contexts = append(c.first.Contexts, &adaptermodel.TranslateContext{
		Role: c.first.Role,
		Lang: c.first.FromLang,
		Text: original,
	})
	c.first.Contexts = append(c.first.Contexts, &adaptermodel.TranslateContext{
		Role: c.first.Role,
		Lang: c.first.ToLang,
		Text: translation,
	})
}

func (c *TranslateClient) buildRequest(text string) (chatRequest *ChatRequest) {
	chatRequest = &ChatRequest{
		Model:       c.first.LlmType,
		Stream:      c.first.EnableStream,
		TopP:        TopP,
		Temperature: Temperature,
		Messages:    []Message{},
	}

	if c.first.FromLang == "auto" {
		chatRequest.Messages = []Message{
			{
				Role: RoleUser,
				Content: fmt.Sprintf(TranslatePromptV3WithAutoDetectLanguage,
					c.first.ToLang,
					LangSampleDict[c.first.ToLang],
					text),
			},
		}
		return chatRequest
	}

	context := ""
	if len(c.first.Contexts) > 0 {
		contexts := c.first.Contexts
		if len(contexts) > 10 {
			contexts = contexts[len(contexts)-10:]
		}

		for _, v := range contexts {
			if v.Lang != c.first.FromLang {
				continue
			}
			if v.Role == "" || v.Text == "" {
				continue
			}
			context += fmt.Sprintf("%s: %s\n", v.Role, v.Text)
		}
	}

	chatRequest.Messages = []Message{
		{
			Role:    RoleSystem,
			Content: TranslateSystemPrompt,
		},
		{
			Role: RoleUser,
			Content: fmt.Sprintf(TranslatePromptTemplate,
				c.first.FromLang,
				c.first.ToLang,
				context,
				text,
			),
		},
	}

	return chatRequest
}
