package anker

import (
	"context"
	"fmt"
	"io"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/vadserverrpc"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
)

func (e *AnkerAdapter) vadRecv(ctx context.Context, stream vadserverrpc.VadServerRpc_LanguageDetectClient, response chan<- *adaptermodel.LanguageDetectResp) error {
	defer close(response)

	for {
		resp, err := stream.Recv()
		if err != nil {
			if err == io.EOF || err == context.Canceled {
				e.Infof("recv resp from vad server stream end, %v", err)
				return nil
			}
			return fmt.Errorf("recv resp from vad server stream failed, err: %v", err)
		}

		select {
		case <-ctx.Done():
			e.Infof("recv resp from vad server stream end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from vad server stream end, logic context done")
			return nil
		default:
			if resp == nil {
				return fmt.Errorf("recv resp from vad server stream failed, resp is nil")
			}
			if resp.Code != 0 {
				e.Errorf("recv resp from vad server stream, code: %d, message: %s", resp.Code, resp.Message)
				return fmt.Errorf("recv resp from vad server stream failed, code: %d, message: %s", resp.Code, resp.Message)
			}

			resp.Language = common.LanguageToIso6391(resp.Language)
			if resp.Language == "" {
				e.Errorf("recv resp from vad server stream, unsupported language: %s", resp.Language)
				return fmt.Errorf("recv resp from vad server stream failed, unsupported language: %s", resp.Language)
			}
			e.Infof("recv resp from vad server stream, Language: %s, Confidence: %v, code: %d, message: %s", resp.Language, resp.Confidence, resp.Code, resp.Message)

			response <- &adaptermodel.LanguageDetectResp{
				Header: &aicommon.RspHeader{
					Code:    resp.Code,
					Message: resp.Message,
				},
				Language:    resp.Language,
				Confidence:  resp.Confidence,
				TimeTakenMs: resp.TimeTakenMs,
			}
		}
	}
}

func (e *AnkerAdapter) vadSend(ctx context.Context, stream vadserverrpc.VadServerRpc_LanguageDetectClient, request <-chan *adaptermodel.LanguageDetectReq) error {
	defer stream.CloseSend()
	taskId := ""
	vadPackIdx := int32(1)
	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to vad server stream end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to vad server stream end, logic context done")
			return nil
		case req, ok := <-request:
			if !ok {
				e.Infof("send req to vad server stream end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send message failed, request is nil")
			}
			if req.Audio == nil {
				return fmt.Errorf("send message failed, audio is nil")
			}

			if taskId == "" {
				taskId = req.TaskId
			}
			r := &vadserverrpc.LanguageDetectReq{
				TaskId:  taskId,
				PackIdx: vadPackIdx,
				Audio: &vadserverrpc.AudioInfo{
					Data:       req.Audio.Data,
					SampleRate: req.Audio.SampleRate,
					BitRate:    req.Audio.BitRate,
					Channels:   req.Audio.Channels,
					Format:     req.Audio.Format,
				},
			}

			err := stream.Send(r)
			if err != nil {
				return fmt.Errorf("send message failed, err: %v", err)
			}
			vadPackIdx++
		}
	}
}
