package texttospeech

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type TextToSpeechExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	buf *bytes.Buffer

	once   bool
	taskId string
}

func NewTextToSpeechExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *TextToSpeechExecutor {
	return &TextToSpeechExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		buf:    new(bytes.Buffer),
		once:   true,
	}
}

func (e *TextToSpeechExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	return nil, fmt.Errorf("Inference not implemented")
}

func (e *TextToSpeechExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}

	if config.GetSrvConfig().TtsSaveAudio {
		index := 0
		for e.buf.Len() > 0 {
			index++
			data := common.BytesToBase64(e.buf.Next(8000))
			e.Infof("recv resp data from tts engine, TaskId: %s, index:%d, Base64 Audio: [%s]", e.taskId, index, data)
		}
		e.Infof("recv resp data from tts engine, TaskId: %s, total index: %d", e.taskId, index)
	}

	e.Info("TextToSpeechExecutor StreamInference end")
	return nil
}

func (e *TextToSpeechExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		return fmt.Errorf("doStreamInference recv first message failed, request is nil")
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("doStreamInference recv tts first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	ttsReq := make(chan *adaptermodel.TextToSpeechReq, 100)
	ttsResp := make(chan *adaptermodel.TextToSpeechResp, 100)
	ttsReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from tts engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, ttsResp, cliResp)
	})
	// send message to tts engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, ttsReq, cliReq)
	})
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.TextToSpeechStreamHandler(ttsReq, ttsResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *TextToSpeechExecutor) recv(ctx context.Context, ttsResp <-chan *adaptermodel.TextToSpeechResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case <-ctx.Done():
			e.Infof("recv resp from tts engine stream end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from tts engine stream end, logic context done")
			return nil
		case resp, ok := <-ttsResp:
			if !ok {
				e.Infof("recv resp from tts engine end, ttsResp channel closed")
				return nil
			}

			if config.GetSrvConfig().TtsSaveAudio && resp.Audio != nil {
				e.buf.Write(resp.Audio.Data)
			}

			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}

			cliResp <- res
		}
	}
}

func (e *TextToSpeechExecutor) send(ctx context.Context, ttsReq chan<- *adaptermodel.TextToSpeechReq, cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(ttsReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to tts engine stream end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to tts engine stream end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to tts engine stream end, request channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to tts failed, request is nil")
			}

			r, err := e.buildParameter(req)
			if err != nil {
				return fmt.Errorf("buildParameter failed, err: %v", err)
			}

			ttsReq <- r
		}
	}
}

func (e *TextToSpeechExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.TextToSpeechReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.TextToSpeechInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.TextToSpeechExtendedParameter
	if e.once {
		e.once = false
		e.taskId = in.Header.TaskId

		if in.Header.AppId == "" {
			return nil, fmt.Errorf("AppId is empty")
		}

		if in.ExtendedParameter == "" {
			return nil, fmt.Errorf("ExtendedParameter is empty")
		}
		err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
		if err != nil {
			return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
		}

		err = e.checkParameter(&iPara, &ePara)
		if err != nil {
			return nil, fmt.Errorf("checkParameter failed, err: %v", err)
		}
	}

	return &adaptermodel.TextToSpeechReq{
		TaskId:          in.Header.TaskId,
		AppId:           in.Header.AppId,
		Format:          ePara.Format,
		SampleRate:      ePara.SampleRate,
		Bitrate:         ePara.BitRate,
		Voice:           ePara.Voice,
		Speed:           ePara.Speed,
		Volume:          ePara.Volume,
		Pitch:           ePara.Pitch,
		Channels:        ePara.Channels,
		Language:        ePara.Language,
		EnableSubtitle:  ePara.EnableSubtitle,
		ServiceProvider: ePara.ServiceProvider,
		Text:            iPara.Text,
		SentenceId:      iPara.SentenceId,
	}, nil
}

func (e *TextToSpeechExecutor) checkParameter(
	iPara *aiparameter.TextToSpeechInferenceParameter,
	ePara *aiparameter.TextToSpeechExtendedParameter) error {
	// check ePara
	if ePara.Format != "" {
		ePara.Format = strings.ToLower(ePara.Format)
		if !common.IsExistInArray(config.SUPPORTEN_FORMAT, ePara.Format) {
			return fmt.Errorf("ExtendedParameter Format is invalid, Format: %s", ePara.Format)
		}
	} else {
		ePara.Format = config.AUDIO_FORMAT_PCM
	}

	if ePara.SampleRate == 0 {
		ePara.SampleRate = 16000
	}
	switch ePara.SampleRate {
	case 16000:
	default:
		return fmt.Errorf("ExtendedParameter SampleRate is invalid, SampleRate: %d", ePara.SampleRate)
	}
	if ePara.BitRate == 0 {
		ePara.BitRate = 16000
	}
	switch ePara.BitRate {
	case 8000, 16000, 32000, 48000, 64000, 96000, 128000, 192000, 256000:
	default:
		return fmt.Errorf("ExtendedParameter BitRate is invalid, BitRate: %d", ePara.BitRate)
	}
	// 语速，范围为-500~500，默认0
	if ePara.Speed < -500 || ePara.Speed > 500 {
		ePara.Speed = 0
	}
	// 音量，范围为0~100，默认50
	if ePara.Volume < 0 || ePara.Volume > 100 {
		ePara.Volume = 50
	}
	// 音调，范围为-500~500，默认0
	if ePara.Pitch < -500 || ePara.Pitch > 500 {
		ePara.Pitch = 0
	}
	if ePara.Channels != 1 {
		return fmt.Errorf("ExtendedParameter Channels is invalid, Channels: %d", ePara.Channels)
	}
	if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, ePara.Language) {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, ePara.Language) {
			return fmt.Errorf("ExtendedParameter Language is invalid, Language: %s", ePara.Language)
		} else {
			ePara.Language = common.LanguageToBcp47(ePara.Language)
		}
	}
	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ALIYUN, config.ADAPTER_SERVICE_TYPE_ANKER, config.ADAPTER_SERVICE_TYPE_AZURE:
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
	}

	return nil
}

func (e *TextToSpeechExecutor) buildResponse(resp *adaptermodel.TextToSpeechResp) (*aiadapterrpc.InferenceResp, error) {
	textToSpeech := &aiparameter.TextToSpeechInferenceResultInfo{
		Audio:         resp.Audio,
		SentenceId:    resp.SentenceId,
		SentenceStart: resp.SentenceStart,
		Subtitle:      resp.Subtitles,
		Timestamp:     time.Now().UnixMilli(),
	}
	// 保留最新的10个字幕
	if len(textToSpeech.Subtitle) > 10 {
		textToSpeech.Subtitle = textToSpeech.Subtitle[len(textToSpeech.Subtitle)-10:]
	}

	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Text_To_Speech,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_TextToSpeech{
			TextToSpeech: textToSpeech,
		},
	}

	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
