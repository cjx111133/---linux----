package task

import (
	"context"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/audio"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/chat"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/ping"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

type IStreamTask interface {
	// Handle 流式任务
	Handle(msg *types.WebSocketReq) error
}

// StreamTaskFactory 流式任务工厂
// type StreamTaskFactory struct {
// 	ctx    context.Context
// 	svcCtx *svc.ServiceContext
// 	ws     *types.WebSocketData
// }

func NewStreamTaskMap(ctx context.Context, svcCtx *svc.ServiceContext, data *types.WebSocketData) map[string]IStreamTask {
	streamTaskMap := make(map[string]IStreamTask)
	streamTaskMap[types.CmdTranslate], _ = audio.NewAudioTranslate(ctx, svcCtx, data)
	streamTaskMap[types.CmdChat], _ = chat.NewChat(ctx, svcCtx, data)
	streamTaskMap[types.CmdPing], _ = ping.NewPing(ctx, svcCtx, data)
	return streamTaskMap
}
