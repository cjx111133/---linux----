package faceswap

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type FaceSwapExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewFaceSwapExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *FaceSwapExecutor {
	return &FaceSwapExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *FaceSwapExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, err
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *FaceSwapExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *FaceSwapExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.FaceSwapReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	var iPara aiparameter.FaceSwapInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	userImages := make([]string, len(iPara.Images))
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
		userImages[i] = image.FileData
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.FaceSwapExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.TemplateImage == nil || ePara.TemplateImage.FileData == "" {
		return nil, fmt.Errorf("ExtendedParameter TemplateImage is nil")
	}

	if len(ePara.FacialAreas) == 0 {
		return nil, fmt.Errorf("ExtendedParameter FacialAreas is nil")
	}
	facialAreas := make([][]float64, len(ePara.FacialAreas))
	for i, facialArea := range ePara.FacialAreas {
		if facialArea == nil {
			return nil, fmt.Errorf("ExtendedParameter FacialAreas[%d] is nil", i)
		}
		if facialArea.X1 < 0 || facialArea.X2 < 0 || facialArea.Y1 < 0 || facialArea.Y2 < 0 {
			return nil, fmt.Errorf("ExtendedParameter FacialAreas[%v] is invalid, x1: %v, x2: %v, y1: %v, y2: %v", i, facialArea.X1, facialArea.X2, facialArea.Y1, facialArea.Y2)
		}
		facialAreas[i] = []float64{facialArea.X1, facialArea.Y1, facialArea.X2, facialArea.Y2}
	}
	thumbUpTokens := ""
	if len(in.ThumbUpTokens) > 0 {
		thumbUpTokens = in.ThumbUpTokens[0]
	}
	req := &adaptermodel.FaceSwapReq{
		TaskId:                      in.Header.TaskId,
		TemplateImage:               ePara.TemplateImage.FileData,
		FacialAreas:                 facialAreas,
		FaceImages:                  userImages,
		Prompt:                      ePara.Prompt,
		NegativePrompt:              ePara.NegativePrompt,
		MaskStrength:                ePara.MaskStrength,
		IpAdapterScale:              ePara.IpAdapterScale,
		ControlnetConditioningScale: ePara.ControlnetConditioningScale,
		NumInferenceSteps:           ePara.NumInferenceSteps,
		GuidanceScale:               ePara.GuidanceScale,
		ResultImageUpToken:          in.ResultUpTokens[0],
		ThumbnailImageUpToken:       thumbUpTokens,
	}
	return req, nil

}

func (e *FaceSwapExecutor) doInference(req *adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.FaceSwapHandler(req)
	if err != nil {
		return nil, fmt.Errorf("FaceSwapHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("FaceSwapHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		if result.Code == codes.CodeFaceSwapNoFaceInFaceImage {
			return nil, grpcerrors.Errorf(codes.CodeFaceSwapNoFaceInFaceImage, result.Message, grpcerrors.FindCaller(1))
		}
		if result.Code == codes.CodeFaceSwapRetryLimitReached {
			e.Errorf("task id: %s, FaceSwapHandler failed, code: %d, message: %s", req.TaskId, result.Code, result.Message)
		} else {
			return nil, fmt.Errorf("task id: %s, FaceSwapHandler failed, code: %d, message: %s", req.TaskId, result.Code, result.Message)
		}
	}

	return result, nil
}

func (e *FaceSwapExecutor) buildResponse(resp *adaptermodel.FaceSwapResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Face_Swap,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_FaceSwap{
			FaceSwap: &aiparameter.FaceSwapInferenceResultInfo{
				Scores: resp.Score,
				Retry:  resp.Retry,
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
		FileData: resp.ResultImage,
		FileMd5:  resp.ImageMd5,
		FileSize: resp.ImageSize,
	})
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
