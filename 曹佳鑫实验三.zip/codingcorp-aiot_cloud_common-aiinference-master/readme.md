## 配置
1、新增说话之后的间隔超时：next_time_period  2
2、新增语种检测间隔超时：lang_detect_period  10
3、修改大语言模型：ExternalModel   从aliyun改为azure
4、修改llm模型：translate.llm_type   从qianwen改为gpt-4o
ps: 配置一定要按以上修改，阿里云的模型不能识别双麦


v1.5.0 新增配置
1. Chat.SpeechGapThreshold json speech_gap_threshold 实时聊天断句间隔 单位毫秒，默认值 2000
2. Chat.SpeechInactivityTimeout json speech_inactivity_timeout  实时聊天不活跃时间 单位毫秒 默认8000
