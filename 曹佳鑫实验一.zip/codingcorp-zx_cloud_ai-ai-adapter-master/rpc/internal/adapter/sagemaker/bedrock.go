package sagemaker

import (
	"context"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/constants"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"fmt"
	"github.com/aws/aws-sdk-go/service/bedrockruntime"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

type BedRockRuntime struct {
	qualifiers          string // 限定词   有效值：grounding_source | query | guard_content
	source              string // 应用护栏的请求中使用的数据源  有效值: INPUT | OUTPUT
	guardrailIdentifier string
	guardrailVersion    string
	enable              bool
	logx.Logger
}

func NewBedRockRuntime(ctx context.Context) *BedRockRuntime {
	return &BedRockRuntime{
		qualifiers:          constants.Qualifiers,
		source:              constants.Source,
		guardrailIdentifier: config.GetSrvConfig().AwsBedRock.GuardrailIdentifier,
		guardrailVersion:    config.GetSrvConfig().AwsBedRock.GuardrailVersion,
		enable:              config.GetSrvConfig().AwsBedRock.Enable,
		Logger:              logx.WithContext(ctx),
	}
}

func (b *BedRockRuntime) SetQualifiers(qualifiers string) {
	b.qualifiers = qualifiers
}
func (b *BedRockRuntime) SetSource(source string) {
	b.source = source
}
func (b *BedRockRuntime) SetGuardrailIdentifier(guardrailIdentifier string) {
	b.guardrailIdentifier = guardrailIdentifier
}
func (b *BedRockRuntime) SetGuardrailVersion(guardrailVersion string) {
	b.guardrailVersion = guardrailVersion
}
func (b *BedRockRuntime) SetEnable(enable bool) {
	b.enable = enable
}

func (b *BedRockRuntime) ApplyGuardrail(inputText string) (*bedrockruntime.GuardrailContentFilter, error) {
	if !b.enable {
		b.Logger.Info("bedrock runtime is disable")
		return nil, nil
	}

	if inputText == "" {
		return nil, fmt.Errorf("input text is empty")
	}

	input := &bedrockruntime.ApplyGuardrailInput{
		Content:             make([]*bedrockruntime.GuardrailContentBlock, 0),
		GuardrailIdentifier: &b.guardrailIdentifier,
		GuardrailVersion:    &b.guardrailVersion,
		Source:              &b.source,
	}

	text := &bedrockruntime.GuardrailTextBlock{
		Qualifiers: []*string{&b.qualifiers},
		Text:       &inputText,
	}

	block := bedrockruntime.GuardrailContentBlock{
		Text: text,
	}

	input.Content = append(input.Content, &block)

	timeStart := time.Now()
	// 调用 ApplyGuardrail API
	output, err := GetSgmClient().BedRockRuntime.ApplyGuardrail(input)
	defer func() {
		b.Infof("bedrock applyGuardrail call time: %v ms", time.Since(timeStart).Milliseconds())
	}()
	if err != nil {
		return nil, err
	}

	policyContent := "sensitive"

	for _, item := range output.Assessments {
		// 内容
		if item.ContentPolicy != nil && len(item.ContentPolicy.Filters) > 0 {
			for _, policy := range item.ContentPolicy.Filters {
				return policy, nil
			}
		}
		// 上下文
		if item.ContextualGroundingPolicy != nil && len(item.ContextualGroundingPolicy.Filters) > 0 {
			for _, policy := range item.ContextualGroundingPolicy.Filters {
				return &bedrockruntime.GuardrailContentFilter{
					Action:     policy.Action,
					Confidence: &policyContent,
					Type:       policy.Type,
				}, nil
			}
		}
		// 敏感信息
		if item.SensitiveInformationPolicy != nil && len(item.ContextualGroundingPolicy.Filters) > 0 {
			return &bedrockruntime.GuardrailContentFilter{
				Action:     &policyContent,
				Confidence: &policyContent,
				Type:       &policyContent,
			}, nil
		}
		// 禁止的话题
		if item.TopicPolicy != nil && len(item.TopicPolicy.Topics) > 0 {
			return &bedrockruntime.GuardrailContentFilter{
				Action:     &policyContent,
				Confidence: &policyContent,
				Type:       &policyContent,
			}, nil
		}
		// 关键词
		if item.WordPolicy != nil && (len(item.WordPolicy.CustomWords) > 0 || len(item.WordPolicy.ManagedWordLists) > 0) {
			return &bedrockruntime.GuardrailContentFilter{
				Action:     &policyContent,
				Confidence: &policyContent,
				Type:       &policyContent,
			}, nil
		}
	}
	return nil, nil
}
