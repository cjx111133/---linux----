package config

import "testing"

func TestSpeechToTextParamString(t *testing.T) {
	// 定义测试案例
	tests := []struct {
		name           string
		param          SpeechToTextParam
		targetLanguage string
		want           string
	}{
		{
			name: "正常情况",
			param: SpeechToTextParam{
				EndPointType:       "audio",
				AddPunctuation:     true,
				MaxSentenceSilence: 500,
				EnableWord:         true,
			},
			targetLanguage: "en",
			want:           `{"target_language": "en","end_point_type": "audio","add_punctuation": true,"max_sentence_silence": 500,"enable_word": true, "service_provider": "anker"}`,
		},
		{
			name: "无标点和单词启用",
			param: SpeechToTextParam{
				EndPointType:       "video",
				AddPunctuation:     false,
				MaxSentenceSilence: 300,
				EnableWord:         false,
			},
			targetLanguage: "zh",
			want:           `{"target_language": "zh","end_point_type": "video","add_punctuation": false,"max_sentence_silence": 300,"enable_word": false, "service_provider": "anker"}`,
		},
	}

	// 遍历测试案例
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.param.String(tt.targetLanguage, false); got != tt.want {
				t.Errorf("SpeechToTextParam.string() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestTranslateParamString(t *testing.T) {
	// 定义测试用例
	testCases := []struct {
		name     string
		param    TranslateParam
		role     string
		fromLang string
		toLang   string
		want     string
	}{
		{
			name:     "正常情况",
			param:    TranslateParam{LlmType: "general", EnableStream: false},
			role:     "user",
			fromLang: "en",
			toLang:   "zh",
			want:     `{"from_lang": "en","to_lang": "zh","llm_type": "general","role": "user","enable_stream": false, "service_provider": "anker"}`,
		},
		{
			name:     "启用流式传输",
			param:    TranslateParam{LlmType: "general", EnableStream: true},
			role:     "user",
			fromLang: "en",
			toLang:   "zh",
			want:     `{"from_lang": "en","to_lang": "zh","llm_type": "general","role": "user","enable_stream": true, "service_provider": "anker"}`,
		},
		{
			name:     "空的语言字段",
			param:    TranslateParam{LlmType: "general", EnableStream: false},
			role:     "user",
			fromLang: "",
			toLang:   "",
			want:     `{"from_lang": "","to_lang": "","llm_type": "general","role": "user","enable_stream": false, "service_provider": "anker"}`,
		},
		// 可以添加更多的边缘情况测试用例
	}

	// 遍历测试用例
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			// 调用 string 方法
			got := tc.param.String(tc.role, tc.fromLang, tc.toLang, false)
			// 比较结果
			if got != tc.want {
				t.Errorf("TranslateParam.string() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestTextToSpeechParamString(t *testing.T) {
	cases := []struct {
		name     string
		param    TextToSpeechParam
		format   string
		sample   int32
		bit      int32
		channels int32
		language string
		want     string
	}{
		{
			name: "正常情况",
			param: TextToSpeechParam{
				Voice:          "{\"zh\":\"aijia\",\"en\":\"brian\",\"ja\":\"tomoya\"}",
				Speed:          1,
				Volume:         5,
				Pitch:          1,
				EnableSubtitle: true,
			},
			format:   "mp3",
			sample:   16000,
			bit:      128,
			channels: 1,
			language: "zh",
			want:     `{"format": "mp3","sample_rate": 16000,"bit_rate": 128,"channels": 1,"language": "zh","voice": "aijia","speed": 1,"volume": 5,"pitch": 1,"enable_subtitle": true, "service_provider": "anker"}`,
		},
	}

	for _, tt := range cases {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.param.String(tt.format, tt.sample, tt.bit, tt.channels, tt.language)
			if got != tt.want {
				t.Errorf("TextToSpeechParam.string() = %v, want %v", got, tt.want)
			}
		})
	}
}
