package logic

import (
	"context"
	"fmt"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetTrainLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetTrainLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTrainLogic {
	return &GetTrainLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 获取训练状态
func (l *GetTrainLogic) GetTrain(in *aiadapterrpc.GetTrainReq) (*aiadapterrpc.GetTrainResp, error) {
	timeStart := time.Now()
	resp := &aiadapterrpc.GetTrainResp{
		Header: &aicommon.RspHeader{
			Code:    codes.CodeOk,
			Message: "success",
		},
	}

	// check input
	if err := l.checkParam(in); err != nil {
		resp.Header.Code = codes.CodeInputParamInvalid
		resp.Header.Message = fmt.Sprintf("GetTrain check param failed, err: %v", err)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	defer func() {
		l.Infof("GetTrain end, task id: %s, total time: %v ms", in.Header.TaskId, resp.TimeTakenMs)
	}()
	l.Infof("GetTrain start, task id: %s", in.Header.TaskId)

	// create adapter
	adapter, err := adapter.NewAdapter(l.ctx, l.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("NewAdapter failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	req := &adaptermodel.GetTrainReq{
		TaskId: in.Header.TaskId,
		UserId: in.Header.UserId,
	}
	result, err := adapter.GetTrainHandler(req)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("GetTrainHandler failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	if result == nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("GetTrainHandler failed, task id: %s, result is nil", in.Header.TaskId)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	if result.Code != codes.CodeOk {
		resp.Header.Code = result.Code
		resp.Header.Message = result.Message
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	status := &aiparameter.TrainResultInfo{
		Status:   result.Status,
		Progress: result.Progress,
	}
	js, err := common.AnyToJson(status)
	if err != nil {
		return nil, fmt.Errorf("AnyToJson failed: %v", err)
	}
	resp.InferenceResultInfo = string(js)
	resp.ResultModel = &aicommon.FileInfo{
		FileData: result.ModelPath,
	}
	resp.TimeTakenMs = int32(time.Since(timeStart).Milliseconds())
	return resp, nil
}

func (l *GetTrainLogic) checkParam(in *aiadapterrpc.GetTrainReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.TaskId == "" {
		return fmt.Errorf("task id is empty")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}

	return nil
}
