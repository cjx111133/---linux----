package handler

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/other"
	"net/http"
	"strings"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/response"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

func EquipmentAnkaHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.AnkaRequest
		if err := httpx.Parse(r, &req); err != nil {
			httpx.Error(w, err)
			return
		}

		// 获取请求参数
		req.Cmd = r.URL.Query().Get("cmd")
		req.SessionId = r.URL.Query().Get("session_id")

		// 检查是否是WebSocket连接请求
		if strings.EqualFold(r.Header.Get("Connection"), "Upgrade") {
			// 设备请求的WebSocket连接，与普通WebSocket相同处理方式
			handleWebSocketConnection(w, r, &req, svcCtx)
		} else {
			// 处理普通HTTP请求
			l := other.NewEquipmentAnkaLogic(r.Context(), svcCtx)
			resp, err := l.EquipmentAnka(&req)
			response.Response(r, w, resp, err)
		}
	}
}
