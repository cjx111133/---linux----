package popart

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/popartrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"github.com/zeromicro/go-zero/core/logx"
)

type PopArtExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewPopArtExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *PopArtExecutor {
	return &PopArtExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *PopArtExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *PopArtExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *PopArtExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*popartrpc.PopArtReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	var iPara aiparameter.PopArtInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.PopArtExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	req := &popartrpc.PopArtReq{
		Header: &aicommon.ReqHeader{
			UserId: in.Header.UserId,
			TaskId: in.Header.TaskId,
		},
		Image:              iPara.Images[0],
		ResultImageUpToken: in.ResultUpTokens[0],
		PopArtParameter:    &ePara,
	}
	return req, nil

}

func (e *PopArtExecutor) doInference(req *popartrpc.PopArtReq) (*popartrpc.PopArtResp, error) {
	resp, err := e.svcCtx.PopArtRpc.PopArt(e.ctx, req)
	if err != nil {
		return nil, fmt.Errorf("PopArt failed, err: %v", err)
	}
	if resp.Header == nil {
		return nil, fmt.Errorf("PopArt Header is nil")
	}
	if resp.Header.Code != codes.CodeOk {
		return nil, fmt.Errorf("PopArt Header Code is not ok, code: %v", resp.Header.Code)
	}
	if resp.ResultImage == nil {
		return nil, fmt.Errorf("PopArt ResultImage is nil")
	}
	return resp, nil
}

func (e *PopArtExecutor) buildResponse(resp *popartrpc.PopArtResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Pop_Art,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_PopArt{
			PopArt: &aiparameter.PopArtInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = resp.Header
	out.ResultImages = append(out.ResultImages, resp.ResultImage)
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
