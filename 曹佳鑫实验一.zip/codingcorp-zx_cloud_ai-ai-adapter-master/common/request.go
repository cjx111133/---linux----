package common

import (
	"bytes"
	"io/ioutil"
	"net/http"
	"time"
)

// Post http post 请求
func PostRequest(url string, headers map[string]string, data []byte, timeout int) ([]byte, error) {
	// 创建POST请求
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(data))
	if err != nil {
		return nil, err
	}

	// 设置HTTP头
	for key, value := range headers {
		req.Header.Set(key, value)
	}
	req.Header.Set("Content-Type", "application/json")

	// 创建HTTP客户端并设置超时时间
	client := &http.Client{
		Timeout: time.Duration(timeout) * time.Second,
	}

	// 发送请求
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// 读取响应内容
	return ioutil.ReadAll(resp.Body)
}
