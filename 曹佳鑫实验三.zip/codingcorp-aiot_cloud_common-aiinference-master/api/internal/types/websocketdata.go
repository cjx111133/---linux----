package types

type WebSocketData struct {
	ConnectionInfo *ConnectionInfo `json:"connect_info"`
	RetryConn      bool            `json:"retry_conn"`
	SendWsChan     chan []byte     `json:"-"` // 发送消息通道
	StopWsChan     chan struct{}   `json:"-"` // 停止通道
}

type HeaderEncryptData struct {
	XEncryptionInfo string `json:"x_encryption_info"` // 加密信息
	XRequestOnce    string `json:"x_request_once"`    // 请求一次
	XRequestTs      string `json:"x_request_ts"`      // 请求时间戳
	XKeyIdent       string `json:"x_key_ident"`       // key标识
	XSignature      string `json:"x_signature"`       // 签名
}

type WebSocketRedisSessionData struct {
	CurrentMessageId string `json:"current_message_id"` // 当前messageId，用于返回客户端数据和处理下一消息的rpc创建，在处理下一消息之前，需要等待当前消息处理完成
	LastMessageId    string `json:"last_message_id"`    // 上一条消息id，消息包是经过首包、中间包、结束包的，用于校验MessageId是否连续
}

type WebSocketReq struct {
	MsgId        string `json:"msg_id"`        // 请求消息ID
	Timestamp    int64  `json:"timestamp"`     // 时间戳（毫秒）
	Cmd          string `json:"cmd"`           // 执行指令，可选值：transalte、chat、ping，默认为transalte
	SubCmd       string `json:"sub_cmd"`       // 子命令类型
	CustomFields string `json:"custom_fields"` // 自定义字段
	Data         []byte `json:"data"`          // 下级协议数据
}

type WebSocketResp struct {
	MsgId        string `json:"msg_id"`        // 请求消息ID
	Code         int64  `json:"code"`          // 返回码
	Msg          string `json:"msg"`           // 返回信息
	Cmd          string `json:"cmd"`           // 命令类型
	SubCmd       string `json:"sub_cmd"`       // 子命令类型
	Timestamp    int64  `json:"timestamp"`     // 时间戳（毫秒）
	CustomFields string `json:"custom_fields"` // 自定义字段
	Data         []byte `json:"data"`          // cmd对应的返回数据结构 (json字符串)
}
