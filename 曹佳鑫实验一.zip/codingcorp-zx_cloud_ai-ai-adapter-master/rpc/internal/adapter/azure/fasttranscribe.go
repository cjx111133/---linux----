package azure

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/zeromicro/go-zero/core/logx"

	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
)

type FastTranscribeClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	start   time.Time
	baseUrl string
	apiKey  string
	client  *resty.Client
	taskDir string
}

func NewFastTranscribeClient(ctx context.Context, svcCtx *svc.ServiceContext, url, apiKey string) *FastTranscribeClient {
	return &FastTranscribeClient{
		ctx:     ctx,
		svcCtx:  svcCtx,
		Logger:  logx.WithContext(ctx),
		start:   time.Now(),
		baseUrl: url,
		apiKey:  apiKey,
		client:  resty.New(),
	}
}

// FastAudioTranscribe handles the transcription request
func (f *FastTranscribeClient) FastAudioTranscribe(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	startTime := time.Now()

	// Validate input parameters
	if err := f.checkParam(req); err != nil {
		return nil, err
	}

	// Create task directory for storing files
	taskDir, err := f.createTaskDirectory(req.TaskId)
	if err != nil {
		return nil, fmt.Errorf("create task directory error: %v", err)
	}
	defer f.cleanupDirectory(taskDir) // Ensure cleanup after processing

	// Download audio files
	localFiles, err := f.downloadAudioFiles(req.AudioUrls, taskDir)
	if err != nil {
		return nil, fmt.Errorf("download audio files error: %v", err)
	}

	f.Info("Downloaded audio files:", localFiles)

	// Handle transcription for the first audio file (future optimization needed for multiple files)
	if err = f.transcribe(req.ResultUrl, localFiles[0], []string{req.Language}, req.MaxSpeakers, req.Diarization); err != nil {
		return nil, err
	}

	// Prepare and return the response
	return &adaptermodel.FastTranscribeResp{
		Code:        codes.CodeOk,
		Message:     "success",
		TimeTakenMs: int32(time.Since(startTime).Milliseconds()),
	}, nil
}

// Transcribe handles the actual transcription and result saving
func (f *FastTranscribeClient) transcribe(resultUrl, audioPath string, locales []string, maxSpeakers int64, enabled bool) error {
	definition, err := f.buildTranscriptionDefinition(locales, maxSpeakers, enabled)
	if err != nil {
		return fmt.Errorf("build transcription definition error: %v", err)
	}

	// Perform the transcription request
	resp, err := f.client.R().
		SetHeader("Ocp-Apim-Subscription-Key", f.apiKey).
		SetFile("audio", audioPath).
		SetFormData(map[string]string{"definition": definition}).
		Post(f.baseUrl)
	if err != nil {
		return fmt.Errorf("transcription request error: %v", err)
	}

	if resp.StatusCode() != 200 {
		return fmt.Errorf("bad response: %d, body: %s", resp.StatusCode(), resp.String())
	}

	// todo:处理返回数据，结构化写入文件
	// Save transcription result to local file
	jsonStr, err := ParseTranscribeResponseToTranscriptFile(resp.Body())
	if err != nil {
		return fmt.Errorf("ParseTranscribeResponse failed, err: %v", err)
	}

	filePath := filepath.Join(f.taskDir, common.GetFileNameFromUrl(resultUrl))
	if err := os.WriteFile(filePath, []byte(jsonStr), 0644); err != nil {
		return fmt.Errorf("save transcription result error: %v", err)
	}

	// Upload the result file to S3
	return common.UploadFileFromPath(f.ctx, resultUrl, filePath)
}

// Build the transcription definition JSON string
func (f *FastTranscribeClient) buildTranscriptionDefinition(locales []string, maxSpeakers int64, enabled bool) (string, error) {
	localesJSONBytes, err := json.Marshal(locales)
	if err != nil {
		return "", fmt.Errorf("marshal locales error: %v", err)
	}

	return fmt.Sprintf(`{
		"locales": %s,
		"diarization": {
			"maxSpeakers": %d,
			"enabled": %v
		}
	}`, string(localesJSONBytes), maxSpeakers, enabled), nil
}

// Check that the required parameters are provided in the request
func (f *FastTranscribeClient) checkParam(req *adaptermodel.FastTranscribeReq) error {
	if req == nil {
		return fmt.Errorf("request is nil")
	}
	if len(req.AudioUrls) == 0 {
		return fmt.Errorf("audio_url list is empty")
	}
	for i, url := range req.AudioUrls {
		if url == "" {
			return fmt.Errorf("audio_url[%d] is empty", i)
		}
	}
	return nil
}

// Create a directory for the task using task ID
func (f *FastTranscribeClient) createTaskDirectory(taskId string) (string, error) {
	f.taskDir = filepath.Join(os.TempDir(), taskId)
	if err := os.MkdirAll(f.taskDir, os.ModePerm); err != nil {
		return "", fmt.Errorf("create directory error: %v", err)
	}
	return f.taskDir, nil
}

// Download audio files from the provided URLs
func (f *FastTranscribeClient) downloadAudioFiles(urls []string, taskDir string) ([]string, error) {
	var localFiles []string

	// todo:后续改成并行下载（目前只有单文件场景）
	for _, u := range urls {
		fileName := common.GetFileNameFromUrl(u)
		if fileName == "" {
			return nil, fmt.Errorf("invalid URL: %s", u)
		}

		localPath := filepath.Join(taskDir, fileName)
		if err := common.DownloadSingleFile(f.ctx, u, localPath); err != nil {
			return nil, fmt.Errorf("download error: %v", err)
		}

		localFiles = append(localFiles, localPath)
		f.Infof("Downloaded %s -> %s", u, localPath)
	}

	return localFiles, nil
}

// Cleanup the task directory after processing
func (f *FastTranscribeClient) cleanupDirectory(dir string) {
	if err := os.RemoveAll(dir); err != nil {
		f.Errorf("failed to remove task directory %s: %v", dir, err)
	} else {
		f.Infof("task directory removed: %s", dir)
	}
}

type TranscribeResponse struct {
	DurationMilliseconds int              `json:"durationMilliseconds"`
	CombinedPhrases      []CombinedPhrase `json:"combinedPhrases"`
	Phrases              []Phrase         `json:"phrases"`
}

type CombinedPhrase struct {
	Text string `json:"text"`
}

type Phrase struct {
	Speaker              int     `json:"speaker"`
	OffsetMilliseconds   int     `json:"offsetMilliseconds"`
	DurationMilliseconds int     `json:"durationMilliseconds"`
	Text                 string  `json:"text"`
	Words                []Word  `json:"words"`
	Locale               string  `json:"locale"`
	Confidence           float64 `json:"confidence"`
}

type Word struct {
	Text                 string `json:"text"`
	OffsetMilliseconds   int    `json:"offsetMilliseconds"`
	DurationMilliseconds int    `json:"durationMilliseconds"`
}

type TranscriptSegment struct {
	Speaker   string `json:"speaker"`    // 说话人
	StartTime int    `json:"start_time"` // 毫秒
	EndTime   int    `json:"end_time"`   // 毫秒
	Content   string `json:"content"`    // 转写文本
}

type TranscriptFile struct {
	FullText string              `json:"full_text"` // 全文
	Segments []TranscriptSegment `json:"segments"`  // 分段
}

// ParseTranscribeResponseToTranscriptFile 解析 Azure 返回的转写数据并转为 TranscriptFile 的 JSON 字符串
func ParseTranscribeResponseToTranscriptFile(respData []byte) (string, error) {
	var transcribeResp TranscribeResponse
	if err := json.Unmarshal(respData, &transcribeResp); err != nil {
		return "", fmt.Errorf("解析 TranscribeResponse 失败: %v", err)
	}

	// 获取全文
	fullText := ""

	// 组装分段
	var segments []TranscriptSegment
	for i, phrase := range transcribeResp.Phrases {
		startTime := formatTime(phrase.OffsetMilliseconds)
		endTime := formatTime(phrase.OffsetMilliseconds + phrase.DurationMilliseconds)

		segment := TranscriptSegment{
			Speaker:   strconv.Itoa(phrase.Speaker),
			StartTime: phrase.OffsetMilliseconds,
			EndTime:   phrase.OffsetMilliseconds + phrase.DurationMilliseconds,
			Content:   phrase.Text,
		}
		segments = append(segments, segment)

		line := fmt.Sprintf("%d\n%s --> %s\nSpeaker %d: %s\n\n",
			i+1,
			startTime,
			endTime,
			phrase.Speaker,
			phrase.Text)
		fullText += line
	}

	transcriptFile := TranscriptFile{
		FullText: fullText,
		Segments: segments,
	}

	result, err := json.MarshalIndent(transcriptFile, "", "  ")
	if err != nil {
		return "", fmt.Errorf("序列化 TranscriptFile 失败: %v", err)
	}
	return string(result), nil
}

func formatTime(milliseconds int) string {
	hours := milliseconds / 3600000
	minutes := (milliseconds % 3600000) / 60000
	seconds := (milliseconds % 60000) / 1000
	millis := milliseconds % 1000

	return fmt.Sprintf("%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
}
