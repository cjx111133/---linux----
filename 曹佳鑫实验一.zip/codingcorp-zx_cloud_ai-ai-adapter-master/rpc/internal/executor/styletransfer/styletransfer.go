package styletransfer

import (
	"context"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/zeromicro/go-zero/core/logx"
)

type StyleTransferExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	maxPixel   int
	maxImgSize int
}

func NewStyleTransferExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *StyleTransferExecutor {
	return &StyleTransferExecutor{
		ctx:        ctx,
		svcCtx:     svcCtx,
		Logger:     logx.WithContext(ctx),
		maxPixel:   2000,
		maxImgSize: 5, // MB
	}
}

func (e *StyleTransferExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *StyleTransferExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *StyleTransferExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.AiGenerateImageReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	if len(in.ResultUpTokens) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}
	var iPara aiparameter.StyleTransferInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}

	// 此处增加depth_to_detail参数
	eParaDepthDetail := adaptermodel.DepthToDetailParams{}
	if err := common.JsonToAny([]byte(in.ExtendedParameter), &eParaDepthDetail); err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	images := make([][]byte, 0, len(iPara.Images))
	for i, image := range iPara.Images {
		if image == nil {
			return nil, fmt.Errorf("InferenceParameter Images[%d] is nil", i)
		}
		if image.FileData == "" {
			return nil, fmt.Errorf("InferenceParameter Image FileData is empty, index: %d", i)
		}
		var imageData []byte
		if common.IsUrl(image.FileData) {
			imageData, err = common.DownloadFile(e.ctx, image.FileData)
			if err != nil {
				return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", image.FileData, err)
			}
		} else if data, err := common.Base64ToBytes(image.FileData); err == nil {
			imageData = data
		} else {
			return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", image.FileData[1000])
		}

		if common.CalcuImageSize(imageData) >= e.maxImgSize {
			// 获取图片高度宽度的最大值，若超过2000像素，则缩小
			imageData, err = common.ResizeImageToMaxPix(imageData, e.maxPixel, config.GetSrvConfig().ImageMaxSize)
			if err != nil {
				return nil, fmt.Errorf("ResizeImageToMaxPix failed, url: %s, error: %v", image.FileData, err)
			}
		}
		images = append(images, imageData)
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	var ePara aiparameter.StyleTransferExtendedParameter
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}
	if ePara.AiGenerateParameter == nil {
		return nil, fmt.Errorf("ExtendedParameter AiGenerateParameter is nil")
	}
	ePara2 := struct {
		ImageToPrompt struct {
			Model string `json:"model"`
		} `json:"image_to_prompt"`
	}{}
	common.JsonToAny([]byte(in.ExtendedParameter), &ePara2)

	var controlnets []adaptermodel.Controlnet
	for i, controlnet := range ePara.AiGenerateParameter.Controlnets {
		ctr := adaptermodel.Controlnet{
			Module:        controlnet.Module,
			Model:         controlnet.Model,
			Weight:        controlnet.Weight,
			ThresholdA:    controlnet.ThresholdA,
			ThresholdB:    controlnet.ThresholdB,
			GuidanceStart: controlnet.GuidanceStart,
			GuidanceEnd:   controlnet.GuidanceEnd,
			PixelPerfect:  controlnet.PixelPerfect,
			ResizeMode:    controlnet.ResizeMode,
			Enabled:       controlnet.Enabled,
		}
		if len(images) > i+1 {
			ctr.Image = images[i+1] //原图
		}
		controlnets = append(controlnets, ctr)
	}

	req := &adaptermodel.AiGenerateImageReq{
		TaskId:              in.Header.TaskId,
		TaskType:            in.TaskType,
		ResultImageUpTokens: in.ResultUpTokens,
		ThumbImageUpTokens:  in.ThumbUpTokens,
		ImageToPromptModel:  ePara2.ImageToPrompt.Model,
		DepthDetail:         eParaDepthDetail,
		ApplyInputMask:      iPara.ApplyInputMask,
		GenerateImageParameter: adaptermodel.GenerateImageParameter{
			Prompt:            ePara.AiGenerateParameter.Prompt,
			NegativePrompt:    ePara.AiGenerateParameter.NegativePrompt,
			InitImage:         images[0], //深度图
			SamplerName:       ePara.AiGenerateParameter.SamplerName,
			BatchSize:         ePara.AiGenerateParameter.BatchSize,
			BatchCount:        ePara.AiGenerateParameter.BatchCount,
			Steps:             ePara.AiGenerateParameter.Steps,
			CfgScale:          ePara.AiGenerateParameter.CfgScale,
			Width:             ePara.AiGenerateParameter.Width,
			Height:            ePara.AiGenerateParameter.Height,
			DenoisingStrength: ePara.AiGenerateParameter.DenoisingStrength,
			Controlnet:        controlnets,
			SdModel:           ePara.AiGenerateParameter.SdModel,
			LoraModels:        ePara.AiGenerateParameter.LoraModels,
			VaeModel:          ePara.AiGenerateParameter.VaeModel,
			ControlnetModels:  ePara.AiGenerateParameter.ControlnetModels,
		},
	}
	return req, nil
}

func (e *StyleTransferExecutor) doInference(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.AiGenerateImageHandler(req)
	if err != nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("AiGenerateImageHandler failed, code: %d, message: %s", result.Code, result.Message)
	}

	return result, nil
}

func (e *StyleTransferExecutor) buildResponse(resp *adaptermodel.AiGenerateImageResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Style_Transfer,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_StyleTransfer{
			StyleTransfer: &aiparameter.StyleTransferInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}
	for _, imageInfo := range resp.ImageInfos {
		out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
			FileData: string(imageInfo.Data),
			FileMd5:  imageInfo.Md5,
			FileSize: imageInfo.Size,
		})
	}
	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)
	return &out, nil
}
