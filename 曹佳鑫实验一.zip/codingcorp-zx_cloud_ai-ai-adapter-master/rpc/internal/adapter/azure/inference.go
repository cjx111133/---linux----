package azure

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/transcriberpc"
	"fmt"
	"google.golang.org/grpc/codes"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type AzureAdapter struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewAzureAdapter(ctx context.Context, svcCtx *svc.ServiceContext) *AzureAdapter {
	return &AzureAdapter{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (s *AzureAdapter) TrainHandler(req *adaptermodel.CreateTrainReq) error {
	return fmt.Errorf("TrainHandler not implemented")
}

func (s *AzureAdapter) GetTrainHandler(req *adaptermodel.GetTrainReq) (*adaptermodel.GetTrainResp, error) {
	return nil, fmt.Errorf("GetTrainHandler not implemented")
}

func (s *AzureAdapter) StopTrainHandler(req *adaptermodel.StopTrainReq) error {
	return fmt.Errorf("StopTrainHandler not implemented")
}

func (s *AzureAdapter) FaceSwapHandler(req *adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error) {
	return nil, fmt.Errorf("FaceSwapHandler not implemented")
}

func (s *AzureAdapter) AiGenerateImageHandler(req *adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error) {
	return nil, fmt.Errorf("AiGenerateImageHandler not implemented")
}

func (s *AzureAdapter) ImageUpscaleHandler(req *adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error) {
	return nil, fmt.Errorf("ImageUpscaleHandler not implemented")
}

func (s *AzureAdapter) ImageToPromptInferences(endpointName, imageToPromptModel string, initImage []byte) (*adaptermodel.ImageToPromptResponse, error) {
	return nil, fmt.Errorf("ImageToPromptInferences not implemented")
}

func (s *AzureAdapter) InstantStyleHandler(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error) {
	return nil, fmt.Errorf("InstantStyleHandler not implemented")
}

func (s *AzureAdapter) InstantStylePlusHandler(req *adaptermodel.InstantStylePlusReq) (*adaptermodel.InstantStylePlusResp, error) {
	return nil, fmt.Errorf("InstantStylePlusHandler not implemented")
}

func (s *AzureAdapter) DepthMapGenerationHandler(req *adaptermodel.DepthMapGenerationReq) (*adaptermodel.DepthMapGenerationResp, error) {
	return nil, fmt.Errorf("DepthMapGenerationHandler not implemented")
}

func (s *AzureAdapter) RemoveBackgroundHandler(req *adaptermodel.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error) {
	return nil, fmt.Errorf("RemoveBackgroundHandler not implemented")
}

func (s *AzureAdapter) TranslateHandler(*adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	return nil, fmt.Errorf("TranslateHandler not implemented")
}

func (s *AzureAdapter) SpeechToTextStreamHandler(request <-chan *adaptermodel.SpeechToTextReq, response chan<- *adaptermodel.SpeechToTextResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.Audio == nil {
		return fmt.Errorf("audio is nil")
	}

	if _, ok := config.GetSrvConfig().Azure[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in azure asr config", req.AppId)
	}

	client := NewAsrClient(s.ctx, s.svcCtx, request, response, req)
	defer client.Close()

	err := client.SpeechTranscription()
	if err != nil {
		return fmt.Errorf("SpeechTranscription failed, err: %v", err)
	}
	s.Infof("SpeechToTextStreamHandler done")
	return nil
}

func (s *AzureAdapter) TextToSpeechStreamHandler(request <-chan *adaptermodel.TextToSpeechReq, response chan<- *adaptermodel.TextToSpeechResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	req, ok := <-request
	if !ok {
		return fmt.Errorf("request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}

	if _, ok := config.GetSrvConfig().Azure[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in azure tts config", req.AppId)
	}

	client := NewTtsClient(s.ctx, s.svcCtx, request, response, req)
	defer client.Close()

	err := client.SpeechSynthesis()
	if err != nil {
		return fmt.Errorf("SpeechSynthesis failed, err: %v", err)
	}
	s.Infof("TextToSpeechStreamHandler done")
	return nil
}

func (s *AzureAdapter) TranslateStreamHandler(request <-chan *adaptermodel.TranslateReq, response chan<- *adaptermodel.TranslateResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}
	req, ok := <-request
	if !ok {
		return fmt.Errorf("recv first request failed, request channel closed")
	}
	if req == nil {
		return fmt.Errorf("the first request is nil")
	}
	if req.LlmType == "" {
		return fmt.Errorf("llm type is empty")
	}
	if req.Role == "" {
		return fmt.Errorf("role is empty")
	}

	if _, ok := config.GetSrvConfig().Azure[config.AppId(req.AppId)]; !ok {
		return fmt.Errorf("appId %s not found in azure llm config", req.AppId)
	}

	url := config.GetSrvConfig().Azure[config.AppId(req.AppId)].LLMUrl
	region := config.GetSrvConfig().Azure[config.AppId(req.AppId)].Region
	client := NewTranslateClient(s.ctx, s.svcCtx, url, region, request, response, req)
	err := client.TranslateStream()
	if err != nil {
		return fmt.Errorf("TranslateStreamHandler failed, err: %v", err)
	}
	s.Infof("TranslateStreamHandler done")
	return nil

}

func (s *AzureAdapter) TranslateQuestionRecommendHandler(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error) {
	return nil, fmt.Errorf("TranslateQuestionRecommendHandler not implemented")
}

func (s *AzureAdapter) FastTranscribeHandler(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	startTime := time.Now()
	if req == nil {
		return nil, fmt.Errorf("request is nil")
	}

	rpcReq := &transcriberpc.FastTransReq{
		TaskId:      req.TaskId,
		Diarization: req.Diarization,
		Locales:     req.Locales,
		AudioUrls:   req.AudioUrls,
		ResultUrl:   req.ResultUrl,
	}

	_, err := s.svcCtx.TranscribeRpc.AudioFastTranscribe(s.ctx, rpcReq)
	if err != nil {
		s.Errorf("TranscribeRpc AudioFastTranscribe failed: %v", err)
		return nil, fmt.Errorf("TranscribeRpc AudioFastTranscribe failed: %v", err)
	}

	rpcResp := &adaptermodel.FastTranscribeResp{
		Code:        int32(codes.OK),
		Message:     "success",
		TimeTakenMs: int32(time.Since(startTime).Milliseconds()),
	}

	s.Infof("FastTranscribeHandler done, taskId: %s, time taken: %d ms", req.TaskId, rpcResp.TimeTakenMs)

	return rpcResp, nil
}

func (s *AzureAdapter) TextSummaryHandler(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error) {
	return nil, fmt.Errorf("TextSummaryHandler not implemented")
}

func (s *AzureAdapter) DifyWorkflowHandler(*adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error) {
	return nil, fmt.Errorf("DifyWorkflowHandler not implemented")
}

func (s *AzureAdapter) DifyWorkflowStreamHandler(request <-chan *adaptermodel.DifyWorkflowReq, response chan<- *adaptermodel.DifyWorkflowResp) error {
	return fmt.Errorf("DifyWorkflowStreamHandler not implemented")
}

func (s *AzureAdapter) DifyChatflowHandler(*adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error) {
	return nil, fmt.Errorf("DifyChatflowHandler not implemented")
}

func (s *AzureAdapter) DifyChatflowStreamHandler(request <-chan *adaptermodel.DifyChatflowReq, response chan<- *adaptermodel.DifyChatflowResp) error {
	return fmt.Errorf("DifyChatflowStreamHandler not implemented")
}

func (s *AzureAdapter) LanguageDetectStreamHandler(<-chan *adaptermodel.LanguageDetectReq, chan<- *adaptermodel.LanguageDetectResp) error {
	return fmt.Errorf("LanguageDetectStreamHandler not implemented")
}

func (s *AzureAdapter) ComfyUiStyleTransferHandler(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error) {
	//TODO implement me
	return nil, fmt.Errorf("PetPortraitComfyHandler not implemented")
}

func (s *AzureAdapter) OpusWrapperStreamHandler(<-chan *adaptermodel.OpusWrapperReq, chan<- *adaptermodel.OpusWrapperResp) error {
	return fmt.Errorf("OpusWrapperStreamHandler not implemented")
}

func (s *AzureAdapter) TranslateQuestionRecommendStreamHandler(<-chan *adaptermodel.TranslateQuestionRecommendReq, chan<- *adaptermodel.TranslateQuestionRecommendResp) error {
	return fmt.Errorf("TranslateQuestionRecommendStreamHandler not implemented")
}
