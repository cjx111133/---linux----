package chat

import (
	"io"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"

	"github.com/zeromicro/go-zero/core/threading"
	"go.uber.org/zap"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

// ChatAnswer implements ChatTaskInterface
type ChatAnswer struct {
	*BaseChatTask
	packetLogic *AnswerPacket
}

func NewChatAnswer(message *ChatMessage) *ChatAnswer {
	answer := &ChatAnswer{
		BaseChatTask: NewBaseChatTask(message),
	}
	answer.packetLogic = NewAnswerPacket(answer.BaseChatTask)
	return answer
}

func (l *ChatAnswer) Process(req *types.ChatReq) error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		l.Logger.Error("Failed to create stream RPC connection", zap.Error(err), zap.String("messageId", req.MessageId))
		return err
	}
	l.stream = stream
	l.isCloseSend.Store(false)
	l.messageId = req.MessageId

	if l.isCreateGrpcConn(req) { // 是否需要创建grpc连接 处理单包无需grpc连接的问题
		threading.GoSafe(func() { l.ProcessReceive(req) })
	}
	return l.ProcessTimer(req)
}

func (l *ChatAnswer) ProcessTimer(req *types.ChatReq) error {
	for {
		select {
		case data, ok := <-l.reqs:
			if !ok {
				return nil
			}
			l.packetLogic.Send(data)
		case <-l.wsData.StopWsChan:
			return nil
		}
	}
}

// Receiving handles receiving messages
func (l *ChatAnswer) ProcessReceive(req *types.ChatReq) {
	defer func() {
		l.Close()
	}()
	if l.stream == nil {
		return
	}

	var index int32
	recvChan := make(chan *aimanagerrpc.StreamTaskResp, 1)
	errChan := make(chan error, 1)
	for {
		// 在单独的goroutine中执行Recv
		go func() {
			resp, err := l.stream.Recv()
			if err != nil {
				errChan <- err
				return
			}
			recvChan <- resp
		}()

		// 现在可以同时等待多个事件
		select {
		case <-l.wsData.StopWsChan:
			return
		case <-l.stopChan:
			l.utilLogic.SendStopDataToRecv(req.CommonReq, index)
			return
		case err := <-errChan:
			index++
			if err == io.EOF {
				l.Infof("Chat Recv EOF")
				l.utilLogic.SendEndDataToRecv(req.CommonReq, index)
				return
			}
			l.Errorf("Chat Recv failed, err: %v", err)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to receive data")
			return
		case streamRecv := <-recvChan:
			index++
			// 处理接收到的数据...
			resp, _, _ := l.convert.ProcessStreamTaskRespData(streamRecv, req, index)
			l.utilLogic.SendSuccessDataToRecv(*resp)
		}
	}
}

func (l *ChatAnswer) Close() {
	// Avoid duplicate cleanup

	l.Logger.Info("Closing ChatAnswer", zap.String("message_id", l.messageId))

	// Close the stream
	l.StreamClose()
	close(l.reqs)
	l.reqs = nil
}
