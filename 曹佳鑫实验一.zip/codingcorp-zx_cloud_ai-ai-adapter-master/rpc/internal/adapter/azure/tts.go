package azure

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	"github.com/Microsoft/cognitive-services-speech-sdk-go/common"
	"github.com/Microsoft/cognitive-services-speech-sdk-go/speech"
	"github.com/zeromicro/go-zero/core/logx"
)

type TtsClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	startTime    time.Time
	complete     chan bool
	speechConfig *speech.SpeechConfig
	ss           *speech.SpeechSynthesizer
	buf          *bytes.Buffer
	voice        string
	ssml         string
	sentenceId   int32

	request  <-chan *adaptermodel.TextToSpeechReq
	response chan<- *adaptermodel.TextToSpeechResp
	first    *adaptermodel.TextToSpeechReq

	sentenceStart bool
}

func NewTtsClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.TextToSpeechReq,
	response chan<- *adaptermodel.TextToSpeechResp,
	first *adaptermodel.TextToSpeechReq) *TtsClient {
	return &TtsClient{
		ctx:           ctx,
		svcCtx:        svcCtx,
		Logger:        logx.WithContext(ctx),
		startTime:     time.Now(),
		complete:      make(chan bool, 10),
		buf:           new(bytes.Buffer),
		request:       request,
		response:      response,
		first:         first,
		sentenceStart: true,
	}
}

func (c *TtsClient) SpeechSynthesis() error {
	err := c.initClient()
	if err != nil {
		return fmt.Errorf("init tts client failed, err: %v", err)
	}
	defer c.speechConfig.Close()

	// send first package to azure
	c.Infof("send first text to azure, text: %v", c.first.Text)
	err = c.sendTextToTts(c.first)
	if err != nil {
		return fmt.Errorf("send first text to azure failed, text: %v, err: %v", c.first.Text, err)
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop speech synthesis failed, err: %v", err)
	}

	c.Infof("speech synthesis end")
	return nil
}

func (c *TtsClient) loop() error {
	for {
		select {
		case <-c.ctx.Done():
			c.Infof("send text to azure tts end, ctx done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send text to azure tts end, request channel closed")
				return nil
			}
			if req == nil {
				continue
			}

			err := c.sendTextToTts(req)
			if err != nil {
				return fmt.Errorf("send text to azure tts failed, err: %v", err)
			}
		}
	}
}

func (c *TtsClient) sendTextToTts(req *adaptermodel.TextToSpeechReq) error {
	// 清空complete
	for len(c.complete) > 0 {
		<-c.complete
	}

	if req.Text == "" {
		c.Errorf("send text to azure tts warning, text is empty")
		return nil
	}
	if req.SentenceId <= 0 {
		return fmt.Errorf("send text to azure tts failed, SentenceId is invalid: %d", req.SentenceId)
	}

	c.sentenceId = req.SentenceId
	// 使用ssml标签设置语音合成的语言和语音
	ssmlTemplate := `
		<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xmlns:mstts='https://www.w3.org/2001/mstts' xml:lang='%s'>
			<voice name='%s'>
				<prosody rate='1.2'>
					<lang xml:lang='%s'>
						%s
					</lang>
				</prosody>
			</voice>
		</speak>`
	ssml := fmt.Sprintf(ssmlTemplate, c.first.Language, c.voice, c.first.Language, req.Text)

	c.Infof("send text to azure tts, SentenceId: %v, text: %v, ssml: %v", req.SentenceId, req.Text, ssml)

	// 发送tts请求, 超时时间60s
	timer := time.NewTimer(60 * time.Second)
	defer timer.Stop()

	// outcome := c.ss.SpeakTextAsync(req.Text)
	outcome := c.ss.SpeakSsmlAsync(ssml)
	select {
	case <-c.ctx.Done():
		c.Infof("send text to azure tts end, ctx done")
		return nil
	case <-timer.C:
		c.Errorf("send text to azure tts timeout")
		return fmt.Errorf("send text to azure tts timeout")
	case task := <-outcome:
		defer task.Close()
		if task.Error != nil {
			c.Errorf("send text to azure tts failed, Reason: %v, err: %v", task.Result.Reason.String(), task.Error)
			return fmt.Errorf("send text to azure tts failed, Reason: %v, err: %v", task.Result.Reason.String(), task.Error)
		} else {
			c.Debugf("send text to azure tts success, Reason: %v", task.Result.Reason.String())
		}
	}

	// 等待tts完成
	err := c.Wait(c.complete)
	if err != nil {
		return fmt.Errorf("Wait failed, err: %v", err)
	}
	return nil
}

func (c *TtsClient) initClient() error {
	var err error
	c.speechConfig, err = speech.NewSpeechConfigFromSubscription(
		config.GetSrvConfig().Azure[config.AppId(c.first.AppId)].VoiceServerKey,
		config.GetSrvConfig().Azure[config.AppId(c.first.AppId)].Region)
	if err != nil {
		return fmt.Errorf(" NewSpeechConfigFromSubscription failed, err: %v", err)
	}

	switch c.first.Format {
	case config.AUDIO_FORMAT_PCM:
		err = c.speechConfig.SetSpeechSynthesisOutputFormat(common.Raw16Khz16BitMonoPcm)
	case config.AUDIO_FORMAT_MP3:
		switch c.first.Bitrate {
		case 32000:
			err = c.speechConfig.SetSpeechSynthesisOutputFormat(common.Audio16Khz32KBitRateMonoMp3)
		case 64000:
			err = c.speechConfig.SetSpeechSynthesisOutputFormat(common.Audio16Khz64KBitRateMonoMp3)
		case 128000:
			err = c.speechConfig.SetSpeechSynthesisOutputFormat(common.Audio16Khz128KBitRateMonoMp3)
		default:
			err = c.speechConfig.SetSpeechSynthesisOutputFormat(common.Audio16Khz32KBitRateMonoMp3)
		}
	default:
		return fmt.Errorf("unsupported format: %s", c.first.Format)
	}
	if err != nil {
		return fmt.Errorf("SetSpeechSynthesisOutputFormat failed, Format: %s, err: %v", c.first.Format, err)
	}

	c.voice, err = c.getVoice()
	if err != nil {
		return fmt.Errorf("get voice failed, err: %v", err)
	}
	err = c.speechConfig.SetSpeechSynthesisVoiceName(c.voice)
	if err != nil {
		return fmt.Errorf("SetSpeechSynthesisVoiceName failed, err: %v", err)
	}

	c.ss, err = speech.NewSpeechSynthesizerFromConfig(c.speechConfig, nil)
	if err != nil {
		c.Errorf("NewSpeechSynthesizerFromConfig failed, err: %v", err)
		return fmt.Errorf("NewSpeechSynthesizerFromConfig failed, err: %v", err)
	}

	c.ss.SynthesisStarted(c.synthesizeStartedHandler)
	c.ss.Synthesizing(c.synthesizingHandler)
	c.ss.SynthesisCompleted(c.synthesizedHandler)
	c.ss.SynthesisCanceled(c.cancelledHandler)
	return nil
}

// 等待start或stop完成
func (c *TtsClient) Wait(ch chan bool) error {
	select {
	case message, done := <-ch:
		if !done {
			return errors.New("wait failed")
		}
		c.Infof("Wait done: %v", message)
	case <-time.After(10 * time.Second):
		return errors.New("Wait timeout")
	}
	return nil
}

func (c *TtsClient) Close() {
	if c.complete != nil {
		for len(c.complete) > 0 {
			<-c.complete
		}
	}
	if c.response != nil {
		close(c.response)
	}

	if c.speechConfig != nil {
		c.speechConfig.Close()
	}

	if c.ss != nil {
		c.ss.Close()
	}
}

func (c *TtsClient) getVoice() (string, error) {
	// 如果用户指定了语音，则直接使用
	if c.first.Voice != "" {
		return c.first.Voice, nil
	}

	var voice string
	switch strings.ToLower(c.first.Language) {
	case "de", "de-de", "de-DE":
		voice = "de-DE-FlorianMultilingualNeural"
	case "en", "en-us", "en-US":
		voice = "en-US-AvaMultilingualNeural"
	case "es", "es-es", "es-ES":
		voice = "es-ES-ArabellaMultilingualNeural"
	case "fr", "fr-fr", "fr-FR":
		voice = "fr-FR-DeniseNeural"
	case "it", "it-it", "it-IT":
		voice = "it-IT-IsabellaMultilingualNeural"
	case "ja", "ja-jp", "ja-JP":
		voice = "ja-JP-NanamiNeural"
	case "ko", "ko-kr", "ko-KR":
		voice = "ko-KR-SunHiNeural"
	case "zh", "zh-cn", "zh-CN":
		voice = "zh-CN-XiaoxiaoNeural"
	case "id", "id-id", "id-ID":
		voice = "id-ID-GadisNeural"
	case "af", "af-za", "af-ZA":
		voice = "af-ZA-AdriNeural"
	case "am", "am-et", "am-ET":
		voice = "am-ET-MekdesNeural"
	case "az", "az-az", "az-AZ":
		voice = "az-AZ-BanuNeural"
	case "bg", "bg-bg", "bg-BG":
		voice = "bg-BG-BorislavNeural"
	case "bn", "bn-in", "bn-IN":
		voice = "bn-IN-TanishaaNeural"
	case "bs", "bs-ba", "bs-BA":
		voice = "bs-BA-VesnaNeural"
	case "ca", "ca-es", "ca-ES":
		voice = "ca-ES-AlbaNeural"
	case "ga", "ga-ie", "ga-IE":
		voice = "ga-IE-OrlaNeural"
	case "ru", "ru-ru", "ru-RU":
		voice = "ru-RU-DariyaNeural"
	case "sv", "sv-se", "sv-SE":
		voice = "sv-SE-HilleviNeural"
	case "cs", "cs-cz", "cs-CZ":
		voice = "cs-CZ-VlastaNeural"
	case "cy", "cy-gb", "cy-GB":
		voice = "cy-GB-NiaNeural"
	case "da", "da-dk", "da-DK":
		voice = "da-DK-ChristelNeural"
	case "el", "el-gr", "el-GR":
		voice = "el-GR-AthinaNeural"
	case "et", "et-ee", "et-EE":
		voice = "et-EE-AnuNeural"
	case "eu", "eu-es", "eu-ES":
		voice = "eu-ES-AinhoaNeural"
	case "fa", "fa-ir", "fa-IR":
		voice = "fa-IR-DilaraNeural"
	case "fi", "fi-fi", "fi-FI":
		voice = "fi-FI-NooraNeural"
	case "fil", "fil-ph", "fil-PH":
		voice = "fil-PH-BlessicaNeural"
	case "gl", "gl-es", "gl-ES":
		voice = "gl-ES-SabelaNeural"
	case "gu", "gu-in", "gu-IN":
		voice = "gu-IN-DhwaniNeural"
	case "he", "he-il", "he-IL":
		voice = "he-IL-HilaNeural"
	case "hi", "hi-in", "hi-IN":
		voice = "hi-IN-AartiNeural"
	case "hr", "hr-hr", "hr-HR":
		voice = "hr-HR-SreckoNeural"
	case "hu", "hu-hu", "hu-HU":
		voice = "hu-HU-TamasNeural"
	case "hy", "hy-am", "hy-AM":
		voice = "hy-AM-AnahitNeural"
	case "is", "is-is", "is-IS":
		voice = "is-IS-GudrunNeural"
	case "jv", "jv-id", "jv-ID":
		voice = "jv-ID-SitiNeural"
	case "ka", "ka-ge", "ka-GE":
		voice = "ka-GE-EkaNeural"
	case "kk", "kk-kz", "kk-KZ":
		voice = "kk-KZ-AigulNeural"
	case "km", "km-kh", "km-KH":
		voice = "km-KH-SreymomNeural"
	case "kn", "kn-in", "kn-IN":
		voice = "kn-IN-SapnaNeural"
	case "lo", "lo-la", "lo-LA":
		voice = "lo-LA-KeomanyNeural"
	case "lt", "lt-lt", "lt-LT":
		voice = "lt-LT-OnaNeural"
	case "lv", "lv-lv", "lv-LV":
		voice = "lv-LV-EveritaNeural"
	case "mk", "mk-mk", "mk-MK":
		voice = "mk-MK-MarijaNeural"
	case "ml", "ml-in", "ml-IN":
		voice = "ml-IN-SobhanaNeural"
	case "mn", "mn-mn", "mn-MN":
		voice = "mn-MN-YesuiNeural"
	case "mr", "mr-in", "mr-IN":
		voice = "mr-IN-AarohiNeural"
	case "ms", "ms-my", "ms-MY":
		voice = "ms-MY-OsmanNeural"
	case "mt", "mt-mt", "mt-MT":
		voice = "mt-MT-GraceNeural"
	case "my", "my-mm", "my-MM":
		voice = "my-MM-NilarNeural"
	case "nb", "nb-no", "nb-NO":
		voice = "nb-NO-IselinNeural"
	case "ne", "ne-np", "ne-NP":
		voice = "ne-NP-HemkalaNeural"
	case "nl-be", "nl-BE":
		voice = "nl-BE-DenaNeural"
	case "nl", "nl-nl", "nl-NL":
		voice = "nl-NL-FennaNeural"
	case "pa", "pa-in", "pa-IN":
		voice = "pa-IN-OjasNeural"
	case "pl", "pl-pl", "pl-PL":
		voice = "pl-PL-ZofiaNeural"
	case "ps", "ps-af", "ps-AF":
		voice = "ps-AF-LatifaNeural"
	case "ro", "ro-ro", "ro-RO":
		voice = "ro-RO-AlinaNeural"
	case "si", "si-lk", "si-LK":
		voice = "si-LK-ThiliniNeural"
	case "sk", "sk-sk", "sk-SK":
		voice = "sk-SK-ViktoriaNeural"
	case "sl", "sl-si", "sl-SI":
		voice = "sl-SI-PetraNeural"
	case "so", "so-so", "so-SO":
		voice = "so-SO-UbaxNeural"
	case "sq", "sq-al", "sq-AL":
		voice = "sq-AL-AnilaNeural"
	case "sr", "sr-rs", "sr-RS":
		voice = "sr-RS-SophieNeural"
	case "sw", "sw-ke", "sw-KE":
		voice = "sw-KE-ZuriNeural"
	case "sw-tz", "sw-TZ":
		voice = "sw-TZ-RehemaNeural"
	case "ta", "ta-in", "ta-IN":
		voice = "ta-IN-PallaviNeural"
	case "te", "te-in", "te-IN":
		voice = "te-IN-ShrutiNeural"
	case "th", "th-th", "th-TH":
		voice = "th-TH-AcharaNeural"
	case "tr", "tr-tr", "tr-TR":
		voice = "tr-TR-EmelNeural"
	case "uk", "uk-ua", "uk-UA":
		voice = "uk-UA-PolinaNeural"
	case "ur", "ur-in", "ur-IN":
		voice = "ur-IN-GulNeural"
	case "uz", "uz-uz", "uz-UZ":
		voice = "uz-UZ-MadinaNeural"
	case "vi", "vi-vn", "vi-VN":
		voice = "vi-VN-HoaiMyNeural"
	case "wuu", "wuu-cn", "wuu-CN":
		voice = "wuu-CN-XiaotongNeural"
	case "yue", "yue-cn", "yue-CN":
		voice = "yue-CN-XiaoMinNeural"
	case "zh-cn-shandong", "zh-CN-shandong":
		voice = "zh-cn-shandong-YunxiangNeural"
	case "zh-cn-sichuan", "zh-CN-sichuan":
		voice = "zh-cn-sichuan-YunxiNeural"
	case "zh-hk", "zh-HK":
		voice = "zh-HK-WanLungNeural"
	case "zh-tw", "zh-TW":
		voice = "zh-TW-HsiaoChenNeural"
	case "zu", "zu-za", "zu-ZA":
		voice = "zu-ZA-ThandoNeural"
	case "ar", "ar-ae", "ar-AE":
		voice = "ar-AE-FatimaNeural"
	case "ar-bh", "ar-BH":
		voice = "ar-BH-LailaNeural"
	case "ar-dz", "ar-DZ":
		voice = "ar-DZ-AminaNeural"
	case "ar-eg", "ar-EG":
		voice = "ar-EG-SalmaNeural"
		// 	不支持
	// case "ar-il", "ar-IL":
	case "ar-iq", "ar-IQ":
		voice = "ar-IQ-RanaNeural"
	case "ar-jo", "ar-JO":
		voice = "ar-JO-SanaNeural"
	case "ar-kw", "ar-KW":
		voice = "ar-KW-NouraNeural"
	case "ar-lb", "ar-LB":
		voice = "ar-LB-LaylaNeural"
	case "ar-ly", "ar-LY":
		voice = "ar-LY-ImanNeural"
	case "ar-ma", "ar-MA":
		voice = "ar-MA-MounaNeural"
	case "ar-om", "ar-OM":
		voice = "ar-OM-AyshaNeural"
		// 	不支持
	// case "ar-ps", "ar-PS":
	case "ar-qa", "ar-QA":
		voice = "ar-QA-AmalNeural"
	case "ar-sa", "ar-SA":
		voice = "ar-SA-ZariyahNeural"
	case "ar-sy", "ar-SY":
		voice = "ar-SY-AmanyNeural"
	case "ar-tn", "ar-TN":
		voice = "ar-TN-ReemNeural"
	case "ar-ye", "ar-YE":
		voice = "ar-YE-MaryamNeural"
	case "pt", "pt-br", "pt-BR":
		voice = "pt-BR-ThalitaNeural"
	case "pt-pt", "pt-PT":
		voice = "pt-PT-RaquelNeural"
	default:
		return "", fmt.Errorf("unsupported language: %s", c.first.Language)
	}
	return voice, nil
}

func (c *TtsClient) synthesizeStartedHandler(event speech.SpeechSynthesisEventArgs) {
	defer event.Close()
	c.Infof("recv Session Started from azure tts, Task id: %s, ResultID: %s, audio length %d", c.first.TaskId, event.Result.ResultID, len(event.Result.AudioData))
}

func (c *TtsClient) synthesizingHandler(event speech.SpeechSynthesisEventArgs) {
	defer event.Close()
	c.Debugf("recv Synthesizing from azure tts, SentenceId: %d, audio chunk size %d", c.sentenceId, len(event.Result.AudioData))

	if len(event.Result.AudioData) == 0 && !c.sentenceStart {
		return
	}

	// 将音频数据拆分为小包发送给客户端
	var buf = bytes.NewBuffer(event.Result.AudioData)
	for buf.Len() > 0 {
		resp := &adaptermodel.TextToSpeechResp{
			Header: &aicommon.RspHeader{
				Code:    0,
				Message: "success",
			},
			SentenceId: c.sentenceId,
			Audio: &aicommon.AudioInfo{
				Data:       buf.Next(6400),
				SampleRate: c.first.SampleRate,
				BitRate:    c.first.Bitrate,
				Channels:   c.first.Channels,
				Format:     c.first.Format,
				Language:   c.first.Language,
			},
			SentenceStart: c.sentenceStart,
			TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
		}
		c.response <- resp
	}

	// 如果是句子的开始，需要重置标志
	if c.sentenceStart {
		c.Infof("sentence start, reset sentenceStart")
		c.sentenceStart = false
	}
}

func (c *TtsClient) synthesizedHandler(event speech.SpeechSynthesisEventArgs) {
	defer event.Close()

	c.Infof("recv Synthesized from azure tts, Task id: %s, ResultID: %s, SentenceId: %d, sentenceStart: %v, AudioDuration: %v, Reason: %v, audio length %d",
		c.first.TaskId,
		event.Result.ResultID,
		c.sentenceId,
		c.sentenceStart,
		event.Result.AudioDuration.String(),
		event.Result.Reason.String(),
		len(event.Result.AudioData))

	c.sentenceStart = true
	c.complete <- true
}

func (c *TtsClient) cancelledHandler(event speech.SpeechSynthesisEventArgs) {
	defer event.Close()
	c.Infof("recv Canceled from azure tts, Task id: %s, Reason: %v", c.first.TaskId, event.Result.Reason.String())
	c.complete <- true
}
