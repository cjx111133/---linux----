package embroidery

import (
	"context"
	"fmt"
	"strings"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/logx"
)

type StyleTransferEmbroideryExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewStyleTransferEmbroideryExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *StyleTransferEmbroideryExecutor {
	return &StyleTransferEmbroideryExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *StyleTransferEmbroideryExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *StyleTransferEmbroideryExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *StyleTransferEmbroideryExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.ComfyUiStyleTransferReq, error) {
	// 复用风格迁移的推理参数
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.StyleTransferInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if len(iPara.Images) == 0 {
		return nil, fmt.Errorf("InferenceParameter Images is nil")
	}
	if iPara.Images[0].FileData == "" {
		return nil, fmt.Errorf("InferenceParameter Images[0].FileData is empty")
	}

	if err := e.checkParams(in); err != nil {
		return nil, fmt.Errorf("checkParams failed, err: %v", err)
	}
	// 处理扩展参数
	//extParams := aiparameter.ComfyuiStyleTransferExtendedParameter{}
	//if err := common.JsonToAny([]byte(in.ExtendedParameter), &extParams); err != nil {
	//	return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	//}

	// 保存图片[]byte数组
	//images := make([][]byte, 0, len(iPara.Images))
	//
	//for _, image := range iPara.Images {
	//	var imageData []byte
	//	if common.IsUrl(image.FileData) {
	//		imageData, err = common.DownloadFile(e.ctx, image.FileData)
	//		if err != nil {
	//			return nil, fmt.Errorf("download file from s3 failed, s3 url:%s, error:%v", image.FileData, err)
	//		}
	//	} else if data, err := common.Base64ToBytes(image.FileData); err == nil {
	//		imageData = data
	//	} else {
	//		return nil, fmt.Errorf("InferenceParameter Image FileData is not url or base64, FileData: %v", image.FileData[1000])
	//	}
	//	images = append(images, imageData)
	//}
	req := &adaptermodel.ComfyUiStyleTransferReq{
		TaskId:              in.Header.TaskId,
		TaskType:            in.TaskType,
		ResultImageUpTokens: in.ResultUpTokens,
		ThumbImageUpTokens:  in.ThumbUpTokens,
		//GenerateImageParameter: extParams.AiGenerateParameter,
		InputImage: iPara.Images[0].FileData,
		ImageNum:   int32(len(in.ResultUpTokens)),
		//ControlNetImage:        controlNetImage,
		//DepthDetail:            eParaDepthDetail,
		ApplyInputMask: iPara.ApplyInputMask,
		//Images:                 images,
	}
	return req, nil
}

func (e *StyleTransferEmbroideryExecutor) doInference(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error) {
	//adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, config.GetSrvConfig().AdapterType)
	//if err != nil {
	//	return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	//}

	//result, err := adapter.ComfyUiStyleTransferHandler(req)
	//if err != nil {
	//	return nil, fmt.Errorf("AiGenerateImageHandler failed, err: %v", err)
	//}
	//if result == nil {
	//	return nil, fmt.Errorf("AiGenerateImageHandler failed, result is nil")
	//}

	return nil, nil
}

func (e *StyleTransferEmbroideryExecutor) buildResponse(resp *adaptermodel.ComfyUiStyleTransferResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_ComfyuiStyleTransfer{
			ComfyuiStyleTransfer: &aiparameter.ComfyuiStyleTransferInferenceResultInfo{},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	//if len(resp.Images) == 0 {
	//	return nil, fmt.Errorf("AiGenerateImageHandler failed, result.Images is empty")
	//}
	var out aiadapterrpc.InferenceResp
	out.Header = &aicommon.RspHeader{
		Code:    0,
		Message: "success",
	}
	//for i, _ := range resp.Images {
	//	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{FileSize: int64(resp.ImagesSize[i])})
	//}

	out.InferenceResultInfo = string(info)
	//out.TimeTakenMs = int32(resp.CostTime)
	return &out, nil
}

func (e *StyleTransferEmbroideryExecutor) checkParams(in *aiadapterrpc.InferenceReq) error {
	if in.ExtendedParameter == "" {
		return fmt.Errorf("ExtendedParameter is empty")
	}
	if strings.TrimSpace(in.ExtendedParameter) == "" {
		return fmt.Errorf("ExtendedParameter is empty")
	}

	if len(in.ResultUpTokens) == 0 {
		return fmt.Errorf("ResultUpTokens is empty")
	}
	return nil
}
