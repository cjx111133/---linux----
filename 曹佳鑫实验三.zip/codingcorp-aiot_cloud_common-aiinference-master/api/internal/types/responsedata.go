package types

// RecvDataResp 接收数据响应
type RecvDataResp struct {
	Code         int32       `json:"code"`          // 0-成功 非0-失败
	Message      string      `json:"message"`       // 失败消息
	Cmd          string      `json:"cmd"`           // 命令 chat translate
	SessionId    string      `json:"session_id"`    // 会话id,唯一
	MessageId    string      `json:"message_id"`    // 每条消息id，客户端生成
	Timestamp    int64       `json:"timestamp"`     // 时间戳，毫秒
	ReqStatus    int32       `json:"req_status"`    // 1-首包 2-中间包 3-结束包
	Index        int32       `json:"index"`         // 包序号 从0开始，依次递增
	SubIndex     int32       `json:"sub_index"`     // 子包序号 从0开始，依次递增（不保证连续）
	ReqType      int32       `json:"req_type"`      // 请求类型 0-音频 1-文本 2-实时翻译(音频模式)
	Type         int32       `json:"type"`          // 类型
	Data         string      `json:"data"`          // 数据，根据type不同，数据不同，（音频识别文本/对话文本）为文本，对话的文本转语音为base64音频数据
	SourceData   interface{} `json:"-"`             // 源数据 未序列化和加密的数据
	MessageType  int         `json:"message_type"`  // 消息类型
	Lang         string      `json:"lang"`          // 语言
	CustomFields string      `json:"custom_fields"` // 自定义字段
}

type TextData struct {
	Text     string    `json:"text,omitempty"` // 文本数据
	Segments []Segment `json:"segments"`
}

// SpeechToTextData 语音识别数据
type SpeechToTextData struct {
	SegmentEnd bool       `json:"segment_end,omitempty"` // 是否分片结束
	Text       string     `json:"text,omitempty"`        // 识别结果
	Segments   []*Segment `json:"segments,omitempty"`    // 历史识别结果，最大长度为5
	SpeechEnd  bool       `json:"speech_end,omitempty"`  // 是否语音结束
}

// TextToSpeechData 文本转语音数据
type TextToSpeechData struct {
	SentenceStart bool        `json:"sentence_start,omitempty"` // 是否句子开始
	Audio         string      `json:"audio,omitempty"`          // base64音频数据
	Subtitle      []*Subtitle `json:"subtitle,omitempty"`       // 字幕
}

// TranslateData 翻译数据
type TranslateData struct {
	SentenceStart bool   `json:"sentence_start,omitempty"` // 是否句子开始
	SentenceEnd   bool   `json:"sentence_end,omitempty"`   // 是否句子结束
	Text          string `json:"text,omitempty"`           // 翻译结果
}

// ChatData 对话数据
type ChatData struct {
	SentenceStart bool     `json:"sentence_start"`      // 是否句子开始
	SentenceEnd   bool     `json:"sentence_end"`        // 是否句子结束
	Text          string   `json:"text"`                // 对话结果
	Questions     []string `json:"questions,omitempty"` // 相似问题列表
	Emotion       string   `json:"emotion,omitempty"`   // 情感结果，可选值如下 1.喜(Happiness) 2.怒(Anger).哀(Sadness) 4.乐(Joy) 5.愁(Worry) 6.疑(Confuse)
	Command       string   `json:"command"`             // 下发指令 这里用于soundcore语音助手给app下发指令
	CommandArgs   string   `json:"command_args"`        // 指令参数
}

// VadData 语音端点检测数据
type VadData struct {
	SegmentEnd bool `json:"segment_end"` // 是否分片结束
}

type LanguageDetectData struct {
	Language   string  `json:"language"`   // 语言
	Confidence float32 `json:"confidence"` // 置信度
}

// EmotionData 情感识别数据
type EmotionData struct {
	Emotion string `json:"emotion"` // 情感结果，可选值如下 1.喜(Happiness) 2.怒(Anger).哀(Sadness) 4.乐(Joy) 5.愁(Worry) 6.疑(Confuse)
}

type Segment struct {
	Id         int32   `json:"id,omitempty"`         // 段落id
	StartMs    int32   `json:"start_ms,omitempty"`   // 起始时间
	EndMs      int32   `json:"end_ms,omitempty"`     // 结束时间
	Text       string  `json:"text,omitempty"`       // 识别结果
	Confidence float32 `json:"confidence,omitempty"` // 置信度
	Words      []*Word `json:"words,omitempty"`      // 识别结果
}

type Word struct {
	Text       string  `json:"text,omitempty"`       // 识别结果
	StartMs    int32   `json:"start_ms,omitempty"`   // 起始时间
	EndMs      int32   `json:"end_ms,omitempty"`     // 结束时间
	Confidence float32 `json:"confidence,omitempty"` // 置信度
}

type Subtitle struct {
	SentenceStart bool   `json:"sentence_start,omitempty"` // 是否句子开始
	Text          string `json:"text,omitempty"`           // 字幕文本
	StartMs       int32  `json:"start_ms,omitempty"`       // 起始时间
	EndMs         int32  `json:"end_ms,omitempty"`         // 结束时间
}

type TranslateContext struct {
	Role      string `json:"role"`
	MessageId string `json:"-"`
	Language  string `json:"language"`
	Text      string `json:"text"`
}

type ChatContext struct {
	User      string `json:"user"`
	Assistant string `json:"assistant"`
}
