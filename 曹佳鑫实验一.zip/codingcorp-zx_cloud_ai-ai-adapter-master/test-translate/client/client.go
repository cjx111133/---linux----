package client

import (
	"context"
	"crypto/md5"
	"fmt"
	"os"
	"sync"
	"time"

	pb "e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"

	"github.com/zeromicro/go-zero/core/logx"
	"google.golang.org/grpc"
)

var (
	lock sync.Mutex
)

type Client struct {
	conf *Config
	conn *grpc.ClientConn
	logx.Logger
}

func NewClient(conf *Config, conn *grpc.ClientConn) *Client {
	return &Client{
		conf: conf,
		conn: conn,
	}
}

func (c *Client) TextToSpeechStream(ctx context.Context, oriId, oriText, text, lang string, scene int) error {
	c.Logger = logx.WithContext(ctx)
	// client := pb.NewAiAdapterRpcClient(c.conn)
	c.Infof("TextToSpeechStream start, scene: %d, oriId: %s, oriText: %s, text: %s, lang: %s", scene, oriId, oriText, text, lang)

	// 计算 text md5 值，作为文件名
	h := md5.New()
	h.Write([]byte(text))
	id := fmt.Sprintf("%x", h.Sum(nil))

	// stream, err := client.StreamInference(ctx)
	// if err != nil {
	// 	return fmt.Errorf("StreamInference failed, err: %v", err)
	// }
	// tskType := aiparameter.TaskType_TASK_TYPE_Text_To_Speech
	// var ePara = aiparameter.TextToSpeechExtendedParameter{
	// 	Format:          "mp3",
	// 	Language:        lang,
	// 	Channels:        1,
	// 	ServiceProvider: "azure", // "azure", "aliyun" or "anker"
	// 	EnableSubtitle:  false,
	// }
	// extendedParameter, err := common.AnyToJson(ePara)
	// if err != nil {
	// 	return fmt.Errorf("AnyToJson failed, err: %v", err)
	// }
	// c.Infof("TextToSpeechStream extendedParameter: %s", string(extendedParameter))

	// var iPara = aiparameter.TextToSpeechInferenceParameter{
	// 	Text:       text,
	// 	SentenceId: 1,
	// }
	// inferenceParameter, err := common.AnyToJson(iPara)
	// if err != nil {
	// 	return fmt.Errorf("AnyToJson failed, err: %v", err)
	// }
	// UserId := "262b363ea6e20f0ea2ee45225184aebac79fff08"
	// TaskId := "test_5bfa38f46cb4aa1a13676d816c316461-7"
	// err = stream.Send(&pb.InferenceReq{
	// 	Header: &aicommon.ReqHeader{
	// 		UserId: UserId,
	// 		TaskId: TaskId,
	// 	},
	// 	TaskType:           tskType,
	// 	InferenceParameter: string(inferenceParameter),
	// 	ExtendedParameter:  string(extendedParameter),
	// })
	// if err != nil {
	// 	return fmt.Errorf("TextToSpeechStream send failed, err: %v", err)
	// }
	// c.Infof("TextToSpeechStream send success, text: %s", text)

	// err = stream.CloseSend()
	// if err != nil {
	// 	c.Errorf("TextToSpeechStream CloseSend failed, err: %v", err)
	// 	return fmt.Errorf("TextToSpeechStream CloseSend failed, err: %v", err)
	// }

	// dir := fmt.Sprintf("data/audio/%s", lang)
	// // 判断目录是否存在
	// _, err = os.Stat(dir)
	// if err != nil {
	// 	if os.IsNotExist(err) {
	// 		err = os.MkdirAll(dir, 0755)
	// 		if err != nil {
	// 			c.Errorf("MkdirAll failed, err: %v", err)
	// 			return fmt.Errorf("MkdirAll failed, err: %v", err)
	// 		}
	// 	} else {
	// 		c.Errorf("Stat failed, err: %v", err)
	// 		return fmt.Errorf("stat failed, err: %v", err)
	// 	}
	// }

	// fileName := fmt.Sprintf("%s/%s.mp3", dir, id)
	// file, err := os.Create(fileName)
	// if err != nil {
	// 	c.Errorf("create failed, err: %v", err)
	// 	return fmt.Errorf("create failed, err: %v", err)
	// }
	// defer file.Close()

	// for {
	// 	rsp, err := stream.Recv()
	// 	if err != nil {
	// 		if err.Error() == "EOF" {
	// 			c.Infof("TextToSpeechStream Recv success, err: %v", err)
	// 			break
	// 		}
	// 		return fmt.Errorf("TextToSpeechStream recv failed, err: %v", err)
	// 	}

	// 	if rsp.Header.Code != 0 {
	// 		return fmt.Errorf("TextToSpeechStream failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
	// 	}

	// 	var result TtsResult
	// 	err = common.JsonToAny([]byte(rsp.InferenceResultInfo), &result)
	// 	if err != nil {
	// 		c.Errorf("JsonToAny failed, err: %v", err)
	// 		return fmt.Errorf("JsonToAny failed, err: %v", err)
	// 	}
	// 	if result.InferenceResultInfo.TextToSpeech.SentenceStart {
	// 		c.Infof("TextToSpeechStream success, sentence start")
	// 	}

	// 	n, err := file.Write(result.InferenceResultInfo.TextToSpeech.Audio.Data)
	// 	if err != nil {
	// 		c.Errorf("write failed, err: %v", err)
	// 		return fmt.Errorf("write failed, err: %v", err)
	// 	}
	// 	c.Infof("TextToSpeechStream success, recv audio len: %d, SentenceStart: %v, index: %d, Subtitle: %v", n, result.InferenceResultInfo.TextToSpeech.SentenceStart, result.InferenceResultInfo.TextToSpeech.SentenceId, result.InferenceResultInfo.TextToSpeech.Subtitle)
	// }

	// c.Infof("TextToSpeechStream success")

	// err = c.SaveText(ctx, oriId, oriText, id, text, lang, fileName, scene)
	err := c.SaveText(ctx, oriId, oriText, id, text, lang, "", scene)
	if err != nil {
		return fmt.Errorf("SaveText failed, err: %v", err)
	}
	return nil
}

func (c *Client) SaveText(ctx context.Context, oriId, oriText, id, text, lang, audio string, scene int) error {
	lock.Lock()
	defer lock.Unlock()

	c.Logger = logx.WithContext(ctx)
	c.Infof("SaveText start, oriId: %s, oriText: %s, id: %s, text: %s, lang: %s, audio: %s, scene: %d", oriId, oriText, id, text, lang, audio, scene)

	fileName := "data/text/translate.txt"
	file, err := os.OpenFile(fileName, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		c.Errorf("OpenFile failed, err: %v", err)
		return fmt.Errorf("OpenFile failed, err: %v", err)
	}
	defer file.Close()

	str := `id: %s
ori_id: %s
ori_text: %s
scene: %d
text: %s
language_code: %s
audio_path: %s

`
	_, err = file.WriteString(fmt.Sprintf(str, id, oriId, oriText, scene, text, lang, audio))
	if err != nil {
		c.Errorf("WriteString failed, err: %v", err)
		return fmt.Errorf("WriteString failed, err: %v", err)
	}

	c.Infof("SaveText success")
	return nil
}

type AsrResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		SpeechToText struct {
			SegmentEnd bool   `json:"segment_end"`
			Text       string `json:"text"`
			Segments   []struct {
				ID         int     `json:"id"`
				StartMs    int     `json:"start_ms"`
				EndMs      int     `json:"end_ms"`
				Text       string  `json:"text"`
				Confidence float64 `json:"confidence"`
			} `json:"segments"`
		} `json:"SpeechToText"`
	} `json:"InferenceResultInfo"`
}

type TranslateResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		Translate struct {
			SentenceStart bool   `json:"sentence_start"`
			SentenceEnd   bool   `json:"sentence_end"`
			Text          string `json:"text"`
		} `json:"Translate"`
	} `json:"InferenceResultInfo"`
}

type TtsResult struct {
	TaskType            int `json:"task_type"`
	InferenceResultInfo struct {
		TextToSpeech struct {
			SentenceId    int32                `json:"sentence_id"`
			Audio         *aicommon.AudioInfo  `json:"audio"`
			SentenceStart bool                 `json:"sentence_start"`
			Subtitle      []*aicommon.Subtitle `json:"subtitle"`
		} `json:"TextToSpeech"`
	} `json:"InferenceResultInfo"`
}

func (c *Client) Translate(ctx context.Context, text string, scene int) error {
	c.Logger = logx.WithContext(ctx)
	client := pb.NewAiAdapterRpcClient(c.conn)

	// 计算 text md5 值，作为文件名
	h := md5.New()
	h.Write([]byte(text))
	oriId := fmt.Sprintf("%x", h.Sum(nil))

	sourceLang := "zh-CN"
	index := 0
	for targetLang := range common.SUPPORTED_LANGUAGES_BCP_47 {
		if targetLang == sourceLang {
			err := c.TextToSpeechStream(ctx, oriId, text, text, targetLang, scene)
			if err != nil {
				return fmt.Errorf("TextToSpeechStream failed, err: %v", err)
			}
			continue
		}
		index++

		c.Infof("Translate start, scene: %d, text: %s, sourceLang: %s, targetLang: %s, process: %d/%d", scene, text, sourceLang, targetLang, index, len(common.SUPPORTED_LANGUAGES_BCP_47))

		tskType := aiparameter.TaskType_TASK_TYPE_Translate
		var history []*aicommon.TranslateContext
		var ePara = aiparameter.TranslateExtendedParameter{
			LlmType:         "gpt-4o",
			EnableStream:    false,
			FromLang:        sourceLang,
			ToLang:          targetLang,
			Role:            "user",
			ServiceProvider: "azure", // "azure", "aliyun" or "anker"
			LlmTypeSentence: "gpt-4o-mini",
			Contexts:        history,
		}
		extendedParameter, err := common.AnyToJson(ePara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		stream, err := client.StreamInference(ctx)
		if err != nil {
			return fmt.Errorf("StreamInference failed, err: %v", err)
		}
		var wg sync.WaitGroup
		wg.Add(1)
		var ret string
		go func() {
			defer wg.Done()
			for {
				rsp, err := stream.Recv()
				if err != nil {
					if err.Error() == "EOF" {
						c.Infof("Translate Recv success, err: %v", err)
						break
					}
					c.Errorf("Translate recv failed, err: %v", err)
					return
				}

				c.Infof("Translate Recv success, rsp: %+v", rsp)

				if rsp.Header.Code != 0 {
					c.Errorf("Translate failed, code: %d, msg: %s", rsp.Header.Code, rsp.Header.Message)
					return
				}

				var result TranslateResult
				common.JsonToAny([]byte(rsp.InferenceResultInfo), &result)
				ret = result.InferenceResultInfo.Translate.Text
				c.Infof("Translate success, result: %+v", result)
			}
		}()

		var iPara = aiparameter.TranslateInferenceParameter{
			Text:       text,
			SentenceId: 1,
			IsSentence: true,
		}
		inferenceParameter, err := common.AnyToJson(iPara)
		if err != nil {
			return fmt.Errorf("AnyToJson failed, err: %v", err)
		}

		UserId := "262b363ea6e20f0ea2ee45225184aebac79fff08"
		TaskId := "test_5bfa38f46cb4aa1a13676d816c316461-7"

		err = stream.Send(&pb.InferenceReq{
			Header: &aicommon.ReqHeader{
				UserId: UserId,
				TaskId: TaskId,
			},
			TaskType:           tskType,
			InferenceParameter: string(inferenceParameter),
			ExtendedParameter:  string(extendedParameter),
		})
		if err != nil {
			return fmt.Errorf("Translate send failed, err: %v", err)
		}

		c.Infof("Translate send success, text: %s", text)
		time.Sleep(50 * time.Millisecond)
		err = stream.CloseSend()
		if err != nil {
			return fmt.Errorf("Translate CloseSend failed, err: %v", err)
		}

		wg.Wait()
		c.Infof("Translate success")

		err = c.TextToSpeechStream(ctx, oriId, text, ret, targetLang, scene)
		if err != nil {
			return fmt.Errorf("TextToSpeechStream failed, err: %v", err)
		}
	}
	return nil
}
