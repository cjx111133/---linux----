package main

import (
	"context"
	"flag"
	"fmt"
	"math"
	"os"
	"os/signal"
	"sort"

	"syscall"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/test/client"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/logx"
	"golang.org/x/sync/errgroup"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var (
	configFile = flag.String("f", "etc/aiadapter.json", "the config file")
	threads    = flag.Int("threads", 1, "Run thread numbers per test")
	runTimes   = flag.Int("run_times", 1, "Run times for each thread")
	action     = flag.String("action", "inference", "request api")
	taskType   = flag.String("task_type", "faceswap", "request api")
)

var logger logx.Logger
var config struct {
	ClientConf *client.Config
}

type RequestStats struct {
	Times        []time.Duration
	SuccessCount int
	FailureCount int
}

func (s *RequestStats) AddTime(t time.Duration, success bool) {
	s.Times = append(s.Times, t)
	if success {
		s.SuccessCount++
	} else {
		s.FailureCount++
	}
}

func (s *RequestStats) GetStats() (avg, max, p95 time.Duration, successRate float64) {
	if len(s.Times) == 0 {
		return 0, 0, 0, 0
	}

	sort.Slice(s.Times, func(i, j int) bool {
		return s.Times[i] < s.Times[j]
	})

	sum := time.Duration(0)
	for _, t := range s.Times {
		sum += t
		if t > max {
			max = t
		}
	}
	avg = sum / time.Duration(len(s.Times))
	p95Index := int(math.Ceil(float64(len(s.Times))*0.95)) - 1
	p95 = s.Times[p95Index]

	totalRequests := s.SuccessCount + s.FailureCount
	if totalRequests > 0 {
		successRate = float64(s.SuccessCount) / float64(totalRequests) * 100
	} else {
		successRate = 0
	}

	return
}

func Process(ctx context.Context, stats *RequestStats) error {
	diaOpt := grpc.WithDefaultCallOptions(grpc.MaxCallRecvMsgSize(100*1024*1024), grpc.MaxCallSendMsgSize(100*1024*1024))
	conn, err := grpc.Dial(config.ClientConf.Address, grpc.WithTransportCredentials(insecure.NewCredentials()), diaOpt)
	if err != nil {
		return fmt.Errorf("failed to dial: %v", err)
	}
	defer conn.Close()

	c := client.NewClient(config.ClientConf, conn)

	for i := 0; i < *runTimes; i++ {
		start := time.Now()
		var err error
		switch *action {
		case "create_train":
			err = c.CreateTrain(ctx)
		case "get_train":
			err = c.GetTrain(ctx)
		case "stop_train":
			err = c.StopTrain(ctx)
		case "inference":
			config.ClientConf.Inference.TaskType = *taskType
			err = c.Inference(ctx)
		case "speech_to_text_stream":
			config.ClientConf.Inference.TaskType = *action
			err = c.SpeechToTextStream(ctx)
		case "text_to_speech_stream":
			config.ClientConf.Inference.TaskType = *action
			err = c.TextToSpeechStream(ctx)
		case "translate":
			config.ClientConf.Inference.TaskType = *action
			err = c.Translate(ctx)
		case "speech_to_speech":
			err = c.SpeechToSpeech(ctx)
		case "dify_workflow":
			config.ClientConf.Inference.TaskType = *action
			err = c.Inference(ctx)
		case "speech_dify_workflow":
			err = c.SpeechDifyWorkflow(ctx)
		case "dify_chatflow":
			config.ClientConf.Inference.TaskType = *action
			err = c.Inference(ctx)
		case "speech_dify_chatflow_stream":
			err = c.SpeechDifyChatflowStream(ctx)
		case "language_detect":
			err = c.LanguageDetectStream(ctx)
		case "opus_decode":
			err = c.OpusDecodeStream(ctx)
		case "translate_question_recommend":
			config.ClientConf.Inference.TaskType = *action
			err = c.Inference(ctx)
		case "translate_question_recommend_stream":
			config.ClientConf.Inference.TaskType = *action
			err = c.TranslateQuestionRecommend(ctx)
		default:
			return fmt.Errorf("action: %s not supported", *action)
		}
		stats.AddTime(time.Since(start), err == nil)
		if err != nil {
			logger.Errorf("Request failed: %v", err)
		}
	}
	return nil
}

func main() {
	flag.Parse()
	ctx, cancel := context.WithCancel(context.Background())
	var (
		g, _  = errgroup.WithContext(ctx)
		stats = make([]*RequestStats, *threads)
	)
	defer cancel()
	logger = logx.WithContext(ctx)

	logger.Infof("configFile: %s, action: %s, threads: %d, runTimes: %d", *configFile, *action, *threads, *runTimes)

	conf.MustLoad(*configFile, &config)
	logger.Infof("config:%+v", *config.ClientConf)

	signalCh := make(chan os.Signal, 1)
	signal.Notify(signalCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		select {
		case <-ctx.Done():
			return
		case sig := <-signalCh:
			logger.Infof("Received signal: %v", sig)
			cancel()
		}
	}()

	beginTime := time.Now()

	for i := 0; i < *threads; i++ {
		stats[i] = &RequestStats{Times: make([]time.Duration, 0)}
		i := i // create a new variable to hold the value of i
		g.Go(func() error {
			return Process(ctx, stats[i])
		})
	}

	if err := g.Wait(); err != nil {
		logger.Errorf("Error occurred: %v", err)
	}

	totalTime := time.Since(beginTime)
	logger.Infof("Total time: %.3fs", totalTime.Seconds())

	totalRequests := 0
	totalSuccesses := 0
	var overallStats RequestStats
	totalTimes := 0
	for _, s := range stats {
		totalTimes += len(s.Times)
	}
	overallStats.Times = make([]time.Duration, 0, totalTimes)

	for i, s := range stats {
		avg, max, p95, successRate := s.GetStats()
		fmt.Printf("Thread %d - Avg: %.3fs, Max: %.3fs, P95: %.3fs, Success Rate: %.2f%%\n",
			i+1, avg.Seconds(), max.Seconds(), p95.Seconds(), successRate)
		totalRequests += s.SuccessCount + s.FailureCount
		totalSuccesses += s.SuccessCount
		overallStats.Times = append(overallStats.Times, s.Times...)
		overallStats.SuccessCount += s.SuccessCount
		overallStats.FailureCount += s.FailureCount
	}

	overallAvg, overallMax, overallP95, overallSuccessRate := overallStats.GetStats()
	fmt.Printf("Overall - Avg: %.3fs, Max: %.3fs, P95: %.3fs, Success Rate: %.2f%%\n",
		overallAvg.Seconds(), overallMax.Seconds(), overallP95.Seconds(), overallSuccessRate)
	fmt.Printf("Total Requests: %d, Successful Requests: %d, Requests/Second: %.2f req/s\n",
		totalRequests, totalSuccesses, float64(totalRequests)/totalTime.Seconds())
}
