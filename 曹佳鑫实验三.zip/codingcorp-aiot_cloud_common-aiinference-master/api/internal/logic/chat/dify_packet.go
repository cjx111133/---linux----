package chat

import (
	"encoding/json"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

// DifyPacket implements ChatPacketInterface for Dify Chatflow
type DifyPacket struct {
	task *BaseChatTask
}

func NewDifyPacket(task *BaseChatTask) *DifyPacket {
	return &DifyPacket{
		task: task,
	}
}

// Send handles sending chat messages
func (p *DifyPacket) Send(req *types.ChatReq) error {
	switch req.ReqStatus {
	case types.ReqStatusFirst:
		err := p.SendFirst(req)
		if err != nil {
			return err
		}
		p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
	case types.ReqStatusMiddle:
		err := p.SendMiddle(req)
		if err != nil {
			return err
		}
	case types.ReqStatusEnd:
		p.task.Infof("Dify Chatflow CloseSend")
		p.task.stream.CloseSend()
	}

	return nil
}

func (p *DifyPacket) getChatflowParam(req *types.ChatReq) *config.DifyChatflowParam {
	chatflowParam := config.NewDefaultDifyChatFlowParams(p.GetContext(req))
	switch p.task.wsData.ConnectionInfo.AppId {
	case types.Soundcore_APPID:
		chatflowParam.ChatflowName = types.ChatflowNameSoundcore
		chatflowParam.NeedReply = true
		chatflowParam.NeedEmotion = false
		chatflowParam.NeedQuestion = false
	case types.HEARD_AID_APPID:
		chatflowParam.ChatflowName = types.ChatflowNameAID
		chatflowParam.NeedEmotion = false
		chatflowParam.NeedQuestion = false
		chatflowParam.NeedReply = true
	case types.DIFM_APP:
		chatflowParam.ChatflowName = types.ChatflowNameDIFM
	default:
		chatflowParam.ChatflowName = types.ChatflowNameT9000
	}
	chatflowParam.Set(common.InterfaceToString(req.Params["house_id"]), common.InterfaceToString(req.Params["language"]), common.InterfaceToString(req.Params["timezone"]))
	for key, value := range req.Params {
		chatflowParam.Params[key] = common.InterfaceToString(value)
	}
	// Set the contexts
	contexts := make([]*types.TranslateContext, 0)
	for _, context := range req.ChatContext {
		contexts = append(contexts, &types.TranslateContext{
			Role: context.Role,
			Text: context.Text,
		})
	}
	chatflowParam.Contexts = contexts
	return chatflowParam
}

// CreateFirstStreamTaskReq creates the first stream task request for Dify Chatflow
func (p *DifyPacket) CreateFirstStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	chatflowParam := p.getChatflowParam(req)

	// Only include Dify Chatflow in the workflow
	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
	streamReq.Workflow = []*aimanagerrpcclient.Node{
		{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Dify_Chatflow), IsNeedResult: true, Parameters: chatflowParam.String()},
	}
	// If there's text data, set it directly to the chatflow
	if req.Data != "" {
		streamReq.Data = &aimanagerrpc.StreamTaskReq_ChatflowReq{
			ChatflowReq: &aiparameter.DifyChatflowInferenceParameter{
				Text: req.Data,
			},
		}
	}

	return streamReq
}

// CreateMiddleStreamTaskReq creates a middle stream task request
func (p *DifyPacket) CreateMiddleStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	// 发送请求
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	// For Dify Chatflow, we only handle text data
	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
	streamReq.Data = &aimanagerrpc.StreamTaskReq_ChatflowReq{
		ChatflowReq: &aiparameter.DifyChatflowInferenceParameter{
			Text: req.Data,
		},
	}

	return streamReq
}

// SendFirst sends first data
func (p *DifyPacket) SendFirst(req *types.ChatReq) error {
	streamReq := p.CreateFirstStreamTaskReq(req)
	p.task.Infof("Dify Chatflow first Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Dify Chatflow Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// SendMiddle sends middle data
func (p *DifyPacket) SendMiddle(req *types.ChatReq) error {
	streamReq := p.CreateMiddleStreamTaskReq(req)
	p.task.Infof("Dify Chatflow middle Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Dify Chatflow Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// GetContext gets the context for the request
func (p *DifyPacket) GetContext(req *types.ChatReq) []*types.TranslateContext {
	if len(req.Data) == 0 {
		return nil
	}

	chatContexts := make([]*types.ChatContext, 0)
	err := json.Unmarshal([]byte(req.Data), &chatContexts)
	if err != nil {
		p.task.Errorf("Dify Chatflow Unmarshal failed, err: %v", err)
		return nil
	}

	resultContexts := make([]*types.TranslateContext, 0)
	for _, chatContext := range chatContexts {
		resultContexts = append(resultContexts, &types.TranslateContext{
			Role: "user",
			Text: chatContext.User,
		}, &types.TranslateContext{
			Role: "model",
			Text: chatContext.Assistant,
		})
	}

	return resultContexts
}
