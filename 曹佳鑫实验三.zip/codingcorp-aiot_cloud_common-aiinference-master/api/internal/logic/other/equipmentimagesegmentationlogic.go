package other

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/errorx"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"encoding/json"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"github.com/zeromicro/go-zero/core/logx"
)

type EquipmentImageSegmentationLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

type EquipmentImageSegmentationRequest struct {
	MacId       string                                 `json:"mac_id"`
	TaskId      int                                    `json:"task_id"`
	TaskType    string                                 `json:"task_type"`
	PackageTime int64                                  `json:"package_time"`
	ImageList   []EquipmentImageSegmentationImageData  `json:"image_list"`
	PromptList  []EquipmentImageSegmentationPromptData `json:"prompt_list"`
}

type EquipmentImageSegmentationImageData struct {
	MessageType string `json:"message_type"`
	MessageTime int64  `json:"message_time"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	DataSize    int    `json:"data_size"`
	Data        string `json:"wsconn"`
}

type EquipmentImageSegmentationPromptData struct {
	MessageType string `json:"message_type"`
	Data        string `json:"wsconn"`
}

func NewEquipmentImageSegmentationLogic(ctx context.Context, svcCtx *svc.ServiceContext) *EquipmentImageSegmentationLogic {
	return &EquipmentImageSegmentationLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *EquipmentImageSegmentationLogic) EquipmentImageSegmentation(data []byte) (resp map[string]interface{}, err error) {
	if l.svcCtx.AwsSagemakerClient == nil || l.svcCtx.Config.AwsSagemakerConfig == nil {
		return nil, errorx.NewCodeError(codes.CodeSystemException, "AWS SageMaker client is nil")
	}

	// 直接调用 SageMaker 接口，不做额外处理
	input := &sagemakerruntime.InvokeEndpointInput{
		EndpointName:     aws.String(l.svcCtx.Config.AwsSagemakerConfig.Endpoint),
		CustomAttributes: aws.String(l.svcCtx.Config.AwsSagemakerConfig.CustomAttribute),
		ContentType:      aws.String("application/json"),
		Accept:           aws.String("application/json"),
		Body:             data,
	}

	result, err := l.svcCtx.AwsSagemakerClient.InvokeEndpoint(input)
	if err != nil {
		return nil, errorx.NewCodeError(codes.CodeTransitRequestFailed, err.Error())
	}

	resp = make(map[string]interface{})
	err = json.Unmarshal(result.Body, &resp)
	if err != nil {
		return nil, errorx.NewCodeError(codes.CodeTransitRequestFailed, err.Error())
	}

	return resp, nil
}
