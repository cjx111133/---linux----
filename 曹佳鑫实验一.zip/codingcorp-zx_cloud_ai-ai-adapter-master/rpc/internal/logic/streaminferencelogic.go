package logic

import (
	"context"
	"fmt"
	"io"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type StreamInferenceLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewStreamInferenceLogic(ctx context.Context, svcCtx *svc.ServiceContext) *StreamInferenceLogic {
	return &StreamInferenceLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *StreamInferenceLogic) StreamInference(stream aiadapterrpc.AiAdapterRpc_StreamInferenceServer) error {
	timeStart := time.Now()
	resp := &aiadapterrpc.InferenceResp{
		Header: &aicommon.RspHeader{
			Code:    codes.CodeOk,
			Message: "success",
		},
	}

	// recv first message
	in, err := stream.Recv()
	if err != nil {
		if err == io.EOF || err == context.Canceled {
			l.Infof("StreamInference recv first message failed, stream:%+v, err: %v", stream, err)
			return nil
		}
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("StreamInference recv first message failed, stream:%+v, err: %v", stream, err)
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)
		return grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	// check input
	if err := l.checkParam(in); err != nil {
		resp.Header.Code = codes.CodeInputParamInvalid
		resp.Header.Message = fmt.Sprintf("StreamInference check param failed, err: %v, task type: %v", err, in.TaskType.String())
		resp.Timestamp = time.Now().UnixMilli()
		return grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	defer func() {
		l.Infof("StreamInference end, task id: %s, task type: %v, inference time: %v ms, total time: %v ms", in.Header.TaskId, in.TaskType.String(), resp.TimeTakenMs, time.Since(timeStart).Milliseconds())
	}()
	l.Infof("StreamInference start, task id: %s, user id: %s, task type: %v", in.Header.TaskId, in.Header.UserId, in.TaskType.String())

	// create executor
	executor, err := executor.NewExecutor(l.ctx, l.svcCtx, in.TaskType)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("NewExecutor failed, task id: %s, task type: %v, err: %v", in.Header.TaskId, in.TaskType.String(), err)
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)
		return grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	request := make(chan *aiadapterrpc.InferenceReq, 100)
	request <- in // send first message
	response := make(chan *aiadapterrpc.InferenceResp, 100)

	err = l.doStreamInference(stream, executor, request, response)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("doStreamInference failed, task id: %s, task type: %v, err: %v", in.Header.TaskId, in.TaskType.String(), err)
		resp.Timestamp = time.Now().UnixMilli()
		l.Error(resp.Header.Message)
		return grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	return nil
}

func (l *StreamInferenceLogic) doStreamInference(stream aiadapterrpc.AiAdapterRpc_StreamInferenceServer, executor executor.Executor, request chan *aiadapterrpc.InferenceReq, response chan *aiadapterrpc.InferenceResp) error {
	ctx, cancel := context.WithCancel(stream.Context())
	defer cancel()

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from stream
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- l.recv(ctx, stream, request)
	})
	// send message to stream
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- l.send(ctx, stream, response)
	})
	// do inference
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- executor.StreamInference(request, response)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (l *StreamInferenceLogic) recv(ctx context.Context, stream aiadapterrpc.AiAdapterRpc_StreamInferenceServer, request chan<- *aiadapterrpc.InferenceReq) error {
	defer close(request) // close request channel
	for {
		req, err := stream.Recv()
		if err != nil {
			if err == io.EOF || err == context.Canceled {
				l.Infof("recv stream end, %v", err)
				return nil
			}
			return fmt.Errorf("recv message failed, err: %v", err)
		}
		if req.Timestamp == 0 {
			req.Timestamp = time.Now().UnixMilli()
		}

		select {
		case <-ctx.Done():
			l.Infof("recv stream end, ctx done")
			return nil
		case <-l.ctx.Done():
			l.Infof("recv stream end, logic context done")
			return nil
		default:
			request <- req
		}
	}
}

func (l *StreamInferenceLogic) send(ctx context.Context, stream aiadapterrpc.AiAdapterRpc_StreamInferenceServer, response <-chan *aiadapterrpc.InferenceResp) error {
	for {
		select {
		case <-ctx.Done():
			l.Infof("send stream end, ctx done")
			return nil
		case <-l.ctx.Done():
			l.Infof("send stream end, logic context done")
			return nil
		case res, ok := <-response:
			if !ok {
				l.Infof("send stream end, response channel closed")
				return nil
			}
			if res == nil {
				return fmt.Errorf("send message failed, response is nil")
			}
			res.Timestamp = time.Now().UnixMilli()

			err := stream.Send(res)
			if err != nil {
				return fmt.Errorf("send message failed, err: %v", err)
			}
		}
	}
}

func (l *StreamInferenceLogic) checkParam(in *aiadapterrpc.InferenceReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.TaskId == "" {
		return fmt.Errorf("task id is empty")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}

	if in.TaskType == aiparameter.TaskType_TASK_TYPE_None {
		return fmt.Errorf("task type is none, TaskType: %v", in.TaskType.String())
	}
	return nil
}
