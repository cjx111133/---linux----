package anker

import (
	"fmt"
	"net/url"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/cloudstorrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/model"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
)

func (s *AnkerAdapter) TrainHandler(req *adaptermodel.CreateTrainReq) error {
	// 1.上传json和toml文件
	tomlPath, err := s.uploadTrainingTomlFile(req)
	if err != nil {
		return fmt.Errorf("upload training toml file failed: %v", err)
	}

	host, err := s.GetHostWithInvocations(config.GetSrvConfig().ModelTrain.TrainHost)
	if err != nil {
		return fmt.Errorf("get host failed, error:%s", err)
	}
	modelPath, err := s.getBaseModelPath()
	if err != nil {
		return fmt.Errorf("get base model path failed: %v", err)
	}
	input := &adaptermodel.CreateTrainingJobInput{
		TaskId:           req.TaskId,
		DataPath:         fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.DatasetPath),
		ModelPath:        modelPath,
		TomlPath:         fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, tomlPath),
		OutputPath:       fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, req.OutputModelPath),
		FmType:           config.GetSrvConfig().ModelTrain.FmType,
		EnableWd14Tagger: true,
		Wd14TaggerParams: adaptermodel.Wd14TaggerParams{
			Onnx:          true,
			ForceDownload: false,
			FrequencyTags: true,
		},
	}
	inputBytes, err := common.AnyToJson(input)
	if err != nil {
		return fmt.Errorf("json marshal failed: %v", err)
	}
	s.Infof("create training job, req: %v, training job name: %s", req, req.TaskId)
	// 2.创建训练任务
	_, err = s.RequestWithJSON(s.ctx, "POST", host, "", inputBytes, 30)
	if err != nil {
		return fmt.Errorf("create training job failed: %v", err)
	}

	_, err = s.svcCtx.TrainModelFileModel.Insert(s.ctx, &model.TTrainModelFile{
		UserId:       req.UserId,
		TaskId:       req.TaskId,
		InstanceName: req.InstanceName,
		TrainMethod:  config.GetSrvConfig().ModelTrain.TrainMethod,
		BaseModel:    config.GetSrvConfig().ModelTrain.BaseModel,
		DatasetPath:  req.DatasetPath,
		TaskState:    int64(aicommon.TaskStatus_TASK_STATUS_PENDING),
		Progress:     0,
		ModelId:      req.InstanceName,
		ModelName:    fmt.Sprint(req.InstanceName, ".safetensors"),
		Type:         "Lora",
		// /makeitreal/makeitreal/editor_uploads/default/262b363ea6e20f0ea2ee45225184aebac79fff08
		ModelPath:   req.OutputModelPath,
		TimeTakenMs: 0,
		CreateTime:  time.Now().Local().UnixMilli(),
		UpdateTime:  time.Now().Local().UnixMilli(),
		DelFlag:     0,
	})
	if err != nil {
		return fmt.Errorf("insert train model file failed: %v", err)
	}

	s.Infof("create training job success, training job name: %s", req.TaskId)
	return nil
}

func (s *AnkerAdapter) GetTrainHandler(req *adaptermodel.GetTrainReq) (*adaptermodel.GetTrainResp, error) {
	// 获取训练任务状态
	trainModel, err := s.svcCtx.TrainModelFileModel.FindOneByTaskId(s.ctx, req.TaskId)
	if err != nil {
		return nil, fmt.Errorf("find train model file failed: %v", err)
	}
	if trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_COMPLETED) ||
		trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_FAILED) ||
		trainModel.TaskState == int64(aicommon.TaskStatus_TASK_STATUS_CANCELLED) {
		return &adaptermodel.GetTrainResp{
			Code:      codes.CodeOk,
			Message:   "success",
			Status:    aicommon.TaskStatus(trainModel.TaskState),
			Progress:  int32(trainModel.Progress),
			ModelPath: fmt.Sprint(config.GetSrvConfig().ModelTrain.Bucket, trainModel.ModelPath),
		}, nil
	}

	host, err := s.GetHostWithStatus(config.GetSrvConfig().ModelTrain.TrainHost, req.TaskId)
	if err != nil {
		return nil, fmt.Errorf("get host failed, error:%s", err)
	}
	outputBytes, err := s.RequestWithJSON(s.ctx, "GET", host, "", []byte(""), 30)
	if err != nil {
		return nil, fmt.Errorf("describe training job failed: %v", err)
	}
	if outputBytes == nil {
		return nil, fmt.Errorf("describe training job failed: output is nil")
	}
	output := &struct {
		Code      int32  `json:"code"`
		JobStatus int    `json:"job_status"`
		Message   string `json:"message"`
	}{}
	err = common.JsonToAny(outputBytes, output)
	if err != nil {
		return nil, fmt.Errorf("DescribeTrainingJob unmarshal response body failed: %v", err)
	}
	if output.Code != 200 {
		return nil, fmt.Errorf("DescribeTrainingJob failed: %s", output.Message)
	}
	status := aicommon.TaskStatus(output.JobStatus)
	var progress int32
	switch status {
	case aicommon.TaskStatus_TASK_STATUS_PENDING:
		progress = 20
	case aicommon.TaskStatus_TASK_STATUS_COMPLETED:
		progress = 100
	case aicommon.TaskStatus_TASK_STATUS_FAILED:
		progress = 100
	case aicommon.TaskStatus_TASK_STATUS_RUNNING:
		progress = 80
	case aicommon.TaskStatus_TASK_STATUS_CANCELLED:
		progress = 0
	}
	resp := &adaptermodel.GetTrainResp{
		Code:     output.Code,
		Status:   status,
		Message:  output.Message,
		Progress: progress,
	}
	s.Infof("describe training job success, training job status: %s", resp.Status)

	// 更新训练任务状态
	trainModel.TaskState = int64(resp.Status)
	trainModel.Progress = int64(resp.Progress)
	trainModel.TimeTakenMs = time.Now().Local().UnixMilli() - trainModel.CreateTime
	trainModel.UpdateTime = time.Now().Local().UnixMilli()
	_, err = s.svcCtx.TrainModelFileModel.Update(s.ctx, trainModel.Id, trainModel)
	if err != nil {
		return nil, fmt.Errorf("update train model file failed: %v", err)
	}

	s.Infof("get training job success, status: %s, progress: %d", resp.Status, resp.Progress)
	return resp, nil
}

func (s *AnkerAdapter) StopTrainHandler(req *adaptermodel.StopTrainReq) error {
	host, err := s.GetHostWithStop(config.GetSrvConfig().ModelTrain.TrainHost, req.TaskId)
	if err != nil {
		return fmt.Errorf("get host failed, error:%s", err)
	}
	_, err = s.RequestWithJSON(s.ctx, "GET", host, "", []byte(""), 30)
	if err != nil {
		return fmt.Errorf("stop training job failed: %v", err)
	}

	s.Infof("stop training job success")
	return nil
}

func (s *AnkerAdapter) uploadTrainingTomlFile(req *adaptermodel.CreateTrainReq) (string, error) {
	var fileName string
	tomlFile := adaptermodel.TomlFile
	if config.GetSrvConfig().ModelTrain.FmType == adaptermodel.SAGEMAKER_TRAIN_FM_TYPE_SD_1_5 {
		fileName = adaptermodel.SAGEMAKER_TRAIN_KOHYA_TOML_FILE_NAME
		tomlFile = s.replaceString(tomlFile, "SD_MODEL_PATH", adaptermodel.SAGEMAKER_TRAIN_KOHYA_PRETRAINED_MODEL_PATH)
		tomlFile = s.replaceString(tomlFile, "NO_HALF_VAE", "false")
	} else if config.GetSrvConfig().ModelTrain.FmType == adaptermodel.SAGEMAKER_TRAIN_FM_TYPE_SD_XL {
		fileName = adaptermodel.SAGEMAKER_TRAIN_KOHYA_XL_TOML_FILE_NAME
		tomlFile = s.replaceString(tomlFile, "SD_MODEL_PATH", adaptermodel.SAGEMAKER_TRAIN_KOHYA_XL_PRETRAINED_MODEL_PATH)
		tomlFile = s.replaceString(tomlFile, "NO_HALF_VAE", "true")
	} else {
		return "", fmt.Errorf("invalid fm type: %s", config.GetSrvConfig().ModelTrain.FmType)
	}
	tomlFile = s.replaceString(tomlFile, "OUTPUT_NAME", req.InstanceName)
	tomlFile = s.replaceString(tomlFile, "SAVE_EVERY_N_EPOCHS", fmt.Sprint(config.GetSrvConfig().ModelTrain.SaveEveryNEpochs))
	tomlFile = s.replaceString(tomlFile, "MAX_TRAIN_EPOCHS", fmt.Sprint(config.GetSrvConfig().ModelTrain.MaxTrainEpochs))

	contentType := common.TypeByExtension(fileName)
	upToken, err := s.svcCtx.CloudstorRpc.GetUpToken(s.ctx, &cloudstorrpc.GetUpTokenReq{
		AppId:       string(config.APP_ID_MAKE_IT_REAL),
		ContentType: &contentType,
		UpTokenData: &cloudstorrpc.UpToken{
			FileType: cloudstorrpc.FileType_Type3DTrainInput,
			FileName: fileName,
			UserId:   req.UserId,
			DeviceSn: req.TaskId,
		}})
	if err != nil {
		return "", fmt.Errorf("get up token failed: %v", err)
	}

	_, err = common.UploadFile(s.ctx, []byte(tomlFile), upToken.UpToken, contentType)
	if err != nil {
		return upToken.KeyPrefix, fmt.Errorf("upload toml file failed: %v", err)
	}
	return upToken.KeyPrefix, nil
}

func (s *AnkerAdapter) getBaseModelPath() (string, error) {
	path, ok := config.GetSrvConfig().ModelFile.StableDiffusion[config.GetSrvConfig().ModelTrain.BaseModel]
	if !ok {
		return "", fmt.Errorf("model name not found, model name: %s", config.GetSrvConfig().ModelTrain.BaseModel)
	}
	return fmt.Sprintf("%s/%s", path.ModelPath, path.ModelName), nil
}

// 替换字符串中的字符串
func (s *AnkerAdapter) replaceString(str, old, new string) string {
	return strings.Replace(str, old, new, -1)
}

func (s *AnkerAdapter) GetHostWithStatus(endpointName, taskId string) (string, error) {
	host, err := url.JoinPath(endpointName, "status")
	if err != nil {
		return "", fmt.Errorf("join path failed, error:%s", err)
	}
	query := url.Values{}
	query.Set("task_id", taskId)
	host = fmt.Sprintf("%s?%s", host, query.Encode())
	return host, nil
}

func (s *AnkerAdapter) GetHostWithStop(endpointName string, taskId string) (string, error) {
	host, err := url.JoinPath(endpointName, "stop")
	if err != nil {
		return "", fmt.Errorf("join path failed, error:%s", err)
	}
	query := url.Values{}
	query.Set("task_id", taskId)
	host = fmt.Sprintf("%s?%s", host, query.Encode())
	return host, nil
}
