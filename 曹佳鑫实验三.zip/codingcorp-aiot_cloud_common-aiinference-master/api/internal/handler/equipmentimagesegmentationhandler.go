package handler

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/other"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/response"
	"github.com/zeromicro/go-zero/rest/httpx"
	"io"
	"net/http"
)

func EquipmentImageSegmentationHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		data, err := io.ReadAll(r.Body)
		if err != nil {
			httpx.Error(w, err)
			return
		}

		l := other.NewEquipmentImageSegmentationLogic(r.Context(), svcCtx)
		resp, err := l.EquipmentImageSegmentation(data)
		response.Response(r, w, resp, err)
	}
}
