package fasttranscribe

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type FastTranscribeExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewFastTranscribeExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *FastTranscribeExecutor {
	return &FastTranscribeExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (e *FastTranscribeExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}

	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (e *FastTranscribeExecutor) StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error {
	return fmt.Errorf("StreamInference not implemented")
}

func (e *FastTranscribeExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.FastTranscribeReq, error) {
	var ePara aiparameter.AudioFastTranscriptionExtendedParameter
	var iPara aiparameter.AudioFastTranscriptionInferenceParameter

	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}

	if len(in.GetResultUpTokens()) == 0 {
		return nil, fmt.Errorf("ResultUpTokens is empty")
	}

	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	if len(iPara.GetImages()) == 0 {
		return nil, fmt.Errorf("InferenceParameter AudioUrls is empty")
	}

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}

	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	if len(ePara.GetLanguage()) == 0 {
		return nil, fmt.Errorf("ExtendedParameter Language is empty")
	}

	req := &adaptermodel.FastTranscribeReq{
		TaskId:          in.Header.TaskId,
		AppId:           in.Header.AppId,
		ServiceProvider: ePara.ServiceProvider,
		Language:        ePara.Language,
		Diarization:     ePara.Diarization,
		AudioUrls:       make([]string, 0),
		ResultUrl:       in.ResultUpTokens[0],
		Locales:         []string{ePara.Language},
	}

	for _, v := range iPara.Images {
		req.AudioUrls = append(req.AudioUrls, v.FileData)
	}

	return req, nil
}

func (e *FastTranscribeExecutor) doInference(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	result, err := adapter.FastTranscribeHandler(req)
	if err != nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, err: %v", err)
	}
	if result == nil {
		return nil, fmt.Errorf("InstantStyleHandler failed, result is nil")
	}
	if result.Code != codes.CodeOk {
		return nil, fmt.Errorf("task id: %s, InstantStyleHandler failed, code: %d, message: %s", req.TaskId, result.Code, result.Message)
	}

	return result, nil
}

func (e *FastTranscribeExecutor) buildResponse(resp *adaptermodel.FastTranscribeResp) (*aiadapterrpc.InferenceResp, error) {
	var out aiadapterrpc.InferenceResp

	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Audio_Fast_Transcription,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_AudioFastTranscription{
			AudioFastTranscription: &aiparameter.AudioFastTranscriptionInferenceResultInfo{},
		},
	}

	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	out.Header = &aicommon.RspHeader{
		Code:    resp.Code,
		Message: resp.Message,
	}

	out.ResultImages = append(out.ResultImages, &aicommon.FileInfo{
		FileData: resp.ResultPath,
		FileMd5:  resp.ImageMd5,
		FileSize: resp.ImageSize,
	})

	out.TimeTakenMs = resp.TimeTakenMs
	out.InferenceResultInfo = string(info)

	return &out, nil
}
