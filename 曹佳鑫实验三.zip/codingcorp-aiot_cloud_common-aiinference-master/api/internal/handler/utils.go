package handler

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/ankerutil/encrypt/hash"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"net/http"
)

type ResponseBody struct {
	Code    int         `json:"code"`
	Message string      `json:"msg"`
	Data    interface{} `json:"data,omitempty"`
}

func wsVerifyEncryption(data *types.WebSocketData, redis *redis.Redis) (int, *ResponseBody) {
	// 验证加解密签名
	if data.ConnectionInfo.XEncryptionInfo == "" {
		return 0, nil
	}

	if data.ConnectionInfo.XEncryptionInfo != "algo_ecdh" {
		return http.StatusForbidden, &ResponseBody{Code: 4422, Message: "header X-Encryption-Info invalid"}
	}

	if len(data.ConnectionInfo.XRequestTs) == 0 || len(data.ConnectionInfo.XRequestOnce) == 0 {
		return http.StatusBadRequest, &ResponseBody{Code: 4405, Message: "header X-Request-Ts/X-Request-Once empt"}
	}

	if len(data.ConnectionInfo.XKeyIdent) != 32 {
		return 463, &ResponseBody{Code: 4404, Message: "header X-Key-Ident invalid"}
	}

	// 从redis中获取key
	secretKey := "aiot:gateway:" + "key-" + data.ConnectionInfo.XKeyIdent
	secret, err := redis.Get(secretKey)
	if err != nil {
		return http.StatusInternalServerError, &ResponseBody{Code: 4406, Message: "get identity error"}
	}
	if len(secret) != 32 {
		return 463, &ResponseBody{Code: 4404, Message: "get identity error"}
	}

	// 校验签名
	sig := hash.HmacSha256([]byte(secret), []byte(data.ConnectionInfo.XRequestTs+"+"+data.ConnectionInfo.XRequestOnce))
	if sig != data.ConnectionInfo.XSignature {
		return http.StatusForbidden, &ResponseBody{Code: 4416, Message: "signature invalid"}
	}

	return 0, nil
}
