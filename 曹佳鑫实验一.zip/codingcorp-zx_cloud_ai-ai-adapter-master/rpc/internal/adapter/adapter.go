package adapter

import (
	"context"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/azure"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpc"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/aliyun"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/anker"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/sagemaker"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
)

type Adapter interface {
	// train
	TrainHandler(*adaptermodel.CreateTrainReq) error
	GetTrainHandler(*adaptermodel.GetTrainReq) (*adaptermodel.GetTrainResp, error)
	StopTrainHandler(*adaptermodel.StopTrainReq) error

	// inference
	AiGenerateImageHandler(*adaptermodel.AiGenerateImageReq) (*adaptermodel.AiGenerateImageResp, error)
	FaceSwapHandler(*adaptermodel.FaceSwapReq) (*adaptermodel.FaceSwapResp, error)
	ImageUpscaleHandler(*adaptermodel.ImageUpscaleReq) (*adaptermodel.ImageUpscaleResp, error)
	TranslateHandler(*adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error)
	InstantStyleHandler(req *adaptermodel.InstantStyleReq) (*adaptermodel.InstantStyleResp, error)
	InstantStylePlusHandler(req *adaptermodel.InstantStylePlusReq) (*adaptermodel.InstantStylePlusResp, error)
	DepthMapGenerationHandler(req *adaptermodel.DepthMapGenerationReq) (*adaptermodel.DepthMapGenerationResp, error)
	RemoveBackgroundHandler(req *adaptermodel.RemoveBackgroundReq) (*bgremoverrpc.RemoveBackgroundResp, error)
	DifyWorkflowHandler(*adaptermodel.DifyWorkflowReq) (*adaptermodel.DifyWorkflowResp, error)
	DifyChatflowHandler(*adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error)
	ComfyUiStyleTransferHandler(req *adaptermodel.ComfyUiStyleTransferReq) (*adaptermodel.ComfyUiStyleTransferResp, error)
	TranslateQuestionRecommendHandler(req *adaptermodel.TranslateQuestionRecommendReq) (*adaptermodel.TranslateQuestionRecommendResp, error)
	FastTranscribeHandler(req *adaptermodel.FastTranscribeReq) (*adaptermodel.FastTranscribeResp, error)
	TextSummaryHandler(req *adaptermodel.TextSummaryReq) (*adaptermodel.TextSummaryResp, error)
	// stream inference
	SpeechToTextStreamHandler(<-chan *adaptermodel.SpeechToTextReq, chan<- *adaptermodel.SpeechToTextResp) error
	TextToSpeechStreamHandler(<-chan *adaptermodel.TextToSpeechReq, chan<- *adaptermodel.TextToSpeechResp) error
	TranslateStreamHandler(<-chan *adaptermodel.TranslateReq, chan<- *adaptermodel.TranslateResp) error
	DifyWorkflowStreamHandler(<-chan *adaptermodel.DifyWorkflowReq, chan<- *adaptermodel.DifyWorkflowResp) error
	DifyChatflowStreamHandler(<-chan *adaptermodel.DifyChatflowReq, chan<- *adaptermodel.DifyChatflowResp) error
	LanguageDetectStreamHandler(<-chan *adaptermodel.LanguageDetectReq, chan<- *adaptermodel.LanguageDetectResp) error
	OpusWrapperStreamHandler(<-chan *adaptermodel.OpusWrapperReq, chan<- *adaptermodel.OpusWrapperResp) error
	TranslateQuestionRecommendStreamHandler(<-chan *adaptermodel.TranslateQuestionRecommendReq, chan<- *adaptermodel.TranslateQuestionRecommendResp) error
}

func NewAdapter(ctx context.Context, svcCtx *svc.ServiceContext, adapterType string) (Adapter, error) {
	switch adapterType {
	case config.ADAPTER_SERVICE_TYPE_SAGEMAKER:
		return sagemaker.NewSagemakerAdapter(ctx, svcCtx), nil
	case config.ADAPTER_SERVICE_TYPE_ANKER:
		return anker.NewAnkerAdapter(ctx, svcCtx), nil
	case config.ADAPTER_SERVICE_TYPE_ALIYUN:
		return aliyun.NewAliyunAdapter(ctx, svcCtx), nil
	case config.ADAPTER_SERVICE_TYPE_AZURE:
		return azure.NewAzureAdapter(ctx, svcCtx), nil
	}
	return nil, fmt.Errorf("adapter type %s not support", adapterType)
}
