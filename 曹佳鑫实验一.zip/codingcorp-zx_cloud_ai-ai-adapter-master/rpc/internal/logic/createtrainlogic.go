package logic

import (
	"context"
	"fmt"
	"path"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/errors/grpcerrors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateTrainLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateTrainLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTrainLogic {
	return &CreateTrainLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 模型训练
func (l *CreateTrainLogic) CreateTrain(in *aiadapterrpc.CreateTrainReq) (*aiadapterrpc.CreateTrainResp, error) {
	timeStart := time.Now()
	resp := &aiadapterrpc.CreateTrainResp{
		Header: &aicommon.RspHeader{
			Code:    codes.CodeOk,
			Message: "success",
		},
	}

	// check input
	if err := l.checkParam(in); err != nil {
		resp.Header.Code = codes.CodeInputParamInvalid
		resp.Header.Message = fmt.Sprintf("CreateTrain check param failed, err: %v", err)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	defer func() {
		l.Infof("CreateTrain end, task id: %s, total time: %v ms", in.Header.TaskId, resp.TimeTakenMs)
	}()
	l.Infof("CreateTrain start, task id: %s", in.Header.TaskId)

	// create adapter
	adapter, err := adapter.NewAdapter(l.ctx, l.svcCtx, config.GetSrvConfig().AdapterType)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("NewAdapter failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	req, err := l.buildTrainReq(in)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("buildTrainReq failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}
	err = adapter.TrainHandler(req)
	if err != nil {
		resp.Header.Code = codes.CodeSystemException
		resp.Header.Message = fmt.Sprintf("TrainHandler failed, task id: %s, err: %v", in.Header.TaskId, err)
		l.Error(resp.Header.Message)
		return resp, grpcerrors.Errorf(int(resp.Header.Code), resp.Header.Message, grpcerrors.FindCaller(1))
	}

	resp.TimeTakenMs = int32(time.Since(timeStart).Milliseconds())
	return resp, nil
}

func (l *CreateTrainLogic) checkParam(in *aiadapterrpc.CreateTrainReq) error {
	if in == nil {
		return fmt.Errorf("input is nil")
	}
	if in.Header == nil {
		return fmt.Errorf("header is nil")
	}
	if in.Header.TaskId == "" {
		return fmt.Errorf("task id is empty")
	}
	if in.Header.UserId == "" {
		return fmt.Errorf("user id is empty")
	}
	if in.InferenceParameter == "" {
		return fmt.Errorf("InferenceParameter is empty")
	}

	return nil
}

func (l *CreateTrainLogic) buildTrainReq(in *aiadapterrpc.CreateTrainReq) (*adaptermodel.CreateTrainReq, error) {
	var iPara aiparameter.TrainInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}
	if iPara.InstanceName == "" {
		return nil, fmt.Errorf("InferenceParameter InstanceName is empty")
	}
	if iPara.DatasetPath == "" {
		return nil, fmt.Errorf("InferenceParameter DatasetPath is empty")
	}
	if iPara.OutputModelPath == "" {
		return nil, fmt.Errorf("InferenceParameter OutputModelPath is empty")
	}

	name := getFileNameWithoutExtension(iPara.OutputModelPath)
	if name == "" {
		return nil, fmt.Errorf("InferenceParameter OutputModelPath is invalid, %s", iPara.OutputModelPath)
	}
	if name != iPara.InstanceName {
		return nil, fmt.Errorf("InferenceParameter OutputModelPath is invalid, expect: %s, actual: %s", iPara.InstanceName, name)
	}

	return &adaptermodel.CreateTrainReq{
		TaskId:          in.Header.TaskId,
		UserId:          in.Header.UserId,
		InstanceName:    iPara.InstanceName,
		DatasetPath:     iPara.DatasetPath,
		OutputModelPath: path.Dir(iPara.OutputModelPath),
	}, nil
}

func getFileNameWithoutExtension(urlPath string) string {
	base := path.Base(urlPath)
	ext := path.Ext(base)
	return strings.TrimSuffix(base, ext)
}
