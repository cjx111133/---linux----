package chat

import (
	"github.com/jinzhu/copier"
	"io"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"

	"github.com/zeromicro/go-zero/core/threading"
	"go.uber.org/zap"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
)

// DifyAnswer implements ChatTaskInterface for Dify Chatflow
type DifyAnswer struct {
	*BaseChatTask
	packetLogic    *DifyPacket
	reqChannel     chan *types.ChatReq
	difyResultChan chan *types.ChatData
}

func NewDifyAnswer(message *ChatMessage) *DifyAnswer {
	answer := &DifyAnswer{
		BaseChatTask: NewBaseChatTask(message),
		reqChannel:   make(chan *types.ChatReq, 3),
	}
	answer.packetLogic = NewDifyPacket(answer.BaseChatTask)
	return answer
}

// 设置channel
func (l *DifyAnswer) SetChannel(difyResultChan chan *types.ChatData) {
	l.difyResultChan = difyResultChan
}

func (l *DifyAnswer) Process(req *types.ChatReq) error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		l.Logger.Error("Failed to create stream RPC connection", zap.Error(err), zap.String("messageId", req.MessageId))
		return err
	}
	l.stream = stream
	l.isCloseSend.Store(false)
	l.messageId = req.MessageId

	threading.GoSafe(func() {
		l.ProcessReceive(req)
	})
	return l.ProcessTimer(req)
}

func (l *DifyAnswer) ProcessTimer(req *types.ChatReq) error {
	// 首包
	l.reqChannel <- req
	// 复制一个中间包
	middleReq := new(types.ChatReq)
	copier.Copy(middleReq, req)
	middleReq.ReqStatus = types.ReqStatusMiddle
	l.reqChannel <- middleReq
	// 结束包
	endReq := new(types.ChatReq)
	copier.Copy(endReq, req)
	endReq.ReqStatus = types.ReqStatusEnd
	l.reqChannel <- endReq

	for {
		select {
		case data, ok := <-l.reqChannel:
			if !ok {
				return nil
			}
			// Send the first request package
			err := l.packetLogic.Send(data)
			if err != nil {
				l.Logger.Error("Failed to send first message", zap.Error(err), zap.String("messageId", req.MessageId))
				return err
			}
		case <-l.wsData.StopWsChan:
			return nil
		}
	}
}

// ProcessReceive handles receiving messages for Dify Chatflow
func (l *DifyAnswer) ProcessReceive(req *types.ChatReq) {
	if l.stream == nil {
		l.Close()
		return
	}
	defer func() {
		l.Close()
	}()
	var index int32
	recvChan := make(chan *aimanagerrpc.StreamTaskResp, 1)
	errChan := make(chan error, 1)
	// 在单独的goroutine中执行Recv
	go func() {
		for {
			resp, err := l.stream.Recv()
			if err != nil {
				errChan <- err
				return
			}
			recvChan <- resp
		}
	}()
	for {
		// 可以同时等待多个事件
		select {
		case <-l.wsData.StopWsChan:
			return
		case <-l.stopChan:
			l.utilLogic.SendStopDataToRecv(req.CommonReq, index)
			return
		case err := <-errChan:
			index++
			if err == io.EOF {
				l.Infof("Dify Chatflow Recv EOF")
				return
			}
			l.Errorf("Dify Chatflow Recv failed, err: %v", err)
			l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to receive data")
			return
		case streamRecv := <-recvChan:
			index++
			// 处理接收到的数据...
			resp, _, _ := l.convert.ProcessStreamTaskRespData(streamRecv, req, index)
			// todo 打印一下
			l.Logger.Debugf("Dify Chatflow ProcessReceive messageId: %s,  resp: %+v", l.messageId, resp)
			chatData, ok := resp.SourceData.(types.ChatData)
			if !ok {
				l.Logger.Error("Failed to convert response to ChatData messageId: %s,  resp: %+v", req.MessageId, resp)
				l.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeRecvErr, "Failed to unmarshal ASR data")
				return
			}
			l.difyResultChan <- &chatData // 发送到语音合成的channel
			l.utilLogic.SendSuccessDataToRecv(*resp)
		}
	}
}

func (l *DifyAnswer) Close() {
	// Avoid duplicate cleanup
	if l.messageId == "" {
		return
	}
	//关闭reqchannel
	if l.reqChannel != nil {
		close(l.reqChannel)
		l.reqChannel = nil
	}
	if l.difyResultChan != nil {
		close(l.difyResultChan)
		l.difyResultChan = nil
	}

	l.Logger.Info("Closing DifyAnswer", zap.String("message_id", l.messageId))

	// Close the stream
	l.StreamClose()
}
