package aliyun

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
	nls "github.com/aliyun/alibabacloud-nls-go-sdk"
	"github.com/zeromicro/go-zero/core/logx"
)

type TtsHeader struct {
	Namespace  string `json:"namespace"` // 消息所属的命名空间
	Name       string `json:"name"`      // 消息名称
	Status     int32  `json:"status"`
	MessageID  string `json:"message_id"`
	TaskID     string `json:"task_id"`     // 任务全局唯一ID，请记录该值，便于排查问题
	StatusText string `json:"status_text"` // 本次消息的ID
}

type Subtitle struct {
	Text        string `json:"text"`
	Phoneme     string `json:"phoneme"`
	Sentence    bool   `json:"sentence"`
	BeginIndex  int32  `json:"begin_index"`
	EndIndex    int32  `json:"end_index"`
	BeginTime   int32  `json:"begin_time"`
	EndTime     int32  `json:"end_time"`
	PhonemeList []int  `json:"phoneme_list"`
}

type TtsPayload struct {
	Subtitles []Subtitle `json:"subtitles"`
}

type TtsResult struct {
	Header  TtsHeader  `json:"header"`
	Payload TtsPayload `json:"payload"`
}

type TtsClient struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
	startTime  time.Time
	complete   chan bool
	errCh      chan error
	sentenceId int32

	request  <-chan *adaptermodel.TextToSpeechReq
	response chan<- *adaptermodel.TextToSpeechResp
	first    *adaptermodel.TextToSpeechReq
	ss       *nls.SpeechSynthesis
	param    *nls.SpeechSynthesisStartParam

	sentenceStart bool
}

func NewTtsClient(ctx context.Context, svcCtx *svc.ServiceContext,
	request <-chan *adaptermodel.TextToSpeechReq,
	response chan<- *adaptermodel.TextToSpeechResp,
	first *adaptermodel.TextToSpeechReq) *TtsClient {
	return &TtsClient{
		ctx:           ctx,
		svcCtx:        svcCtx,
		Logger:        logx.WithContext(ctx),
		startTime:     time.Now(),
		complete:      make(chan bool, 1),
		errCh:         make(chan error, 1),
		request:       request,
		response:      response,
		first:         first,
		sentenceStart: true,
	}
}

func (c *TtsClient) SpeechSynthesis() error {
	var err error
	c.ss, err = c.initClient()
	if err != nil {
		return fmt.Errorf("init tts client failed, err: %v", err)
	}
	defer c.ss.Shutdown()

	c.param = &nls.SpeechSynthesisStartParam{
		Voice:          c.first.Voice,
		Format:         c.first.Format,
		SampleRate:     int(c.first.SampleRate),
		Volume:         int(c.first.Volume),
		SpeechRate:     int(c.first.Speed),
		PitchRate:      int(c.first.Pitch),
		EnableSubtitle: c.first.EnableSubtitle,
	}
	if c.first.Voice == "" {
		c.param.Voice, err = c.getVoice()
		if err != nil {
			return fmt.Errorf("get voice failed, err: %v", err)
		}
	}

	// send first package to Aliyun
	c.Infof("send first text to aliyun, text: %v", c.first.Text)
	err = c.sendTextToAliyun(c.first)
	if err != nil {
		return fmt.Errorf("send first text to aliyun failed, text: %v, err: %v", c.first.Text, err)
	}

	err = c.loop()
	if err != nil {
		return fmt.Errorf("loop speech synthesis failed, err: %v", err)
	}
	c.Infof("speech synthesis end")
	return nil
}

func (c *TtsClient) loop() error {
	for {
		select {
		case err, ok := <-c.errCh:
			if !ok {
				return nil
			}
			return fmt.Errorf("speech synthesis failed, err: %v", err)
		case <-c.ctx.Done():
			c.Infof("send text to aliyun end, ctx done")
			return nil
		case <-c.ctx.Done():
			c.Infof("send text to aliyun end, logic context done")
			return nil
		case req, ok := <-c.request:
			if !ok {
				c.Infof("send text to aliyun end, request channel closed")
				return nil
			}
			if req == nil {
				continue
			}

			c.Infof("send text to aliyun, text: %v", req.Text)
			err := c.sendTextToAliyun(req)
			if err != nil {
				return fmt.Errorf("send text to aliyun failed, err: %v", err)
			}
		}
	}
}

func (c *TtsClient) sendTextToAliyun(req *adaptermodel.TextToSpeechReq) error {
	if req.Text == "" {
		c.Errorf("send text to aliyun warning, text is empty")
		return nil
	}
	if req.SentenceId <= 0 {
		return fmt.Errorf("send text to aliyun tts failed, SentenceId is invalid: %d", req.SentenceId)
	}

	c.sentenceId = req.SentenceId
	c.Infof("send text to aliyun, SentenceId: %d, text: %v", req.SentenceId, req.Text)

	end, err := c.ss.Start(req.Text, *c.param, nil)
	if err != nil {
		return fmt.Errorf("start speech synthesis failed, text: %v, err: %v", req.Text, err)
	}

	err = c.Wait(end)
	if err != nil {
		return fmt.Errorf("wait speech synthesis end failed, text: %v, err: %v", req.Text, err)
	}
	err = c.Wait(c.complete)
	if err != nil {
		return fmt.Errorf("wait speech synthesis complete failed, text: %v, err: %v", req.Text, err)
	}

	c.ss.Shutdown()
	return nil
}

func (c *TtsClient) initClient() (*nls.SpeechSynthesis, error) {
	// connect to Aliyun
	var cfg = config.GetSrvConfig().ALiYun[config.AppId(c.first.AppId)]
	connectCfg, err := nls.NewConnectionConfigWithAKInfoDefault(cfg.VoiceServerUrl, cfg.TtsAppKey, cfg.AccessKeyID, cfg.AccessKeySecret)
	if err != nil {
		return nil, fmt.Errorf("create connection config failed, err: %v", err)
	}

	ss, err := nls.NewSpeechSynthesis(connectCfg, nil, false,
		c.TaskFailed,
		c.SynthesisResult,
		c.Metainfo,
		c.Completed,
		c.Closed, nil)
	if err != nil {
		return nil, fmt.Errorf("create speech synthesis failed, err: %v", err)
	}

	return ss, nil
}

// 识别过程中的错误处理回调
func (c *TtsClient) TaskFailed(text string, param interface{}) {
	c.Errorf("recv TaskFailed from aliyun tts, text: %s", text)
	c.errCh <- errors.New(text)
}

// 语音合成数据回调
func (c *TtsClient) SynthesisResult(data []byte, param interface{}) {
	if len(data) == 0 && !c.sentenceStart {
		return
	}
	c.Debugf("recv SynthesisResult from aliyun tts, len: %d", len(data))

	c.response <- &adaptermodel.TextToSpeechResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SentenceId: c.sentenceId,
		Audio: &aicommon.AudioInfo{
			Data:       data,
			SampleRate: c.first.SampleRate,
			BitRate:    c.first.Bitrate,
			Channels:   c.first.Channels,
			Format:     c.first.Format,
			Language:   c.first.Language,
		},
		SentenceStart: c.sentenceStart,
		TimeTakenMs:   int32(time.Since(c.startTime).Milliseconds()),
	}

	// 如果是句子的开始，需要重置标志
	if c.sentenceStart {
		c.Infof("sentence start, reset sentenceStart")
		c.sentenceStart = false
	}
}

// 字幕数据回调，需要参数中EnableSubtitle为true
func (c *TtsClient) Metainfo(text string, param interface{}) {
	if !c.first.EnableSubtitle {
		return
	}

	var ttsResult TtsResult
	err := common.JsonToAny([]byte(text), &ttsResult)
	if err != nil {
		c.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		c.errCh <- fmt.Errorf("json.Unmarshal failed: %v, text: %s", err, text)
		return
	}

	c.Debugf("recv Metainfo from aliyun tts, Subtitles: %d", len(ttsResult.Payload.Subtitles))

	var subtitles []*aicommon.Subtitle
	if len(ttsResult.Payload.Subtitles) == 0 {
		return
	} else {
		subtitles = make([]*aicommon.Subtitle, 0, len(ttsResult.Payload.Subtitles))
	}

	for _, subtitle := range ttsResult.Payload.Subtitles {
		subtitles = append(subtitles, &aicommon.Subtitle{
			SentenceStart: subtitle.Sentence,
			Text:          subtitle.Text,
			StartMs:       subtitle.BeginTime,
			EndMs:         subtitle.EndTime,
		})
	}
	c.response <- &adaptermodel.TextToSpeechResp{
		Header: &aicommon.RspHeader{
			Code:    0,
			Message: "success",
		},
		SentenceId: c.sentenceId,
		Audio: &aicommon.AudioInfo{
			SampleRate: c.first.SampleRate,
			BitRate:    c.first.Bitrate,
			Channels:   c.first.Channels,
			Format:     c.first.Format,
			Language:   c.first.Language,
		},
		Subtitles:   subtitles,
		TimeTakenMs: int32(time.Since(c.startTime).Milliseconds()),
	}
}

// 合成完毕结果回调
func (c *TtsClient) Completed(text string, param interface{}) {
	c.sentenceStart = true
	c.Infof("recv Completed from aliyun tts, text: %s, sentenceStart: %v", text, c.sentenceStart)
	c.complete <- true
}

// 连接断开回调
func (c *TtsClient) Closed(param interface{}) {
	c.Infof("recv Closed from aliyun tts")
}

// 等待start或stop完成
func (c *TtsClient) Wait(ch chan bool) error {
	select {
	case message, done := <-ch:
		if !done {
			return errors.New("wait failed")
		}
		c.Infof("Wait done: %v", message)
	case <-time.After(60 * time.Second):
		return errors.New("Wait timeout")
	}
	return nil
}

func (c *TtsClient) Close() {
	for len(c.errCh) > 0 {
		<-c.errCh
	}
	close(c.errCh)
	for len(c.complete) > 0 {
		<-c.complete
	}
	close(c.complete)
	close(c.response)
}

func (c *TtsClient) getVoice() (string, error) {
	var voice string
	switch strings.ToLower(c.first.Language) {
	case "zh", "zh-cn", "zh-CN":
		voice = "sijia"
	case "en", "en-us", "en-US":
		voice = "beth"
	case "ja", "ja-jp", "ja-JP":
		voice = "tomoka"
	case "de", "de-de", "de-DE":
		voice = "hanna"
	case "fr", "fr-fr", "fr-FR":
		voice = "clara"
	case "es", "es-es", "es-ES":
		voice = "camila"
	default:
		return "", fmt.Errorf("unsupported language: %s", c.first.Language)
	}
	return voice, nil
}
