package types

type PingReq struct {
	MessageId string `json:"message_id"` // 每条消息id，客户端生成
	Timestamp int64  `json:"timestamp"`  // 时间戳，毫秒
	ReqStatus int32  `json:"req_status"` // 1-首包 2-中间包 3-结束包
	Index     int32  `json:"index"`      // 包序号 从0开始，依次递增
	Data      string `json:"data"`       // base64音频数据
}
