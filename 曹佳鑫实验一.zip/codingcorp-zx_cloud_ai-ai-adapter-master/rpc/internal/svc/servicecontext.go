package svc

import (
	"context"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/transcriberpcclient"
	"fmt"
	"net/http"
	"net/http/pprof"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/audioprocessorrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/bgremoverrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/cloudstorrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/imagetovectorrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/popartrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/ttsenginerpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/vadserverrpcclient"
	gormconfig "e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/gorm/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/gorm/gormlogx"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/healthcheck"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/middleware/clientinterceptor/errors"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/middleware/clientinterceptor/prometheus"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/proc"
	"github.com/zeromicro/go-zero/zrpc"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

type ServiceContext struct {
	GormDB *gorm.DB

	// add model or redisConn
	InternalModelFileModel model.TInternalModelFileModel
	TrainModelFileModel    model.TTrainModelFileModel

	CloudstorRpc      cloudstorrpcclient.CloudStorRpc
	PopArtRpc         popartrpcclient.PopArtRpc
	BgRemoverRpc      bgremoverrpcclient.BgRemoverRpc
	ImageToVectorRpc  imagetovectorrpcclient.ImageToVectorRpc
	TextToSpeechRpc   ttsenginerpcclient.TtsEngineRpc
	SpeechToTextRpc   vadserverrpcclient.VadServerRpc
	AudioProcessorRpc audioprocessorrpcclient.AudioProcessorRpc
	TranscribeRpc     transcriberpcclient.TranscribeRpc
}

func NewServiceContext() *ServiceContext {
	logx.DisableStat()

	//将gozreo自带的退出信号强制超时改为200s，避免服务退出时，仍存在未结束的请求
	proc.SetTimeToForceQuit(200 * time.Second)

	c := config.GetDefaultConfig()
	gormDB, err := gorm.Open(mysql.Open(c.GormConfig.DataSource), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "",   // 表名前缀，`User` 的表名应该是 `t_users`
			SingularTable: true, // 使用单数表名，启用该选项，此时，`User` 的表名应该是 `t_user`
		},
		Logger: gormlogx.New(*c.GormConfig),
	})
	if err != nil {
		panic(err)
	}

	sqlDB, err := gormDB.DB()
	if err != nil {
		panic(err)
	}
	gormconfig.SetSqlDB(sqlDB, c.GormConfig)

	// health check begin
	go func() {
		health := healthcheck.NewHandler()
		health.AddReadinessCheck("xxx-rpc-check", func() error {
			return nil
		})

		server := &http.Server{
			Addr:              ":8086",
			ReadHeaderTimeout: 3 * time.Second,
			Handler:           health,
		}
		err := server.ListenAndServe()
		if err != nil {
			return
		}
	}()

	go func() {
		serveMux := http.NewServeMux()
		// pprof
		serveMux.HandleFunc("/debug/pprof/", pprof.Index)
		serveMux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
		serveMux.HandleFunc("/debug/pprof/profile", pprof.Profile)
		serveMux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
		serveMux.HandleFunc("/debug/pprof/trace", pprof.Trace)

		server := &http.Server{
			Addr:    ":8087",
			Handler: serveMux,
		}
		err := server.ListenAndServe()
		if err != nil {
			return
		}
	}()
	// health check end

	// add model or redis initialization
	imfModel := model.NewTInternalModelFileModel(gormDB, nil)
	tmfModel := model.NewTTrainModelFileModel(gormDB, nil)

	return &ServiceContext{
		GormDB:                 gormDB,
		InternalModelFileModel: imfModel,
		TrainModelFileModel:    tmfModel,
		CloudstorRpc: cloudstorrpcclient.NewCloudStorRpc(zrpc.MustNewClient(c.CloudStorRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		PopArtRpc: popartrpcclient.NewPopArtRpc(zrpc.MustNewClient(c.PopArtRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		BgRemoverRpc: bgremoverrpcclient.NewBgRemoverRpc(zrpc.MustNewClient(c.BgRemoverRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		ImageToVectorRpc: imagetovectorrpcclient.NewImageToVectorRpc(zrpc.MustNewClient(c.ImageToVectorRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		SpeechToTextRpc: vadserverrpcclient.NewVadServerRpc(zrpc.MustNewClient(c.SpeechToTextRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		TextToSpeechRpc: ttsenginerpcclient.NewTtsEngineRpc(zrpc.MustNewClient(c.TextToSpeechRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		AudioProcessorRpc: audioprocessorrpcclient.NewAudioProcessorRpc(zrpc.MustNewClient(c.AudioProcessorRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
		TranscribeRpc: transcriberpcclient.NewTranscribeRpc(zrpc.MustNewClient(c.TranscribeRpc,
			zrpc.WithUnaryClientInterceptor(errors.ClientErrorInterceptor),
			zrpc.WithUnaryClientInterceptor(prometheus.PrometheusInterceptor))),
	}
}

func (s *ServiceContext) InitInternalModelFile() error {
	modelFiles, err := s.InternalModelFileModel.GetAllData(context.Background())
	if err != nil {
		return err
	}
	if len(modelFiles) == 0 {
		return fmt.Errorf("model file not found")
	}
	m := config.ModelFile{}
	if m.StableDiffusion == nil {
		m.StableDiffusion = make(map[string]config.Model)
	}
	if m.Lora == nil {
		m.Lora = make(map[string]config.Model)
	}
	if m.ControlNet == nil {
		m.ControlNet = make(map[string]config.Model)
	}
	if m.VAE == nil {
		m.VAE = make(map[string]config.Model)
	}

	for _, modelFile := range modelFiles {
		if modelFile.ModelId == "" {
			return fmt.Errorf("model id is empty")
		}
		if modelFile.ModelName == "" {
			return fmt.Errorf("model name is empty")
		}
		if modelFile.ModelPath == "" {
			return fmt.Errorf("model path is empty")
		}
		if modelFile.Type == "" {
			return fmt.Errorf("model type is empty")
		}
		modelPath := modelFile.ModelPath
		if modelFile.ModelPath != "None" {
			modelPath = fmt.Sprintf("%s%s", config.GetSrvConfig().ModelTrain.Bucket, modelFile.ModelPath)
		}
		model := config.Model{
			ModelID:   modelFile.ModelId,
			ModelName: modelFile.ModelName,
			ModelPath: modelPath,
			ModelType: modelFile.Type,
		}
		switch modelFile.Type {
		case config.MODEL_TYPE_STABLE_DIFFUSION:
			m.StableDiffusion[modelFile.ModelName] = model
		case config.MODEL_TYPE_LORA:
			m.Lora[modelFile.ModelName] = model
		case config.MODEL_TYPE_CONTROL_NET:
			m.ControlNet[modelFile.ModelName] = model
		case config.MODEL_TYPE_VAE:
			m.VAE[modelFile.ModelName] = model
		}
	}
	config.InitDefaultConfigModelFile(m)
	fmt.Printf("model file init success, modelfile:%v\n", config.GetSrvConfig().ModelFile)

	return nil
}
