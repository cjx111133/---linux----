package common

import (
	"crypto/md5"
	"fmt"
	"io"
	"os"
)

func CheckFileMd5(name, md5 string) error {
	sum, err := GetFileMd5(name)
	if err != nil {
		return fmt.Errorf("get file md5 failed, error:%s", err)
	}
	if sum != md5 {
		return fmt.Errorf("file '%s' md5 is '%s', not '%s'", name, sum, md5)
	}
	return nil
}

// start_ai_generated
// GetFileMd5 获取文件的MD5值
func GetFileMd5(name string) (string, error) {
	// 使用os.Stat先检查文件是否存在以及是否为目录，避免不必要的文件打开操作
	info, err := os.Stat(name)
	if err != nil {
		return "", fmt.Errorf("get file:'%v' Stat failed, error: %v", name, err)
	}
	if info.IsDir() {
		return "", fmt.Errorf("unable to get md5 of dir:'%v'", name)
	}

	// 仅当确认文件存在且不是目录时，再打开文件
	file, err := os.Open(name)
	if err != nil {
		return "", fmt.Errorf("open file '%v' failed, error: %v", name, err)
	}
	defer file.Close()

	// 使用带缓冲的读取，减少对Read方法的调用次数
	hash := md5.New()
	buf := make([]byte, 32*1024) // 创建一个32KB的缓冲区
	_, err = io.CopyBuffer(hash, file, buf)
	if err != nil {
		return "", fmt.Errorf("read file '%v' failed, error: %v", name, err)
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}

// end_ai_generated
