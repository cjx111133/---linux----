package chat

import (
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"github.com/zeromicro/go-zero/core/threading"
	"go.uber.org/zap"
)

// ChatMessageInterface defines the interface for chat message handling
type ChatMessageInterface interface {
	// WorkFlow handles the main workflow of chat processing
	WorkFlow(req *types.ChatReq)
	// WorkFlowOver handles the cleanup when workflow is completed
	WorkFlowOver()
	// Send handles sending messages
	Send(req *types.ChatReq) error
}

// ChatMessage implements ChatMessageInterface
type ChatMessage struct {
	*ChatLogic
	stopChan chan struct{} // 用于停止接收数据

	contextManager *common.ContextManager
	convert        ChatConvertInterface // 用于处理数据包的接口
	chatPacket     ChatPacketInterface  // 用于处理聊天消息的接口

	messageId     string
	reqs          chan *types.ChatReq // 消息队列
	workFlowIndex int
}

func NewChatMessage(manager *ChatLogic, req *types.ChatReq) *ChatMessage {
	l := &ChatMessage{
		ChatLogic: manager,
		reqs:      make(chan *types.ChatReq, 1024),
		stopChan:  make(chan struct{}),
	}
	l.messageId = req.MessageId
	l.contextManager = common.NewContextManager(manager.Logger, manager.svcCtx, manager.wsData.ConnectionInfo)
	l.convert = NewChatConvert(l)
	manager.Logger.Info("Chat workflow start", zap.String("message_id", req.MessageId))

	// 启动工作流
	threading.GoSafe(func() { l.WorkFlow(req) })

	return l
}

func (l *ChatMessage) WorkFlow(req *types.ChatReq) {
	defer func() {
		l.WorkFlowOver()
	}()
	// 下发tts指令
	if req.ReqStatus == types.ReqStatusAlone && req.Type == types.MessageTypeTTS {
		if err := NewChatAnswer(l).Process(req); err != nil {
			l.Logger.Error("Failed to handle answer", zap.Error(err))
			return
		}
		return
	}
	// 文本对话
	if req.Type == types.ReqTypeText || req.Type == types.ReqTypeAudio || l.wsData.ConnectionInfo.AppId != types.Soundcore_APPID {
		if err := NewChatAnswer(l).Process(req); err != nil {
			l.Logger.Error("Failed to handle answer", zap.Error(err))
			return
		}
		return
	} else {
		// 先进行语音到文本的ASR处理
		asrAnswer := NewVoiceASRAnswer(l)
		if err := asrAnswer.Process(req); err != nil {
			l.Logger.Error("Failed to handle ASR", zap.Error(err))
			return
		}

		// 检查ASR结果是否为空
		if asrAnswer.result == "" { // todo 这里需要根据实际的ASR结果进行判断
			l.Logger.Info("ASR result is empty", zap.String("message_id", req.MessageId))
			return
		}
		l.utilLogic.SendSpeechEndDataToRecv(&types.CommonReq{MessageId: req.MessageId, CustomFields: req.CustomFields,
			ReqStatus: req.ReqStatus}, 0, asrAnswer.result)
		difyResultChan := make(chan *types.ChatData, 100)
		// 使用ASR结果进行Dify Chatflow处理
		difyChatflowReq := *req
		difyChatflowReq.Data = asrAnswer.result  // 使用ASR结果作为Dify Chatflow的输入
		difyChatflowReq.Type = types.ReqTypeText // 更改类型为文本
		// 启动Dify Chatflow处理
		threading.GoSafe(func() {
			difyAnswer := NewDifyAnswer(l)
			difyAnswer.SetChannel(difyResultChan)
			if err := difyAnswer.Process(&difyChatflowReq); err != nil {
				l.Logger.Errorf("Failed to handle Dify Chatflow %+v, messageID: %s", zap.Error(err), l.messageId)
				return
			}
		})
		// 处理Dify Chatflow的结果
		ttsReq := *req
		ttsReq.Type = types.ReqTypeText // 确保类型为文本
		ttlAnswer := NewTTSAnswer(l)
		ttlAnswer.SetChannel(difyResultChan)
		if err := ttlAnswer.Process(&ttsReq); err != nil {
			l.Logger.Errorf("Failed to handle TTS %+v, messageId: %s ", zap.Error(err), l.messageId)
			return
		}
	}
}

func (l *ChatMessage) WorkFlowOver() {
	l.mu.Lock()
	delete(l.msgLogicMap, l.messageId)
	l.mu.Unlock()
	// 避免重复执行清理
	if l.messageId == "" {
		return
	}
	l.Logger.Info("Chat workflow completed", zap.String("message_id", l.messageId))
}

func (l *ChatMessage) Send(req *types.ChatReq) error {
	if l.reqs == nil {
		return nil
	}
	// 将消息添加到队列
	l.reqs <- req
	return nil
}

// 判断是否需要创建新的grpc连接
func (l *ChatMessage) isCreateGrpcConn(req *types.ChatReq) bool {
	if req.ReqStatus == types.ReqStatusAlone && req.MessageType == types.MessageTypePreset {
		return false
	}
	return true
}
