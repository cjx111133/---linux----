package utils

// Entry 表示一个索引和值的对
type Entry struct {
	Index int
	Value int
}

// RingBuffer 是一个固定大小的环形缓冲区，带有索引映射
type RingBuffer struct {
	data     []Entry
	indexMap map[int]int // 用于快速查找索引对应的值
	size     int
	start    int
	count    int
}

// NewRingBuffer 创建一个新的环形缓冲区
func NewRingBuffer(size int) *RingBuffer {
	return &RingBuffer{
		data:     make([]Entry, size),
		indexMap: make(map[int]int),
		size:     size,
	}
}

// Add 向环形缓冲区添加一个新的索引和值的对
func (rb *RingBuffer) Add(index, value int) {
	entry := Entry{Index: index, Value: value}
	if rb.count < rb.size {
		rb.data[(rb.start+rb.count)%rb.size] = entry
		rb.count++
	} else {
		// 删除最旧的条目对应的索引映射
		oldEntry := rb.data[rb.start]
		delete(rb.indexMap, oldEntry.Index)

		rb.data[rb.start] = entry
		rb.start = (rb.start + 1) % rb.size
	}
	// 添加新的索引映射
	rb.indexMap[index] = value
}

// Update 更新环形缓冲区中指定索引的值
func (rb *RingBuffer) Update(index, value int) {
	if _, found := rb.indexMap[index]; found {
		rb.indexMap[index] = value
		for i := 0; i < rb.count; i++ {
			if rb.data[(rb.start+i)%rb.size].Index == index {
				rb.data[(rb.start+i)%rb.size].Value = value
				break
			}
		}
	}
}

// GetAll 返回环形缓冲区中的所有条目
func (rb *RingBuffer) GetAll() []Entry {
	result := make([]Entry, rb.count)
	for i := 0; i < rb.count; i++ {
		result[i] = rb.data[(rb.start+i)%rb.size]
	}
	return result
}

// GetValueByIndex 根据索引获取对应的值
func (rb *RingBuffer) GetValueByIndex(index int) (int, bool) {
	value, found := rb.indexMap[index]
	return value, found
}
