package common

import (
	"encoding/base64"
)

// []byte转base64
func BytesToBase64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

// base64转[]byte
func Base64ToBytes(data string) ([]byte, error) {
	return base64.StdEncoding.DecodeString(data)
}
