package sagemaker

import (
	"fmt"
	"github.com/aws/aws-sdk-go/service/bedrockruntime"
	"sync"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sagemaker"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
)

var (
	sgm         *SageMaker
	sgmOnce     sync.Once
	sgmPlus     *SageMaker
	sgmOncePlus sync.Once
)

type SageMaker struct {
	SgmRunClient   *sagemakerruntime.SageMakerRuntime
	SgmClient      *sagemaker.SageMaker
	BedRockRuntime *bedrockruntime.BedrockRuntime
}

func newSageMakerClient() *SageMaker {
	mySession := session.Must(session.NewSessionWithOptions(session.Options{
		Config: aws.Config{
			Region: aws.String(config.GetSrvConfig().SageMaker.Region),
			Credentials: credentials.NewStaticCredentials(
				config.GetSrvConfig().AwsAccessKeyID,
				config.GetSrvConfig().AwsSecretAccessKey,
				config.GetSrvConfig().AwsSessionToken),
		},
	}))
	// 打印输出，代表初始化开始
	fmt.Println("newSageMakerClient")
	return &SageMaker{
		SgmClient:      sagemaker.New(mySession),
		SgmRunClient:   sagemakerruntime.New(mySession),
		BedRockRuntime: bedrockruntime.New(mySession),
	}
}

func GetSgmClient() *SageMaker {
	sgmOnce.Do(func() {
		sgm = newSageMakerClient()
	})
	return sgm
}

func newSageMakerPlusClient() *SageMaker {
	mySession := session.Must(session.NewSessionWithOptions(session.Options{
		Config: aws.Config{
			Region: aws.String(config.GetSrvConfig().SageMaker.PlusRegion),
			Credentials: credentials.NewStaticCredentials(
				config.GetSrvConfig().AwsPlusAccessKeyID,
				config.GetSrvConfig().AwsPlusSecretAccessKey,
				config.GetSrvConfig().AwsPlusSessionToken),
		},
	}))
	// 打印输出，代表初始化开始
	fmt.Println("newSageMakerPlusClient")

	return &SageMaker{
		SgmClient:    sagemaker.New(mySession),
		SgmRunClient: sagemakerruntime.New(mySession),
	}
}

func GetSgmPlusClient() *SageMaker {
	sgmOncePlus.Do(func() {
		sgmPlus = newSageMakerPlusClient()
	})
	return sgmPlus
}
