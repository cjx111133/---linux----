package sagemaker

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"image"
	"net/url"
	"path"
	"strings"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/sagemakerruntime"
	"golang.org/x/sync/errgroup"
)

func (s *SagemakerAdapter) ComfyUiGenImage(req *adaptermodel.ComfyUiStyleTransferReq, endPointName string) (resp adaptermodel.ComfyUiStyleTransferResp, err error) {
	prompt := []byte(req.GenerateImageParameter)

	x := &sagemakerruntime.InvokeEndpointInput{
		Body:         prompt,
		EndpointName: aws.String(endPointName),
		ContentType:  aws.String("application/json"),
	}
	sgmRunClient := GetSgmClient().SgmRunClient
	reqSt := time.Now()
	sageOutput, err := sgmRunClient.InvokeEndpointWithContext(s.ctx, x)
	// 计算请求耗时
	resp.CostTime = time.Since(reqSt).Milliseconds()
	if err != nil {
		return resp, fmt.Errorf("invoke endpoint error: %v", err)
	}
	if sageOutput == nil {
		return resp, fmt.Errorf("invoke endpoint error: sageOutput is nil")
	}
	s.Logger.Info(fmt.Sprintf("task_id: %s, request elapsed: %d ms", req.TaskId, resp.CostTime))

	err = common.JsonToAny(sageOutput.Body, &resp)
	if err != nil {
		return resp, fmt.Errorf("json unmarshal error: %v", err)
	}

	if err = s.handleComfyUiImage(req, &resp); err != nil {
		return resp, err
	}
	return resp, nil
}

func (s *SagemakerAdapter) handleComfyUiImage(req *adaptermodel.ComfyUiStyleTransferReq, resp *adaptermodel.ComfyUiStyleTransferResp) error {
	resultImageUpTokens := req.ResultImageUpTokens
	thumbImageUpTokens := req.ThumbImageUpTokens

	for i, imageInfo := range resp.Images {
		imageInfo = strings.TrimSpace(imageInfo)
		if imageInfo == "" {
			return fmt.Errorf("comfyui, image info is nil at index %d", i)
		}
		urlParse, err := url.Parse(resultImageUpTokens[i])
		if err != nil {
			return fmt.Errorf("comfyui, raw url into a [URL] failed, url: %s, error: %v", resultImageUpTokens[i], err)
		}
		urlPath := strings.ToLower(urlParse.Path)
		contentType := common.TypeByExtension(urlPath)

		base64St := time.Now()
		// base64图片转[]byte
		imgData, err := base64.StdEncoding.DecodeString(imageInfo)
		if err != nil {
			return fmt.Errorf("comfyui, base64 decode failed, url: %s, error: %v", resultImageUpTokens[i], err)
		}
		s.Logger.Info(fmt.Sprintf("task_id: %s, base64 elapsed: %d ms", req.TaskId, time.Since(base64St).Milliseconds()))

		// 0:默认，不处理生图结果图， 1:前端裁减过的图会调用，输入图带mask则需要叠加到结果图
		if req.ApplyInputMask == 1 && len(req.Images) > 0 {
			maskSt := time.Now()
			resultImg, err := common.AddInputMaskNew(req.Images[0], imgData)
			if err != nil {
				s.Logger.Error(fmt.Sprintf("task_id: %s, applyInputMask failed, url: %s, error: %v", req.TaskId, req.ResultImageUpTokens[i], err))
			}
			if resultImg != nil {
				s.Logger.Info(fmt.Sprintf("task_id: %s, applyInputMask elapsed: %d ms", req.TaskId, time.Since(maskSt).Milliseconds()))
				imgData, err = common.ImageEncode(resultImg, ".png", 100)
				if err != nil {
					return err
				}
				s.Logger.Info(fmt.Sprintf("task_id: %s, resultImg imageEncode elapsed: %d ms", req.TaskId, time.Since(maskSt).Milliseconds()))
			}
		}

		// 这里处理灰度图叠底与应用mask的逻辑
		controlNetImage := make([]byte, 0)
		if len(req.Images) > 1 {
			controlNetImage = req.Images[1]
			if imgData, err = s.depthGrayAddAndMask(req.TaskId, req.DepthDetail, controlNetImage, imgData); err != nil {
				return fmt.Errorf("generateImage, depth gray add and mask failed, url: %s, error: %v", req.ResultImageUpTokens[i], err)
			}
		}

		//图片大小
		resp.ImagesSize = append(resp.ImagesSize, len(imgData))

		// 上传原图和缩略图到s3，可以并发上传，提升接口吞吐能力
		wg := errgroup.Group{}

		wg.Go(func() error {
			// 原图
			st := time.Now()
			var oriImageData []byte
			img, _, err := image.Decode(bytes.NewReader(imgData))
			if err != nil {
				return fmt.Errorf("comfyui, image decode failed, url: %s, error: %v", resultImageUpTokens[i], err)
			}
			s.Logger.Info(fmt.Sprintf("task_id: %s, comfyui ori image decode elapsed: %d ms", req.TaskId, time.Since(st).Milliseconds()))
			ext := path.Ext(urlPath)
			if common.IsExitSuffix(strings.ToLower(ext)) {
				oriImageData, err = common.ImageEncode(img, strings.ToLower(ext), config.GetSrvConfig().Thumbnail.ImageQuality)
			} else {
				oriImageData, err = common.ImageEncode(img, ".webp", config.GetSrvConfig().Thumbnail.ImageQuality)
			}
			if err != nil {
				return fmt.Errorf("comfyui, convert image failed, error: %v", err)
			}
			s.Logger.Info(fmt.Sprintf("task_id: %s, comfyui ori image encode elapsed: %d ms", req.TaskId, time.Since(st).Milliseconds()))

			uploadSt := time.Now()
			if _, err = common.UploadFile(s.ctx, oriImageData, resultImageUpTokens[i], contentType); err != nil {
				return fmt.Errorf("upload image s3 failed, url: %s, error: %v", resultImageUpTokens[i], err)
			}
			s.Logger.Info(fmt.Sprintf("task_id: %s, comfyui ori image upload elapsed: %d ms", req.TaskId, time.Since(uploadSt).Milliseconds()))
			return nil
		})

		wg.Go(func() error {
			//缩略图
			var imageThumbData []byte
			if len(thumbImageUpTokens) > 0 && len(thumbImageUpTokens) == len(resultImageUpTokens) {
				// svg格式的上传图片不生成缩略图
				thumbUrlParse, err := url.Parse(thumbImageUpTokens[i])
				if err != nil {
					return fmt.Errorf("comfyui, raw url failed, thumbnail url: %s, error: %v", thumbImageUpTokens[i], err)
				}
				thumbUrlPath := strings.ToLower(thumbUrlParse.Path)
				if !strings.HasSuffix(thumbUrlPath, ".svg") {
					imageThumbData, err = s.thumbResizeAndEncodePng(req.TaskId, imgData, thumbUrlPath)
					if err != nil {
						return fmt.Errorf("comfyui, thumbResizeAndEncodePng failed, url: %s, error: %v", thumbImageUpTokens[i], err)
					}
				}
			}
			if len(imageThumbData) > 0 {
				uploadSt := time.Now()
				if _, err = common.UploadFile(s.ctx, imageThumbData, thumbImageUpTokens[i], contentType); err != nil {
					return fmt.Errorf("upload thumb image s3 failed, url: %s, error: %v", thumbImageUpTokens[i], err)
				}
				s.Logger.Info(fmt.Sprintf("task_id: %s, comfyui thumb image upload elapsed: %d ms", req.TaskId, time.Since(uploadSt).Milliseconds()))
			}
			return nil
		})

		if err = wg.Wait(); err != nil {
			return err
		}
	}
	return nil
}
