package dify

import (
	"context"
	"fmt"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type DifyChatflowExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDifyChatflowExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *DifyChatflowExecutor {
	return &DifyChatflowExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (d *DifyChatflowExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := d.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}
	resp, err := d.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := d.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	return out, nil
}

func (d *DifyChatflowExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := d.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}
	return nil
}

func (d *DifyChatflowExecutor) receiveStream(resChan chan *adaptermodel.DifyChatflowResp, cliResp chan<- *aiadapterrpc.InferenceResp) {
	defer close(cliResp)
	for {
		resp, ok := <-resChan
		if !ok {
			d.Infof("recv resp from llm engine end, resChan channel closed")
			return
		}
		if resp == nil {
			continue
		}
		out, err := d.buildResponse(resp)
		if err != nil {
			d.Errorf("buildResponse failed, err: %v", err)
			return
		}
		cliResp <- out
	}
}

func (d *DifyChatflowExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		d.Infof("DifyChatflow doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		d.Infof("DifyChatflow doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := d.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}

	ctx, cancel := context.WithTimeout(d.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, d.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	chatflowReq := make(chan *adaptermodel.DifyChatflowReq, 100)
	chatflowResp := make(chan *adaptermodel.DifyChatflowResp, 100)
	chatflowReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- d.recv(ctx, chatflowResp, cliResp)
	})
	// send message to Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- d.send(ctx, chatflowReq, cliReq)
	})
	// handle message from Dify
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.DifyChatflowStreamHandler(chatflowReq, chatflowResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (d *DifyChatflowExecutor) recv(ctx context.Context, DifyChatflowResp <-chan *adaptermodel.DifyChatflowResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-DifyChatflowResp:
			if !ok {
				d.Infof("recv resp from Dify end, DifyChatflowResp channel closed")
				return nil
			}

			res, err := d.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			d.Infof("recv resp from Dify end, ctx done")
			return nil
		case <-d.ctx.Done():
			d.Infof("recv resp from Dify end, logic context done")
			return nil
		}
	}
}

func (d *DifyChatflowExecutor) send(ctx context.Context,
	difychatflowReq chan *adaptermodel.DifyChatflowReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(difychatflowReq)

	for {
		select {
		case <-ctx.Done():
			d.Infof("send req to Dify end, ctx done")
			return nil
		case <-d.ctx.Done():
			d.Infof("send req to Dify end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				d.Infof("send req to Dify end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to Dify failed, request is nil")
			}
			r, err := d.buildParameter(req)
			if err != nil {
				d.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			d.Infof("send req to dify, text: %s", r.Body.Query)

			difychatflowReq <- r
		}
	}

}

func (d *DifyChatflowExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.DifyChatflowReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.DifyChatflowInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.DifyChatflowExtendedParameter
	// var contexts []*adaptermodel.TranslateContext

	if in.ExtendedParameter == "" {
		return nil, fmt.Errorf("ExtendedParameter is empty")
	}
	err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
	if err != nil {
		return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
	}

	err = d.checkParameter(&iPara, &ePara)
	if err != nil {
		return nil, fmt.Errorf("checkParameter failed, err: %v", err)
	}
	chatflowName := config.T9000_CHATFLOW_NAME
	if ePara.ChatFlowName != "" {
		chatflowName = ePara.ChatFlowName
	}
	inputs := map[string]interface{}{
		"house_id":   ePara.HouseId,
		"language":   ePara.Language,
		"timezone":   ePara.Timezone,
		"station_sn": ePara.StationSn,
		"user_id":    ePara.UserId,
	}
	for k, v := range ePara.Params {
		inputs[k] = v
	}
	var contexts []*adaptermodel.TranslateContext
	if ePara.Contexts != nil {
		for _, context := range ePara.Contexts {
			translateContext := &adaptermodel.TranslateContext{
				Role: context.Role,
				Text: context.Text,
			}
			contexts = append(contexts, translateContext)
		}
	}

	req := &adaptermodel.DifyChatflowReq{
		TaskId: in.Header.TaskId,
		Body: adaptermodel.DifyChatflowReqBody{
			Inputs:         inputs,
			Query:          iPara.Text,
			ResponseMode:   config.GetSrvConfig().DifyChatflow.ResponseMode,
			User:           config.GetSrvConfig().DifyChatflow.User,
			ConversationId: iPara.ConversationId,
		},
		ServiceProvider: ePara.ServiceProvider,
		NeedReply:       ePara.NeedReply,
		NeedEmotion:     ePara.NeedEmotion,
		NeedQuestion:    ePara.NeedQuestion,
		ChatFlowName:    chatflowName,
		StationSn:       ePara.StationSn,
		Params:          ePara.Params,
		Contexts:        contexts,
	}

	d.Logger.Infof("dify chatflow param %+v", req)
	return req, nil
}

func (d *DifyChatflowExecutor) checkParameter(
	iPara *aiparameter.DifyChatflowInferenceParameter,
	ePara *aiparameter.DifyChatflowExtendedParameter) error {
	if iPara.Text == "" {
		return fmt.Errorf("InferenceParameter Text is empty")
	}
	return nil
}

func (d *DifyChatflowExecutor) doInference(req *adaptermodel.DifyChatflowReq) (*adaptermodel.DifyChatflowResp, error) {
	adapter, err := adapter.NewAdapter(d.ctx, d.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	resp, err := adapter.DifyChatflowHandler(req)
	if err != nil {
		return nil, fmt.Errorf("DifyChatflowHandler failed, err: %v", err)
	}
	if resp.Answer == "" {
		return nil, fmt.Errorf("DifyChatflowHandler failed, text is empty")
	}
	return resp, nil
}

func (d *DifyChatflowExecutor) buildResponse(resp *adaptermodel.DifyChatflowResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Dify_Chatflow,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_DifyChatflow{
			DifyChatflow: &aiparameter.DifyChatflowInferenceResultInfo{
				Text:          resp.Answer,
				Question:      resp.Question,
				Emotion:       resp.Emotion,
				SentenceStart: resp.SentenceStart,
				SentenceEnd:   resp.SentenceEnd,
				Command:       resp.Command,
				CommandArgs:   resp.CommandArgs,
				Timestamp:     time.Now().UnixMilli(),
				SentenceId:    1,
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	header := aicommon.RspHeader{
		Code:    0,
		Message: "",
	}
	// 为了占位，避免 inferencelogic 报错
	resultImages := []*aicommon.FileInfo{
		{},
	}
	return &aiadapterrpc.InferenceResp{
		Header:              &header,
		InferenceResultInfo: string(info),
		ResultImages:        resultImages,
		TimeTakenMs:         int32(resp.MetaData.Usage.Latency * 1000),
	}, nil
}
