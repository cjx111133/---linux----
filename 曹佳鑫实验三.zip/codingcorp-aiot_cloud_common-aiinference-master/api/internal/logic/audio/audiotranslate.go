package audio

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/utils"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"github.com/zeromicro/go-zero/core/threading"
)

type TranslateTask struct {
	*BaseAITask
}

func NewTranslateTask(message *AudioMessage) *TranslateTask {
	return &TranslateTask{
		BaseAITask: NewBaseAITask(message),
	}
}

// Process implements AITaskInterface
func (l *TranslateTask) Process(first *types.AudioTranslateReq) error {
	// 1. set translate
	err := l.setTranslate()
	if err != nil {
		return fmt.Errorf("set translate failed: %s", err)
	}

	var errCh = make(chan error, 2)
	defer func() {
		close(errCh)
	}()

	// 2. Receiving
	threading.GoSafe(func() {
		err := l.ProcessReceive(l.ctx, first)
		if err != nil {
			errCh <- fmt.Errorf("translate receive failed: %s", err)
		}
		errCh <- nil
	})

	// 3. Send requests
	threading.GoSafe(func() {
		err := l.ProcessTimer(l.ctx, first)
		if err != nil {
			errCh <- fmt.Errorf("translate send failed: %s", err)
		}
		errCh <- nil
	})

	var newErr error
	// 4. Wait for completion
	for i := 0; i < 2; i++ {
		if err = <-errCh; err != nil {
			l.Errorf("TranslateTask Process error: %s", err)
			newErr = err
		}
	}
	return newErr
}

func (l *TranslateTask) setTranslate() error {
	stream, err := l.utilLogic.CreateStreamRPCConn()
	if err != nil {
		return fmt.Errorf("failed to create stream RPC connection: %w", err)
	}

	l.stream = stream
	l.isCloseSend.Store(false)
	l.workFlow = aiparameter.TaskType_TASK_TYPE_Translate
	return nil
}

func (l *TranslateTask) ProcessTimer(ctx context.Context, first *types.AudioTranslateReq) error {
	l.Infof("TranslateTask ProcessTimer start, msgId: %s, Type: %d, SimultaneousTimePeriod: %d, TimePeriod: %d", first.MessageId, first.Type, l.svcCtx.Config.AudioTranslate.SimultaneousTimePeriod, l.svcCtx.Config.AudioTranslate.TimePeriod)

	// 循环读取音频数据发送，直到读取到结束或者超时
	// 定时器100ms
	timerSend := time.NewTicker(100 * time.Millisecond)
	l.isTimeUp.Store(false)

	if first.Type == types.ReqTypeSimultaneous {
		l.timer = time.NewTicker(time.Second * time.Duration(l.svcCtx.Config.AudioTranslate.SimultaneousTimePeriod))
	} else {
		l.timer = time.NewTicker(time.Second * time.Duration(l.svcCtx.Config.AudioTranslate.TimePeriod))
	}

	defer func() {
		l.Close()
		timerSend.Stop()
		if l.timer != nil {
			l.timer.Stop()
		}
		l.Infof("TranslateTask ProcessTimer stop, msgId: %s", first.MessageId)
	}()

	for {
		select {
		case <-l.timer.C:
			l.Errorf("TranslateTask ProcessTimer timer up, messageId: %s, reqType: %d, sourceLanguage: %s", first.MessageId, first.Type, first.SourceLanguage)
			l.isTimeUp.Store(true)
			return nil
		case <-l.wsStopChan:
			l.Errorf("TranslateTask ProcessTimer stop, websocket stop, messageId: %s", first.MessageId)
			return nil
		case <-l.closeCh:
			l.Errorf("TranslateTask ProcessTimer stop, close channel, messageId: %s", first.MessageId)
			return nil
		case <-timerSend.C:
			// 这里可能有数组越界 加入判断
			if l.audioIndex >= len(l.audios) {
				l.Infof("audio index out of range, messageId: %s, audioIndex: %d, len(audios): %d", first.MessageId, l.audioIndex, len(l.audios))
				continue
			}

			for _, audio := range l.audios[l.audioIndex:] {
				if audio == nil {
					l.Errorf("TranslateTask ProcessTimer audio is nil, messageId: %s", first.MessageId)
					continue
				}

				l.audioIndex++
				// 如果是自动检测语种，且当前语种不为空，则设置当前语种
				if audio.SourceLanguage == types.AutoDetectLanguage && l.lang != "" {
					audio.SourceLanguage = l.lang
				}
				err := l.packetLogic.Send(audio)
				if err != nil {
					return fmt.Errorf("failed to send audio data: %s", err)
				}
				if audio.ReqStatus == types.ReqStatusEnd {
					return nil
				}
			}
		}
	}
}

// Receiving 接收语音翻译的结果
func (l *TranslateTask) ProcessReceive(ctx context.Context, req *types.AudioTranslateReq) error {
	l.Infof("TranslateTask ProcessReceive start, messageId: %s", req.MessageId)

	defer func() {
		l.Infof("TranslateTask ProcessReceive end, messageId: %s", req.MessageId)
		l.Close()
	}()

	var existData bool
	var index int32 = 0
	lastDataTypeEndCountMap := map[int32]int32{
		types.TaskTypeSpeechToText: 1,
		types.TaskTypeTranslate:    1,
		types.TaskTypeTextToSpeech: 0,
	}

	// 将每一段ASR结果的subIndex存起来，后续TRANSLATE和tts都直接取这个subindex
	resultIndex := make(map[int32]int32)

	lastSegmentEnd := false
	ringBuffer := utils.NewRingBuffer(100)
	ringBuffer.Add(0, 1)
	ringBuffer.Add(1, 1)
	lastAsrTime := time.Now().Add(time.Minute)

	for {
		index++
		streamRecv, err := l.stream.Recv()
		timeUp := l.isTimeUp.Load()
		if timeUp {
			if req.Type == types.ReqTypeSimultaneous {
				l.utilLogic.SendTimeoutDataToRecv(req.CommonReq)
				l.resetTranslateTimer(req)
			}
		}
		if isStreamEOF(err) {
			l.Infof("AudioTranslate Recv EOF, messageId:%s exist: %v, timeUp:%v, err:%v, reqType: %v", req.MessageId, existData, timeUp, err, req.MessageType)
			// 分三种情况
			// 1. 未检测到音频数据，手动停止或者超时停止，直接发送未检测数据给前端
			// 2. 检测到音频数据，超时停止，直接发送检测数据但超时数据给前端
			// 3. 检测到音频数据，正常结束，发送结束数据给前端
			if req.Type == types.ReqTypeSimultaneous {
				l.utilLogic.SendEndDataToRecvWithMessageId(req.CommonReq, index)
				l.contextManager.SaveContext(req.MessageId)
				return nil
			}
			if !existData {
				l.utilLogic.SendErrDataToRecvWithMessageId(req.CommonReq, types.RespCodeUndetectedData, "Undetected wsconn")
			} else if existData && timeUp {
				l.utilLogic.SendErrDataToRecvWithMessageId(req.CommonReq, types.RespDataDetectedDataButTimeout, "Detected wsconn but timeout")
			} else {
				l.utilLogic.SendEndDataToRecvWithMessageId(req.CommonReq, index)
			}
			l.contextManager.SaveContext(req.MessageId)
			return nil
		}
		if err != nil {
			// 发送错误数据给前端
			l.utilLogic.SendErrDataToRecvWithMessageId(req.CommonReq, types.RespCodeRecvErr, "Failed to receive wsconn")
			return fmt.Errorf("audio translate recv failed: %w", err)
		}

		// 将语音翻译的结果发送给前端
		resp, exist, end := l.convertManager.ProcessStreamTaskRespData(streamRecv, req, index)
		if exist {
			existData = true
		}

		if streamRecv.TaskType == aiparameter.TaskType_TASK_TYPE_Speech_To_Text && exist {
			l.resetTranslateTimer(req)
		}
		// 如果是其他类型的任务，需要重置timer
		if streamRecv.TaskType != aiparameter.TaskType_TASK_TYPE_Speech_To_Text {
			l.resetTranslateTimer(req)
		}

		subIndex, _ := ringBuffer.GetValueByIndex(int(lastDataTypeEndCountMap[resp.Type]))
		// 子句结束 并且超过两秒 才自增 因为子句不结束有可能变化

		if resp.Type == types.TaskTypeSpeechToText {
			l.Debugf("messageId %s subIndex: %d, lastDataTypeEndCountMap: %v, resp.Type: %d, end: %v, time: %v s, lastAsrTime: %v, lastSegmentEnd: %v",
				req.MessageId, subIndex, lastDataTypeEndCountMap, resp.Type, end, time.Since(lastAsrTime).Seconds(), lastAsrTime, lastSegmentEnd)
		}
		if resp.Type == types.TaskTypeSpeechToText &&
			time.Since(lastAsrTime).Seconds() > l.svcCtx.Config.AudioTranslate.SimultaneousLineTime && lastSegmentEnd && exist {
			// 超过2s了，asr的subIndex需要自增
			subIndex++
			l.Infof("subindex added messageId %s subIndex: %d, lastDataTypeEndCountMap: %v, resp.Type: %d, end: %v, time: %v s, lastAsrTime: %v, lastSegmentEnd: %v",
				req.MessageId, subIndex, lastDataTypeEndCountMap, resp.Type, end, time.Since(lastAsrTime).Seconds(), lastAsrTime, lastSegmentEnd)
			ringBuffer.Update(int(lastDataTypeEndCountMap[resp.Type]), subIndex)
		}

		if resp.Type == types.TaskTypeSpeechToText {
			lastSegmentEnd = false
		}

		if resp.Type == types.TaskTypeSpeechToText {
			resp.SubIndex = int32(subIndex)
		} else if streamRecv.TaskType == aiparameter.TaskType_TASK_TYPE_Translate {
			resp.SubIndex = resultIndex[streamRecv.GetTranslateResp().GetSentenceId()]
		} else if streamRecv.TaskType == aiparameter.TaskType_TASK_TYPE_Text_To_Speech {
			resp.SubIndex = resultIndex[streamRecv.GetTtsResp().GetSentenceId()]
		}

		if end {
			lastDataTypeEndCountMap[resp.Type]++
			if resp.Type == types.TaskTypeSpeechToText {
				ringBuffer.Add(int(lastDataTypeEndCountMap[resp.Type]), int(resp.SubIndex))
			}
		}
		// 如果是语音识别任务类型，记录最后一次语音识别的时间戳，用于判断是否超时
		if resp.Type == types.TaskTypeSpeechToText {
			lastAsrTime = time.Now()
		}

		// 发送数据给前端
		//if resp.Type == int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech) {
		//	audioData = append(audioData, streamRecv.GetOpusWrapperResp().Audio.Data...)
		//	num++
		//	fmt.Println("resp", num, len(resp.Data))
		//}
		if end && resp.Type == types.TaskTypeSpeechToText {
			lastSegmentEnd = true
		}

		l.utilLogic.SendSuccessDataToRecv(*resp)

		if streamRecv.TaskType == aiparameter.TaskType_TASK_TYPE_Speech_To_Text {
			resultIndex[streamRecv.GetAsrResp().SegmentId] = resp.SubIndex
		}
	}
}

// 关闭
func (l *TranslateTask) Close() {
	l.StreamClose()
	if l.closeCh != nil {
		close(l.closeCh) // 确保关闭 channel
		l.closeCh = nil
	}
}

func SaveOpusFile(audioData []byte) error {
	// 设置默认文件名
	outFileName := "out_" + strconv.FormatInt(time.Now().UnixNano(), 10) + ".opus"

	// 创建文件
	file, err := os.Create(outFileName)
	if err != nil {
		return fmt.Errorf("创建文件失败: %w", err)
	}
	defer file.Close()

	// 写入数据
	_, err = file.Write(audioData)
	if err != nil {
		return fmt.Errorf("写入文件失败: %w", err)
	}
	file.Sync()

	fmt.Printf("success save opus: %s (大小: %d 字节)\n", outFileName, len(audioData))
	return nil
}

// resetReceiveTimer 有数据接收，重置定时器
func (l *TranslateTask) resetTranslateTimer(req *types.AudioTranslateReq) {
	if req.Type == types.ReqTypeAudio {
		l.timer.Reset(time.Second * time.Duration(l.svcCtx.Config.AudioTranslate.NextTimePeriod))
	} else if req.Type == types.ReqTypeSimultaneous {
		l.timer.Reset(time.Second * time.Duration(l.svcCtx.Config.AudioTranslate.SimultaneousTimePeriod))
	} else {
		l.timer.Reset(time.Minute)
	}
}
