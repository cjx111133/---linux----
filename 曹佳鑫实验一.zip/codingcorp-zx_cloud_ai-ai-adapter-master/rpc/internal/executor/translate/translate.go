package translate

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/common"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/config"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/protocol/codes"
	adaptermodel "e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/adapter/model"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/threading"
)

type TranslateExecutor struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger

	once bool
}

func NewTranslateExecutor(ctx context.Context, svcCtx *svc.ServiceContext) *TranslateExecutor {
	return &TranslateExecutor{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
		once:   true,
	}
}

func (e *TranslateExecutor) Inference(in *aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error) {
	req, err := e.buildParameter(in)
	if err != nil {
		return nil, fmt.Errorf("buildParameter failed, err: %v", err)
	}
	resp, err := e.doInference(req)
	if err != nil {
		return nil, fmt.Errorf("doInference failed, err: %v", err)
	}

	out, err := e.buildResponse(resp)
	if err != nil {
		return nil, fmt.Errorf("buildResponse failed, err: %v", err)
	}
	e.Info("TranslateExecutor Inference end")
	return out, nil
}

func (e *TranslateExecutor) StreamInference(request <-chan *aiadapterrpc.InferenceReq, response chan<- *aiadapterrpc.InferenceResp) error {
	if request == nil || response == nil {
		return fmt.Errorf("request or response channel is nil")
	}

	err := e.doStreamInference(request, response)
	if err != nil {
		return fmt.Errorf("doStreamInference failed, err: %v", err)
	}
	e.Info("TranslateExecutor StreamInference end")
	return nil
}

func (e *TranslateExecutor) receiveStream(resChan chan *adaptermodel.TranslateResp, cliResp chan<- *aiadapterrpc.InferenceResp) {
	defer close(cliResp)
	for {
		resp, ok := <-resChan
		if !ok {
			e.Infof("recv resp from llm engine end, resChan channel closed")
			return
		}
		if resp == nil {
			continue
		}
		out, err := e.buildResponse(resp)
		if err != nil {
			e.Errorf("buildResponse failed, err: %v", err)
			return
		}
		cliResp <- out
	}
}

func (e *TranslateExecutor) doStreamInference(cliReq <-chan *aiadapterrpc.InferenceReq, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	// recv first message
	req, ok := <-cliReq
	if !ok {
		e.Infof("translate doStreamInference recv first message failed, cliReq channel closed")
		return nil
	}
	if req == nil {
		e.Infof("translate doStreamInference recv first message failed, request is nil")
		return nil
	}
	r, err := e.buildParameter(req)
	if err != nil {
		return fmt.Errorf("buildParameter failed, err: %v", err)
	}
	e.Infof("doStreamInference recv llm first message, TaskId: %s, first message: %+v", r.TaskId, *r)

	ctx, cancel := context.WithTimeout(e.ctx, 7200*time.Second) // 2小时
	defer cancel()

	adapter, err := adapter.NewAdapter(ctx, e.svcCtx, r.ServiceProvider)
	if err != nil {
		return fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	llmReq := make(chan *adaptermodel.TranslateReq, 100)
	llmResp := make(chan *adaptermodel.TranslateResp, 100)
	llmReq <- r

	var wg sync.WaitGroup
	wg.Add(3)
	defer wg.Wait()

	errCh := make(chan error, 3)
	// recv message from llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.recv(ctx, llmResp, cliResp)
	})
	// send message to llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- e.send(ctx, llmReq, cliReq)
	})
	// handle message from llm engine
	threading.GoSafe(func() {
		defer wg.Done()
		errCh <- adapter.TranslateStreamHandler(llmReq, llmResp)
	})

	for i := 0; i < 3; i++ {
		if err := <-errCh; err != nil {
			cancel()
			return err
		}
	}
	return nil
}

func (e *TranslateExecutor) recv(ctx context.Context, llmResp <-chan *adaptermodel.TranslateResp, cliResp chan<- *aiadapterrpc.InferenceResp) error {
	defer close(cliResp)

	for {
		select {
		case resp, ok := <-llmResp:
			if !ok {
				e.Infof("recv resp from llm engine end, llmResp channel closed")
				return nil
			}

			if resp.SentenceEnd || resp.SentenceStart {
				e.Infof("recv resp from llm engine, text: %s, SentenceStart: %v, SentenceEnd: %v", resp.Text, resp.SentenceStart, resp.SentenceEnd)
			}

			res, err := e.buildResponse(resp)
			if err != nil {
				return fmt.Errorf("buildResponse failed, err: %v", err)
			}
			cliResp <- res
		case <-ctx.Done():
			e.Infof("recv resp from llm engine end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("recv resp from llm engine end, logic context done")
			return nil
		}
	}
}

func (e *TranslateExecutor) send(ctx context.Context,
	llmReq chan *adaptermodel.TranslateReq,
	cliReq <-chan *aiadapterrpc.InferenceReq) error {
	defer close(llmReq)

	for {
		select {
		case <-ctx.Done():
			e.Infof("send req to llm engine end, ctx done")
			return nil
		case <-e.ctx.Done():
			e.Infof("send req to llm engine end, logic context done")
			return nil
		case req, ok := <-cliReq:
			if !ok {
				e.Infof("send req to llm engine end, cliReq channel closed")
				return nil
			}
			if req == nil {
				return fmt.Errorf("send req to llm engine failed, request is nil")
			}
			r, err := e.buildParameter(req)
			if err != nil {
				e.Errorf("buildParameter failed, err: %v", err)
				return nil
			}
			e.Infof("send req to llm engine, text: %s, Role: %s, IsSentence: %v, Contexts: %+v", r.Text, r.Role, r.IsSentence, r.Contexts)

			llmReq <- r
		}
	}

}

func (e *TranslateExecutor) buildParameter(in *aiadapterrpc.InferenceReq) (*adaptermodel.TranslateReq, error) {
	if in.InferenceParameter == "" {
		return nil, fmt.Errorf("InferenceParameter is empty")
	}
	var iPara aiparameter.TranslateInferenceParameter
	err := common.JsonToAny([]byte(in.InferenceParameter), &iPara)
	if err != nil {
		return nil, fmt.Errorf("InferenceParameter JsonToAny failed, err: %v", err)
	}

	var ePara aiparameter.TranslateExtendedParameter
	var contexts []*adaptermodel.TranslateContext
	if e.once {
		e.once = false

		if in.Header.AppId == "" {
			return nil, fmt.Errorf("AppId is empty")
		}

		if in.ExtendedParameter == "" {
			return nil, fmt.Errorf("ExtendedParameter is empty")
		}
		err = common.JsonToAny([]byte(in.ExtendedParameter), &ePara)
		if err != nil {
			return nil, fmt.Errorf("ExtendedParameter JsonToAny failed, err: %v", err)
		}

		err = e.checkParameter(&iPara, &ePara)
		if err != nil {
			return nil, fmt.Errorf("checkParameter failed, err: %v", err)
		}

		if len(ePara.Contexts) > 0 {
			if len(ePara.Contexts) > 10 {
				// 只取最新的10个上下文
				ePara.Contexts = ePara.Contexts[len(ePara.Contexts)-10:]
			}
			contexts = make([]*adaptermodel.TranslateContext, 0, len(ePara.Contexts))
			for _, v := range ePara.Contexts {
				contexts = append(contexts, &adaptermodel.TranslateContext{
					Text: v.Text,
					Role: v.Role,
					Lang: v.Language,
				})
			}
		}
	}

	req := &adaptermodel.TranslateReq{
		TaskId:          in.Header.TaskId,
		AppId:           in.Header.AppId,
		Text:            iPara.Text,
		SentenceId:      iPara.SentenceId,
		LlmType:         ePara.LlmType,
		ServiceProvider: ePara.ServiceProvider,
		EnableStream:    ePara.EnableStream,
		FromLang:        ePara.FromLang,
		ToLang:          ePara.ToLang,
		Role:            ePara.Role,
		Contexts:        contexts,
		IsSentence:      iPara.IsSentence,
		LlmTypeSentence: ePara.LlmTypeSentence,
	}

	e.Logger.Infof("translate param %+v", req)
	return req, nil
}

func (e *TranslateExecutor) checkParameter(
	iPara *aiparameter.TranslateInferenceParameter,
	ePara *aiparameter.TranslateExtendedParameter) error {
	// check ePara
	if ePara.ServiceProvider != "" {
		switch strings.ToLower(ePara.ServiceProvider) {
		case config.ADAPTER_SERVICE_TYPE_ALIYUN:
			if ePara.LlmType == "" {
				ePara.LlmType = "qwen-max"
			} else if !strings.HasPrefix(ePara.LlmType, "qwen") {
				return fmt.Errorf("ExtendedParameter LlmType is invalid, ServiceProvider: %s, LlmType: %s", ePara.ServiceProvider, ePara.LlmType)
			}
			if ePara.LlmTypeSentence == "" {
				ePara.LlmTypeSentence = ePara.LlmType
			} else if !strings.HasPrefix(ePara.LlmTypeSentence, "qwen") {
				return fmt.Errorf("ExtendedParameter LlmTypeSentence is invalid, ServiceProvider: %s, LlmTypeSentence: %s", ePara.ServiceProvider, ePara.LlmTypeSentence)
			}
		case config.ADAPTER_SERVICE_TYPE_ANKER:
			if ePara.LlmType == "" {
				ePara.LlmType = "gemma2"
			}
			if ePara.LlmTypeSentence == "" {
				ePara.LlmTypeSentence = ePara.LlmType
			}
		case config.ADAPTER_SERVICE_TYPE_AZURE:
			if ePara.LlmType == "" {
				ePara.LlmType = "translate"
			} else {
				switch ePara.LlmType {
				case "translate", "gpt-4o", "gpt-4o-mini":
				default:
					return fmt.Errorf("ExtendedParameter LlmType is invalid, ServiceProvider: %s, LlmType: %s", ePara.ServiceProvider, ePara.LlmType)
				}
			}
			if ePara.LlmTypeSentence == "" {
				ePara.LlmTypeSentence = ePara.LlmType
			} else {
				switch ePara.LlmTypeSentence {
				case "translate", "gpt-4o", "gpt-4o-mini":
				default:
					return fmt.Errorf("ExtendedParameter LlmTypeSentence is invalid, ServiceProvider: %s, LlmTypeSentence: %s", ePara.ServiceProvider, ePara.LlmTypeSentence)
				}
			}
		default:
			return fmt.Errorf("ExtendedParameter ServiceProvider is invalid, ServiceProvider: %s", ePara.ServiceProvider)
		}
	} else {
		ePara.ServiceProvider = config.ADAPTER_SERVICE_TYPE_ANKER
		ePara.LlmType = "gemma2"
	}
	if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, ePara.FromLang) {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, ePara.FromLang) {
			if ePara.FromLang != "auto" {
				return fmt.Errorf("ExtendedParameter FromLang is invalid, FromLang: %s", ePara.FromLang)
			} else {
				e.Infof("ExtendedParameter FromLang is auto, FromLang: %s", ePara.FromLang)
			}
		} else {
			ePara.FromLang = common.LanguageToBcp47(ePara.FromLang)
		}
	}
	if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_BCP_47, ePara.ToLang) {
		if !common.IsExistInMap(common.SUPPORTED_LANGUAGES_ISO6391, ePara.ToLang) {
			return fmt.Errorf("ExtendedParameter ToLang is invalid, ToLang: %s", ePara.ToLang)
		} else {
			ePara.ToLang = common.LanguageToBcp47(ePara.ToLang)
		}
	}
	if ePara.Role == "" {
		return fmt.Errorf("ExtendedParameter Role is empty")
	}

	return nil
}

func (e *TranslateExecutor) doInference(req *adaptermodel.TranslateReq) (*adaptermodel.TranslateResp, error) {
	adapter, err := adapter.NewAdapter(e.ctx, e.svcCtx, req.ServiceProvider)
	if err != nil {
		return nil, fmt.Errorf("NewAdapter failed, err: %v", err)
	}

	resp, err := adapter.TranslateHandler(req)
	if err != nil {
		return nil, fmt.Errorf("TranslateHandler failed, err: %v", err)
	}
	if resp.Header.Code != codes.CodeOk {
		return nil, fmt.Errorf("TranslateHandler failed, code: %d, message: %s", resp.Header.Code, resp.Header.Message)
	}
	if resp.Text == "" {
		return nil, fmt.Errorf("TranslateHandler failed, text is empty")
	}
	return resp, nil
}

func (e *TranslateExecutor) buildResponse(resp *adaptermodel.TranslateResp) (*aiadapterrpc.InferenceResp, error) {
	resultInfo := &aiparameter.InferenceResultInfo{
		TaskType: aiparameter.TaskType_TASK_TYPE_Translate,
		InferenceResultInfo: &aiparameter.InferenceResultInfo_Translate{
			Translate: &aiparameter.TranslateInferenceResultInfo{
				Text:          resp.Text,
				SentenceId:    resp.SentenceId,
				Language:      resp.Language,
				SentenceStart: resp.SentenceStart,
				SentenceEnd:   resp.SentenceEnd,
				Timestamp:     time.Now().UnixMilli(),
			},
		},
	}
	info, err := common.AnyToJson(resultInfo)
	if err != nil {
		return nil, fmt.Errorf("InferenceResultInfo AnyToJson failed, err: %v", err)
	}

	return &aiadapterrpc.InferenceResp{
		Header:              resp.Header,
		InferenceResultInfo: string(info),
		TimeTakenMs:         resp.TimeTakenMs,
	}, nil
}
