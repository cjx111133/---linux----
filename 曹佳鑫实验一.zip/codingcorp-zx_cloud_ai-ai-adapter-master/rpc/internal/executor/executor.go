package executor

import (
	"context"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/embroidery"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/fasttranscribe"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/textsummary"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aiadapterrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/comfyuistyletransfer"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/depthmapgeneration"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/dify"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/faceswap"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/imagetovector"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/imageupscale"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/instantstyle"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/instantstyleplus"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/languagedetect"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/magiceraser"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/opuswrapper"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/petportrait"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/popart"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/removebackground"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/speechtotext"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/styletransfer"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/texttoimagedesign"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/texttospeech"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/translate"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/executor/translatequestionrecommend"
	"e.coding.anker-in.com/codingcorp/zx_cloud_ai/ai-adapter/rpc/internal/svc"
)

type Executor interface {
	Inference(*aiadapterrpc.InferenceReq) (*aiadapterrpc.InferenceResp, error)
	StreamInference(<-chan *aiadapterrpc.InferenceReq, chan<- *aiadapterrpc.InferenceResp) error
}

func NewExecutor(ctx context.Context, svcCtx *svc.ServiceContext, taskType aiparameter.TaskType) (Executor, error) {
	switch taskType {
	case aiparameter.TaskType_TASK_TYPE_Image_Upscale:
		return imageupscale.NewImageUpscaleExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Remove_Background:
		return removebackground.NewRemoveBackgroundExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Image_To_Vector:
		return imagetovector.NewImageToVectorExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Text_To_Image_Design:
		return texttoimagedesign.NewTextToImageDesignExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Style_Transfer,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer1,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer2,
		aiparameter.TaskType_TASK_TYPE_Style_Transfer3:
		return styletransfer.NewStyleTransferExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Pop_Art:
		return popart.NewPopArtExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Pet_Portrait:
		return petportrait.NewPetPortraitExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Face_Swap:
		return faceswap.NewFaceSwapExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Speech_To_Text:
		return speechtotext.NewSpeechToTextExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Text_To_Speech:
		return texttospeech.NewTextToSpeechExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Translate:
		return translate.NewTranslateExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Magic_Eraser:
		return magiceraser.NewMagicEraserExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Instant_Style:
		return instantstyle.NewInstantStyleExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Instant_Style_Plus:
		return instantstyleplus.NewInstantStylePlusExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Depth_Map_Generation:
		return depthmapgeneration.NewDepthMapGenerationExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Dify_Workflow:
		return dify.NewDifyWorkflowExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Dify_Chatflow:
		return dify.NewDifyChatflowExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Language_Detect:
		return languagedetect.NewLanguageDetectExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer,
		aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer1,
		aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer2,
		aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer3,
		aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer4,
		aiparameter.TaskType_TASK_TYPE_Comfyui_StyleTransfer5:
		return comfyuistyletransfer.NewStyleTransferComfyUiExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Opus_Wrapper:
		return opuswrapper.NewOpusWrapperExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Translate_Question_Recommend:
		return translatequestionrecommend.NewTranslateQuestionRecommendExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Extract_Text_Summary:
		return textsummary.NewTextSummaryExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Audio_Fast_Transcription:
		return fasttranscribe.NewFastTranscribeExecutor(ctx, svcCtx), nil
	case aiparameter.TaskType_TASK_TYPE_Embroidery_StyleTransfer:
		return embroidery.NewStyleTransferEmbroideryExecutor(ctx, svcCtx), nil
	}
	return nil, fmt.Errorf("task type %v not support", taskType.String())
}
