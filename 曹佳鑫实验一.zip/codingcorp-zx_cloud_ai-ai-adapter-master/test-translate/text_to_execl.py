import pandas as pd

# 定义输入TXT文件路径和输出Excel文件路径
txt_file = "data/text/translate.txt"  # 替换为你的TXT文件路径
excel_file = "data/text/translate.xlsx"  # 输出的Excel文件路径

# 读取TXT文件并解析内容
data = []
with open(txt_file, "r", encoding="utf-8") as file:
    record = {}
    for line in file:
        line = line.strip()
        if line:  # 如果行不为空
            print(f"Processing line: {line}")  # 调试信息
            key, value = line.split(": ", 1)
            record[key] = value
        else:  # 如果遇到空行，表示一个记录结束
            if record:
                data.append(record)
                record = {}
    if record:  # 添加最后一条记录（如果文件末尾没有空行）
        data.append(record)

# 将数据转换为DataFrame
df = pd.DataFrame(data)

# 将DataFrame保存为Excel文件
df.to_excel(excel_file, index=False, engine="openpyxl")

print(f"TXT文件已成功转换为Excel文件，保存路径为：{excel_file}")
