package common

import (
	"context"
	"fmt"
	"github.com/go-resty/resty/v2"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"path"
	"strings"
	"time"
)

var restyCli = resty.New().SetTimeout(time.Minute)

// DownloadSingleFile 下载文件到指定路径
func DownloadSingleFile(ctx context.Context, url, destPath string) error {
	resp, err := restyCli.R().
		SetContext(ctx).
		SetDoNotParseResponse(true).
		Get(url)
	if err != nil {
		return fmt.Errorf("download error: %v", err)
	}
	defer resp.RawBody().Close()

	if resp.StatusCode() != http.StatusOK {
		return fmt.Errorf("bad response: %d", resp.StatusCode())
	}

	file, err := os.Create(destPath)
	if err != nil {
		return fmt.Errorf("create file error: %v", err)
	}
	defer file.Close()

	if _, err = io.Copy(file, resp.RawBody()); err != nil {
		return fmt.Errorf("write file error: %v", err)
	}

	return nil
}

// UploadFileFromPath 上传文件到指定的URL
func UploadFileFromPath(ctx context.Context, url, filePath string) error {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("failed to read file %q: %w", filePath, err)
	}

	contentType := mime.TypeByExtension(path.Ext(filePath))

	resp, err := restyCli.R().
		SetContext(ctx).
		SetHeader("Content-Type", contentType).
		SetBody(data).
		Put(url)

	if err != nil {
		return fmt.Errorf("upload error: %v", err)
	}

	if resp.StatusCode() != http.StatusOK {
		return fmt.Errorf("bad response: %d", resp.StatusCode())
	}

	return nil
}

// GetFileNameFromUrl 从URL中提取文件名
func GetFileNameFromUrl(u string) string {
	parsedURL, err := url.Parse(u)
	if err != nil {
		return ""
	}
	segments := strings.Split(parsedURL.Path, "/")
	return segments[len(segments)-1]
}
