package chat

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_findBreakableText(t *testing.T) {
	tests := []struct {
		name          string
		processedText string
		fullText      string
		sentenceEnd   bool
		want          string
	}{
		{
			name:          "已处理为空，完整文本有断句符号",
			processedText: "",
			fullText:      "今天天气很好，阳光明媚。",
			sentenceEnd:   false,
			want:          "今天天气很好，阳光明媚。",
		},
		{
			name:          "已处理部分文本，完整文本有新断句符号",
			processedText: "今天天气很好，",
			fullText:      "今天天气很好，阳光明媚。我想去公园。",
			sentenceEnd:   false,
			want:          "阳光明媚。我想去公园。",
		},
		{
			name:          "有多个断句符号时取最后一个",
			processedText: "",
			fullText:      "早上好，今天天气不错。希望大家有个好心情！",
			sentenceEnd:   false,
			want:          "早上好，今天天气不错。希望大家有个好心情！",
		},
		{
			name:          "英文断句符号测试",
			processedText: "",
			fullText:      "Hello, world! How are you today?",
			sentenceEnd:   false,
			want:          "Hello, world! How are you today?",
		},
		{
			name:          "混合中英文断句符号",
			processedText: "Hello, ",
			fullText:      "Hello, 你好！Welcome to China.",
			sentenceEnd:   false,
			want:          "你好！Welcome to China.",
		},
		{
			name:          "无新增断句符号",
			processedText: "今天天气很好",
			fullText:      "今天天气很好阳光明媚",
			sentenceEnd:   false,
			want:          "",
		},
		{
			name:          "无新增断句符号但是标记为句尾",
			processedText: "今天天气很好",
			fullText:      "今天天气很好阳光明媚",
			sentenceEnd:   true,
			want:          "阳光明媚",
		},
		{
			name:          "完整文本短于已处理文本",
			processedText: "今天天气很好，阳光明媚。",
			fullText:      "今天",
			sentenceEnd:   false,
			want:          "",
		},
		{
			name:          "完整文本等于已处理文本",
			processedText: "今天天气很好。",
			fullText:      "今天天气很好。",
			sentenceEnd:   false,
			want:          "",
		},
		{
			name:          "连续多个断句符号",
			processedText: "",
			fullText:      "你好，世界！！！欢迎。",
			sentenceEnd:   false,
			want:          "你好，世界！！！欢迎。",
		},
		{
			name:          "断句符号在开头",
			processedText: "",
			fullText:      "，你好世界",
			sentenceEnd:   false,
			want:          "，",
		},
		{
			name:          "断句符号在结尾",
			processedText: "",
			fullText:      "你好世界。",
			sentenceEnd:   false,
			want:          "你好世界。",
		},
		{
			name:          "已处理文本包含部分断句符号",
			processedText: "你好，",
			fullText:      "你好，世界。",
			sentenceEnd:   false,
			want:          "世界。",
		},
		{
			name:          "处理未发现断句但有空格的情况",
			processedText: "",
			fullText:      "这是一个 没有断句符号的句子",
			sentenceEnd:   false,
			want:          "",
		},
		{
			name:          "处理未发现断句但有空格的情况且标记为句尾",
			processedText: "",
			fullText:      "这是一个 没有断句符号的句子",
			sentenceEnd:   true,
			want:          "这是一个 没有断句符号的句子",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := findBreakableText(tt.processedText, tt.fullText, tt.sentenceEnd)
			assert.Equal(t, tt.want, got, "findBreakableText(%q, %q, %v) = %q, want %q",
				tt.processedText, tt.fullText, tt.sentenceEnd, got, tt.want)
		})
	}
}

// 测试一个更复杂的实际场景，模拟流式输出断句
func Test_findBreakableText_RealScenario(t *testing.T) {
	// 模拟LLM流式输出的情况
	streams := []string{
		"今",
		"今天",
		"今天天",
		"今天天气",
		"今天天气怎",
		"今天天气怎么",
		"今天天气怎么样",
		"今天天气怎么样？",
		"今天天气怎么样？今",
		"今天天气怎么样？今天",
		"今天天气怎么样？今天天",
		"今天天气怎么样？今天天气",
		"今天天气怎么样？今天天气晴",
		"今天天气怎么样？今天天气晴朗",
		"今天天气怎么样？今天天气晴朗，",
		"今天天气怎么样？今天天气晴朗，阳",
		"今天天气怎么样？今天天气晴朗，阳光",
		"今天天气怎么样？今天天气晴朗，阳光明",
		"今天天气怎么样？今天天气晴朗，阳光明媚",
		"今天天气怎么样？今天天气晴朗，阳光明媚。",
	}

	var processedText string
	var expectedOutputs = []string{
		"",         // 流1：今
		"",         // 流2：今天
		"",         // 流3：今天天
		"",         // 流4：今天天气
		"",         // 流5：今天天气怎
		"",         // 流6：今天天气怎么
		"",         // 流7：今天天气怎么样
		"今天天气怎么样？", // 流8：今天天气怎么样？
		"",         // 流9：今天天气怎么样？今
		"",         // 流10：今天天气怎么样？今天
		"",         // 流11：今天天气怎么样？今天天
		"",         // 流12：今天天气怎么样？今天天气
		"",         // 流13：今天天气怎么样？今天天气晴
		"",         // 流14：今天天气怎么样？今天天气晴朗
		"今天天气晴朗，",  // 流15：今天天气怎么样？今天天气晴朗，
		"",         // 流16：今天天气怎么样？今天天气晴朗，阳
		"",         // 流17：今天天气怎么样？今天天气晴朗，阳光
		"",         // 流18：今天天气怎么样？今天天气晴朗，阳光明
		"",         // 流19：今天天气怎么样？今天天气晴朗，阳光明媚
		"阳光明媚。",    // 流20：今天天气怎么样？今天天气晴朗，阳光明媚。
	}

	// 每一步sentence_end设为false，只有最后一步设为true
	sentenceEnds := make([]bool, len(streams))
	sentenceEnds[len(streams)-1] = true

	for i, stream := range streams {
		result := findBreakableText(processedText, stream, sentenceEnds[i])

		// 验证结果是否符合预期
		assert.Equal(t, expectedOutputs[i], result, "步骤 %d: 预期: %q, 得到: %q", i+1, expectedOutputs[i], result)

		// 更新已处理文本
		if result != "" {
			processedText += result
		}
	}

	// 最终验证处理完所有流后的结果
	assert.Equal(t, "今天天气怎么样？今天天气晴朗，阳光明媚。", processedText, "处理后的完整文本应该匹配")
}
