package chat

import (
	"encoding/json"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/logic/common"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpcclient"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aicommon"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
)

const (
	// 音频参数常量
	DefaultSampleRate  = 16000 // 默认采样率
	DefaultBitRate     = 32000 // 默认比特率
	DefaultChannels    = 1     // 默认声道数
	DefaultFrameSizeMs = 60    // 默认帧大小(ms)
)

// ChatPacketInterface defines the interface for chat convert handling
type ChatPacketInterface interface {
	// Send handles sending chat messages
	Send(req *types.ChatReq) error
	// CreateAloneStreamTaskReq creates a standalone stream task request
	CreateAloneStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq
	// CreateFirstStreamTaskReq creates the first stream task request
	CreateFirstStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq
	// CreateMiddleStreamTaskReq creates a middle stream task request
	CreateMiddleStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq
	// SendAlone sends standalone convert data
	SendAlone(req *types.ChatReq) error
	// SendFirst sends first convert data
	SendFirst(req *types.ChatReq) error
	// SendMiddle sends middle convert data
	SendMiddle(req *types.ChatReq) error
	// GetContext gets the context for the request
	GetContext(req *types.ChatReq) []*types.TranslateContext
}

// AnswerPacket implements ChatPacketInterface
type AnswerPacket struct {
	task *BaseChatTask
}

func NewAnswerPacket(task *BaseChatTask) *AnswerPacket {
	return &AnswerPacket{
		task: task,
	}
}

// Send handles sending chat messages
func (p *AnswerPacket) Send(req *types.ChatReq) error {
	switch req.ReqStatus {
	case types.ReqStatusAlone:
		err := p.SendAlone(req)
		if err != nil {
			return err
		}
	case types.ReqStatusFirst:
		err := p.SendFirst(req)
		if err != nil {
			return err
		}
		p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
	case types.ReqStatusMiddle:
		err := p.SendMiddle(req)
		if err != nil {
			return err
		}
	case types.ReqStatusEnd:
		p.task.Infof("Chat CloseSend")
		p.task.stream.CloseSend()
	case types.ReqStatusStop:
		p.task.Infof("Chat Stop")
		select {
		case <-p.task.stopChan:
			p.task.Infof("Chat Stop: stopChan already closed")
		default:
			close(p.task.stopChan)
		}
	}

	return nil
}

// CreateAloneStreamTaskReq creates a standalone stream task request
func (p *AnswerPacket) CreateAloneStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}
	contexts := p.GetContext(req)
	chatflowParam := config.NewDefaultDifyChatFlowParams(contexts)
	chatflowParam.Set(common.InterfaceToString(req.Params["house_id"]), common.InterfaceToString(req.Params["language"]), common.InterfaceToString(req.Params["timezone"]))
	if req.Type == types.MessageTypeTTS {
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Text_To_Speech
		streamReq.Data = &aimanagerrpc.StreamTaskReq_TtsReq{
			TtsReq: &aiparameter.TextToSpeechInferenceParameter{
				Text:       "",
				SentenceId: 1,
			},
		}
		streamReq.Workflow = append(streamReq.Workflow, []*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech), IsNeedResult: false, Parameters: p.task.svcCtx.Config.Chat.TextToSpeechParam.String(types.AudioFormatPcm, DefaultSampleRate, DefaultBitRate, DefaultChannels, req.SourceLanguage)},
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper), IsNeedResult: true, Parameters: fmt.Sprintf(
				`{"service_provider": "anker", "target": {"sample_rate": %d, "bit_rate": %d, "channels": %d, "format": "%s", "language": "%s", "frame_size_ms": 60}}`,
				DefaultSampleRate, DefaultBitRate, DefaultChannels, types.AudioFormatOpus, req.SourceLanguage),
			},
		}...)
		return streamReq
	}
	switch req.MessageType {
	case types.MessageTypePreset: // 预设问题
		chatflowParam.NeedReply = false
	case types.MessageTypeSimilar: // 相似问题
		chatflowParam.NeedReply = false
	case types.MessageTypeCustomer: // 客户信息
		chatflowParam.NeedQuestion = false
	}

	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
	streamReq.Workflow = []*aimanagerrpcclient.Node{
		{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Dify_Chatflow), IsNeedResult: true, Parameters: chatflowParam.String()},
	}

	return streamReq
}

func (l *AnswerPacket) getChatflowParam(req *types.ChatReq) *config.DifyChatflowParam {
	chatflowParam := config.NewDefaultDifyChatFlowParams(l.GetContext(req))
	switch l.task.wsData.ConnectionInfo.AppId {
	case types.Soundcore_APPID:
		chatflowParam.ChatflowName = types.ChatflowNameSoundcore
		chatflowParam.NeedReply = true
		chatflowParam.NeedEmotion = false
		chatflowParam.NeedQuestion = false
	case types.HEARD_AID_APPID:
		chatflowParam.ChatflowName = types.ChatflowNameAID
		chatflowParam.NeedEmotion = false
		chatflowParam.NeedQuestion = false
		chatflowParam.NeedReply = true
	case types.DIFM_APP:
		chatflowParam.ChatflowName = types.ChatflowNameDIFM
	default:
		chatflowParam.ChatflowName = types.ChatflowNameT9000
	}
	chatflowParam.Set(common.InterfaceToString(req.Params["house_id"]), common.InterfaceToString(req.Params["language"]), common.InterfaceToString(req.Params["timezone"]))
	for key, value := range req.Params {
		chatflowParam.Params[key] = common.InterfaceToString(value)
	}
	// Set the contexts
	contexts := make([]*types.TranslateContext, 0)
	for _, context := range req.ChatContext {
		contexts = append(contexts, &types.TranslateContext{
			Role: context.Role,
			Text: context.Text,
		})
	}
	chatflowParam.Contexts = contexts
	return chatflowParam
}

// CreateFirstStreamTaskReq creates the first stream task request
func (p *AnswerPacket) CreateFirstStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}

	chatflowParam := p.getChatflowParam(req)
	switch req.Type {
	case types.ReqTypeAudio:
		if req.Format == types.AudioFormatOpus {
			p.setupOpusWrapper(req, streamReq)
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Format:     req.Format,
						SampleRate: req.SampleRate,
						BitRate:    DefaultBitRate,
						Channels:   req.Channels,
						Language:   req.SourceLanguage,
					}},
			}
		}
		streamReq.Workflow = append(streamReq.Workflow,
			[]*aimanagerrpcclient.Node{
				{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text), IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.SpeechToTextParam.String(req.SourceLanguage, false)},
				{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Dify_Chatflow), IsNeedResult: true, Parameters: chatflowParam.String()},
				// 加入tts节点
				{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech), IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.TextToSpeechParam.String(types.AudioFormatPcm, req.SampleRate, DefaultBitRate, req.Channels, req.SourceLanguage)},
			}...)
		if req.Format == types.AudioFormatOpus {
			// 这里改成最后一个节点的needresult为false
			streamReq.Workflow[len(streamReq.Workflow)-1].IsNeedResult = false
			encodeParams := fmt.Sprintf(`{
				   "service_provider": "anker",
				   "target": {
					   "sample_rate": %d,
					   "bit_rate": %d,
					   "channels": %d,
					   "format": "%s",
					   "frame_size_ms": %d
				   }
				}`, DefaultSampleRate, DefaultBitRate, DefaultChannels, types.AudioFormatOpus, req.FrameSizeMs)

			streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
				TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
				IsNeedResult: true,
				Parameters:   encodeParams,
			})
		}

	case types.ReqTypeText:
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
		streamReq.Workflow = []*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Dify_Chatflow), IsNeedResult: true, Parameters: chatflowParam.String()},
		}
		if p.task.wsData.ConnectionInfo.AppId == types.Soundcore_APPID {
			ttsFormat := req.Format
			if req.Format == types.AudioFormatOpus {
				ttsFormat = types.AudioFormatPcm // TTS 生成 PCM 再进行编码
			}

			// 添加文本转语音节点
			ttsData := &aimanagerrpcclient.Node{
				TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech),
				IsNeedResult: true,
				Parameters: p.task.svcCtx.Config.AudioTranslate.TextToSpeechParam.String(
					ttsFormat, DefaultSampleRate, DefaultBitRate,
					DefaultChannels, req.SourceLanguage),
			}
			if req.Format == types.AudioFormatOpus {
				ttsData.IsNeedResult = false
			}
			streamReq.Workflow = append(streamReq.Workflow, ttsData)

			// 如果需要返回 OPUS 格式，添加编码节点
			if req.Format == types.AudioFormatOpus {
				encodeParams := fmt.Sprintf(`{
				   "service_provider": "anker",
				   "target": {
					   "sample_rate": %d,
					   "bit_rate": %d,
					   "channels": %d,
					   "format": "%s",
					   "frame_size_ms": %d
				   }
				}`, DefaultSampleRate, DefaultBitRate, DefaultChannels, types.AudioFormatOpus, DefaultFrameSizeMs)

				streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
					TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
					IsNeedResult: true,
					Parameters:   encodeParams,
				})
			}
		}
	case types.ReqTypeSimultaneous:
		//if p.task.wsData.ConnectionInfo.AppId == types.Soundcore_APPID {
		//	p.setupOpusWrapper(req, streamReq)
		//	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		//		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text),
		//		IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.SpeechToTextParam.String(req.SourceLanguage, modelName)})
		//	return streamReq
		//}
		if req.Format == types.AudioFormatOpus {
			p.setupOpusWrapper(req, streamReq)
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Format:     req.Format,
						SampleRate: req.SampleRate,
						BitRate:    DefaultBitRate,
						Channels:   req.Channels,
						Language:   req.SourceLanguage,
					}},
			}
		}

		streamReq.Workflow = []*aimanagerrpcclient.Node{
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Speech_To_Text), IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.SpeechToTextParam.String(req.SourceLanguage, false)},
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Dify_Chatflow), IsNeedResult: true, Parameters: chatflowParam.String()},
			{TaskType: int32(aiparameter.TaskType_TASK_TYPE_Text_To_Speech), IsNeedResult: true, Parameters: p.task.svcCtx.Config.Chat.TextToSpeechParam.String(req.Format, req.SampleRate, DefaultBitRate, req.Channels, req.SourceLanguage)},
		}
	}

	return streamReq
}

func getAudioString(audio *aicommon.AudioInfo) string {
	return fmt.Sprintf(
		`{"service_provider": "anker", "target": {"sample_rate": %d, "bit_rate": %d, "channels": %d, "format": "%s", "language": "%s", "frame_size_ms": 60}}`,
		audio.SampleRate, audio.BitRate, audio.Channels, audio.Format, audio.Language)
}

func (p *AnswerPacket) setupOpusWrapper(req *types.ChatReq, streamReq *aimanagerrpcclient.StreamTaskReq) {
	var targetAudio = &aicommon.AudioInfo{
		Format:      types.AudioFormatPcm,
		SampleRate:  req.SampleRate,
		BitRate:     DefaultBitRate,
		Channels:    1,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}
	var sourceAudio = &aicommon.AudioInfo{
		Format:      req.Format,
		SampleRate:  req.SampleRate,
		BitRate:     DefaultBitRate,
		Channels:    req.Channels,
		FrameSizeMs: req.FrameSizeMs,
		Language:    req.SourceLanguage,
	}

	streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
	streamReq.Workflow = append(streamReq.Workflow, &aimanagerrpcclient.Node{
		TaskType:     int32(aiparameter.TaskType_TASK_TYPE_Opus_Wrapper),
		IsNeedResult: false,
		Parameters:   getAudioString(targetAudio),
	})
	streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
		OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
			Source:      sourceAudio,
			IsEnableEnc: true,
		},
	}
}

// CreateMiddleStreamTaskReq creates a middle stream task request
func (p *AnswerPacket) CreateMiddleStreamTaskReq(req *types.ChatReq) *aimanagerrpcclient.StreamTaskReq {
	// 发送识别请求
	streamReq := &aimanagerrpcclient.StreamTaskReq{
		Header: &aicommon.ReqHeader{
			TaskId: p.task.wsData.ConnectionInfo.SessionId + "-" + req.MessageId,
			UserId: p.task.wsData.ConnectionInfo.UserId,
			AppId:  p.task.wsData.ConnectionInfo.AppId,
		},
	}
	switch req.Type {
	case types.ReqTypeAudio:
		if req.Format == types.AudioFormatOpus {
			//if true {
			isEnableEnc := false
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Opus_Wrapper
			streamReq.Data = &aimanagerrpc.StreamTaskReq_OpusWrapperReq{
				OpusWrapperReq: &aiparameter.OpusWrapperInferenceParameter{
					Source: &aicommon.AudioInfo{
						Data:        []byte(req.Data),
						SampleRate:  req.SampleRate,
						BitRate:     DefaultBitRate,
						Channels:    req.Channels,
						FrameSizeMs: DefaultFrameSizeMs,
						Language:    req.SourceLanguage,
						Format:      types.AudioFormatOpus,
					},
					IsEnableEnc: isEnableEnc,
				},
			}
		} else {
			streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
			streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
				AsrReq: &aiparameter.SpeechToTextInferenceParameter{
					Audio: &aicommon.AudioInfo{
						Data: []byte(req.Data),
					}},
			}
		}
		//streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
		//streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
		//	AsrReq: &aiparameter.SpeechToTextInferenceParameter{
		//		Audio: &aicommon.AudioInfo{
		//			Data: []byte(req.Data),
		//		}},
		//}
	case types.ReqTypeText:
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Dify_Chatflow
		streamReq.Data = &aimanagerrpc.StreamTaskReq_ChatflowReq{
			ChatflowReq: &aiparameter.DifyChatflowInferenceParameter{
				Text: req.Data,
			},
		}
	case types.ReqTypeSimultaneous:
		streamReq.TaskType = aiparameter.TaskType_TASK_TYPE_Speech_To_Text
		streamReq.Data = &aimanagerrpc.StreamTaskReq_AsrReq{
			AsrReq: &aiparameter.SpeechToTextInferenceParameter{
				Audio: &aicommon.AudioInfo{
					Data: []byte(req.Data),
				},
			},
		}
	}

	return streamReq
}

// SendAlone sends standalone convert data
func (p *AnswerPacket) SendAlone(req *types.ChatReq) error {
	// 1. 无需创建连接的场景
	if !p.task.isCreateGrpcConn(req) {
		switch req.MessageType {
		case types.MessageTypePreset:
			p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)
			p.task.utilLogic.SendPresetDataToRecv(req.CommonReq)
			p.task.utilLogic.SendEndDataToRecv(req.CommonReq, 2)
		}
		return nil
	}

	// 2. 创建连接的场景
	streamReq := p.CreateAloneStreamTaskReq(req)
	//p.task.Infof("Chat SendAlone Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	p.task.utilLogic.SendFirstDataToRecv(req.CommonReq)

	streamReq.Workflow = nil
	if req.Type == types.MessageTypeTTS {
		streamReq.Data = &aimanagerrpc.StreamTaskReq_TtsReq{
			TtsReq: &aiparameter.TextToSpeechInferenceParameter{
				Text:       req.Data,
				SentenceId: 1,
			},
		}
		if err := p.task.stream.Send(streamReq); err != nil {
			p.task.Errorf("Chat Send failed, err: %v", err)
			p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
			return err
		}
		p.task.stream.CloseSend()
		return nil
	}
	var data string
	switch req.MessageType {
	case types.MessageTypeSimilar:
		data = fmt.Sprintf(`{"pn":"%s","sn":"%s"}`, req.Params["pn"], req.Params["sn"])
	case types.MessageTypeCustomer:
		data = fmt.Sprintf(`Obtain information about artificial customer service`)
	case types.MessageTypeSafetyDaily:
		data = fmt.Sprintf(`Obtain daily security reports`)
	}
	if len(data) > 0 {
		streamReq.Data = &aimanagerrpc.StreamTaskReq_ChatflowReq{
			ChatflowReq: &aiparameter.DifyChatflowInferenceParameter{
				Text: data,
			},
		}
		if err := p.task.stream.Send(streamReq); err != nil {
			p.task.Errorf("Chat Send failed, err: %v", err)
			p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
			return err
		}
	}
	return nil
}

// SendFirst sends first convert data
func (p *AnswerPacket) SendFirst(req *types.ChatReq) error {
	streamReq := p.CreateFirstStreamTaskReq(req)
	p.task.Infof("Chat first Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// SendMiddle sends middle convert data
func (p *AnswerPacket) SendMiddle(req *types.ChatReq) error {
	streamReq := p.CreateMiddleStreamTaskReq(req)
	//p.task.Infof("Chat middle Send: %+v", streamReq)
	if p.task.isCloseSend.Load() {
		return nil
	}
	if err := p.task.stream.Send(streamReq); err != nil {
		p.task.Errorf("Chat Send failed, err: %v", err)
		p.task.utilLogic.SendErrDataToRecv(req.CommonReq, types.RespCodeSendErr, "Failed to Send data")
		return err
	}
	return nil
}

// GetContext gets the context for the request
func (p *AnswerPacket) GetContext(req *types.ChatReq) []*types.TranslateContext {
	if len(req.Data) == 0 {
		return nil
	}

	chatContexts := make([]*types.ChatContext, 0)
	err := json.Unmarshal([]byte(req.Data), &chatContexts)
	if err != nil {
		p.task.Errorf("Chat Unmarshal failed, err: %v", err)
		return nil
	}

	resultContexts := make([]*types.TranslateContext, 0)
	for _, chatContext := range chatContexts {
		resultContexts = append(resultContexts, &types.TranslateContext{
			Role: "user",
			Text: chatContext.User,
		}, &types.TranslateContext{
			Role: "model",
			Text: chatContext.Assistant,
		})
	}

	return resultContexts
}
