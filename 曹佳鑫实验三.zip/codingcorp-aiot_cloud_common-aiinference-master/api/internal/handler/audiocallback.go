package handler

import (
	"context"
	"encoding/json"
	"fmt"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/channel"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/config"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/svc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/kit/queue/kq"
	"github.com/pkg/errors"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/service"
)

// RegisterService 返回所有消费者服务
func RegisterService(c config.Config, svcCtx *svc.ServiceContext) []service.Service {
	var services []service.Service

	// kafka .
	services = append(services, NewAiKafka(c, svcCtx)...)

	return services

}

// kafka 消费者服务
func NewAiKafka(c config.Config, svcCtx *svc.ServiceContext) []service.Service {
	services := make([]service.Service, 0)
	for k, v := range c.AiKafka {
		logic := NewFactoryDeviceLogic(context.Background(), svcCtx, k)
		services = append(services, kq.MustNewQueue(v, logic))
	}
	return services
}

type AudioCallBackLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
	AppId  string
}

// start_ai_generated
// NewFactoryDeviceLogic 初始化消息队列消费者处理工厂上报的设备信息
func NewFactoryDeviceLogic(ctx context.Context, svcCtx *svc.ServiceContext, appId string) *AudioCallBackLogic {
	return &AudioCallBackLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
		AppId:  appId,
	}
}

func (l *AudioCallBackLogic) Consume(key string, value string) error {
	return nil
	msg, err := parseMessage(value)
	if err != nil {
		return fmt.Errorf("parse message failed: %w", err)
	}
	l.Logger.Infof("audio callback consume key:%s msgId:%s", key, msg.MsgID)
	// 后续处理逻辑...
	channel.WsManager.GetClients("audio", "abc")
	return nil
}

func parseMessage(value string) (*types.KafkaMessage, error) {
	var msg types.KafkaMessage
	if err := json.Unmarshal([]byte(value), &msg); err != nil {
		return nil, fmt.Errorf("json unmarshal error: %w", err)
	}

	// 设置msgId默认值
	if msg.MsgID == "" {
		msg.MsgID = types.CmdTranslate
	}

	// 验证必填字段
	if msg.Timestamp == 0 {
		return nil, errors.New("timestamp is required")
	}
	if msg.MsgType == "" {
		return nil, errors.New("msgType is required")
	}
	if len(msg.Data) == 0 {
		return nil, errors.New("data is required")
	}

	// 验证msgId合法值
	validMsgIDs := map[string]struct{}{
		types.CmdTranslate: {},
		types.CmdChat:      {},
		types.CmdPing:      {},
	}
	if _, valid := validMsgIDs[msg.MsgID]; !valid {
		return nil, fmt.Errorf("invalid msgId: %s", msg.MsgID)
	}

	return &msg, nil
}
