package audio

import (
	"sync/atomic"
	"time"

	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/aiinference/api/internal/types"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/aimanagerrpc"
	"e.coding.anker-in.com/codingcorp/aiot_cloud_common/idl/makeitrealcommon/aiparameter"
	"go.uber.org/zap"
)

// AITaskInterface defines the common interface for all AI tasks
type AITaskInterface interface {
	// Process handles the main task processing
	Process(req *types.AudioTranslateReq) error
	// ProcessTimer handles the timing for task processing
	ProcessTimer(req *types.AudioTranslateReq) error
	// ProcessReceive handles receiving task results
	ProcessReceive(req *types.AudioTranslateReq)
	// StreamClose closes the task stream
	StreamClose()
	// IsStreamClosed checks if the stream is closed
	IsStreamClosed() bool
	// GetStream returns the current stream
	GetStream() aimanagerrpc.AiManagerRpc_CreateStreamTaskClient
	// GetWorkFlow returns the current workflow type
	GetWorkFlow() aiparameter.TaskType
	// GetPacketLogic returns the packet logic handler
	GetPacketLogic() *AudioTranslatePacketLogic
}

// BaseAITask provides common fields and methods for AI tasks
type BaseAITask struct {
	*AudioMessage
	stream      aimanagerrpc.AiManagerRpc_CreateStreamTaskClient
	isCloseSend atomic.Bool
	timer       *time.Ticker
	isTimeUp    atomic.Bool
	closeCh     chan struct{}
	audioIndex  int
	packetLogic *AudioTranslatePacketLogic
}

// NewBaseAITask creates a new base AI task
func NewBaseAITask(message *AudioMessage) *BaseAITask {
	task := &BaseAITask{
		AudioMessage: message,
		closeCh:      make(chan struct{}),
	}
	task.packetLogic = NewAudioTranslatePacketLogic(task)
	return task
}

// IsStreamClosed implements AITaskInterface
func (b *BaseAITask) IsStreamClosed() bool {
	return b.isCloseSend.Load()
}

// GetStream implements AITaskInterface
func (b *BaseAITask) GetStream() aimanagerrpc.AiManagerRpc_CreateStreamTaskClient {
	return b.stream
}

// GetWorkFlow implements AITaskInterface
func (b *BaseAITask) GetWorkFlow() aiparameter.TaskType {
	return b.workFlow
}

// GetPacketLogic implements AITaskInterface
func (b *BaseAITask) GetPacketLogic() *AudioTranslatePacketLogic {
	return b.packetLogic
}

// StreamClose implements AITaskInterface
func (b *BaseAITask) StreamClose() {
	if b.stream != nil {
		err := b.stream.CloseSend()
		if err != nil {
			b.Logger.Error("Stream CloseSend failed", zap.Error(err))
		}
	}
	b.isCloseSend.Store(true)
}
