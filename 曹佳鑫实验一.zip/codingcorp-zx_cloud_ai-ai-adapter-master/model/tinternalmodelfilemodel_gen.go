package model

import (
	"context"
	"database/sql"
	"errors"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/cache"
	"gorm.io/gorm"
)

type (
	TInternalModelFileModel interface {
		Insert(ctx context.Context, data *TInternalModelFile) (int64, error)                                       // 返回的是受影响行数，如需获取自增id，请通过data参数获取
		TxInsert(ctx context.Context, tx *gorm.DB, data *TInternalModelFile) (int64, error)                        // 用于事务新增数据，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
		FindOne(ctx context.Context, id int64) (*TInternalModelFile, error)                                        // 通过主键id查找数据
		FindOneByModelId(ctx context.Context, modelId string) (*TInternalModelFile, error)                         // 通过指定字段查找数据
		FindOneByModelName(ctx context.Context, modelName string) (*TInternalModelFile, error)                     // 通过指定字段查找数据
		Update(ctx context.Context, id int64, data *TInternalModelFile) (int64, error)                             // 通过主键id更新指定字段，零值不可更新，返回受影响行数
		UpdateOneMapById(ctx context.Context, id int64, data map[string]interface{}) (int64, error)                // 通过主键id更新字段，map参数为数据库需要更新的字段，返回受影响行数
		TxUpdateOneMapById(ctx context.Context, tx *gorm.DB, id int64, data map[string]interface{}) (int64, error) // 用于事务更新字段，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
		Delete(ctx context.Context, id int64) (int64, error)                                                       // 通过主键id删除数据，返回受影响行数
		Deletes(ctx context.Context, ids []int64) (int64, error)                                                   // 通过主键id批量删除数据，返回受影响行数

		// add extra method in here
		GetAllData(ctx context.Context) ([]TInternalModelFile, error)
	}

	defaultTInternalModelFileModel struct {
		DbEngin *gorm.DB
		Cache   cache.Cache
	}

	TInternalModelFile struct {
		Id        int64          `db:"id"`         // 自增长ID
		ModelId   string         `db:"model_id"`   // 模型ID，全剧唯一
		ModelName string         `db:"model_name"` // 模型名称，全剧唯一
		Type      string         `db:"type"`       // 模型类型
		ModelPath string         `db:"model_path"` // 模型路径
		ModelMd5  sql.NullString `db:"model_md5"`  // 模型文件md5
		ModelSize int64          `db:"model_size"` // 模型文件大小，单位字节
	}
)

func NewTInternalModelFileModel(conn *gorm.DB, c cache.CacheConf) TInternalModelFileModel {
	return &defaultTInternalModelFileModel{
		// Cache:   cache.New(c, cached.ExclusiveCalls, cached.Stats, sql.ErrNoRows),
		DbEngin: conn,
	}
}

// Insert 返回的是受影响行数，如需获取自增id，请通过data参数获取
func (d *defaultTInternalModelFileModel) Insert(ctx context.Context, data *TInternalModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	result := d.DbEngin.Debug().WithContext(ctx).Create(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// TxInsert // 用于事务新增数据，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
// tx：上层传递时请加上context
func (d *defaultTInternalModelFileModel) TxInsert(ctx context.Context, tx *gorm.DB, data *TInternalModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	result := tx.Debug().WithContext(ctx).Create(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// FindOne 通过主键id查找数据
func (d *defaultTInternalModelFileModel) FindOne(ctx context.Context, id int64) (*TInternalModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", id)

	var result TInternalModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// FindOneByModelId 通过指定字段查找数据
func (d *defaultTInternalModelFileModel) FindOneByModelId(ctx context.Context, modelId string) (*TInternalModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", modelId)

	var result TInternalModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`model_id` = ?", modelId).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// FindOneByModelName 通过指定字段查找数据
func (d *defaultTInternalModelFileModel) FindOneByModelName(ctx context.Context, modelName string) (*TInternalModelFile, error) {
	logx.WithContext(ctx).Infof("data:%+v", modelName)

	var result TInternalModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Where("`model_name` = ?", modelName).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &result, nil
}

// Update 通过主键id更新指定字段，零值不可更新，返回受影响行数
func (d *defaultTInternalModelFileModel) Update(ctx context.Context, id int64, data *TInternalModelFile) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// UpdateOneMapById 通过主键id更新字段，map参数为数据库需要更新的字段，返回受影响行数
func (d *defaultTInternalModelFileModel) UpdateOneMapById(ctx context.Context, id int64, data map[string]interface{}) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := d.DbEngin.Debug().WithContext(ctx).Model(&TInternalModelFile{}).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// TxUpdateOneMapById 用于事务更新字段，由上层(如rpc层)调用Transaction去实现，返回受影响的行数
// tx：上层传递时请加上context
func (d *defaultTInternalModelFileModel) TxUpdateOneMapById(ctx context.Context, tx *gorm.DB, id int64, data map[string]interface{}) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", data)

	if id == 0 {
		return 0, errors.New("invalid param")
	}

	result := tx.Debug().WithContext(ctx).Model(&TInternalModelFile{}).Where("`id` = ?", id).Updates(data)
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// Delete 通过主键id删除数据，返回受影响行数
func (d *defaultTInternalModelFileModel) Delete(ctx context.Context, id int64) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", id)

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` = ?", id).Delete(&TInternalModelFile{})
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// Deletes 通过主键id批量删除数据，返回受影响行数
func (d *defaultTInternalModelFileModel) Deletes(ctx context.Context, ids []int64) (int64, error) {
	logx.WithContext(ctx).Infof("data:%+v", ids)

	result := d.DbEngin.Debug().WithContext(ctx).Where("`id` in ?", ids).Delete(&TInternalModelFile{})
	if result.Error != nil {
		return 0, result.Error
	}

	return result.RowsAffected, nil
}

// GetAllData 获取所有数据
func (d *defaultTInternalModelFileModel) GetAllData(ctx context.Context) ([]TInternalModelFile, error) {

	var result []TInternalModelFile
	err := d.DbEngin.Debug().WithContext(ctx).Find(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}
